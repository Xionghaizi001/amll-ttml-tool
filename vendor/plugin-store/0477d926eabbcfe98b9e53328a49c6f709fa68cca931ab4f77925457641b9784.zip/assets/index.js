import * as e from "react";
import t, { createContext as n, createElement as r, useContext as i, useEffect as a, useRef as o, useState as s, useSyncExternalStore as c } from "react";
import { Fragment as l, jsx as u, jsxs as d } from "react/jsx-runtime";
import { Button as f, Dialog as p, Flex as ee, IconButton as m, Text as h, TextField as g } from "@radix-ui/themes";
// \0rolldown/runtime.js
var _ = Object.create, v = Object.defineProperty, y = Object.getOwnPropertyDescriptor, b = Object.getOwnPropertyNames, te = Object.getPrototypeOf, x = Object.prototype.hasOwnProperty, S = (e, t) => () => (t || (e((t = { exports: {} }).exports, t, t.exports), e = null), t.exports), ne = (e, t, n, r) => {
	if (t && typeof t == "object" || typeof t == "function") for (var i = b(t), a = 0, o = i.length, s; a < o; a++) s = i[a], !x.call(e, s) && s !== n && v(e, s, {
		get: ((e) => t[e]).bind(null, s),
		enumerable: !(r = y(t, s)) || r.enumerable
	});
	return e;
}, re = (e, t, n) => (n = e == null ? {} : _(te(e)), ne(t || !e || !e.__esModule || !x.call(e, "default") ? v(n, "default", {
	value: e,
	enumerable: !0
}) : n, e)), C = typeof window > "u" ? global : window, w = "@griffel/";
function T(e, t) {
	return C[Symbol.for(w + e)] || (C[Symbol.for(w + e)] = t), C[Symbol.for(w + e)];
}
var E = /*#__PURE__*/ T("DEBUG_RESET_CLASSES", {}), D = /*#__PURE__*/ T("DEFINITION_LOOKUP_TABLE", {}), O = "data-make-styles-bucket", ie = "data-priority", ae = "data-container", oe = process.env.NODE_ENV === "production" ? 10 : 18;
// node_modules/.pnpm/@emotion+hash@0.9.2/node_modules/@emotion/hash/dist/emotion-hash.esm.js
function k(e) {
	for (var t = 0, n, r = 0, i = e.length; i >= 4; ++r, i -= 4) n = e.charCodeAt(r) & 255 | (e.charCodeAt(++r) & 255) << 8 | (e.charCodeAt(++r) & 255) << 16 | (e.charCodeAt(++r) & 255) << 24, n = (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16), n ^= n >>> 24, t = (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16) ^ (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
	switch (i) {
		case 3: t ^= (e.charCodeAt(r + 2) & 255) << 16;
		case 2: t ^= (e.charCodeAt(r + 1) & 255) << 8;
		case 1: t ^= e.charCodeAt(r) & 255, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
	}
	return t ^= t >>> 13, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16), ((t ^ t >>> 15) >>> 0).toString(36);
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/utils/hashSequence.js
function A(e) {
	let t = e.length;
	if (t === 7) return e;
	for (let n = t; n < 7; n++) e += "0";
	return e;
}
function se(e, t, n = []) {
	return process.env.NODE_ENV === "production" ? "___" + A(k(e + t)) : "___" + A(k(e + t)) + "_" + A(k(n.join("")));
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/reduceToClassNameForSlots.js
function ce(e, t) {
	let n = "", r = "";
	for (let i in e) {
		let a = e[i];
		if (a === 0) {
			r += i + " ";
			continue;
		}
		let o = Array.isArray(a), s = t === "rtl" ? (o ? a[1] : a) + " " : (o ? a[0] : a) + " ";
		n += s, r += s;
	}
	return [n.slice(0, -1), r.slice(0, -1)];
}
function le(e, t) {
	let n = {};
	for (let r in e) {
		let [i, a] = ce(e[r], t);
		if (a === "") {
			n[r] = "";
			continue;
		}
		let o = se(a, t), s = o + (i === "" ? "" : " " + i);
		D[o] = [e[r], t], n[r] = s;
	}
	return n;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/mergeClasses.js
var j = {};
function ue() {
	let e = null, t = "", n = "", r = Array(arguments.length), i = "";
	for (let e = 0; e < arguments.length; e++) {
		let a = arguments[e];
		if (typeof a == "string" && a !== "") {
			let o = a.indexOf("___");
			if (o === -1) process.env.NODE_ENV !== "production" && a.split(" ").forEach((e) => {
				e.startsWith("r") && E[e] && (i ? console.error(`mergeClasses(): a passed string contains multiple classes produced by makeResetStyles (${a} & ${t}, this will lead to non-deterministic behavior. Learn more:https://griffel.js.org/react/api/make-reset-styles#limitations
Source string: ${a}`) : i = e);
			}), t += a + " ";
			else {
				let i = a.substr(o, oe);
				o > 0 && (t += a.slice(0, o)), n += i, r[e] = i;
			}
			process.env.NODE_ENV !== "production" && a.indexOf("___", o + 1) !== -1 && console.error(`mergeClasses(): a passed string contains multiple identifiers of atomic classes (classes that start with "___"), it's possible that passed classes were concatenated in a wrong way. Source string: ${a}`);
		}
	}
	if (n === "") return t.slice(0, -1);
	let a = j[n];
	if (a !== void 0) return t + a;
	let o = [];
	for (let t = 0; t < arguments.length; t++) {
		let n = r[t];
		if (n) {
			let r = D[n];
			r ? (o.push(r[0]), process.env.NODE_ENV !== "production" && e !== null && e !== r[1] && console.error(`mergeClasses(): a passed string contains an identifier (${n}) that has different direction (dir="${r[1] ? "rtl" : "ltr"}") setting than other classes. This is not supported. Source string: ${arguments[t]}`), e = r[1]) : process.env.NODE_ENV !== "production" && console.error(`mergeClasses(): a passed string contains an identifier (${n}) that does not match any entry in cache. Source string: ${arguments[t]}`);
		}
	}
	let s = Object.assign.apply(Object, [{}].concat(o)), [c, l] = ce(s, e), u = se(l, e, r), d = u + " " + c;
	return j[n] = d, D[u] = [s, e], t + d;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/store.js
var de = {}, M = /* @__PURE__ */ new Set(), N = {
	getChildrenSequences: (e) => {
		let t = Object.keys(j).find((t) => j[t].startsWith(e));
		return t ? t.split("___").filter((e) => e.length).map((e) => "___" + e) : [];
	},
	addCSSRule: (e) => {
		M.add(e);
	},
	addSequenceDetails: (e, t) => {
		Object.entries(e).forEach(([e, n]) => {
			de[n.substring(0, oe)] = {
				slotName: e,
				sourceURL: t
			};
		});
	},
	getCSSRules: () => Array.from(M),
	getSequenceDetails: (e) => de[e]
};
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/utils.js
function P(e, t) {
	return Array.isArray(e) ? t === "rtl" ? e[1] : e[0] : e || "";
}
function fe(e, t, n, r) {
	let i = e[0], a = e[1];
	return Object.entries(i).map(([e, i]) => {
		let o = P(i, a), s;
		if (n && t) {
			let i = n.find(({ className: e }) => e === o);
			!i && t[0][e] ? s = P(t[0][e], t[1]) : i && t[0][e] ? s = r && r.filter(({ debugClassNames: e }) => e.filter(({ className: e }) => e === o).length > 0).length > 0 ? i.className : i.overriddenBy : (!i && !t[0][e] || i && !t[0][e]) && (s = void 0);
		}
		return {
			className: o,
			overriddenBy: s
		};
	});
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getAtomicDebugSequenceTree.js
function F(e, t) {
	let n = D[e];
	if (n === void 0) return;
	let r = fe(n, t ? D[t.sequenceHash] : void 0, t?.debugClassNames, t?.children), i = {
		sequenceHash: e,
		direction: n[1],
		children: [],
		debugClassNames: r
	};
	return N.getChildrenSequences(i.sequenceHash).reverse().forEach((e) => {
		let t = F(e, i);
		t && i.children.push(t);
	}), i.children.length || (i.rules = {}, i.debugClassNames.forEach(({ className: t }) => {
		let n = N.getSequenceDetails(e);
		n && (i.slot = n.slotName, i.sourceURL = n.sourceURL);
		let r = N.getCSSRules().find((e) => e.includes(t));
		i.rules[t] = r;
	})), i;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getResetDebugSequence.js
function pe(e) {
	if (E[e] === void 0) return;
	let t = {
		sequenceHash: e,
		direction: "ltr",
		children: [],
		debugClassNames: [{ className: e }]
	};
	t.rules = {}, t.slot = "makeResetStyles()";
	let [{ className: n }] = t.debugClassNames, r = N.getCSSRules().filter((e) => e.includes(`.${n}`));
	return t.rules[n] = r.join(""), t;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/mergeDebugSequence.js
function me(e, t) {
	let n = e ? F(e) : void 0, r = t ? pe(t) : void 0;
	if (n || r) return n ? r ? {
		sequenceHash: n.sequenceHash + r.sequenceHash,
		direction: n.direction,
		children: [n, r],
		debugClassNames: [...n.debugClassNames, ...r.debugClassNames]
	} : n : r;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/injectDevTools.js
function he(e) {
	let t = e.defaultView;
	if (!t || t.__GRIFFEL_DEVTOOLS__) return;
	let n = { getInfo: (e) => {
		let t, n;
		for (let r of e.classList) r.startsWith("___") && (t = r), E[r] && (n = r);
		return me(t, n);
	} };
	Object.defineProperty(t, "__GRIFFEL_DEVTOOLS__", {
		configurable: !1,
		enumerable: !1,
		get() {
			return n;
		}
	});
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/isDevToolsEnabled.js
var I = (() => {
	try {
		return !!(typeof window < "u" && window.sessionStorage?.getItem("__GRIFFEL_DEVTOOLS__"));
	} catch {
		return !1;
	}
})(), L = "<unknown>";
function ge(e) {
	return be(e) || Ce(e) || Te(e);
}
var _e = /^\s*at (.*?) ?\(((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/|[a-z]:\\|\\\\).*?)?\)?\s*$/i, ve = /^\s*at ()((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/|[a-z]:\\|\\\\).*?)\s*$/i, ye = /\((\S*)\)/;
function be(e) {
	let t = _e.exec(e) || ve.exec(e);
	if (!t) return null;
	let n = t[2], r = n && n.indexOf("native") === 0, i = n && n.indexOf("eval") === 0, a = ye.exec(n);
	return i && a !== null && (n = a[1]), {
		loc: r ? null : t[2],
		name: t[1] || L
	};
}
var xe = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|resource|\[native).*?|[^@]*bundle)\s*$/i, Se = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;
function Ce(e) {
	let t = xe.exec(e);
	if (!t) return null;
	let n = t[3], r = n && n.indexOf(" > eval") > -1, i = Se.exec(n);
	return r && i !== null && (n = i[1]), {
		loc: t[3],
		name: t[1] || L
	};
}
var we = /^\s*(?:([^@]*)(?:\((.*?)\))?@)?(\S.*?)\s*$/i;
function Te(e) {
	let t = we.exec(e);
	return t ? {
		loc: t[3],
		name: t[1] || L
	} : null;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getSourceURLfromError.js
function Ee() {
	let e = De(String((/* @__PURE__ */ Error()).stack).split("\n"));
	return e === void 0 ? void 0 : ge(e)?.loc;
}
function De(e) {
	for (let t = e.length - 1; t >= 0; --t) if (e[t].includes("at getSourceURLfromError")) return e[t + 3];
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/utils/normalizeCSSBucketEntry.js
function Oe(e) {
	if (!Array.isArray(e)) return [e];
	if (process.env.NODE_ENV !== "production" && e.length > 2) throw Error("CSS Bucket contains an entry with greater than 2 items, please report this to https://github.com/microsoft/griffel/issues");
	return e;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/createIsomorphicStyleSheet.js
function ke(e, t, n, r) {
	let i = [];
	if (r[O] = t, r[ie] = String(n), e) for (let t in r) e.setAttribute(t, r[t]);
	function a(t) {
		return e?.sheet ? e.sheet.insertRule(t, e.sheet.cssRules.length) : i.push(t);
	}
	return {
		elementAttributes: r,
		insertRule: a,
		element: e,
		bucketName: t,
		cssRules() {
			return e?.sheet ? Array.from(e.sheet.cssRules).map((e) => e.cssText) : i;
		}
	};
}
var R = /*#__PURE__*/ [
	"r",
	"d",
	"l",
	"v",
	"w",
	"f",
	"i",
	"h",
	"a",
	"s",
	"k",
	"t",
	"m",
	"c",
	"x"
].reduce((e, t, n) => (e[t] = n, e), {});
function Ae(e, t, n) {
	return e === "m" || e === "x" ? e + t + n : e + n;
}
function je(e, t, n, r, i = {}) {
	let a = e === "m", o = e === "x", s = i.m, c = i.x, l = i.p ?? 0, u = Ae(e, c ?? s ?? "0", l);
	if (!r.stylesheets[u]) {
		let d = t && t.createElement("style"), f = ke(d, e, l, {
			...r.styleElementAttributes,
			...a && { media: s },
			...o && { "data-container": c }
		});
		r.stylesheets[u] = f, t?.head && d && t.head.insertBefore(d, Ne(t, n, e, r, i));
	}
	return r.stylesheets[u];
}
function Me(e, t, n) {
	return e.getAttribute("data-make-styles-bucket") === t ? t === "m" ? n.m === e.media : t !== "x" || n.x === e.getAttribute(ae) : !1;
}
function Ne(e, t, n, r, i = {}) {
	let a = R[n], o = i.m ?? "", s = i.x ?? "", c = i.p ?? 0, l = (e) => a - R[e.getAttribute(O)], u = e.head.querySelectorAll(`[${O}]`);
	if (n === "m" || n === "x") {
		let t = e.head.querySelectorAll(`[${O}="${n}"]`);
		t.length && (u = t, l = n === "m" ? (e) => r.compareMediaQueries(o, e.media) : (e) => r.compareContainerQueries(s, e.getAttribute("data-container") ?? ""));
	}
	let d = (e) => Me(e, n, i) ? c - Number(e.getAttribute(ie)) : l(e), f = u.length, p = f - 1;
	for (; p >= 0;) {
		let e = u.item(p);
		if (d(e) > 0) return e.nextSibling;
		p--;
	}
	return f > 0 ? u.item(0) : t ? t.nextSibling : null;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/safeInsertRule.js
var Pe = /*#__PURE__*/ RegExp(":(-moz-placeholder|-moz-focus-inner|-moz-focusring|-ms-input-placeholder|-moz-read-write|-moz-read-only)");
function z(e, t) {
	try {
		e.insertRule(t);
	} catch (e) {
		process.env.NODE_ENV !== "production" && !Pe.test(t) && console.error(`There was a problem inserting the following rule: "${t}"`, e);
	}
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/createDOMRenderer.js
var Fe = 0, Ie = (e, t) => e < t ? -1 : +(e > t);
function Le(e = typeof document > "u" ? void 0 : document, t = {}) {
	let { classNameHashSalt: n, unstable_filterCSSRule: r, insertionPoint: i, styleElementAttributes: a, compareMediaQueries: o = Ie, compareContainerQueries: s = o } = t, c = {
		classNameHashSalt: n,
		insertionCache: {},
		stylesheets: {},
		styleElementAttributes: Object.freeze(a),
		compareMediaQueries: o,
		compareContainerQueries: s,
		id: `d${Fe++}`,
		insertCSSRules(t) {
			for (let n in t) {
				let a = t[n];
				for (let t = 0, o = a.length; t < o; t++) {
					let [o, s] = Oe(a[t]), l = je(n, e, i || null, c, s);
					c.insertionCache[o] || (c.insertionCache[o] = n, process.env.NODE_ENV !== "production" && I && N.addCSSRule(o), r ? r(o) && z(l, o) : z(l, o));
				}
			}
		}
	};
	return e && process.env.NODE_ENV !== "production" && I && he(e), c;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/insertionFactory.js
var Re = () => {
	let e = {};
	return function(t, n) {
		e[t.id] === void 0 && (t.insertCSSRules(n), e[t.id] = !0);
	};
};
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/__styles.js
function ze(e, t, n = Re) {
	let r = n(), i = null, a = null, o;
	process.env.NODE_ENV !== "production" && I && (o = Ee());
	function s(n) {
		let { dir: s, renderer: c } = n, l = s === "ltr";
		l ? i === null && (i = le(e, s)) : a === null && (a = le(e, s)), r(c, t);
		let u = l ? i : a;
		return process.env.NODE_ENV !== "production" && I && N.addSequenceDetails(u, o), u;
	}
	return s;
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/utils/canUseDOM.js
function Be() {
	return typeof window < "u" && !!(window.document && window.document.createElement);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/useInsertionEffect.js
var B = t.useInsertionEffect ? t.useInsertionEffect : void 0, Ve = () => {
	let e = {};
	return function(t, n) {
		B && Be() ? B(() => {
			t.insertCSSRules(n);
		}, [t, n]) : e[t.id] === void 0 && (t.insertCSSRules(n), e[t.id] = !0);
	};
}, He = /*#__PURE__*/ n(/*#__PURE__*/ Le());
function Ue() {
	return i(He);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/TextDirectionContext.js
var We = /*#__PURE__*/ n("ltr");
function Ge() {
	return i(We);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/__styles.js
function V(e, t) {
	let n = ze(e, t, Ve);
	return function() {
		let e = Ge(), t = Ue();
		return n({
			dir: e,
			renderer: t
		});
	};
}
// node_modules/.pnpm/@fluentui+react-icons@2.0.333_react@19.2.7/node_modules/@fluentui/react-icons/lib/utils/useIconStyles.styles.js
var Ke = V({
	root: {
		mc9l5x: "f1w7gpdv",
		Bg96gwp: "fez10in"
	},
	rtl: { Bz10aip: "f13rod7r" }
}, { d: [
	".f1w7gpdv{display:inline;}",
	".fez10in{line-height:0;}",
	".f13rod7r{transform:scaleX(-1);}"
] }), H = e.createContext(void 0), qe = {};
H.Provider;
var Je = () => e.useContext(H) ?? qe, Ye = "fui-Icon", Xe = "data-fui-icon", Ze = (e, t) => {
	let { filled: n, idPrefix: r, title: i, primaryFill: a = "currentColor", ...o } = e, s = {
		...o,
		fill: a
	}, c = Je(), l = !!(t?.flipInRtl && c?.textDirection === "rtl");
	return i && (s["aria-label"] = i), !s["aria-label"] && !s["aria-labelledby"] ? s["aria-hidden"] = !0 : s.role = "img", s[Xe] = "", {
		state: s,
		isRtlFlip: l
	};
}, Qe = (e, t) => {
	let n = Ke(), { state: r, isRtlFlip: i } = Ze(e, t);
	return r.className = ue(n.root, i && n.rtl, r.className), r;
}, $e = V({ root: { B8gzw0y: "f1dd5bof" } }, { m: [["@media (forced-colors: active){.f1dd5bof{forced-color-adjust:auto;}}", { m: "(forced-colors: active)" }]] }), et = "url(#", U = (t, n, r) => {
	let [i, a, ...o] = t, s = a;
	if (r && a) {
		let e = {};
		for (let t in a) {
			let n = a[t];
			if (typeof n != "string") e[t] = n;
			else if (t === "id") e[t] = r + n;
			else {
				let i = n.indexOf(et);
				e[t] = i < 0 ? n : n.slice(0, i + 5) + r + n.slice(i + 5);
			}
		}
		s = e;
	}
	return e.createElement(i, {
		...s,
		key: n
	}, ...o.map((e, t) => U(e, t, r)));
}, tt = (e) => e === "1em" ? "20" : e, nt = (e, t, n) => typeof e != "string" && (t?.color || Array.isArray(e[0])) ? e.map((e, t) => U(e, t, n)) : void 0, rt = () => void 0, it = (t, n) => {
	let r = nt(t, n);
	return r ? function(i) {
		return e.useMemo(() => i ? nt(t, n, i) : r, [i]);
	} : rt;
}, at = (t, n, r) => typeof n == "string" ? e.createElement("svg", {
	...t,
	dangerouslySetInnerHTML: { __html: n }
}) : r ? e.createElement("svg", t, ...r) : e.createElement("svg", t, ...n.map((n) => e.createElement("path", {
	d: n,
	fill: t.fill
}))), W = (t, n, r, i) => {
	let a = tt(n), o = it(r, i), s = e.forwardRef((e, t) => {
		let s = $e(), c = Qe(e, { flipInRtl: i?.flipInRtl }), l = o(e.idPrefix);
		return at({
			...c,
			className: ue(Ye, c.className, s.root),
			ref: t,
			width: n,
			height: n,
			viewBox: `0 0 ${a} ${a}`,
			xmlns: "http://www.w3.org/2000/svg"
		}, r, l);
	});
	return s.displayName = t, s;
}, ot = /*#__PURE__*/ W("TranslateRegular", "1em", ["M4.08 4.22c.7-.21 1.7-.34 2.84 0 1.01.3 1.56.9 1.83 1.56.26.63.26 1.27.26 1.67v5.05a.5.5 0 0 1-1 0v-.53c-.31.19-.67.38-1.05.55-.78.34-1.74.6-2.64.42a2.97 2.97 0 0 1-2.25-2.09c-.29-.97-.08-2.1.8-2.84a4.57 4.57 0 0 1 3.21-1c.71.03 1.38.17 1.93.32 0-.37-.03-.79-.18-1.17-.16-.4-.48-.77-1.19-.98a4.04 4.04 0 0 0-3.15.37h-.01a.5.5 0 0 1-.57-.82h.01l.02-.02a2.45 2.45 0 0 1 .3-.17c.2-.1.48-.22.84-.32ZM6.04 8a3.58 3.58 0 0 0-2.52.77 1.66 1.66 0 0 0-.5 1.79c.2.66.73 1.23 1.5 1.39.6.12 1.33-.04 2.04-.35.58-.26 1.1-.6 1.45-.85V8.37a8.27 8.27 0 0 0-1.97-.36Zm8.43-1.34a.5.5 0 0 0-.94-.34c-.18.5-.37 1.22-.47 1.65-.5.03-1 .03-1.53 0a.5.5 0 1 0-.06 1c.47.02.92.03 1.36 0-.11.58-.2 1.1-.25 1.56a4.71 4.71 0 0 0-2.3 2.3c-.44 1.02-.4 2.17.25 2.85.43.46 1.06.53 1.64.4.42-.1.86-.31 1.28-.61l.08.2a.5.5 0 0 0 .93-.36 8.18 8.18 0 0 0-.23-.53 6.7 6.7 0 0 0 1.68-3.6c.77.26 1.28.8 1.5 1.38.38 1.04-.04 2.55-2.11 3.47a.5.5 0 1 0 .4.92c2.43-1.08 3.26-3.07 2.64-4.73A3.37 3.37 0 0 0 16 10.17V10a.5.5 0 1 0-1 0v.02c-.43-.01-.88.03-1.36.13l.23-1.25a21.3 21.3 0 0 0 2.24-.41.5.5 0 0 0-.22-.98c-.62.15-1.2.27-1.77.35.1-.38.23-.85.35-1.2Zm-3.27 6.57c.23-.52.64-1.06 1.3-1.5-.01.63.04 1.16.13 1.61.1.48.24.87.38 1.2-.38.3-.75.49-1.06.56-.39.09-.6 0-.69-.1-.27-.3-.4-.97-.06-1.77Zm3.73-2.22a5.83 5.83 0 0 1-1.15 2.76l-.17-.62a7.2 7.2 0 0 1-.09-1.94l.13-.04c.46-.12.89-.17 1.28-.16Z"]), st = /*#__PURE__*/ W("Warning48Color", "48", [
	["path", {
		d: "M20.47 6.23a4.25 4.25 0 0 1 7.5.04l15.53 29.5A4.25 4.25 0 0 1 39.74 42H8.26a4.25 4.25 0 0 1-3.74-6.27l15.95-29.5Z",
		fill: "#212121"
	}],
	["path", {
		d: "M20.47 6.23a4.25 4.25 0 0 1 7.5.04l15.53 29.5A4.25 4.25 0 0 1 39.74 42H8.26a4.25 4.25 0 0 1-3.74-6.27l15.95-29.5Z",
		fill: "url(#ic_fluent_warning_48_color__a)"
	}],
	["path", {
		d: "M24 15c.69 0 1.25.56 1.25 1.25v11.5a1.25 1.25 0 1 1-2.5 0v-11.5c0-.69.56-1.25 1.25-1.25Zm0 20a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z",
		fill: "url(#ic_fluent_warning_48_color__b)"
	}],
	[
		"defs",
		null,
		[
			"linearGradient",
			{
				id: "ic_fluent_warning_48_color__a",
				x1: "10.25",
				y1: "-1.94",
				x2: "34.45",
				y2: "46.59",
				gradientUnits: "userSpaceOnUse"
			},
			["stop", { stopColor: "#FFCD0F" }],
			["stop", {
				offset: "1",
				stopColor: "#FE8401"
			}]
		],
		[
			"linearGradient",
			{
				id: "ic_fluent_warning_48_color__b",
				x1: "18.67",
				y1: "15",
				x2: "28.27",
				y2: "35.5",
				gradientUnits: "userSpaceOnUse"
			},
			["stop", { stopColor: "#4A4A4A" }],
			["stop", {
				offset: "1",
				stopColor: "#242424"
			}]
		]
	]
], { color: !0 }), ct = /*#__PURE__*/ W("Add20Regular", "20", ["M10 2.5c.28 0 .5.22.5.5v6.5H17a.5.5 0 0 1 0 1h-6.5V17a.5.5 0 0 1-1 0v-6.5H3a.5.5 0 0 1 0-1h6.5V3c0-.28.22-.5.5-.5Z"]), lt = /* @__PURE__ */ re((/* @__PURE__ */ S(((e, t) => {
	(function() {
		var e = {}.hasOwnProperty;
		function n() {
			for (var e = "", t = 0; t < arguments.length; t++) {
				var n = arguments[t];
				n && (e = i(e, r(n)));
			}
			return e;
		}
		function r(t) {
			if (typeof t == "string" || typeof t == "number") return t;
			if (typeof t != "object") return "";
			if (Array.isArray(t)) return n.apply(null, t);
			if (t.toString !== Object.prototype.toString && !t.toString.toString().includes("[native code]")) return t.toString();
			var r = "";
			for (var a in t) e.call(t, a) && t[a] && (r = i(r, a));
			return r;
		}
		function i(e, t) {
			return t ? e ? e + " " + t : e + t : e;
		}
		t !== void 0 && t.exports ? (n.default = n, t.exports = n) : typeof define == "function" && typeof define.amd == "object" && define.amd ? define("classnames", [], function() {
			return n;
		}) : window.classNames = n;
	})();
})))(), 1);
function G(e) {
	return e === null ? "null" : e === Object(e) ? {}.toString.call(e).slice(8, -1).toLowerCase() : typeof e;
}
function K(e) {
	return G(e) !== "string" || !e.length;
}
function ut(e = "", t, n) {
	if (K(e)) return !1;
	let r = e.charCodeAt(0);
	return t <= r && r <= n;
}
var dt = {
	HIRAGANA: "toHiragana",
	KATAKANA: "toKatakana"
}, ft = { HEPBURN: "hepburn" }, pt = {
	useObsoleteKana: !1,
	passRomaji: !1,
	convertLongVowelMark: !0,
	upcaseKatakana: !1,
	IMEMode: !1,
	romanization: ft.HEPBURN
}, mt = 65, ht = 90, gt = 12353, _t = 12438, vt = 12540, yt = 12539, bt = [65281, 65295], xt = [65306, 65311], St = [65339, 65343], Ct = [65371, 65376], wt = [65504, 65518], Tt = [12352, 12447], Et = [12448, 12543], Dt = [65382, 65439], Ot = [12539, 12540], kt = [65377, 65381], At = [12288, 12351], jt = [
	Tt,
	Et,
	kt,
	Dt
], Mt = [
	At,
	kt,
	Ot,
	bt,
	xt,
	St,
	Ct,
	wt
];
[...jt, ...Mt];
var Nt = [
	[256, 257],
	[274, 275],
	[298, 299],
	[332, 333],
	[362, 363]
], Pt = [[8216, 8217], [8220, 8221]];
[...Nt], [...Pt];
var Ft = Number.isNaN || function(e) {
	return typeof e == "number" && e !== e;
};
function It(e, t) {
	return !!(e === t || Ft(e) && Ft(t));
}
function Lt(e, t) {
	if (e.length !== t.length) return !1;
	for (var n = 0; n < e.length; n++) if (!It(e[n], t[n])) return !1;
	return !0;
}
function Rt(e, t) {
	t === void 0 && (t = Lt);
	var n = null;
	function r() {
		var r = [...arguments];
		if (n && n.lastThis === this && t(r, n.lastArgs)) return n.lastResult;
		var i = e.apply(this, r);
		return n = {
			lastResult: i,
			lastArgs: r,
			lastThis: this
		}, i;
	}
	return r.clear = function() {
		n = null;
	}, r;
}
var zt = Object.prototype.hasOwnProperty;
function Bt(e, t, n) {
	for (n of e.keys()) if (q(n, t)) return n;
}
function q(e, t) {
	var n, r, i;
	if (e === t) return !0;
	if (e && t && (n = e.constructor) === t.constructor) {
		if (n === Date) return e.getTime() === t.getTime();
		if (n === RegExp) return e.toString() === t.toString();
		if (n === Array) {
			if ((r = e.length) === t.length) for (; r-- && q(e[r], t[r]););
			return r === -1;
		}
		if (n === Set) {
			if (e.size !== t.size) return !1;
			for (r of e) if (i = r, i && typeof i == "object" && (i = Bt(t, i), !i) || !t.has(i)) return !1;
			return !0;
		}
		if (n === Map) {
			if (e.size !== t.size) return !1;
			for (r of e) if (i = r[0], i && typeof i == "object" && (i = Bt(t, i), !i) || !q(r[1], t.get(i))) return !1;
			return !0;
		}
		if (n === ArrayBuffer) e = new Uint8Array(e), t = new Uint8Array(t);
		else if (n === DataView) {
			if ((r = e.byteLength) === t.byteLength) for (; r-- && e.getInt8(r) === t.getInt8(r););
			return r === -1;
		}
		if (ArrayBuffer.isView(e)) {
			if ((r = e.byteLength) === t.byteLength) for (; r-- && e[r] === t[r];);
			return r === -1;
		}
		if (!n || typeof e == "object") {
			for (n in r = 0, e) if (zt.call(e, n) && ++r && !zt.call(t, n) || !(n in t) || !q(e[n], t[n])) return !1;
			return Object.keys(t).length === r;
		}
	}
	return e !== e && t !== t;
}
var Vt = (e = {}) => Object.assign({}, pt, e);
function Ht(e, t, n) {
	let r = t;
	function i(e, t) {
		if (e[t] !== void 0) return Object.assign({ "": e[""] + t }, e[t]);
	}
	function a(e, t) {
		let n = e.charAt(0);
		return o(Object.assign({ "": n }, r[n]), e.slice(1), t, t + 1);
	}
	function o(e, t, r, s) {
		if (!t) return n || Object.keys(e).length === 1 ? e[""] ? [[
			r,
			s,
			e[""]
		]] : [] : [[
			r,
			s,
			null
		]];
		if (Object.keys(e).length === 1) return [[
			r,
			s,
			e[""]
		]].concat(a(t, s));
		let c = i(e, t.charAt(0));
		return c === void 0 ? [[
			r,
			s,
			e[""]
		]].concat(a(t, s)) : o(c, t.slice(1), r, s + 1);
	}
	return a(e, 0);
}
function J(e) {
	return Object.entries(e).reduce((e, [t, n]) => (e[t] = G(n) === "string" ? { "": n } : J(n), e), {});
}
function Ut(e, t) {
	return t.split("").reduce((e, t) => (e[t] === void 0 && (e[t] = {}), e[t]), e);
}
function Wt(e = {}) {
	let t = {};
	return G(e) === "object" && Object.entries(e).forEach(([e, n]) => {
		let r = t;
		e.split("").forEach((e) => {
			r[e] === void 0 && (r[e] = {}), r = r[e];
		}), r[""] = n;
	}), function(e) {
		let n = JSON.parse(JSON.stringify(e));
		function r(e, t) {
			return e === void 0 || G(e) === "string" ? t : Object.entries(t).reduce((t, [n, i]) => (t[n] = r(e[n], i), t), e);
		}
		return r(n, t);
	};
}
function Gt(e, t) {
	return t ? G(t) === "function" ? t(e) : Wt(t)(e) : e;
}
var Kt = {
	a: "あ",
	i: "い",
	u: "う",
	e: "え",
	o: "お",
	k: {
		a: "か",
		i: "き",
		u: "く",
		e: "け",
		o: "こ"
	},
	s: {
		a: "さ",
		i: "し",
		u: "す",
		e: "せ",
		o: "そ"
	},
	t: {
		a: "た",
		i: "ち",
		u: "つ",
		e: "て",
		o: "と"
	},
	n: {
		a: "な",
		i: "に",
		u: "ぬ",
		e: "ね",
		o: "の"
	},
	h: {
		a: "は",
		i: "ひ",
		u: "ふ",
		e: "へ",
		o: "ほ"
	},
	m: {
		a: "ま",
		i: "み",
		u: "む",
		e: "め",
		o: "も"
	},
	y: {
		a: "や",
		u: "ゆ",
		o: "よ"
	},
	r: {
		a: "ら",
		i: "り",
		u: "る",
		e: "れ",
		o: "ろ"
	},
	w: {
		a: "わ",
		i: "ゐ",
		e: "ゑ",
		o: "を"
	},
	g: {
		a: "が",
		i: "ぎ",
		u: "ぐ",
		e: "げ",
		o: "ご"
	},
	z: {
		a: "ざ",
		i: "じ",
		u: "ず",
		e: "ぜ",
		o: "ぞ"
	},
	d: {
		a: "だ",
		i: "ぢ",
		u: "づ",
		e: "で",
		o: "ど"
	},
	b: {
		a: "ば",
		i: "び",
		u: "ぶ",
		e: "べ",
		o: "ぼ"
	},
	p: {
		a: "ぱ",
		i: "ぴ",
		u: "ぷ",
		e: "ぺ",
		o: "ぽ"
	},
	v: {
		a: "ゔぁ",
		i: "ゔぃ",
		u: "ゔ",
		e: "ゔぇ",
		o: "ゔぉ"
	}
}, qt = {
	".": "。",
	",": "、",
	":": "：",
	"/": "・",
	"!": "！",
	"?": "？",
	"~": "〜",
	"-": "ー",
	"‘": "「",
	"’": "」",
	"“": "『",
	"”": "』",
	"[": "［",
	"]": "］",
	"(": "（",
	")": "）",
	"{": "｛",
	"}": "｝"
}, Jt = {
	k: "き",
	s: "し",
	t: "ち",
	n: "に",
	h: "ひ",
	m: "み",
	r: "り",
	g: "ぎ",
	z: "じ",
	d: "ぢ",
	b: "び",
	p: "ぴ",
	v: "ゔ",
	q: "く",
	f: "ふ"
}, Yt = {
	ya: "ゃ",
	yi: "ぃ",
	yu: "ゅ",
	ye: "ぇ",
	yo: "ょ"
}, Xt = {
	a: "ぁ",
	i: "ぃ",
	u: "ぅ",
	e: "ぇ",
	o: "ぉ"
}, Zt = {
	sh: "sy",
	ch: "ty",
	cy: "ty",
	chy: "ty",
	shy: "sy",
	j: "zy",
	jy: "zy",
	shi: "si",
	chi: "ti",
	tsu: "tu",
	ji: "zi",
	fu: "hu"
}, Qt = Object.assign({
	tu: "っ",
	wa: "ゎ",
	ka: "ヵ",
	ke: "ヶ"
}, Xt, Yt), $t = {
	yi: "い",
	wu: "う",
	ye: "いぇ",
	wi: "うぃ",
	we: "うぇ",
	kwa: "くぁ",
	whu: "う",
	tha: "てゃ",
	thu: "てゅ",
	tho: "てょ",
	dha: "でゃ",
	dhu: "でゅ",
	dho: "でょ"
}, en = {
	wh: "う",
	kw: "く",
	qw: "く",
	q: "く",
	gw: "ぐ",
	sw: "す",
	ts: "つ",
	th: "て",
	tw: "と",
	dh: "で",
	dw: "ど",
	fw: "ふ",
	f: "ふ"
};
function tn() {
	let e = J(Kt), t = (t) => Ut(e, t);
	Object.entries(Jt).forEach(([e, n]) => {
		Object.entries(Yt).forEach(([r, i]) => {
			t(e + r)[""] = n + i;
		});
	}), Object.entries(qt).forEach(([e, n]) => {
		t(e)[""] = n;
	}), Object.entries(en).forEach(([e, n]) => {
		Object.entries(Xt).forEach(([r, i]) => {
			let a = t(e + r);
			a[""] = n + i;
		});
	}), [
		"n",
		"n'",
		"xn"
	].forEach((e) => {
		t(e)[""] = "ん";
	}), e.c = JSON.parse(JSON.stringify(e.k)), Object.entries(Zt).forEach(([e, n]) => {
		let r = e.slice(0, e.length - 1), i = e.charAt(e.length - 1), a = t(r);
		a[i] = JSON.parse(JSON.stringify(t(n)));
	});
	function n(e) {
		return [...Object.entries(Zt), ["c", "k"]].reduce((t, [n, r]) => e.startsWith(r) ? t.concat(e.replace(r, n)) : t, []);
	}
	Object.entries(Qt).forEach(([e, r]) => {
		let i = (e) => e.charAt(e.length - 1), a = (e) => e.slice(0, e.length - 1), o = `x${e}`, s = t(o);
		s[""] = r;
		let c = t(`l${a(e)}`);
		c[i(e)] = s, n(e).forEach((n) => {
			["l", "x"].forEach((r) => {
				let o = t(r + a(n));
				o[i(n)] = t(r + e);
			});
		});
	}), Object.entries($t).forEach(([e, n]) => {
		t(e)[""] = n;
	});
	function r(e) {
		return Object.entries(e).reduce((e, [t, n]) => (e[t] = t ? r(n) : `っ${n}`, e), {});
	}
	return [
		...Object.keys(Jt),
		"c",
		"y",
		"w",
		"j"
	].forEach((t) => {
		let n = e[t];
		n[t] = r(n);
	}), delete e.n.n, Object.freeze(JSON.parse(JSON.stringify(e)));
}
var nn = null;
function rn() {
	return nn ??= tn(), nn;
}
var an = Wt({
	wi: "ゐ",
	we: "ゑ"
});
function on(e) {
	let t = JSON.parse(JSON.stringify(e));
	return t.n.n = { "": "ん" }, t.n[" "] = { "": "ん" }, t;
}
function sn(e = "") {
	return !K(e) && ut(e, mt, ht);
}
function cn(e = "") {
	return !K(e) && e.charCodeAt(0) === vt;
}
function ln(e = "") {
	return !K(e) && e.charCodeAt(0) === yt;
}
function un(e = "") {
	return K(e) ? !1 : cn(e) ? !0 : ut(e, gt, _t);
}
function dn(e = "") {
	let t = [];
	return e.split("").forEach((e) => {
		if (cn(e) || ln(e)) t.push(e);
		else if (un(e)) {
			let n = e.charCodeAt(0) + 96, r = String.fromCharCode(n);
			t.push(r);
		} else t.push(e);
	}), t.join("");
}
var fn = Rt((e, t, n) => {
	let r = rn();
	return r = e ? on(r) : r, r = t ? an(r) : r, n && (r = Gt(r, n)), r;
}, q);
function pn(e = "", t = {}, n) {
	let r;
	return n ? r = t : (r = Vt(t), n = fn(r.IMEMode, r.useObsoleteKana, r.customKanaMapping)), mn(e, r, n).map((t) => {
		let [n, i, a] = t;
		if (a === null) return e.slice(n);
		let o = r.IMEMode === dt.HIRAGANA, s = r.IMEMode === dt.KATAKANA || [...e.slice(n, i)].every(sn);
		return o || !s ? a : dn(a);
	}).join("");
}
function mn(e = "", t = {}, n) {
	let { IMEMode: r, useObsoleteKana: i, customKanaMapping: a } = t;
	return n ||= fn(r, i, a), Ht(e.toLowerCase(), n, !r);
}
var hn = null, gn = {
	あ: "a",
	い: "i",
	う: "u",
	え: "e",
	お: "o",
	か: "ka",
	き: "ki",
	く: "ku",
	け: "ke",
	こ: "ko",
	さ: "sa",
	し: "shi",
	す: "su",
	せ: "se",
	そ: "so",
	た: "ta",
	ち: "chi",
	つ: "tsu",
	て: "te",
	と: "to",
	な: "na",
	に: "ni",
	ぬ: "nu",
	ね: "ne",
	の: "no",
	は: "ha",
	ひ: "hi",
	ふ: "fu",
	へ: "he",
	ほ: "ho",
	ま: "ma",
	み: "mi",
	む: "mu",
	め: "me",
	も: "mo",
	ら: "ra",
	り: "ri",
	る: "ru",
	れ: "re",
	ろ: "ro",
	や: "ya",
	ゆ: "yu",
	よ: "yo",
	わ: "wa",
	ゐ: "wi",
	ゑ: "we",
	を: "wo",
	ん: "n",
	が: "ga",
	ぎ: "gi",
	ぐ: "gu",
	げ: "ge",
	ご: "go",
	ざ: "za",
	じ: "ji",
	ず: "zu",
	ぜ: "ze",
	ぞ: "zo",
	だ: "da",
	ぢ: "ji",
	づ: "zu",
	で: "de",
	ど: "do",
	ば: "ba",
	び: "bi",
	ぶ: "bu",
	べ: "be",
	ぼ: "bo",
	ぱ: "pa",
	ぴ: "pi",
	ぷ: "pu",
	ぺ: "pe",
	ぽ: "po",
	ゔぁ: "va",
	ゔぃ: "vi",
	ゔ: "vu",
	ゔぇ: "ve",
	ゔぉ: "vo"
}, _n = {
	"。": ".",
	"、": ",",
	"：": ":",
	"・": "/",
	"！": "!",
	"？": "?",
	"〜": "~",
	ー: "-",
	"「": "‘",
	"」": "’",
	"『": "“",
	"』": "”",
	"［": "[",
	"］": "]",
	"（": "(",
	"）": ")",
	"｛": "{",
	"｝": "}",
	"　": " "
}, vn = [
	"あ",
	"い",
	"う",
	"え",
	"お",
	"や",
	"ゆ",
	"よ"
], Y = {
	ゃ: "ya",
	ゅ: "yu",
	ょ: "yo"
}, yn = {
	ぃ: "yi",
	ぇ: "ye"
}, bn = {
	ぁ: "a",
	ぃ: "i",
	ぅ: "u",
	ぇ: "e",
	ぉ: "o"
}, xn = [
	"き",
	"に",
	"ひ",
	"み",
	"り",
	"ぎ",
	"び",
	"ぴ",
	"ゔ",
	"く",
	"ふ"
], Sn = {
	し: "sh",
	ち: "ch",
	じ: "j",
	ぢ: "j"
}, Cn = {
	っ: "",
	ゃ: "ya",
	ゅ: "yu",
	ょ: "yo",
	ぁ: "a",
	ぃ: "i",
	ぅ: "u",
	ぇ: "e",
	ぉ: "o"
}, wn = {
	b: "b",
	c: "t",
	d: "d",
	f: "f",
	g: "g",
	h: "h",
	j: "j",
	k: "k",
	m: "m",
	p: "p",
	q: "q",
	r: "r",
	s: "s",
	t: "t",
	v: "v",
	w: "w",
	x: "x",
	z: "z"
};
function Tn() {
	return hn ??= Dn(), hn;
}
function En(e) {
	switch (e) {
		case ft.HEPBURN: return Tn();
		default: return {};
	}
}
function Dn() {
	let e = J(gn), t = (t) => Ut(e, t), n = (e, n) => {
		t(e)[""] = n;
	};
	return Object.entries(_n).forEach(([e, n]) => {
		t(e)[""] = n;
	}), [...Object.entries(Y), ...Object.entries(bn)].forEach(([e, t]) => {
		n(e, t);
	}), xn.forEach((e) => {
		let r = t(e)[""][0];
		Object.entries(Y).forEach(([t, i]) => {
			n(e + t, r + i);
		}), Object.entries(yn).forEach(([t, i]) => {
			n(e + t, r + i);
		});
	}), Object.entries(Sn).forEach(([e, t]) => {
		Object.entries(Y).forEach(([r, i]) => {
			n(e + r, t + i[1]);
		}), n(`${e}ぃ`, `${t}yi`), n(`${e}ぇ`, `${t}e`);
	}), e.っ = On(e), Object.entries(Cn).forEach(([e, t]) => {
		n(e, t);
	}), vn.forEach((e) => {
		n(`ん${e}`, `n'${t(e)[""]}`);
	}), Object.freeze(JSON.parse(JSON.stringify(e)));
}
function On(e) {
	return Object.entries(e).reduce((e, [t, n]) => {
		if (t) e[t] = On(n);
		else {
			let r = n.charAt(0);
			e[t] = Object.keys(wn).includes(r) ? wn[r] + n : n;
		}
		return e;
	}, {});
}
Rt((e, t) => {
	let n = En(e);
	return t && (n = Gt(n, t)), n;
}, q);
// src/ruby-generator.ts
var kn = /* @__PURE__ */ new Set(/* @__PURE__ */ "きゃ.きゅ.きょ.ぎゃ.ぎゅ.ぎょ.キャ.キュ.キョ.ギャ.ギュ.ギョ.しゃ.しゅ.しょ.じゃ.じゅ.じょ.ちゃ.ちゅ.ちょ.にゃ.にゅ.にょ.ひゃ.ひゅ.ひょ.びゃ.びゅ.びょ.ぴゃ.ぴゅ.ぴょ.みゃ.みゅ.みょ.りゃ.りゅ.りょ.じょ".split(".")), X = (e, t) => t.map((t) => ({
	text: t,
	startTime: e.startTime,
	endTime: e.endTime
})), An = (e) => pn(e).trim(), jn = (e) => /\p{Script=Latin}/u.test(e), Mn = (e) => {
	let t = e.toLowerCase();
	return t === "t" || t === "s" ? "っ" : e;
}, Nn = (e, t) => {
	let n = (e.romanText ?? "").trim();
	if (!n || t(e.text) || jn(e.text)) return;
	let r = An(n);
	if (!r) return;
	let i = r.replace(/\s+/g, "");
	if (!i) return;
	for (let t of kn) if (i.includes(t)) return X(e, [i]);
	let a = Array.from(i).map((e) => Mn(e)).filter((e) => e.trim() !== "");
	if (a.length !== 0) return X(e, a);
};
// src/edits.ts
function Z(e, t, n, r) {
	if (!t.length) return !0;
	let i = e.document.applyEdit(t, n, { expectedRevision: r });
	return i.ok || e.ui.notify({
		level: "error",
		message: e.i18n.t("editFailed"),
		detail: i.error.message
	}), i.ok;
}
function Q(e, t, n, r) {
	let i = e.document.readSnapshot(), a = i.lines.flatMap((e) => e.words).find((e) => e.id === t);
	return a ? (n(a), Z(e, [{
		op: "updateWord",
		wordId: t,
		patch: { ruby: a.ruby ?? null }
	}], r, i.revision)) : !1;
}
function Pn(e, t) {
	e.ruby?.[t] && (e.ruby.splice(t, 1), e.ruby.length || delete e.ruby);
}
function Fn(e, t) {
	let n = e.ruby?.[t - 1], r = e.ruby?.[t];
	n && r && (n.text += r.text, n.startTime = Math.min(n.startTime, r.startTime), n.endTime = Math.max(n.endTime, r.endTime), e.ruby?.splice(t, 1));
}
function In(e, t, n) {
	if (e.endsWith("|")) return {
		text: e.slice(0, -1),
		...t.ruby ? {} : { ruby: n === "insert" ? [{
			text: "",
			startTime: t.startTime,
			endTime: t.endTime
		}] : [] }
	};
}
function Ln(e) {
	let t = e.document.readSnapshot(), n = new Set(e.selection.get().lineIds), r = [];
	for (let i of t.lines) if (!n.size || n.has(i.id)) for (let t of i.words) {
		if (t.ruby?.length) continue;
		let n = Nn(t, e.segmentation.isKanaOnly);
		n?.length && r.push({
			op: "updateWord",
			wordId: t.id,
			patch: { ruby: n }
		});
	}
	return Z(e, r, "Generate lyric ruby", t.revision);
}
async function Rn(e, t) {
	let n = e.document.readSnapshot(), r = n.lines.flatMap((e) => e.words), i = r.find((e) => e.id === t);
	if (!i?.ruby?.length) return;
	let a = [];
	for (let t of r) {
		if (t.text !== i.text) continue;
		let n = await e.segmentation.segmentText(t, i.ruby.map((e) => e.text));
		n.length && a.push({
			op: "updateWord",
			wordId: t.id,
			patch: { ruby: n }
		});
	}
	return Z(e, a, "Apply lyric word ruby segments", n.revision);
}
async function zn(e) {
	let t = e.document.readSnapshot(), n = new Set(e.selection.get().wordIds), r = [];
	for (let i of t.lines) for (let t of i.words) {
		if (n.size && !n.has(t.id) || !t.ruby?.length) continue;
		let i = [];
		for (let n of t.ruby) {
			let r = n.text.split("|");
			for (let a = 0; a < r.length; a++) {
				let o = {
					text: r[a],
					startTime: a === 0 ? n.startTime : t.startTime,
					endTime: a === 0 ? n.endTime : t.endTime
				}, s = await e.segmentation.segmentText(o);
				i.push(...s.length ? s : [o]);
			}
		}
		r.push({
			op: "updateWord",
			wordId: t.id,
			patch: { ruby: i }
		});
	}
	return Z(e, r, "Segment lyric ruby", t.revision);
}
async function Bn(e, t) {
	try {
		await t();
	} catch (t) {
		e.ui.notify({
			level: "error",
			message: e.i18n.t("editFailed"),
			detail: String(t)
		});
	}
}
// src/styles.ts
var $ = {
	rubyEditor: "amll-ruby-rubyEditor",
	rubyEditorCompact: "amll-ruby-rubyEditorCompact",
	autoSizeInput: "amll-ruby-autoSizeInput",
	autoSizeInputText: "amll-ruby-autoSizeInputText",
	autoSizeInputField: "amll-ruby-autoSizeInputField"
}, Vn = ".amll-ruby-rubyEditor {\n	display: inline-flex;\n	align-items: center;\n	gap: var(--space-2);\n}\n\n.amll-ruby-rubyEditorCompact {\n	gap: 0.25em;\n}\n\n.amll-ruby-autoSizeInput {\n	position: relative;\n	display: inline-block;\n	min-width: 6ch;\n}\n\n.amll-ruby-autoSizeInputText {\n	visibility: hidden;\n	white-space: pre;\n	font: inherit;\n	line-height: inherit;\n	padding: var(--space-1) var(--space-2);\n}\n\n.amll-ruby-autoSizeInputField {\n	position: absolute;\n	inset: 0;\n	width: 100%;\n	height: 100%;\n}", Hn = ({ value: e, className: t, style: n, placeholder: r, inputRef: i, ...a }) => {
	let o = e == null ? "" : String(e), s = o.length > 0 ? o : typeof r == "string" && r.length > 0 ? r : "    ";
	return /* @__PURE__ */ d("span", {
		className: (0, lt.default)($.autoSizeInput, t),
		style: n,
		children: [/* @__PURE__ */ u("span", {
			className: $.autoSizeInputText,
			children: s
		}), /* @__PURE__ */ u(g.Root, {
			className: $.autoSizeInputField,
			value: e,
			placeholder: r,
			ref: i,
			...a
		})]
	});
}, Un = ({ word: e, layout: t, host: n, warnedProjects: r }) => {
	c((e) => {
		let t = n.i18n.onLocaleChanged(e);
		return () => t.dispose();
	}, () => n.i18n.locale, () => n.i18n.locale);
	let i = e.ruby ?? [], g = t === "advanced", _ = o([]), v = o(void 0), [y, b] = s(!1), [te, x] = s(!1);
	a(() => () => {
		v.current !== void 0 && cancelAnimationFrame(v.current);
	}, []);
	let S = (e, t) => {
		v.current !== void 0 && cancelAnimationFrame(v.current), v.current = requestAnimationFrame(() => {
			let n = _.current[e];
			n?.focus(), t !== void 0 && n?.setSelectionRange(t, t);
		});
	}, ne = () => {
		let t = n.project.getInfo().projectId;
		r.has(t) || (r.add(t), n.document.readSnapshot().lines.some((e) => e.words.some((e) => e.ruby?.length)) || b(!0));
		let i = 0;
		Q(n, e.id, (e) => {
			i = e.ruby?.length ?? 0, e.ruby ??= [], e.ruby.push({
				text: "",
				startTime: e.startTime,
				endTime: e.endTime
			});
		}, "Add ruby word") && S(i);
	}, re = (t, r) => Q(n, e.id, (e) => {
		e.ruby?.[t] && (e.ruby[t].text = r);
	}, "Edit ruby word"), C = (t) => {
		Q(n, e.id, (e) => Pn(e, t), "Remove ruby word") && t > 0 && S(t - 1);
	}, w = (t) => {
		let r = 0;
		Q(n, e.id, (e) => {
			Fn(e, t), r = e.ruby?.[t - 1]?.text.length ?? 0;
		}, "Merge ruby words") && S(t - 1, r);
	};
	return !g && i.length === 0 ? null : /* @__PURE__ */ d(l, { children: [
		/* @__PURE__ */ u("style", { children: Vn }),
		/* @__PURE__ */ u(p.Root, {
			open: y,
			onOpenChange: b,
			children: /* @__PURE__ */ u(p.Content, {
				style: {
					position: "fixed",
					inset: 0,
					width: "100vw",
					height: "100vh",
					maxWidth: "100vw",
					maxHeight: "100vh",
					borderRadius: 0,
					padding: 0,
					background: "transparent"
				},
				children: /* @__PURE__ */ u(ee, {
					direction: "column",
					align: "center",
					justify: "center",
					height: "100%",
					style: {
						backdropFilter: "blur(10px)",
						background: "rgba(0, 0, 0, 0.35)",
						padding: "var(--space-6)"
					},
					children: /* @__PURE__ */ d(ee, {
						direction: "column",
						align: "center",
						justify: "center",
						gap: "4",
						style: {
							background: "var(--color-panel)",
							borderRadius: "var(--radius-4)",
							padding: "var(--space-6)",
							maxWidth: "720px",
							width: "min(90vw, 720px)",
							boxShadow: "0 24px 48px rgba(0, 0, 0, 0.2)"
						},
						children: [
							/* @__PURE__ */ u(st, {}),
							/* @__PURE__ */ d(p.Title, {
								size: "5",
								children: [
									n.i18n.t("warningPrefix"),
									/* @__PURE__ */ d(h, {
										as: "span",
										weight: "bold",
										children: [
											" ",
											n.i18n.t("ruby"),
											" "
										]
									}),
									n.i18n.t("warningSuffix")
								]
							}),
							/* @__PURE__ */ u(h, {
								size: "4",
								align: "center",
								children: n.i18n.t("warningBody")
							}),
							/* @__PURE__ */ u(h, {
								size: "4",
								align: "center",
								children: n.i18n.t("warningDetails")
							}),
							/* @__PURE__ */ u(p.Close, { children: /* @__PURE__ */ u(f, { children: n.i18n.t("understood") }) })
						]
					})
				})
			})
		}),
		/* @__PURE__ */ d("span", {
			className: (0, lt.default)($.rubyEditor, g && $.rubyEditorCompact),
			children: [
				g && /* @__PURE__ */ u(m, {
					size: "1",
					variant: "soft",
					disabled: te,
					"aria-label": n.i18n.t("applyAll"),
					onClick: async () => {
						x(!0);
						try {
							await Bn(n, () => Rn(n, e.id));
						} finally {
							x(!1);
						}
					},
					children: /* @__PURE__ */ u(ot, {})
				}),
				i.map((t, r) => /* @__PURE__ */ u(Hn, {
					size: "1",
					"aria-label": n.i18n.t("rubyInput", { index: r + 1 }),
					inputRef: (e) => {
						_.current[r] = e;
					},
					value: t.text,
					onChange: (e) => re(r, e.currentTarget.value),
					onKeyDown: (e) => {
						if (e.key !== "Backspace") return;
						let t = e.currentTarget.selectionStart ?? 0, n = e.currentTarget.selectionEnd ?? 0;
						t === 0 && n === 0 && r > 0 ? (e.preventDefault(), w(r)) : e.currentTarget.value === "" && (e.preventDefault(), C(r));
					}
				}, `${e.id}-ruby-${r}`)),
				/* @__PURE__ */ u(m, {
					size: "1",
					variant: "soft",
					"aria-label": n.i18n.t("add"),
					onClick: ne,
					children: /* @__PURE__ */ u(ct, {})
				})
			]
		})
	] });
}, Wn = {
	title: {
		default: "Ruby editor",
		"zh-CN": "注音编辑器"
	},
	add: {
		default: "Add Ruby",
		"zh-CN": "添加注音"
	},
	applyAll: {
		default: "Apply to matching words",
		"zh-CN": "应用到所有相同单词"
	},
	rubyInput: {
		default: "Ruby {index}",
		"zh-CN": "注音 {index}"
	},
	editFailed: {
		default: "Could not edit Ruby",
		"zh-CN": "注音修改失败"
	},
	segment: {
		"cs-CZ": "Ruby Segmentation",
		"da-DK": "Ruby Segmentating",
		"en-US": "Ruby Segmentation",
		"es-ES": "Segmentación Ruby",
		"fr-FR": "Ruby Segmentation",
		"id-ID": "Segmentasi Furigana/Ruby",
		"pl-PL": "Ruby Segmentation",
		"pt-BR": "Ruby Segmentation",
		"ru-RU": "Ruby Segmentation",
		"sk-SK": "Ruby Segmentation",
		"zh-CN": "注音分词",
		default: "Ruby Segmentation"
	},
	generate: {
		"en-US": "Auto Ruby",
		"id-ID": "Anotasi Ruby Otomatis",
		"zh-CN": "自动注音",
		default: "Auto Ruby"
	},
	warningPrefix: {
		default: "You are using the experimental",
		"zh-CN": "你正在使用测试中的"
	},
	ruby: {
		default: "Ruby",
		"zh-CN": "注音"
	},
	warningSuffix: {
		default: "feature",
		"zh-CN": "功能"
	},
	warningBody: {
		default: "After adding Ruby, saved files require a parser that supports this structure.",
		"zh-CN": "一旦你添加了注音内容，保存的文件将无法被不支持该结构的解析器使用"
	},
	warningDetails: {
		default: "Unsupported parsers may omit text or display it incorrectly.",
		"zh-CN": "如果仍要在不支持的解析器中使用，可能会出现缺少文字等现象"
	},
	understood: {
		default: "I understand",
		"zh-CN": "我已了解"
	}
};
// src/plugin.ts
function Gn({ host: e }) {
	let t = /* @__PURE__ */ new Set();
	e.views.registerView({
		id: "builtin.ruby.word-editor",
		kind: "word-editor",
		title: Wn.title,
		view: (n) => r(Un, {
			...n,
			host: e,
			warnedProjects: t
		}),
		transformTextInput: In
	});
	for (let [t, n] of [["generate", Ln], ["segment", zn]]) {
		let r = `builtin.ruby.${t}`;
		e.commands.register({
			id: r,
			title: Wn[t],
			handler: () => Bn(e, () => n(e))
		}), e.menus.register({
			id: `${r}.menu`,
			menu: "menu.tool",
			command: r
		});
	}
}
export { Gn as activate };
