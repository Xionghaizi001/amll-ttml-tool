//#region src/index.ts
var e = "builtin.time-shift", t = `${e}.run`, n = ({ selectedCount: e, totalLines: t }) => {
	let n = e > 0, r = Math.max(1, t);
	return {
		title: {
			default: "Shift lyric timing",
			"zh-CN": "平移时间"
		},
		size: "small",
		fields: [
			{
				kind: "number",
				key: "amount",
				label: {
					default: "Offset (ms)",
					"zh-CN": "偏移量 (ms)"
				},
				default: 100,
				min: 0,
				step: 50,
				required: !0
			},
			{
				kind: "radio",
				key: "direction",
				label: {
					default: "Direction",
					"zh-CN": "方向"
				},
				default: "delay",
				orientation: "horizontal",
				options: [{
					value: "advance",
					label: {
						default: "Advance (-)",
						"zh-CN": "提前 (-)"
					}
				}, {
					value: "delay",
					label: {
						default: "Delay (+)",
						"zh-CN": "延后 (+)"
					}
				}]
			},
			{
				kind: "radio",
				key: "scope",
				label: {
					default: "Apply to",
					"zh-CN": "应用于"
				},
				default: n ? "selected" : "all",
				options: [
					{
						value: "all",
						label: {
							default: "All lines",
							"zh-CN": "所有行"
						}
					},
					{
						value: "selected",
						label: {
							default: n ? `Selected lines (${e})` : "Selected lines",
							"zh-CN": n ? `所选行 (${e})` : "所选行"
						},
						disabled: !n
					},
					{
						value: "selected-following",
						label: {
							default: "Selected and following",
							"zh-CN": "所选行及其后续"
						},
						disabled: !n
					},
					{
						value: "custom",
						label: {
							default: "Custom range",
							"zh-CN": "自定义范围"
						}
					}
				]
			},
			{
				kind: "group",
				id: "customRange",
				visibleWhen: {
					field: "scope",
					equals: "custom"
				},
				fields: [
					{
						kind: "note",
						text: {
							default: "From",
							"zh-CN": "从"
						},
						tone: "default"
					},
					{
						kind: "number",
						key: "startLine",
						label: {
							default: "Start line",
							"zh-CN": "起始行"
						},
						controlSize: "small",
						default: 1,
						min: 1,
						max: r
					},
					{
						kind: "note",
						text: {
							default: "to",
							"zh-CN": "行 到"
						},
						tone: "default"
					},
					{
						kind: "number",
						key: "endLine",
						label: {
							default: "End line",
							"zh-CN": "结束行"
						},
						controlSize: "small",
						default: r,
						min: 1,
						max: r
					},
					{
						kind: "note",
						text: {
							default: "line",
							"zh-CN": "行"
						},
						tone: "default"
					}
				]
			}
		],
		submitLabel: {
			default: "Apply",
			"zh-CN": "应用"
		},
		cancelLabel: {
			default: "Cancel",
			"zh-CN": "取消"
		}
	};
}, r = (e, t, n, r, i) => {
	if (n === "all") return;
	if (n === "selected") return e.lines.filter((e) => t.has(e.id)).map((e) => e.id);
	if (n === "selected-following") {
		let n = e.lines.findIndex((e) => t.has(e.id));
		return n < 0 ? [] : e.lines.slice(n).map((e) => e.id);
	}
	let a = Math.max(0, Math.trunc(r) - 1), o = Math.min(e.lines.length, Math.trunc(i));
	return e.lines.slice(a, Math.max(a, o)).map((e) => e.id);
}, i = (e, t) => Math.max(0, e + t), a = (e, t) => e.map((e) => ({
	...e,
	startTime: i(e.startTime, t),
	endTime: i(e.endTime, t)
})), o = (e, t) => {
	if (!Number.isFinite(t.offsetMs) || !Number.isInteger(t.offsetMs)) throw RangeError("offsetMs must be a finite integer");
	let n = [], r = [];
	if (t.offsetMs === 0) return {
		ops: n,
		lineIds: r
	};
	let o = t.lineIds === void 0 ? void 0 : new Set(t.lineIds);
	for (let s of e.lines) if (o === void 0 || o.has(s.id)) {
		r.push(s.id), n.push({
			op: "updateLine",
			lineId: s.id,
			patch: {
				startTime: i(s.startTime, t.offsetMs),
				endTime: i(s.endTime, t.offsetMs)
			}
		});
		for (let e of s.words) n.push({
			op: "updateWord",
			wordId: e.id,
			patch: {
				startTime: i(e.startTime, t.offsetMs),
				endTime: i(e.endTime, t.offsetMs),
				...e.ruby === void 0 ? {} : { ruby: a(e.ruby, t.offsetMs) }
			}
		});
	}
	return {
		ops: n,
		lineIds: r
	};
}, s = (i) => {
	i.commands.register({
		id: t,
		title: {
			default: "Shift timing...",
			"zh-CN": "平移时间..."
		},
		category: {
			default: "Edit",
			"zh-CN": "编辑"
		},
		handler: async () => {
			let e = i.document.readSnapshot(), t = await i.ui.showForm(n({
				selectedCount: i.selection.get().lineIds.length,
				totalLines: e.lines.length
			}));
			if (!t.submitted) return;
			let a = Number(t.values.amount);
			if (!Number.isFinite(a) || a === 0) return;
			let s = String(t.values.direction), c = i.document.readSnapshot(), { ops: l, lineIds: u } = o(c, {
				offsetMs: Math.trunc(s === "advance" ? -a : a),
				lineIds: r(c, new Set(i.selection.get().lineIds), String(t.values.scope), Number(t.values.startLine), Number(t.values.endLine))
			});
			if (l.length === 0) return;
			let d = i.document.applyEdit(l, "Shift lyric timing", { expectedRevision: c.revision });
			if (!d.ok) {
				i.ui.notify({
					level: "error",
					message: "Lyric timing was not shifted",
					detail: d.error.message
				});
				return;
			}
			i.ui.notify({
				level: "success",
				message: "Lyric timing shifted",
				detail: `${u.length} line(s) updated`
			});
		}
	}), i.menus.register({
		id: `${e}.menu.edit`,
		command: t,
		menu: "menu.edit",
		group: "timing",
		order: 100
	});
}, c = "1.1.1";
function l({ host: e }) {
	s(e);
}
//#endregion
export { c as TIME_SHIFT_PLUGIN_VERSION, l as activate };
