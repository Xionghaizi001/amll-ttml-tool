var e = {
	"command.title": {
		default: "Import from plain text…",
		"cs-CZ": "Importovat z prostého textu…",
		"da-DK": "Importér fra almindelig tekst…",
		"es-ES": "Importar desde texto plano…",
		"fr-FR": "Importer depuis du texte brut…",
		"id-ID": "Impor dari Teks Polos…",
		"pl-PL": "Importuj z tekstu nieformatowanego…",
		"pt-BR": "Importar de texto simples…",
		"ru-RU": "Импорт из простого текста…",
		"sk-SK": "Importovať z obyčajného textu…",
		"zh-CN": "从纯文本导入…"
	},
	"form.title": {
		default: "Import Lyrics from Plain Text",
		"cs-CZ": "Importovat titulky z prostého textu",
		"da-DK": "Importér sangtekster fra almindelig tekst",
		"es-ES": "Importar letras desde texto plano",
		"fr-FR": "Importer des paroles depuis du texte brut",
		"id-ID": "Impor Lirik Teks Polos",
		"pl-PL": "Importuj tekst z tekstu nieformatowanego",
		"pt-BR": "Importar letras de texto simples",
		"ru-RU": "Импорт текста из простого текста",
		"sk-SK": "Importovať texty z obyčajného textu",
		"zh-CN": "导入纯文本歌词"
	},
	"form.submit": {
		default: "Import",
		"cs-CZ": "Importovat",
		"da-DK": "Importér",
		"es-ES": "Importar",
		"fr-FR": "Importer",
		"id-ID": "Impor Lirik",
		"pl-PL": "Importuj",
		"pt-BR": "Importar",
		"ru-RU": "Импортировать",
		"sk-SK": "Importovať",
		"zh-CN": "导入歌词"
	},
	"form.cancel": {
		default: "Cancel",
		"cs-CZ": "Zrušit",
		"da-DK": "Annuller",
		"es-ES": "Cancelar",
		"fr-FR": "Annuler",
		"id-ID": "Batal",
		"pl-PL": "Anuluj",
		"pt-BR": "Cancelar",
		"ru-RU": "Отмена",
		"sk-SK": "Zrušiť",
		"zh-CN": "取消"
	},
	"mode.caption": {
		default: "Text content",
		"cs-CZ": "Obsah textu",
		"da-DK": "Tekstindhold",
		"es-ES": "Contenido del texto",
		"fr-FR": "Contenu du texte",
		"id-ID": "Mode Impor",
		"pl-PL": "Zawartość tekstu",
		"pt-BR": "Conteúdo do texto",
		"ru-RU": "Содержимое текста",
		"sk-SK": "Obsah textu",
		"zh-CN": "导入模式"
	},
	"mode.lyric": {
		default: "Lyrics Only",
		"cs-CZ": "Pouze titulky",
		"da-DK": "Kun sangtekster",
		"es-ES": "Solo letras",
		"fr-FR": "Paroles uniquement",
		"id-ID": "Hanya Lirik",
		"pl-PL": "Tylko tekst",
		"pt-BR": "Apenas letras",
		"ru-RU": "Только текст",
		"sk-SK": "Iba texty",
		"zh-CN": "仅歌词"
	},
	"mode.withTranslation": {
		default: "Lyrics with translation",
		"cs-CZ": "titulky s překladem",
		"da-DK": "Sangtekster med oversættelse",
		"es-ES": "Letras con traducción",
		"fr-FR": "Paroles avec traduction",
		"id-ID": "Lirik dan Terjemahan",
		"pl-PL": "Tekst z tłumaczeniem",
		"pt-BR": "Letras com tradução",
		"ru-RU": "Текст с переводом",
		"sk-SK": "Texty s prekladom",
		"zh-CN": "歌词和翻译歌词"
	},
	"mode.withRoman": {
		default: "Lyrics with romanization",
		"cs-CZ": "titulky s romanizací",
		"da-DK": "Sangtekster med romanisering",
		"es-ES": "Letras con romanización",
		"fr-FR": "Paroles avec romanisation",
		"id-ID": "Lirik dan Romanisasi",
		"pl-PL": "Tekst z romanizacją",
		"pt-BR": "Letras com romanização",
		"ru-RU": "Текст с романизацией",
		"sk-SK": "Texty s romanizáciou",
		"zh-CN": "歌词和音译歌词"
	},
	"mode.withBoth": {
		default: "Lyrics with both",
		"cs-CZ": "titulky s obojím",
		"da-DK": "Sangtekster med begge",
		"es-ES": "Letras con ambos",
		"fr-FR": "Paroles avec les deux",
		"id-ID": "Lirik, Terjemahan, dan Romanisasi",
		"pl-PL": "Tekst z oboma",
		"pt-BR": "Letras com ambos",
		"ru-RU": "Текст с обоими",
		"sk-SK": "Texty s oboma",
		"zh-CN": "歌词和翻译、音译歌词"
	},
	"separation.caption": {
		default: "Translation/Romanization Format",
		"cs-CZ": "Formát překladu/romanizace",
		"da-DK": "Oversættelses-/romaniseringsformat",
		"es-ES": "Formato de traducción/romanización",
		"fr-FR": "Format de traduction/romanisation",
		"id-ID": "Mode Pemisah Baris (Terjemahan dan Romanisasi)",
		"pl-PL": "Format tłumaczenia/romanizacji",
		"pt-BR": "Formato de tradução/romanização",
		"ru-RU": "Формат перевода/романизации",
		"sk-SK": "Formát prekladu/romanizácie",
		"zh-CN": "歌词分行（翻译和音译）模式"
	},
	"separation.multipleLine": {
		default: "Interleaved Multiple Lines",
		"cs-CZ": "Prokládané více řádků",
		"da-DK": "Sammenflettet flere linjer",
		"es-ES": "Múltiples líneas intercaladas",
		"fr-FR": "Lignes multiples intercalées",
		"id-ID": "Pemisah Baris Berselang-seling",
		"pl-PL": "Przeplatane wiele linii",
		"pt-BR": "Múltiplas linhas intercaladas",
		"ru-RU": "Чередующиеся строки",
		"sk-SK": "Prekladané viac riadkov",
		"zh-CN": "多行交错分隔"
	},
	"separation.sameLine": {
		default: "Same Line Separation",
		"cs-CZ": "Oddělení na stejném řádku",
		"da-DK": "Samme linje adskillelse",
		"es-ES": "Separación en misma línea",
		"fr-FR": "Séparation sur la même ligne",
		"id-ID": "Pemisah di Baris yang Sama",
		"pl-PL": "Separacja w tej samej linii",
		"pt-BR": "Separação na mesma linha",
		"ru-RU": "Разделение в одной строке",
		"sk-SK": "Oddelenie na rovnakom riadku",
		"zh-CN": "同行分隔"
	},
	separator: {
		default: "Line Separator",
		"cs-CZ": "Oddělovač řádků",
		"da-DK": "Linjeseparator",
		"es-ES": "Separador de línea",
		"fr-FR": "Séparateur de ligne",
		"id-ID": "Pemisah Baris Lirik",
		"pl-PL": "Separator linii",
		"pt-BR": "Separador de linha",
		"ru-RU": "Разделитель строк",
		"sk-SK": "Oddeľovač riadkov",
		"zh-CN": "歌词行分隔符"
	},
	swapTransAndRoman: {
		default: "Swap translation and romanization lines",
		"cs-CZ": "Prohodit řádky překladu a romanizace",
		"da-DK": "Byt oversættelses- og romaniseringslinjer",
		"es-ES": "Intercambiar líneas de traducción y romanización",
		"fr-FR": "Permuter les lignes de traduction et de romanisation",
		"id-ID": "Tukarkan Baris Terjemahan dan Romanisasi",
		"pl-PL": "Zamień linie tłumaczenia i romanizacji",
		"pt-BR": "Trocar linhas de tradução e romanização",
		"ru-RU": "Поменять местами строки перевода и романизации",
		"sk-SK": "Prehodiť riadky prekladu a romanizácie",
		"zh-CN": "交换翻译行和音译行"
	},
	wordSeparator: {
		default: "Word Separator",
		"cs-CZ": "Oddělovač slov",
		"da-DK": "Ordseparator",
		"es-ES": "Separador de palabras",
		"fr-FR": "Séparateur de mots",
		"id-ID": "Pemisah Kata",
		"pl-PL": "Separator słów",
		"pt-BR": "Separador de palavras",
		"ru-RU": "Разделитель слов",
		"sk-SK": "Oddeľovač slov",
		"zh-CN": "单词分隔符"
	},
	enableSpecialPrefix: {
		default: "Enable Special Prefix",
		"cs-CZ": "Povolit speciální předponu",
		"da-DK": "Aktiver specielt præfiks",
		"es-ES": "Habilitar prefijo especial",
		"fr-FR": "Activer le préfixe spécial",
		"id-ID": "Aktifkan Prefiks Khusus",
		"pl-PL": "Włącz specjalny prefiks",
		"pt-BR": "Ativar prefixo especial",
		"ru-RU": "Включить специальный префикс",
		"sk-SK": "Povoliť špeciálnu predponu",
		"zh-CN": "启用特殊前缀"
	},
	bgLyricPrefix: {
		default: "Background Lyric Prefix",
		"cs-CZ": "Předpona doprovodné titulky",
		"da-DK": "Baggrundssangtekst-præfiks",
		"es-ES": "Prefijo de letra de fondo",
		"fr-FR": "Préfixe de paroles de fond",
		"id-ID": "Prefiks Lirik Latar",
		"pl-PL": "Prefiks linii w tle",
		"pt-BR": "Prefixo de letra de fundo",
		"ru-RU": "Префикс фонового текста",
		"sk-SK": "Predpona sprievodného textu",
		"zh-CN": "背景歌词前缀"
	},
	duetLyricPrefix: {
		default: "Duet Lyric Prefix",
		"cs-CZ": "Předpona duetové titulky",
		"da-DK": "Duetsangtekst-præfiks",
		"es-ES": "Prefijo de letra de dueto",
		"fr-FR": "Préfixe de paroles de duo",
		"id-ID": "Prefiks Lirik Duet",
		"pl-PL": "Prefiks lnii w duecie",
		"pt-BR": "Prefixo de letra de dueto",
		"ru-RU": "Префикс дуэтного текста",
		"sk-SK": "Predpona duetového textu",
		"zh-CN": "对唱歌词前缀"
	},
	enableEmptyBeat: {
		default: "Enable Empty Beat",
		"cs-CZ": "Povolit prázdnou dobu",
		"da-DK": "Aktiver tom takt",
		"es-ES": "Habilitar tiempo vacío",
		"fr-FR": "Activer le temps vide",
		"id-ID": "Aktifkan Ketukan Kosong",
		"pl-PL": "Włącz pusty takt",
		"pt-BR": "Ativar batida vazia",
		"ru-RU": "Включить пустую долю",
		"sk-SK": "Povoliť prázdnu dobu",
		"zh-CN": "启用空拍"
	},
	emptyBeatSymbol: {
		default: "Empty Beat Symbol",
		"cs-CZ": "Symbol prázdné doby",
		"da-DK": "Tom takt-symbol",
		"es-ES": "Símbolo de tiempo vacío",
		"fr-FR": "Symbole de temps vide",
		"id-ID": "Simbol Ketukan Kosong",
		"pl-PL": "Symbol pustego taktu",
		"pt-BR": "Símbolo de batida vazia",
		"ru-RU": "Символ пустой доли",
		"sk-SK": "Symbol prázdnej doby",
		"zh-CN": "空拍符号"
	},
	text: {
		default: "Lyrics text",
		"zh-CN": "歌词文本"
	},
	"error.failed": {
		default: "Failed to import plain text lyrics. Check the text and the import settings.",
		"zh-CN": "导入纯文本歌词失败，请检查输入的文本是否正确，或者导入设置是否正确"
	}
}, t = {
	mode: "lyric",
	lineSeparatorMode: "interleaved-line",
	lineSeparator: "|",
	swapTransAndRoman: !1,
	wordSeparator: "\\",
	enableSpecialPrefix: !1,
	bgLyricPrefix: "<",
	duetLyricPrefix: ">",
	enableEmptyBeat: !1,
	emptyBeatSymbol: "^"
}, n = (e) => ({
	text: e,
	startTime: 0,
	endTime: 0,
	emptyBeat: 0,
	romanText: ""
}), r = (e) => {
	switch (e) {
		case "lyric-trans": return ["translation"];
		case "lyric-roman": return ["romanization"];
		case "lyric-trans-roman": return ["translation", "romanization"];
		default: return [];
	}
};
function i(e, t) {
	let i = e.split("\n"), a = [], o = (e = "") => {
		let r = e, i = !1, o = !1;
		if (t.enableSpecialPrefix) for (;;) if (t.bgLyricPrefix && r.startsWith(t.bgLyricPrefix)) i = !0, r = r.slice(t.bgLyricPrefix.length);
		else if (t.duetLyricPrefix && r.startsWith(t.duetLyricPrefix)) o = !0, r = r.slice(t.duetLyricPrefix.length);
		else break;
		let s = {
			words: [n(r)],
			translation: "",
			romanization: "",
			isBackground: i,
			isDuet: o,
			startTime: 0,
			endTime: 0,
			ignoreSync: !1
		};
		return a.push(s), s;
	}, [s, c] = r(t.mode);
	if (!s) for (let e of i) o(e);
	else if (t.lineSeparatorMode === "interleaved-line") {
		let e = c ? 3 : 2;
		for (let t = 0; t < i.length; t += e) {
			let e = o(i[t]);
			e[s] = i[t + 1] ?? "", c && (e[c] = i[t + 2] ?? "");
		}
	} else for (let e of i) {
		let n = e.split(t.lineSeparator), r = o(n[0] ?? "");
		r[s] = n[1] ?? "", c && (r[c] = n[2] ?? "");
	}
	if (t.swapTransAndRoman) for (let e of a) [e.romanization, e.translation] = [e.translation, e.romanization];
	if (t.wordSeparator.length > 0) for (let e of a) e.words = e.words.map((e) => e.text).join("").split(t.wordSeparator).map(n);
	if (t.enableEmptyBeat && t.emptyBeatSymbol.length > 0) for (let e of a) for (let n of e.words) for (; n.text.endsWith(t.emptyBeatSymbol);) n.text = n.text.slice(0, -t.emptyBeatSymbol.length), n.emptyBeat += 1;
	return a;
}
// src/index.ts
var a = "builtin.plain-text-import", o = `${a}.run`, s = "options", c = 65536, l = (e, t, n) => {
	let r = (n, r) => ({
		kind: "text",
		key: n,
		label: e(n),
		default: String(t[n]),
		maxLength: 64,
		controlSize: "small",
		...r ? { visibleWhen: r } : {}
	}), i = (n) => ({
		kind: "boolean",
		key: n,
		label: e(n),
		default: !!t[n]
	});
	return {
		title: e("form.title"),
		size: "large",
		fields: [
			{
				kind: "text",
				key: "text",
				label: e("text"),
				default: n,
				multiline: !0,
				required: !0,
				maxLength: c
			},
			{
				kind: "select",
				key: "mode",
				label: e("mode.caption"),
				default: t.mode,
				options: [
					{
						value: "lyric",
						label: e("mode.lyric")
					},
					{
						value: "lyric-trans",
						label: e("mode.withTranslation")
					},
					{
						value: "lyric-roman",
						label: e("mode.withRoman")
					},
					{
						value: "lyric-trans-roman",
						label: e("mode.withBoth")
					}
				]
			},
			{
				kind: "select",
				key: "lineSeparatorMode",
				label: e("separation.caption"),
				default: t.lineSeparatorMode,
				options: [{
					value: "interleaved-line",
					label: e("separation.multipleLine")
				}, {
					value: "same-line-separator",
					label: e("separation.sameLine")
				}]
			},
			r("lineSeparator", {
				field: "lineSeparatorMode",
				equals: "same-line-separator"
			}),
			i("swapTransAndRoman"),
			r("wordSeparator"),
			i("enableSpecialPrefix"),
			r("bgLyricPrefix", {
				field: "enableSpecialPrefix",
				equals: !0
			}),
			r("duetLyricPrefix", {
				field: "enableSpecialPrefix",
				equals: !0
			}),
			i("enableEmptyBeat"),
			r("emptyBeatSymbol", {
				field: "enableEmptyBeat",
				equals: !0
			})
		],
		submitLabel: e("form.submit"),
		cancelLabel: e("form.cancel")
	};
}, u = (e) => {
	let n = { ...t };
	if (typeof e != "object" || !e || Array.isArray(e)) return n;
	for (let t of Object.keys(n)) typeof e[t] == typeof n[t] && (n[t] = e[t]);
	return n;
}, d = (t) => {
	let n = "";
	t.commands.register({
		id: o,
		title: e["command.title"],
		handler: async () => {
			let e = u(await t.storage.kv.get(s)), r = await t.ui.showForm(l(t.i18n.t, e, n));
			if (!r.submitted) return;
			let { text: a, ...o } = r.values;
			n = String(a ?? "");
			let c = u(o);
			await t.storage.kv.set(s, { ...c });
			let d = await t.project.importDocument({
				lines: i(n, c),
				metadata: []
			}, "Import plain text lyrics");
			!d.ok && d.error.code !== "cancelled" && t.ui.notify({
				level: "error",
				message: t.i18n.t("error.failed"),
				detail: d.error.message
			});
		}
	}), t.menus.register({
		id: `${a}.menu.file`,
		command: o,
		menu: "menu.file",
		group: "import",
		order: 100
	});
};
// src/plugin.ts
function f({ host: e }) {
	d(e);
}
export { f as activate };
