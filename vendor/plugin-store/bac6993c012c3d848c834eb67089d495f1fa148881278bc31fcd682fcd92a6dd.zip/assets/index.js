import * as e from "react";
import t, { Children as n, Component as r, Fragment as i, createContext as a, createElement as o, forwardRef as s, isValidElement as c, memo as l, useCallback as u, useContext as d, useEffect as f, useId as p, useInsertionEffect as m, useLayoutEffect as h, useMemo as g, useRef as _, useState as v, useSyncExternalStore as y } from "react";
import { Fragment as b, jsx as x, jsxs as S } from "react/jsx-runtime";
import { Badge as C, Box as w, Button as T, Card as E, Checkbox as ee, Flex as D, Heading as te, IconButton as ne, Spinner as re, Text as O, TextField as ie } from "@radix-ui/themes";
// \0rolldown/runtime.js
var ae = Object.defineProperty, oe = Object.getOwnPropertyDescriptor, se = Object.getOwnPropertyNames, ce = Object.prototype.hasOwnProperty, le = (e, t, n) => () => {
	if (n) throw n[0];
	try {
		return e && (t = e(e = 0)), t;
	} catch (e) {
		throw n = [e], e;
	}
}, ue = (e, t) => {
	let n = {};
	for (var r in e) ae(n, r, {
		get: e[r],
		enumerable: !0
	});
	return t || ae(n, Symbol.toStringTag, { value: "Module" }), n;
}, de = (e, t, n, r) => {
	if (t && typeof t == "object" || typeof t == "function") for (var i = se(t), a = 0, o = i.length, s; a < o; a++) s = i[a], !ce.call(e, s) && s !== n && ae(e, s, {
		get: ((e) => t[e]).bind(null, s),
		enumerable: !(r = oe(t, s)) || r.enumerable
	});
	return e;
}, fe = (e) => ce.call(e, "module.exports") ? e["module.exports"] : de(ae({}, "__esModule", { value: !0 }), e), pe = typeof window > "u" ? global : window, me = "@griffel/";
function he(e, t) {
	return pe[Symbol.for(me + e)] || (pe[Symbol.for(me + e)] = t), pe[Symbol.for(me + e)];
}
var ge = /*#__PURE__*/ he("DEBUG_RESET_CLASSES", {}), _e = /*#__PURE__*/ he("DEFINITION_LOOKUP_TABLE", {}), ve = "data-make-styles-bucket", ye = "data-priority", be = "data-container", xe = process.env.NODE_ENV === "production" ? 10 : 18;
// node_modules/.pnpm/@emotion+hash@0.9.2/node_modules/@emotion/hash/dist/emotion-hash.esm.js
function Se(e) {
	for (var t = 0, n, r = 0, i = e.length; i >= 4; ++r, i -= 4) n = e.charCodeAt(r) & 255 | (e.charCodeAt(++r) & 255) << 8 | (e.charCodeAt(++r) & 255) << 16 | (e.charCodeAt(++r) & 255) << 24, n = (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16), n ^= n >>> 24, t = (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16) ^ (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
	switch (i) {
		case 3: t ^= (e.charCodeAt(r + 2) & 255) << 16;
		case 2: t ^= (e.charCodeAt(r + 1) & 255) << 8;
		case 1: t ^= e.charCodeAt(r) & 255, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
	}
	return t ^= t >>> 13, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16), ((t ^ t >>> 15) >>> 0).toString(36);
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/utils/hashSequence.js
function Ce(e) {
	let t = e.length;
	if (t === 7) return e;
	for (let n = t; n < 7; n++) e += "0";
	return e;
}
function we(e, t, n = []) {
	return process.env.NODE_ENV === "production" ? "___" + Ce(Se(e + t)) : "___" + Ce(Se(e + t)) + "_" + Ce(Se(n.join("")));
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/reduceToClassNameForSlots.js
function Te(e, t) {
	let n = "", r = "";
	for (let i in e) {
		let a = e[i];
		if (a === 0) {
			r += i + " ";
			continue;
		}
		let o = Array.isArray(a), s = t === "rtl" ? (o ? a[1] : a) + " " : (o ? a[0] : a) + " ";
		n += s, r += s;
	}
	return [n.slice(0, -1), r.slice(0, -1)];
}
function Ee(e, t) {
	let n = {};
	for (let r in e) {
		let [i, a] = Te(e[r], t);
		if (a === "") {
			n[r] = "";
			continue;
		}
		let o = we(a, t), s = o + (i === "" ? "" : " " + i);
		_e[o] = [e[r], t], n[r] = s;
	}
	return n;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/mergeClasses.js
var De = {};
function Oe() {
	let e = null, t = "", n = "", r = Array(arguments.length), i = "";
	for (let e = 0; e < arguments.length; e++) {
		let a = arguments[e];
		if (typeof a == "string" && a !== "") {
			let o = a.indexOf("___");
			if (o === -1) process.env.NODE_ENV !== "production" && a.split(" ").forEach((e) => {
				e.startsWith("r") && ge[e] && (i ? console.error(`mergeClasses(): a passed string contains multiple classes produced by makeResetStyles (${a} & ${t}, this will lead to non-deterministic behavior. Learn more:https://griffel.js.org/react/api/make-reset-styles#limitations
Source string: ${a}`) : i = e);
			}), t += a + " ";
			else {
				let i = a.substr(o, xe);
				o > 0 && (t += a.slice(0, o)), n += i, r[e] = i;
			}
			process.env.NODE_ENV !== "production" && a.indexOf("___", o + 1) !== -1 && console.error(`mergeClasses(): a passed string contains multiple identifiers of atomic classes (classes that start with "___"), it's possible that passed classes were concatenated in a wrong way. Source string: ${a}`);
		}
	}
	if (n === "") return t.slice(0, -1);
	let a = De[n];
	if (a !== void 0) return t + a;
	let o = [];
	for (let t = 0; t < arguments.length; t++) {
		let n = r[t];
		if (n) {
			let r = _e[n];
			r ? (o.push(r[0]), process.env.NODE_ENV !== "production" && e !== null && e !== r[1] && console.error(`mergeClasses(): a passed string contains an identifier (${n}) that has different direction (dir="${r[1] ? "rtl" : "ltr"}") setting than other classes. This is not supported. Source string: ${arguments[t]}`), e = r[1]) : process.env.NODE_ENV !== "production" && console.error(`mergeClasses(): a passed string contains an identifier (${n}) that does not match any entry in cache. Source string: ${arguments[t]}`);
		}
	}
	let s = Object.assign.apply(Object, [{}].concat(o)), [c, l] = Te(s, e), u = we(l, e, r), d = u + " " + c;
	return De[n] = d, _e[u] = [s, e], t + d;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/store.js
var ke = {}, Ae = /* @__PURE__ */ new Set(), je = {
	getChildrenSequences: (e) => {
		let t = Object.keys(De).find((t) => De[t].startsWith(e));
		return t ? t.split("___").filter((e) => e.length).map((e) => "___" + e) : [];
	},
	addCSSRule: (e) => {
		Ae.add(e);
	},
	addSequenceDetails: (e, t) => {
		Object.entries(e).forEach(([e, n]) => {
			ke[n.substring(0, xe)] = {
				slotName: e,
				sourceURL: t
			};
		});
	},
	getCSSRules: () => Array.from(Ae),
	getSequenceDetails: (e) => ke[e]
};
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/utils.js
function Me(e, t) {
	return Array.isArray(e) ? t === "rtl" ? e[1] : e[0] : e || "";
}
function Ne(e, t, n, r) {
	let i = e[0], a = e[1];
	return Object.entries(i).map(([e, i]) => {
		let o = Me(i, a), s;
		if (n && t) {
			let i = n.find(({ className: e }) => e === o);
			!i && t[0][e] ? s = Me(t[0][e], t[1]) : i && t[0][e] ? s = r && r.filter(({ debugClassNames: e }) => e.filter(({ className: e }) => e === o).length > 0).length > 0 ? i.className : i.overriddenBy : (!i && !t[0][e] || i && !t[0][e]) && (s = void 0);
		}
		return {
			className: o,
			overriddenBy: s
		};
	});
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getAtomicDebugSequenceTree.js
function Pe(e, t) {
	let n = _e[e];
	if (n === void 0) return;
	let r = Ne(n, t ? _e[t.sequenceHash] : void 0, t?.debugClassNames, t?.children), i = {
		sequenceHash: e,
		direction: n[1],
		children: [],
		debugClassNames: r
	};
	return je.getChildrenSequences(i.sequenceHash).reverse().forEach((e) => {
		let t = Pe(e, i);
		t && i.children.push(t);
	}), i.children.length || (i.rules = {}, i.debugClassNames.forEach(({ className: t }) => {
		let n = je.getSequenceDetails(e);
		n && (i.slot = n.slotName, i.sourceURL = n.sourceURL);
		let r = je.getCSSRules().find((e) => e.includes(t));
		i.rules[t] = r;
	})), i;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getResetDebugSequence.js
function Fe(e) {
	if (ge[e] === void 0) return;
	let t = {
		sequenceHash: e,
		direction: "ltr",
		children: [],
		debugClassNames: [{ className: e }]
	};
	t.rules = {}, t.slot = "makeResetStyles()";
	let [{ className: n }] = t.debugClassNames, r = je.getCSSRules().filter((e) => e.includes(`.${n}`));
	return t.rules[n] = r.join(""), t;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/mergeDebugSequence.js
function Ie(e, t) {
	let n = e ? Pe(e) : void 0, r = t ? Fe(t) : void 0;
	if (n || r) return n ? r ? {
		sequenceHash: n.sequenceHash + r.sequenceHash,
		direction: n.direction,
		children: [n, r],
		debugClassNames: [...n.debugClassNames, ...r.debugClassNames]
	} : n : r;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/injectDevTools.js
function Le(e) {
	let t = e.defaultView;
	if (!t || t.__GRIFFEL_DEVTOOLS__) return;
	let n = { getInfo: (e) => {
		let t, n;
		for (let r of e.classList) r.startsWith("___") && (t = r), ge[r] && (n = r);
		return Ie(t, n);
	} };
	Object.defineProperty(t, "__GRIFFEL_DEVTOOLS__", {
		configurable: !1,
		enumerable: !1,
		get() {
			return n;
		}
	});
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/isDevToolsEnabled.js
var Re = (() => {
	try {
		return !!(typeof window < "u" && window.sessionStorage?.getItem("__GRIFFEL_DEVTOOLS__"));
	} catch {
		return !1;
	}
})(), ze = "<unknown>";
function Be(e) {
	return We(e) || qe(e) || Ye(e);
}
var Ve = /^\s*at (.*?) ?\(((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/|[a-z]:\\|\\\\).*?)?\)?\s*$/i, He = /^\s*at ()((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/|[a-z]:\\|\\\\).*?)\s*$/i, Ue = /\((\S*)\)/;
function We(e) {
	let t = Ve.exec(e) || He.exec(e);
	if (!t) return null;
	let n = t[2], r = n && n.indexOf("native") === 0, i = n && n.indexOf("eval") === 0, a = Ue.exec(n);
	return i && a !== null && (n = a[1]), {
		loc: r ? null : t[2],
		name: t[1] || ze
	};
}
var Ge = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|resource|\[native).*?|[^@]*bundle)\s*$/i, Ke = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;
function qe(e) {
	let t = Ge.exec(e);
	if (!t) return null;
	let n = t[3], r = n && n.indexOf(" > eval") > -1, i = Ke.exec(n);
	return r && i !== null && (n = i[1]), {
		loc: t[3],
		name: t[1] || ze
	};
}
var Je = /^\s*(?:([^@]*)(?:\((.*?)\))?@)?(\S.*?)\s*$/i;
function Ye(e) {
	let t = Je.exec(e);
	return t ? {
		loc: t[3],
		name: t[1] || ze
	} : null;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getSourceURLfromError.js
function Xe() {
	let e = Ze(String((/* @__PURE__ */ Error()).stack).split("\n"));
	return e === void 0 ? void 0 : Be(e)?.loc;
}
function Ze(e) {
	for (let t = e.length - 1; t >= 0; --t) if (e[t].includes("at getSourceURLfromError")) return e[t + 3];
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/utils/normalizeCSSBucketEntry.js
function Qe(e) {
	if (!Array.isArray(e)) return [e];
	if (process.env.NODE_ENV !== "production" && e.length > 2) throw Error("CSS Bucket contains an entry with greater than 2 items, please report this to https://github.com/microsoft/griffel/issues");
	return e;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/createIsomorphicStyleSheet.js
function $e(e, t, n, r) {
	let i = [];
	if (r[ve] = t, r[ye] = String(n), e) for (let t in r) e.setAttribute(t, r[t]);
	function a(t) {
		return e?.sheet ? e.sheet.insertRule(t, e.sheet.cssRules.length) : i.push(t);
	}
	return {
		elementAttributes: r,
		insertRule: a,
		element: e,
		bucketName: t,
		cssRules() {
			return e?.sheet ? Array.from(e.sheet.cssRules).map((e) => e.cssText) : i;
		}
	};
}
var et = /*#__PURE__*/ [
	"r",
	"d",
	"l",
	"v",
	"w",
	"f",
	"i",
	"h",
	"a",
	"s",
	"k",
	"t",
	"m",
	"c",
	"x"
].reduce((e, t, n) => (e[t] = n, e), {});
function tt(e, t, n) {
	return e === "m" || e === "x" ? e + t + n : e + n;
}
function nt(e, t, n, r, i = {}) {
	let a = e === "m", o = e === "x", s = i.m, c = i.x, l = i.p ?? 0, u = tt(e, c ?? s ?? "0", l);
	if (!r.stylesheets[u]) {
		let d = t && t.createElement("style"), f = $e(d, e, l, {
			...r.styleElementAttributes,
			...a && { media: s },
			...o && { "data-container": c }
		});
		r.stylesheets[u] = f, t?.head && d && t.head.insertBefore(d, it(t, n, e, r, i));
	}
	return r.stylesheets[u];
}
function rt(e, t, n) {
	return e.getAttribute("data-make-styles-bucket") === t ? t === "m" ? n.m === e.media : t !== "x" || n.x === e.getAttribute(be) : !1;
}
function it(e, t, n, r, i = {}) {
	let a = et[n], o = i.m ?? "", s = i.x ?? "", c = i.p ?? 0, l = (e) => a - et[e.getAttribute(ve)], u = e.head.querySelectorAll(`[${ve}]`);
	if (n === "m" || n === "x") {
		let t = e.head.querySelectorAll(`[${ve}="${n}"]`);
		t.length && (u = t, l = n === "m" ? (e) => r.compareMediaQueries(o, e.media) : (e) => r.compareContainerQueries(s, e.getAttribute("data-container") ?? ""));
	}
	let d = (e) => rt(e, n, i) ? c - Number(e.getAttribute(ye)) : l(e), f = u.length, p = f - 1;
	for (; p >= 0;) {
		let e = u.item(p);
		if (d(e) > 0) return e.nextSibling;
		p--;
	}
	return f > 0 ? u.item(0) : t ? t.nextSibling : null;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/safeInsertRule.js
var at = /*#__PURE__*/ RegExp(":(-moz-placeholder|-moz-focus-inner|-moz-focusring|-ms-input-placeholder|-moz-read-write|-moz-read-only)");
function ot(e, t) {
	try {
		e.insertRule(t);
	} catch (e) {
		process.env.NODE_ENV !== "production" && !at.test(t) && console.error(`There was a problem inserting the following rule: "${t}"`, e);
	}
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/createDOMRenderer.js
var st = 0, ct = (e, t) => e < t ? -1 : +(e > t);
function lt(e = typeof document > "u" ? void 0 : document, t = {}) {
	let { classNameHashSalt: n, unstable_filterCSSRule: r, insertionPoint: i, styleElementAttributes: a, compareMediaQueries: o = ct, compareContainerQueries: s = o } = t, c = {
		classNameHashSalt: n,
		insertionCache: {},
		stylesheets: {},
		styleElementAttributes: Object.freeze(a),
		compareMediaQueries: o,
		compareContainerQueries: s,
		id: `d${st++}`,
		insertCSSRules(t) {
			for (let n in t) {
				let a = t[n];
				for (let t = 0, o = a.length; t < o; t++) {
					let [o, s] = Qe(a[t]), l = nt(n, e, i || null, c, s);
					c.insertionCache[o] || (c.insertionCache[o] = n, process.env.NODE_ENV !== "production" && Re && je.addCSSRule(o), r ? r(o) && ot(l, o) : ot(l, o));
				}
			}
		}
	};
	return e && process.env.NODE_ENV !== "production" && Re && Le(e), c;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/insertionFactory.js
var ut = () => {
	let e = {};
	return function(t, n) {
		e[t.id] === void 0 && (t.insertCSSRules(n), e[t.id] = !0);
	};
};
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/__styles.js
function dt(e, t, n = ut) {
	let r = n(), i = null, a = null, o;
	process.env.NODE_ENV !== "production" && Re && (o = Xe());
	function s(n) {
		let { dir: s, renderer: c } = n, l = s === "ltr";
		l ? i === null && (i = Ee(e, s)) : a === null && (a = Ee(e, s)), r(c, t);
		let u = l ? i : a;
		return process.env.NODE_ENV !== "production" && Re && je.addSequenceDetails(u, o), u;
	}
	return s;
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/utils/canUseDOM.js
function ft() {
	return typeof window < "u" && !!(window.document && window.document.createElement);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/useInsertionEffect.js
var pt = t.useInsertionEffect ? t.useInsertionEffect : void 0, mt = () => {
	let e = {};
	return function(t, n) {
		pt && ft() ? pt(() => {
			t.insertCSSRules(n);
		}, [t, n]) : e[t.id] === void 0 && (t.insertCSSRules(n), e[t.id] = !0);
	};
}, ht = /*#__PURE__*/ a(/*#__PURE__*/ lt());
function gt() {
	return d(ht);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/TextDirectionContext.js
var _t = /*#__PURE__*/ a("ltr");
function vt() {
	return d(_t);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/__styles.js
function yt(e, t) {
	let n = dt(e, t, mt);
	return function() {
		let e = vt(), t = gt();
		return n({
			dir: e,
			renderer: t
		});
	};
}
// node_modules/.pnpm/@fluentui+react-icons@2.0.333_react@19.2.7/node_modules/@fluentui/react-icons/lib/utils/useIconStyles.styles.js
var bt = yt({
	root: {
		mc9l5x: "f1w7gpdv",
		Bg96gwp: "fez10in"
	},
	rtl: { Bz10aip: "f13rod7r" }
}, { d: [
	".f1w7gpdv{display:inline;}",
	".fez10in{line-height:0;}",
	".f13rod7r{transform:scaleX(-1);}"
] }), xt = e.createContext(void 0), St = {};
xt.Provider;
var Ct = () => e.useContext(xt) ?? St, wt = "fui-Icon", Tt = "data-fui-icon", Et = (e, t) => {
	let { filled: n, idPrefix: r, title: i, primaryFill: a = "currentColor", ...o } = e, s = {
		...o,
		fill: a
	}, c = Ct(), l = !!(t?.flipInRtl && c?.textDirection === "rtl");
	return i && (s["aria-label"] = i), !s["aria-label"] && !s["aria-labelledby"] ? s["aria-hidden"] = !0 : s.role = "img", s[Tt] = "", {
		state: s,
		isRtlFlip: l
	};
}, Dt = (e, t) => {
	let n = bt(), { state: r, isRtlFlip: i } = Et(e, t);
	return r.className = Oe(n.root, i && n.rtl, r.className), r;
}, Ot = yt({ root: { B8gzw0y: "f1dd5bof" } }, { m: [["@media (forced-colors: active){.f1dd5bof{forced-color-adjust:auto;}}", { m: "(forced-colors: active)" }]] }), kt = "url(#", At = (t, n, r) => {
	let [i, a, ...o] = t, s = a;
	if (r && a) {
		let e = {};
		for (let t in a) {
			let n = a[t];
			if (typeof n != "string") e[t] = n;
			else if (t === "id") e[t] = r + n;
			else {
				let i = n.indexOf(kt);
				e[t] = i < 0 ? n : n.slice(0, i + 5) + r + n.slice(i + 5);
			}
		}
		s = e;
	}
	return e.createElement(i, {
		...s,
		key: n
	}, ...o.map((e, t) => At(e, t, r)));
}, jt = (e) => e === "1em" ? "20" : e, Mt = (e, t, n) => typeof e != "string" && (t?.color || Array.isArray(e[0])) ? e.map((e, t) => At(e, t, n)) : void 0, Nt = () => void 0, Pt = (t, n) => {
	let r = Mt(t, n);
	return r ? function(i) {
		return e.useMemo(() => i ? Mt(t, n, i) : r, [i]);
	} : Nt;
}, Ft = (t, n, r) => typeof n == "string" ? e.createElement("svg", {
	...t,
	dangerouslySetInnerHTML: { __html: n }
}) : r ? e.createElement("svg", t, ...r) : e.createElement("svg", t, ...n.map((n) => e.createElement("path", {
	d: n,
	fill: t.fill
}))), k = (t, n, r, i) => {
	let a = jt(n), o = Pt(r, i), s = e.forwardRef((e, t) => {
		let s = Ot(), c = Dt(e, { flipInRtl: i?.flipInRtl }), l = o(e.idPrefix);
		return Ft({
			...c,
			className: Oe(wt, c.className, s.root),
			ref: t,
			width: n,
			height: n,
			viewBox: `0 0 ${a} ${a}`,
			xmlns: "http://www.w3.org/2000/svg"
		}, r, l);
	});
	return s.displayName = t, s;
}, It = /*#__PURE__*/ k("AlbumRegular", "1em", ["M8 8.5C8 7.67 8.67 7 9.5 7h4c.83 0 1.5.67 1.5 1.5v1c0 .83-.67 1.5-1.5 1.5h-4A1.5 1.5 0 0 1 8 9.5v-1ZM9.5 8a.5.5 0 0 0-.5.5v1c0 .28.22.5.5.5h4a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-4ZM2 6c0-1.1.9-2 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6Zm4 9h10a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6v10ZM5 5H4a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h1V5Z"], { flipInRtl: !0 }), Lt = /*#__PURE__*/ k("MusicNote1Regular", "1em", ["M10.15 2.02a.5.5 0 0 0-.65.48v9.9A3.24 3.24 0 0 0 4 14.75a3.25 3.25 0 1 0 6.5-.25V7.18l5.85 1.8A.5.5 0 0 0 17 8.5V5.98a2.5 2.5 0 0 0-1.76-2.4l-5.1-1.56ZM16 7.82l-5.5-1.69V3.18l4.44 1.36c.63.2 1.06.78 1.06 1.44v1.84ZM5 14.75a2.25 2.25 0 1 1 4.5 0 2.25 2.25 0 0 1-4.5 0Z"]), Rt = /*#__PURE__*/ k("NumberSymbol16Regular", "16", ["M7 2.6a.5.5 0 1 0-1-.19L5.55 5H3.5a.5.5 0 0 0 0 1h1.86l-.73 4H2.5a.5.5 0 0 0 0 1h1.95L4 13.41a.5.5 0 0 0 .98.18L5.46 11h3.98l-.43 2.4a.5.5 0 0 0 .98.19l.47-2.59h2.04a.5.5 0 0 0 0-1h-1.86l.73-4h2.13a.5.5 0 1 0 0-1h-1.95L12 2.6a.5.5 0 1 0-.98-.19l-.47 2.6H6.55L7 2.58ZM6.36 6h3.99l-.73 4H5.64l.73-4Z"]), zt = /*#__PURE__*/ k("Person16Regular", "16", ["M11.5 8c.83 0 1.5.67 1.5 1.5v.5c0 1.97-1.86 4-5 4-3.14 0-5-2.03-5-4v-.5C3 8.67 3.67 8 4.5 8h7Zm0 1h-7a.5.5 0 0 0-.5.5v.5c0 1.44 1.43 3 4 3 2.57 0 4-1.56 4-3v-.5a.5.5 0 0 0-.5-.5ZM8 1.5A2.75 2.75 0 1 1 8 7a2.75 2.75 0 0 1 0-5.5Zm0 1A1.75 1.75 0 1 0 8 6a1.75 1.75 0 0 0 0-3.5Z"]), Bt = /*#__PURE__*/ k("GlobeSearch20Regular", "20", ["M2.05 9.11a8 8 0 1 1 9.72 8.7 1.5 1.5 0 0 0-.2-1.87l-.02-.01c.16-.24.32-.52.47-.84.22-.46.4-1 .56-1.59H9.74c.12-.32.2-.65.23-1h2.82a14.86 14.86 0 0 0 0-5H7.21l-.05.31c-.31-.12-.64-.2-.98-.26l.01-.05H3.46l-.2.6c-.46.26-.87.6-1.21 1.01Zm9.97-4.2C11.41 3.59 10.66 3 10 3c-.66 0-1.4.59-2.02 1.9-.22.47-.4 1.01-.56 1.6h5.16a9.25 9.25 0 0 0-.56-1.6ZM6.4 6.5c.17-.74.4-1.42.68-2.01.19-.4.4-.78.64-1.1A7.02 7.02 0 0 0 3.94 6.5h2.45Zm9.67 7h-2.45c-.17.74-.4 1.42-.68 2.01-.19.4-.4.78-.64 1.1a7.02 7.02 0 0 0 3.77-3.11Zm-2.25-1h2.73a6.98 6.98 0 0 0 0-5h-2.73a15.97 15.97 0 0 1 0 5Zm2.25-6a7.02 7.02 0 0 0-3.77-3.12c.24.33.45.7.64 1.1.27.6.5 1.28.68 2.02h2.45ZM8.3 14.1a3.5 3.5 0 1 0-.7.7l2.55 2.55a.5.5 0 0 0 .7-.7L8.3 14.1ZM8 12a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0Z"]), Vt = /*#__PURE__*/ k("Open16Regular", "16", ["M4.5 3C3.67 3 3 3.67 3 4.5v7c0 .83.67 1.5 1.5 1.5h7c.83 0 1.5-.67 1.5-1.5V9.27a.5.5 0 0 1 1 0v2.23a2.5 2.5 0 0 1-2.5 2.5h-7A2.5 2.5 0 0 1 2 11.5v-7A2.5 2.5 0 0 1 4.5 2h2.23a.5.5 0 0 1 0 1H4.5Zm4.27-.5c0-.28.22-.5.5-.5h4.23c.28 0 .5.22.5.5v4.23a.5.5 0 0 1-1 0V3.71L9.62 7.08a.5.5 0 1 1-.7-.7L12.29 3H9.27a.5.5 0 0 1-.5-.5Z"]), Ht = /*#__PURE__*/ k("Info16Regular", "16", ["M8.5 7.5a.5.5 0 1 0-1 0v3a.5.5 0 0 0 1 0v-3Zm.25-2a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0ZM8 1a7 7 0 1 0 0 14A7 7 0 0 0 8 1ZM2 8a6 6 0 1 1 12 0A6 6 0 0 1 2 8Z"]), Ut = /*#__PURE__*/ k("Add16Regular", "16", ["M8 2c.28 0 .5.22.5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5c0-.28.22-.5.5-.5Z"]), Wt = /*#__PURE__*/ k("BookOpen24Regular", "24", ["M12 19.14c-.5.53-1.21.86-2 .86H3.75C2.78 20 2 19.22 2 18.25V5.75C2 4.78 2.78 4 3.75 4H10c.79 0 1.5.33 2 .86.5-.53 1.21-.86 2-.86h6.25c.97 0 1.75.78 1.75 1.75v12.5c0 .97-.78 1.75-1.75 1.75H14c-.79 0-1.5-.33-2-.86ZM3.5 5.75v12.5c0 .14.11.25.25.25H10c.69 0 1.25-.56 1.25-1.25V6.75c0-.69-.56-1.25-1.25-1.25H3.75a.25.25 0 0 0-.25.25Zm9.25 11.5c0 .69.56 1.25 1.25 1.25h6.25c.14 0 .25-.11.25-.25V5.75a.25.25 0 0 0-.25-.25H14c-.69 0-1.25.56-1.25 1.25v10.5Z"]), Gt = /*#__PURE__*/ k("ArrowDownload16Regular", "16", ["M3.5 13h9a.5.5 0 0 1 .09 1H3.5a.5.5 0 0 1-.09-1h9.09-9ZM7.91 1H8a.5.5 0 0 1 .5.41v8.89l2.68-2.69a.5.5 0 0 1 .64-.06l.07.06c.17.17.2.44.06.64l-.06.07-3.54 3.53a.5.5 0 0 1-.63.06l-.07-.06L4.1 8.32a.5.5 0 0 1 .64-.77l.07.06L7.5 10.3V1.5a.5.5 0 0 1 .41-.5H8h-.09Z"]), Kt = /*#__PURE__*/ k("ArrowLeft16Regular", "16", ["M13.5 8.5a.5.5 0 0 0 0-1H3.8l4.03-3.63a.5.5 0 1 0-.66-.74l-5 4.5a.5.5 0 0 0 0 .74l5 4.5a.5.5 0 1 0 .66-.74L3.8 8.5h9.7Z"]), qt = /*#__PURE__*/ k("ArrowRight16Regular", "16", ["M2.5 7.5a.5.5 0 1 0 0 1h9.7l-4.03 3.63a.5.5 0 1 0 .66.74l5-4.5a.5.5 0 0 0 0-.74l-5-4.5a.5.5 0 0 0-.66.74L12.2 7.5H2.5Z"]), Jt = /*#__PURE__*/ k("Delete16Regular", "16", ["M7 3h2a1 1 0 0 0-2 0ZM6 3a2 2 0 1 1 4 0h4a.5.5 0 0 1 0 1h-.56l-1.2 8.84A2.5 2.5 0 0 1 9.74 15h-3.5a2.5 2.5 0 0 1-2.48-2.16L2.57 4H2a.5.5 0 0 1 0-1h4Zm1 3.5a.5.5 0 0 0-1 0v5a.5.5 0 0 0 1 0v-5ZM9.5 6c.28 0 .5.22.5.5v5a.5.5 0 0 1-1 0v-5c0-.28.22-.5.5-.5Zm-4.74 6.7c.1.75.74 1.3 1.49 1.3h3.5a1.5 1.5 0 0 0 1.5-1.3L12.42 4H3.57l1.19 8.7Z"]), Yt = a({});
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/utils/use-constant.mjs
function Xt(e) {
	let t = _(null);
	return t.current === null && (t.current = e()), t.current;
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/utils/use-isomorphic-effect.mjs
var Zt = typeof window < "u" ? h : f, Qt = /* @__PURE__ */ a(null);
// node_modules/.pnpm/motion-utils@12.39.0/node_modules/motion-utils/dist/es/array.mjs
function $t(e, t) {
	e.indexOf(t) === -1 && e.push(t);
}
function en(e, t) {
	let n = e.indexOf(t);
	n > -1 && e.splice(n, 1);
}
// node_modules/.pnpm/motion-utils@12.39.0/node_modules/motion-utils/dist/es/clamp.mjs
var A = (e, t, n) => n > t ? t : n < e ? e : n;
// node_modules/.pnpm/motion-utils@12.39.0/node_modules/motion-utils/dist/es/format-error-message.mjs
function tn(e, t) {
	return t ? `${e}. For more information and steps for solving, visit https://motion.dev/troubleshooting/${t}` : e;
}
// node_modules/.pnpm/motion-utils@12.39.0/node_modules/motion-utils/dist/es/errors.mjs
var nn = () => {}, j = () => {};
typeof process < "u" && process.env.NODE_ENV !== "production" && (nn = (e, t, n) => {
	!e && typeof console < "u" && console.warn(tn(t, n));
}, j = (e, t, n) => {
	if (!e) throw Error(tn(t, n));
});
// node_modules/.pnpm/motion-utils@12.39.0/node_modules/motion-utils/dist/es/global-config.mjs
var M = {}, rn = (e) => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(e), an = (e) => typeof e == "object" && !!e, on = (e) => /^0[^.\s]+$/u.test(e);
// node_modules/.pnpm/motion-utils@12.39.0/node_modules/motion-utils/dist/es/memo.mjs
/*#__NO_SIDE_EFFECTS__*/
function sn(e) {
	let t;
	return () => (t === void 0 && (t = e()), t);
}
// node_modules/.pnpm/motion-utils@12.39.0/node_modules/motion-utils/dist/es/noop.mjs
var N = /* @__NO_SIDE_EFFECTS__ */ (e) => e, cn = (...e) => e.reduce((e, t) => (n) => t(e(n))), ln = /* @__NO_SIDE_EFFECTS__ */ (e, t, n) => {
	let r = t - e;
	return r ? (n - e) / r : 1;
}, un = class {
	constructor() {
		this.subscriptions = [];
	}
	add(e) {
		return $t(this.subscriptions, e), () => en(this.subscriptions, e);
	}
	notify(e, t, n) {
		let r = this.subscriptions.length;
		if (r) {
			if (r === 1) this.subscriptions[0](e, t, n);
			else for (let i = 0; i < r; i++) {
				let r = this.subscriptions[i];
				r && r(e, t, n);
			}
		}
	}
	getSize() {
		return this.subscriptions.length;
	}
	clear() {
		this.subscriptions.length = 0;
	}
}, P = /* @__NO_SIDE_EFFECTS__ */ (e) => e * 1e3, F = /* @__NO_SIDE_EFFECTS__ */ (e) => e / 1e3, dn = /* @__NO_SIDE_EFFECTS__ */ (e, t) => t ? 1e3 / t * e : 0, fn = /* @__PURE__ */ new Set();
function pn(e, t, n) {
	e || fn.has(t) || (console.warn(tn(t, n)), fn.add(t));
}
// node_modules/.pnpm/motion-utils@12.39.0/node_modules/motion-utils/dist/es/easing/cubic-bezier.mjs
var mn = (e, t, n) => (((1 - 3 * n + 3 * t) * e + (3 * n - 6 * t)) * e + 3 * t) * e, hn = 1e-7, gn = 12;
function _n(e, t, n, r, i) {
	let a, o, s = 0;
	do
		o = t + (n - t) / 2, a = mn(o, r, i) - e, a > 0 ? n = o : t = o;
	while (Math.abs(a) > hn && ++s < gn);
	return o;
}
/*#__NO_SIDE_EFFECTS__*/
function vn(e, t, n, r) {
	if (e === t && n === r) return N;
	let i = (t) => _n(t, 0, 1, e, n);
	return (e) => e === 0 || e === 1 ? e : mn(i(e), t, r);
}
// node_modules/.pnpm/motion-utils@12.39.0/node_modules/motion-utils/dist/es/easing/modifiers/mirror.mjs
var yn = /* @__NO_SIDE_EFFECTS__ */ (e) => (t) => t <= .5 ? e(2 * t) / 2 : (2 - e(2 * (1 - t))) / 2, bn = /* @__NO_SIDE_EFFECTS__ */ (e) => (t) => 1 - e(1 - t), xn = /*@__PURE__*/ vn(.33, 1.53, .69, .99), Sn = /*@__PURE__*/ bn(xn), Cn = /*@__PURE__*/ yn(Sn), wn = (e) => e >= 1 ? 1 : (e *= 2) < 1 ? .5 * Sn(e) : .5 * (2 - 2 ** (-10 * (e - 1))), Tn = (e) => 1 - Math.sin(Math.acos(e)), En = /* @__PURE__ */ bn(Tn), Dn = /* @__PURE__ */ yn(Tn), On = /*@__PURE__*/ vn(.42, 0, 1, 1), kn = /*@__PURE__*/ vn(0, 0, .58, 1), An = /*@__PURE__*/ vn(.42, 0, .58, 1), jn = /* @__NO_SIDE_EFFECTS__ */ (e) => Array.isArray(e) && typeof e[0] != "number", Mn = /* @__NO_SIDE_EFFECTS__ */ (e) => Array.isArray(e) && typeof e[0] == "number", Nn = {
	linear: N,
	easeIn: On,
	easeInOut: An,
	easeOut: kn,
	circIn: Tn,
	circInOut: Dn,
	circOut: En,
	backIn: Sn,
	backInOut: Cn,
	backOut: xn,
	anticipate: wn
}, Pn = (e) => typeof e == "string", Fn = (e) => {
	if (/* @__PURE__ */ Mn(e)) {
		j(e.length === 4, "Cubic bezier arrays must contain four numerical values.", "cubic-bezier-length");
		let [t, n, r, i] = e;
		return /* @__PURE__ */ vn(t, n, r, i);
	}
	return Pn(e) ? (j(Nn[e] !== void 0, `Invalid easing type '${e}'`, "invalid-easing-type"), Nn[e]) : e;
}, In = [
	"setup",
	"read",
	"resolveKeyframes",
	"preUpdate",
	"update",
	"preRender",
	"render",
	"postRender"
];
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/frameloop/render-step.mjs
function Ln(e) {
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = !1, i = !1, a = /* @__PURE__ */ new WeakSet(), o = {
		delta: 0,
		timestamp: 0,
		isProcessing: !1
	};
	function s(t) {
		a.has(t) && (c.schedule(t), e()), t(o);
	}
	let c = {
		schedule: (e, i = !1, o = !1) => {
			let s = o && r ? t : n;
			return i && a.add(e), s.add(e), e;
		},
		cancel: (e) => {
			n.delete(e), a.delete(e);
		},
		process: (e) => {
			if (o = e, r) {
				i = !0;
				return;
			}
			r = !0;
			let a = t;
			t = n, n = a, t.forEach(s), t.clear(), r = !1, i && (i = !1, c.process(e));
		}
	};
	return c;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/frameloop/batcher.mjs
var Rn = 40;
function zn(e, t) {
	let n = !1, r = !0, i = {
		delta: 0,
		timestamp: 0,
		isProcessing: !1
	}, a = () => n = !0, o = In.reduce((e, t) => (e[t] = Ln(a), e), {}), { setup: s, read: c, resolveKeyframes: l, preUpdate: u, update: d, preRender: f, render: p, postRender: m } = o, h = () => {
		let a = M.useManualTiming, o = a ? i.timestamp : performance.now();
		n = !1, a || (i.delta = r ? 1e3 / 60 : Math.max(Math.min(o - i.timestamp, Rn), 1)), i.timestamp = o, i.isProcessing = !0, s.process(i), c.process(i), l.process(i), u.process(i), d.process(i), f.process(i), p.process(i), m.process(i), i.isProcessing = !1, n && t && (r = !1, e(h));
	}, g = () => {
		n = !0, r = !0, i.isProcessing || e(h);
	};
	return {
		schedule: In.reduce((e, t) => {
			let r = o[t];
			return e[t] = (e, t = !1, i = !1) => (n || g(), r.schedule(e, t, i)), e;
		}, {}),
		cancel: (e) => {
			for (let t = 0; t < In.length; t++) o[In[t]].cancel(e);
		},
		state: i,
		steps: o
	};
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/frameloop/frame.mjs
var { schedule: I, cancel: Bn, state: L, steps: Vn } = /* @__PURE__ */ zn(typeof requestAnimationFrame < "u" ? requestAnimationFrame : N, !0), Hn;
function Un() {
	Hn = void 0;
}
var R = {
	now: () => (Hn === void 0 && R.set(L.isProcessing || M.useManualTiming ? L.timestamp : performance.now()), Hn),
	set: (e) => {
		Hn = e, queueMicrotask(Un);
	}
}, Wn = (e) => (t) => typeof t == "string" && t.startsWith(e), Gn = /*@__PURE__*/ Wn("--"), Kn = /*@__PURE__*/ Wn("var(--"), qn = (e) => Kn(e) ? Jn.test(e.split("/*")[0].trim()) : !1, Jn = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu;
function Yn(e) {
	return typeof e == "string" && e.split("/*")[0].includes("var(--");
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/numbers/index.mjs
var Xn = {
	test: (e) => typeof e == "number",
	parse: parseFloat,
	transform: (e) => e
}, Zn = {
	...Xn,
	transform: (e) => A(0, 1, e)
}, Qn = {
	...Xn,
	default: 1
}, $n = (e) => Math.round(e * 1e5) / 1e5, er = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/utils/is-nullish.mjs
function tr(e) {
	return e == null;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/utils/single-color-regex.mjs
var nr = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu, rr = (e, t) => (n) => !!(typeof n == "string" && nr.test(n) && n.startsWith(e) || t && !tr(n) && Object.prototype.hasOwnProperty.call(n, t)), ir = (e, t, n) => (r) => {
	if (typeof r != "string") return r;
	let [i, a, o, s] = r.match(er);
	return {
		[e]: parseFloat(i),
		[t]: parseFloat(a),
		[n]: parseFloat(o),
		alpha: s === void 0 ? 1 : parseFloat(s)
	};
}, ar = (e) => A(0, 255, e), or = {
	...Xn,
	transform: (e) => Math.round(ar(e))
}, sr = {
	test: /*@__PURE__*/ rr("rgb", "red"),
	parse: /*@__PURE__*/ ir("red", "green", "blue"),
	transform: ({ red: e, green: t, blue: n, alpha: r = 1 }) => "rgba(" + or.transform(e) + ", " + or.transform(t) + ", " + or.transform(n) + ", " + $n(Zn.transform(r)) + ")"
};
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/color/hex.mjs
function cr(e) {
	let t = "", n = "", r = "", i = "";
	return e.length > 5 ? (t = e.substring(1, 3), n = e.substring(3, 5), r = e.substring(5, 7), i = e.substring(7, 9)) : (t = e.substring(1, 2), n = e.substring(2, 3), r = e.substring(3, 4), i = e.substring(4, 5), t += t, n += n, r += r, i += i), {
		red: parseInt(t, 16),
		green: parseInt(n, 16),
		blue: parseInt(r, 16),
		alpha: i ? parseInt(i, 16) / 255 : 1
	};
}
var lr = {
	test: /*@__PURE__*/ rr("#"),
	parse: cr,
	transform: sr.transform
}, ur = /* @__NO_SIDE_EFFECTS__ */ (e) => ({
	test: (t) => typeof t == "string" && t.endsWith(e) && t.split(" ").length === 1,
	parse: parseFloat,
	transform: (t) => `${t}${e}`
}), z = /*@__PURE__*/ ur("deg"), B = /*@__PURE__*/ ur("%"), V = /*@__PURE__*/ ur("px"), dr = /*@__PURE__*/ ur("vh"), fr = /*@__PURE__*/ ur("vw"), pr = {
	...B,
	parse: (e) => B.parse(e) / 100,
	transform: (e) => B.transform(e * 100)
}, mr = {
	test: /*@__PURE__*/ rr("hsl", "hue"),
	parse: /*@__PURE__*/ ir("hue", "saturation", "lightness"),
	transform: ({ hue: e, saturation: t, lightness: n, alpha: r = 1 }) => "hsla(" + Math.round(e) + ", " + B.transform($n(t)) + ", " + B.transform($n(n)) + ", " + $n(Zn.transform(r)) + ")"
}, H = {
	test: (e) => sr.test(e) || lr.test(e) || mr.test(e),
	parse: (e) => sr.test(e) ? sr.parse(e) : mr.test(e) ? mr.parse(e) : lr.parse(e),
	transform: (e) => typeof e == "string" ? e : e.hasOwnProperty("red") ? sr.transform(e) : mr.transform(e),
	getAnimatableNone: (e) => {
		let t = H.parse(e);
		return t.alpha = 0, H.transform(t);
	}
}, hr = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/complex/index.mjs
function gr(e) {
	return isNaN(e) && typeof e == "string" && (e.match(er)?.length || 0) + (e.match(hr)?.length || 0) > 0;
}
var _r = "number", vr = "color", yr = "var", br = "var(", xr = "${}", Sr = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;
function Cr(e) {
	let t = e.toString(), n = [], r = {
		color: [],
		number: [],
		var: []
	}, i = [], a = 0;
	return {
		values: n,
		split: t.replace(Sr, (e) => (H.test(e) ? (r.color.push(a), i.push(vr), n.push(H.parse(e))) : e.startsWith(br) ? (r.var.push(a), i.push(yr), n.push(e)) : (r.number.push(a), i.push(_r), n.push(parseFloat(e))), ++a, xr)).split(xr),
		indexes: r,
		types: i
	};
}
function wr(e) {
	return Cr(e).values;
}
function Tr({ split: e, types: t }) {
	let n = e.length;
	return (r) => {
		let i = "";
		for (let a = 0; a < n; a++) if (i += e[a], r[a] !== void 0) {
			let e = t[a];
			i += e === _r ? $n(r[a]) : e === vr ? H.transform(r[a]) : r[a];
		}
		return i;
	};
}
function Er(e) {
	return Tr(Cr(e));
}
var Dr = (e) => typeof e == "number" ? 0 : H.test(e) ? H.getAnimatableNone(e) : e, Or = (e, t) => typeof e == "number" ? t?.trim().endsWith("/") ? e : 0 : Dr(e);
function kr(e) {
	let t = Cr(e);
	return Tr(t)(t.values.map((e, n) => Or(e, t.split[n])));
}
var U = {
	test: gr,
	parse: wr,
	createTransformer: Er,
	getAnimatableNone: kr
};
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/color/hsla-to-rgba.mjs
function Ar(e, t, n) {
	return n < 0 && (n += 1), n > 1 && --n, n < 1 / 6 ? e + (t - e) * 6 * n : n < 1 / 2 ? t : n < 2 / 3 ? e + (t - e) * (2 / 3 - n) * 6 : e;
}
function jr({ hue: e, saturation: t, lightness: n, alpha: r }) {
	e /= 360, t /= 100, n /= 100;
	let i = 0, a = 0, o = 0;
	if (!t) i = a = o = n;
	else {
		let r = n < .5 ? n * (1 + t) : n + t - n * t, s = 2 * n - r;
		i = Ar(s, r, e + 1 / 3), a = Ar(s, r, e), o = Ar(s, r, e - 1 / 3);
	}
	return {
		red: Math.round(i * 255),
		green: Math.round(a * 255),
		blue: Math.round(o * 255),
		alpha: r
	};
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/mix/immediate.mjs
function Mr(e, t) {
	return (n) => n > 0 ? t : e;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/mix/number.mjs
var W = (e, t, n) => e + (t - e) * n, Nr = (e, t, n) => {
	let r = e * e, i = n * (t * t - r) + r;
	return i < 0 ? 0 : Math.sqrt(i);
}, Pr = [
	lr,
	sr,
	mr
], Fr = (e) => Pr.find((t) => t.test(e));
function Ir(e) {
	let t = Fr(e);
	if (nn(!!t, `'${e}' is not an animatable color. Use the equivalent color code instead.`, "color-not-animatable"), !t) return !1;
	let n = t.parse(e);
	return t === mr && (n = jr(n)), n;
}
var Lr = (e, t) => {
	let n = Ir(e), r = Ir(t);
	if (!n || !r) return Mr(e, t);
	let i = { ...n };
	return (e) => (i.red = Nr(n.red, r.red, e), i.green = Nr(n.green, r.green, e), i.blue = Nr(n.blue, r.blue, e), i.alpha = W(n.alpha, r.alpha, e), sr.transform(i));
}, Rr = /* @__PURE__ */ new Set(["none", "hidden"]);
function zr(e, t) {
	return Rr.has(e) ? (n) => n <= 0 ? e : t : (n) => n >= 1 ? t : e;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/mix/complex.mjs
function Br(e, t) {
	return (n) => W(e, t, n);
}
function Vr(e) {
	return typeof e == "number" ? Br : typeof e == "string" ? qn(e) ? Mr : H.test(e) ? Lr : Gr : Array.isArray(e) ? Hr : typeof e == "object" ? H.test(e) ? Lr : Ur : Mr;
}
function Hr(e, t) {
	let n = [...e], r = n.length, i = e.map((e, n) => Vr(e)(e, t[n]));
	return (e) => {
		for (let t = 0; t < r; t++) n[t] = i[t](e);
		return n;
	};
}
function Ur(e, t) {
	let n = {
		...e,
		...t
	}, r = {};
	for (let i in n) e[i] !== void 0 && t[i] !== void 0 && (r[i] = Vr(e[i])(e[i], t[i]));
	return (e) => {
		for (let t in r) n[t] = r[t](e);
		return n;
	};
}
function Wr(e, t) {
	let n = [], r = {
		color: 0,
		var: 0,
		number: 0
	};
	for (let i = 0; i < t.values.length; i++) {
		let a = t.types[i], o = e.indexes[a][r[a]], s = e.values[o] ?? 0;
		n[i] = s, r[a]++;
	}
	return n;
}
var Gr = (e, t) => {
	let n = U.createTransformer(t), r = Cr(e), i = Cr(t);
	return r.indexes.var.length === i.indexes.var.length && r.indexes.color.length === i.indexes.color.length && r.indexes.number.length >= i.indexes.number.length ? Rr.has(e) && !i.values.length || Rr.has(t) && !r.values.length ? zr(e, t) : cn(Hr(Wr(r, i), i.values), n) : (nn(!0, `Complex values '${e}' and '${t}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`, "complex-values-different"), Mr(e, t));
};
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/mix/index.mjs
function Kr(e, t, n) {
	return typeof e == "number" && typeof t == "number" && typeof n == "number" ? W(e, t, n) : Vr(e)(e, t);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/drivers/frame.mjs
var qr = (e) => {
	let t = ({ timestamp: t }) => e(t);
	return {
		start: (e = !0) => I.update(t, e),
		stop: () => Bn(t),
		now: () => L.isProcessing ? L.timestamp : R.now()
	};
}, Jr = (e, t, n = 10) => {
	let r = "", i = Math.max(Math.round(t / n), 2);
	for (let t = 0; t < i; t++) r += Math.round(e(t / (i - 1)) * 1e4) / 1e4 + ", ";
	return `linear(${r.substring(0, r.length - 2)})`;
}, Yr = 2e4;
function Xr(e) {
	let t = 0, n = e.next(t);
	for (; !n.done && t < 2e4;) t += 50, n = e.next(t);
	return t >= 2e4 ? Infinity : t;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/generators/utils/create-generator-easing.mjs
function Zr(e, t = 100, n) {
	let r = n({
		...e,
		keyframes: [0, t]
	}), i = Math.min(Xr(r), Yr);
	return {
		type: "keyframes",
		ease: (e) => r.next(i * e).value / t,
		duration: /* @__PURE__ */ F(i)
	};
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/generators/spring.mjs
var G = {
	stiffness: 100,
	damping: 10,
	mass: 1,
	velocity: 0,
	duration: 800,
	bounce: .3,
	visualDuration: .3,
	restSpeed: {
		granular: .01,
		default: 2
	},
	restDelta: {
		granular: .005,
		default: .5
	},
	minDuration: .01,
	maxDuration: 10,
	minDamping: .05,
	maxDamping: 1
};
function Qr(e, t) {
	return e * Math.sqrt(1 - t * t);
}
var $r = 12;
function ei(e, t, n) {
	let r = n;
	for (let n = 1; n < $r; n++) r -= e(r) / t(r);
	return r;
}
var ti = .001;
function ni({ duration: e = G.duration, bounce: t = G.bounce, velocity: n = G.velocity, mass: r = G.mass }) {
	let i, a;
	nn(e <= /* @__PURE__ */ P(G.maxDuration), "Spring duration must be 10 seconds or less", "spring-duration-limit");
	let o = 1 - t;
	o = A(G.minDamping, G.maxDamping, o), e = A(G.minDuration, G.maxDuration, /* @__PURE__ */ F(e)), o < 1 ? (i = (t) => {
		let r = t * o, i = r * e, a = r - n, s = Qr(t, o), c = Math.exp(-i);
		return ti - a / s * c;
	}, a = (t) => {
		let r = t * o * e, a = r * n + n, s = o ** 2 * t ** 2 * e, c = Math.exp(-r), l = Qr(t ** 2, o);
		return (-i(t) + ti > 0 ? -1 : 1) * ((a - s) * c) / l;
	}) : (i = (t) => -.001 + Math.exp(-t * e) * ((t - n) * e + 1), a = (t) => Math.exp(-t * e) * ((n - t) * (e * e)));
	let s = 5 / e, c = ei(i, a, s);
	if (e = /* @__PURE__ */ P(e), isNaN(c)) return {
		stiffness: G.stiffness,
		damping: G.damping,
		duration: e
	};
	{
		let t = c ** 2 * r;
		return {
			stiffness: t,
			damping: o * 2 * Math.sqrt(r * t),
			duration: e
		};
	}
}
var ri = ["duration", "bounce"], ii = [
	"stiffness",
	"damping",
	"mass"
];
function ai(e, t) {
	return t.some((t) => e[t] !== void 0);
}
function oi(e) {
	let t = {
		velocity: G.velocity,
		stiffness: G.stiffness,
		damping: G.damping,
		mass: G.mass,
		isResolvedFromDuration: !1,
		...e
	};
	if (!ai(e, ii) && ai(e, ri)) {
		if (t.velocity = 0, e.visualDuration) {
			let n = e.visualDuration, r = 2 * Math.PI / (n * 1.2), i = r * r, a = 2 * A(.05, 1, 1 - (e.bounce || 0)) * Math.sqrt(i);
			t = {
				...t,
				mass: G.mass,
				stiffness: i,
				damping: a
			};
		} else {
			let n = ni({
				...e,
				velocity: 0
			});
			t = {
				...t,
				...n,
				mass: G.mass
			}, t.isResolvedFromDuration = !0;
		}
	}
	return t;
}
function si(e = G.visualDuration, t = G.bounce) {
	let n = typeof e == "object" ? e : {
		visualDuration: e,
		keyframes: [0, 1],
		bounce: t
	}, { restSpeed: r, restDelta: i } = n, a = n.keyframes[0], o = n.keyframes[n.keyframes.length - 1], s = {
		done: !1,
		value: a
	}, { stiffness: c, damping: l, mass: u, duration: d, velocity: f, isResolvedFromDuration: p } = oi({
		...n,
		velocity: -/* @__PURE__ */ F(n.velocity || 0)
	}), m = f || 0, h = l / (2 * Math.sqrt(c * u)), g = o - a, _ = /* @__PURE__ */ F(Math.sqrt(c / u)), v = Math.abs(g) < 5;
	r ||= v ? G.restSpeed.granular : G.restSpeed.default, i ||= v ? G.restDelta.granular : G.restDelta.default;
	let y, b, x, S, C, w;
	if (h < 1) x = Qr(_, h), S = (m + h * _ * g) / x, y = (e) => {
		let t = Math.exp(-h * _ * e);
		return o - t * (S * Math.sin(x * e) + g * Math.cos(x * e));
	}, C = h * _ * S + g * x, w = h * _ * g - S * x, b = (e) => Math.exp(-h * _ * e) * (C * Math.sin(x * e) + w * Math.cos(x * e));
	else if (h === 1) {
		y = (e) => o - Math.exp(-_ * e) * (g + (m + _ * g) * e);
		let e = m + _ * g;
		b = (t) => Math.exp(-_ * t) * (_ * e * t - m);
	} else {
		let e = _ * Math.sqrt(h * h - 1);
		y = (t) => {
			let n = Math.exp(-h * _ * t), r = Math.min(e * t, 300);
			return o - n * ((m + h * _ * g) * Math.sinh(r) + e * g * Math.cosh(r)) / e;
		};
		let t = (m + h * _ * g) / e, n = h * _ * t - g * e, r = h * _ * g - t * e;
		b = (t) => {
			let i = Math.exp(-h * _ * t), a = Math.min(e * t, 300);
			return i * (n * Math.sinh(a) + r * Math.cosh(a));
		};
	}
	let T = {
		calculatedDuration: p && d || null,
		velocity: (e) => /* @__PURE__ */ P(b(e)),
		next: (e) => {
			if (!p && h < 1) {
				let t = Math.exp(-h * _ * e), n = Math.sin(x * e), a = Math.cos(x * e), c = o - t * (S * n + g * a), l = /* @__PURE__ */ P(t * (C * n + w * a));
				return s.done = Math.abs(l) <= r && Math.abs(o - c) <= i, s.value = s.done ? o : c, s;
			}
			let t = y(e);
			if (p) s.done = e >= d;
			else {
				let n = /* @__PURE__ */ P(b(e));
				s.done = Math.abs(n) <= r && Math.abs(o - t) <= i;
			}
			return s.value = s.done ? o : t, s;
		},
		toString: () => {
			let e = Math.min(Xr(T), Yr), t = Jr((t) => T.next(e * t).value, e, 30);
			return e + "ms " + t;
		},
		toTransition: () => {}
	};
	return T;
}
si.applyToOptions = (e) => {
	let t = Zr(e, 100, si);
	return e.ease = t.ease, e.duration = /* @__PURE__ */ P(t.duration), e.type = "keyframes", e;
};
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/generators/utils/velocity.mjs
var ci = 5;
function li(e, t, n) {
	let r = Math.max(t - ci, 0);
	return /* @__PURE__ */ dn(n - e(r), t - r);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/generators/inertia.mjs
function ui({ keyframes: e, velocity: t = 0, power: n = .8, timeConstant: r = 325, bounceDamping: i = 10, bounceStiffness: a = 500, modifyTarget: o, min: s, max: c, restDelta: l = .5, restSpeed: u }) {
	let d = e[0], f = {
		done: !1,
		value: d
	}, p = (e) => s !== void 0 && e < s || c !== void 0 && e > c, m = (e) => s === void 0 ? c : c === void 0 || Math.abs(s - e) < Math.abs(c - e) ? s : c, h = n * t, g = d + h, _ = o === void 0 ? g : o(g);
	_ !== g && (h = _ - d);
	let v = (e) => -h * Math.exp(-e / r), y = (e) => _ + v(e), b = (e) => {
		let t = v(e), n = y(e);
		f.done = Math.abs(t) <= l, f.value = f.done ? _ : n;
	}, x, S, C = (e) => {
		p(f.value) && (x = e, S = si({
			keyframes: [f.value, m(f.value)],
			velocity: li(y, e, f.value),
			damping: i,
			stiffness: a,
			restDelta: l,
			restSpeed: u
		}));
	};
	return C(0), {
		calculatedDuration: null,
		next: (e) => {
			let t = !1;
			return !S && x === void 0 && (t = !0, b(e), C(e)), x !== void 0 && e >= x ? S.next(e - x) : (!t && b(e), f);
		}
	};
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/interpolate.mjs
function di(e, t, n) {
	let r = [], i = n || M.mix || Kr, a = e.length - 1;
	for (let n = 0; n < a; n++) {
		let a = i(e[n], e[n + 1]);
		t && (a = cn(Array.isArray(t) ? t[n] || N : t, a)), r.push(a);
	}
	return r;
}
function fi(e, t, { clamp: n = !0, ease: r, mixer: i } = {}) {
	let a = e.length;
	if (j(a === t.length, "Both input and output ranges must be the same length", "range-length"), a === 1) return () => t[0];
	if (a === 2 && t[0] === t[1]) return () => t[1];
	let o = e[0] === e[1];
	e[0] > e[a - 1] && (e = [...e].reverse(), t = [...t].reverse());
	let s = di(t, r, i), c = s.length, l = (n) => {
		if (o && n < e[0]) return t[0];
		let r = 0;
		if (c > 1) for (; r < e.length - 2 && !(n < e[r + 1]); r++);
		let i = /* @__PURE__ */ ln(e[r], e[r + 1], n);
		return s[r](i);
	};
	return n ? (t) => l(A(e[0], e[a - 1], t)) : l;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/offsets/fill.mjs
function pi(e, t) {
	let n = e[e.length - 1];
	for (let r = 1; r <= t; r++) {
		let i = /* @__PURE__ */ ln(0, t, r);
		e.push(W(n, 1, i));
	}
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/offsets/default.mjs
function mi(e) {
	let t = [0];
	return pi(t, e.length - 1), t;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/offsets/time.mjs
function hi(e, t) {
	return e.map((e) => e * t);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/generators/keyframes.mjs
function gi(e, t) {
	return e.map(() => t || An).splice(0, e.length - 1);
}
function _i({ duration: e = 300, keyframes: t, times: n, ease: r = "easeInOut" }) {
	let i = /* @__PURE__ */ jn(r) ? r.map(Fn) : Fn(r), a = {
		done: !1,
		value: t[0]
	}, o = fi(hi(n && n.length === t.length ? n : mi(t), e), t, { ease: Array.isArray(i) ? i : gi(t, i) });
	return {
		calculatedDuration: e,
		next: (t) => (a.value = o(t), a.done = t >= e, a)
	};
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/get-final.mjs
var vi = (e) => e !== null;
function yi(e, { repeat: t, repeatType: n = "loop" }, r, i = 1) {
	let a = e.filter(vi), o = i < 0 || t && n !== "loop" && t % 2 == 1 ? 0 : a.length - 1;
	return !o || r === void 0 ? a[o] : r;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/replace-transition-type.mjs
var bi = {
	decay: ui,
	inertia: ui,
	tween: _i,
	keyframes: _i,
	spring: si
};
function xi(e) {
	typeof e.type == "string" && (e.type = bi[e.type]);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/WithPromise.mjs
var Si = class {
	constructor() {
		this.updateFinished();
	}
	get finished() {
		return this._finished;
	}
	updateFinished() {
		this._finished = new Promise((e) => {
			this.resolve = e;
		});
	}
	notifyFinished() {
		this.resolve();
	}
	then(e, t) {
		return this.finished.then(e, t);
	}
}, Ci = (e) => e / 100, wi = class extends Si {
	constructor(e) {
		super(), this.state = "idle", this.startTime = null, this.isStopped = !1, this.currentTime = 0, this.holdTime = null, this.playbackSpeed = 1, this.delayState = {
			done: !1,
			value: void 0
		}, this.stop = () => {
			let { motionValue: e } = this.options;
			e && e.updatedAt !== R.now() && this.tick(R.now()), this.isStopped = !0, this.state !== "idle" && (this.teardown(), this.options.onStop?.());
		}, this.options = e, this.initAnimation(), this.play(), e.autoplay === !1 && this.pause();
	}
	initAnimation() {
		let { options: e } = this;
		xi(e);
		let { type: t = _i, repeat: n = 0, repeatDelay: r = 0, repeatType: i, velocity: a = 0 } = e, { keyframes: o } = e, s = t || _i;
		process.env.NODE_ENV !== "production" && s !== _i && j(o.length <= 2, `Only two keyframes currently supported with spring and inertia animations. Trying to animate ${o}`, "spring-two-frames"), s !== _i && typeof o[0] != "number" && (this.mixKeyframes = cn(Ci, Kr(o[0], o[1])), o = [0, 100]);
		let c = s({
			...e,
			keyframes: o
		});
		i === "mirror" && (this.mirroredGenerator = s({
			...e,
			keyframes: [...o].reverse(),
			velocity: -a
		})), c.calculatedDuration === null && (c.calculatedDuration = Xr(c));
		let { calculatedDuration: l } = c;
		this.calculatedDuration = l, this.resolvedDuration = l + r, this.totalDuration = this.resolvedDuration * (n + 1) - r, this.generator = c;
	}
	updateTime(e) {
		let t = Math.round(e - this.startTime) * this.playbackSpeed;
		this.currentTime = this.holdTime === null ? t : this.holdTime;
	}
	tick(e, t = !1) {
		let { generator: n, totalDuration: r, mixKeyframes: i, mirroredGenerator: a, resolvedDuration: o, calculatedDuration: s } = this;
		if (this.startTime === null) return n.next(0);
		let { delay: c = 0, keyframes: l, repeat: u, repeatType: d, repeatDelay: f, type: p, onUpdate: m, finalKeyframe: h } = this.options;
		this.speed > 0 ? this.startTime = Math.min(this.startTime, e) : this.speed < 0 && (this.startTime = Math.min(e - r / this.speed, this.startTime)), t ? this.currentTime = e : this.updateTime(e);
		let g = this.currentTime - c * (this.playbackSpeed >= 0 ? 1 : -1), _ = this.playbackSpeed >= 0 ? g < 0 : g > r;
		this.currentTime = Math.max(g, 0), this.state === "finished" && this.holdTime === null && (this.currentTime = r);
		let v = this.currentTime, y = n;
		if (u) {
			let e = Math.min(this.currentTime, r) / o, t = Math.floor(e), n = e % 1;
			!n && e >= 1 && (n = 1), n === 1 && t--, t = Math.min(t, u + 1), t % 2 && (d === "reverse" ? (n = 1 - n, f && (n -= f / o)) : d === "mirror" && (y = a)), v = A(0, 1, n) * o;
		}
		let b;
		_ ? (this.delayState.value = l[0], b = this.delayState) : b = y.next(v), i && !_ && (b.value = i(b.value));
		let { done: x } = b;
		!_ && s !== null && (x = this.playbackSpeed >= 0 ? this.currentTime >= r : this.currentTime <= 0);
		let S = this.holdTime === null && (this.state === "finished" || this.state === "running" && x);
		return S && p !== ui && (b.value = yi(l, this.options, h, this.speed)), m && m(b.value), S && this.finish(), b;
	}
	then(e, t) {
		return this.finished.then(e, t);
	}
	get duration() {
		return /* @__PURE__ */ F(this.calculatedDuration);
	}
	get iterationDuration() {
		let { delay: e = 0 } = this.options || {};
		return this.duration + /* @__PURE__ */ F(e);
	}
	get time() {
		return /* @__PURE__ */ F(this.currentTime);
	}
	set time(e) {
		e = /* @__PURE__ */ P(e), this.currentTime = e, this.startTime === null || this.holdTime !== null || this.playbackSpeed === 0 ? this.holdTime = e : this.driver && (this.startTime = this.driver.now() - e / this.playbackSpeed), this.driver ? this.driver.start(!1) : (this.startTime = 0, this.state = "paused", this.holdTime = e, this.tick(e));
	}
	getGeneratorVelocity() {
		let e = this.currentTime;
		if (e <= 0) return this.options.velocity || 0;
		if (this.generator.velocity) return this.generator.velocity(e);
		let t = this.generator.next(e).value;
		return li((e) => this.generator.next(e).value, e, t);
	}
	get speed() {
		return this.playbackSpeed;
	}
	set speed(e) {
		let t = this.playbackSpeed !== e;
		t && this.driver && this.updateTime(R.now()), this.playbackSpeed = e, t && this.driver && (this.time = /* @__PURE__ */ F(this.currentTime));
	}
	play() {
		if (this.isStopped) return;
		let { driver: e = qr, startTime: t } = this.options;
		this.driver ||= e((e) => this.tick(e)), this.options.onPlay?.();
		let n = this.driver.now();
		this.state === "finished" ? (this.updateFinished(), this.startTime = n) : this.holdTime === null ? this.startTime ||= t ?? n : this.startTime = n - this.holdTime, this.state === "finished" && this.speed < 0 && (this.startTime += this.calculatedDuration), this.holdTime = null, this.state = "running", this.driver.start();
	}
	pause() {
		this.state = "paused", this.updateTime(R.now()), this.holdTime = this.currentTime;
	}
	complete() {
		this.state !== "running" && this.play(), this.state = "finished", this.holdTime = null;
	}
	finish() {
		this.notifyFinished(), this.teardown(), this.state = "finished", this.options.onComplete?.();
	}
	cancel() {
		this.holdTime = null, this.startTime = 0, this.tick(0), this.teardown(), this.options.onCancel?.();
	}
	teardown() {
		this.state = "idle", this.stopDriver(), this.startTime = this.holdTime = null;
	}
	stopDriver() {
		this.driver &&= (this.driver.stop(), void 0);
	}
	sample(e) {
		return this.startTime = 0, this.tick(e, !0);
	}
	attachTimeline(e) {
		return this.options.allowFlatten && (this.options.type = "keyframes", this.options.ease = "linear", this.initAnimation()), this.driver?.stop(), e.observe(this);
	}
};
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/utils/fill-wildcards.mjs
function Ti(e) {
	for (let t = 1; t < e.length; t++) e[t] ?? (e[t] = e[t - 1]);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/dom/parse-transform.mjs
var Ei = (e) => e * 180 / Math.PI, Di = (e) => ki(Ei(Math.atan2(e[1], e[0]))), Oi = {
	x: 4,
	y: 5,
	translateX: 4,
	translateY: 5,
	scaleX: 0,
	scaleY: 3,
	scale: (e) => (Math.abs(e[0]) + Math.abs(e[3])) / 2,
	rotate: Di,
	rotateZ: Di,
	skewX: (e) => Ei(Math.atan(e[1])),
	skewY: (e) => Ei(Math.atan(e[2])),
	skew: (e) => (Math.abs(e[1]) + Math.abs(e[2])) / 2
}, ki = (e) => (e %= 360, e < 0 && (e += 360), e), Ai = Di, ji = (e) => Math.sqrt(e[0] * e[0] + e[1] * e[1]), Mi = (e) => Math.sqrt(e[4] * e[4] + e[5] * e[5]), Ni = {
	x: 12,
	y: 13,
	z: 14,
	translateX: 12,
	translateY: 13,
	translateZ: 14,
	scaleX: ji,
	scaleY: Mi,
	scale: (e) => (ji(e) + Mi(e)) / 2,
	rotateX: (e) => ki(Ei(Math.atan2(e[6], e[5]))),
	rotateY: (e) => ki(Ei(Math.atan2(-e[2], e[0]))),
	rotateZ: Ai,
	rotate: Ai,
	skewX: (e) => Ei(Math.atan(e[4])),
	skewY: (e) => Ei(Math.atan(e[1])),
	skew: (e) => (Math.abs(e[1]) + Math.abs(e[4])) / 2
};
function Pi(e) {
	return +!!e.includes("scale");
}
function Fi(e, t) {
	if (!e || e === "none") return Pi(t);
	let n = e.match(/^matrix3d\(([-\d.e\s,]+)\)$/u), r, i;
	if (n) r = Ni, i = n;
	else {
		let t = e.match(/^matrix\(([-\d.e\s,]+)\)$/u);
		r = Oi, i = t;
	}
	if (!i) return Pi(t);
	let a = r[t], o = i[1].split(",").map(Li);
	return typeof a == "function" ? a(o) : o[a];
}
var Ii = (e, t) => {
	let { transform: n = "none" } = getComputedStyle(e);
	return Fi(n, t);
};
function Li(e) {
	return parseFloat(e.trim());
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/keys-transform.mjs
var Ri = [
	"transformPerspective",
	"x",
	"y",
	"z",
	"translateX",
	"translateY",
	"translateZ",
	"scale",
	"scaleX",
	"scaleY",
	"rotate",
	"rotateX",
	"rotateY",
	"rotateZ",
	"skew",
	"skewX",
	"skewY"
], zi = /* @__PURE__ */ new Set([...Ri, "pathRotation"]), Bi = (e) => e === Xn || e === V, Vi = /* @__PURE__ */ new Set([
	"x",
	"y",
	"z"
]), Hi = Ri.filter((e) => !Vi.has(e));
function Ui(e) {
	let t = [];
	return Hi.forEach((n) => {
		let r = e.getValue(n);
		r !== void 0 && (t.push([n, r.get()]), r.set(+!!n.startsWith("scale")));
	}), t;
}
var Wi = {
	width: ({ x: e }, { paddingLeft: t = "0", paddingRight: n = "0", boxSizing: r }) => {
		let i = e.max - e.min;
		return r === "border-box" ? i : i - parseFloat(t) - parseFloat(n);
	},
	height: ({ y: e }, { paddingTop: t = "0", paddingBottom: n = "0", boxSizing: r }) => {
		let i = e.max - e.min;
		return r === "border-box" ? i : i - parseFloat(t) - parseFloat(n);
	},
	top: (e, { top: t }) => parseFloat(t),
	left: (e, { left: t }) => parseFloat(t),
	bottom: ({ y: e }, { top: t }) => parseFloat(t) + (e.max - e.min),
	right: ({ x: e }, { left: t }) => parseFloat(t) + (e.max - e.min),
	x: (e, { transform: t }) => Fi(t, "x"),
	y: (e, { transform: t }) => Fi(t, "y")
};
Wi.translateX = Wi.x, Wi.translateY = Wi.y;
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/KeyframesResolver.mjs
var Gi = /* @__PURE__ */ new Set(), Ki = !1, qi = !1, Ji = !1;
function Yi() {
	if (qi) {
		let e = Array.from(Gi).filter((e) => e.needsMeasurement), t = new Set(e.map((e) => e.element)), n = /* @__PURE__ */ new Map();
		t.forEach((e) => {
			let t = Ui(e);
			t.length && (n.set(e, t), e.render());
		}), e.forEach((e) => e.measureInitialState()), t.forEach((e) => {
			e.render();
			let t = n.get(e);
			t && t.forEach(([t, n]) => {
				e.getValue(t)?.set(n);
			});
		}), e.forEach((e) => e.measureEndState()), e.forEach((e) => {
			e.suspendedScrollY !== void 0 && window.scrollTo(0, e.suspendedScrollY);
		});
	}
	qi = !1, Ki = !1, Gi.forEach((e) => e.complete(Ji)), Gi.clear();
}
function Xi() {
	Gi.forEach((e) => {
		e.readKeyframes(), e.needsMeasurement && (qi = !0);
	});
}
function Zi() {
	Ji = !0, Xi(), Yi(), Ji = !1;
}
var Qi = class {
	constructor(e, t, n, r, i, a = !1) {
		this.state = "pending", this.isAsync = !1, this.needsMeasurement = !1, this.unresolvedKeyframes = [...e], this.onComplete = t, this.name = n, this.motionValue = r, this.element = i, this.isAsync = a;
	}
	scheduleResolve() {
		this.state = "scheduled", this.isAsync ? (Gi.add(this), Ki || (Ki = !0, I.read(Xi), I.resolveKeyframes(Yi))) : (this.readKeyframes(), this.complete());
	}
	readKeyframes() {
		let { unresolvedKeyframes: e, name: t, element: n, motionValue: r } = this;
		if (e[0] === null) {
			let i = r?.get(), a = e[e.length - 1];
			if (i !== void 0) e[0] = i;
			else if (n && t) {
				let r = n.readValue(t, a);
				r != null && (e[0] = r);
			}
			e[0] === void 0 && (e[0] = a), r && i === void 0 && r.set(e[0]);
		}
		Ti(e);
	}
	setFinalKeyframe() {}
	measureInitialState() {}
	renderEndStyles() {}
	measureEndState() {}
	complete(e = !1) {
		this.state = "complete", this.onComplete(this.unresolvedKeyframes, this.finalKeyframe, e), Gi.delete(this);
	}
	cancel() {
		this.state === "scheduled" && (Gi.delete(this), this.state = "pending");
	}
	resume() {
		this.state === "pending" && this.scheduleResolve();
	}
}, $i = (e) => e.startsWith("--");
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/dom/style-set.mjs
function ea(e, t, n) {
	$i(t) ? e.style.setProperty(t, n) : e.style[t] = n;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/supports/flags.mjs
var ta = {};
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/supports/memo.mjs
function na(e, t) {
	let n = /* @__PURE__ */ sn(e);
	return () => ta[t] ?? n();
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/supports/scroll-timeline.mjs
var ra = /* @__PURE__ */ na(() => window.ScrollTimeline !== void 0, "scrollTimeline"), ia = /*@__PURE__*/ na(() => {
	try {
		document.createElement("div").animate({ opacity: 0 }, { easing: "linear(0, 1)" });
	} catch {
		return !1;
	}
	return !0;
}, "linearEasing"), aa = ([e, t, n, r]) => `cubic-bezier(${e}, ${t}, ${n}, ${r})`, oa = {
	linear: "linear",
	ease: "ease",
	easeIn: "ease-in",
	easeOut: "ease-out",
	easeInOut: "ease-in-out",
	circIn: /*@__PURE__*/ aa([
		0,
		.65,
		.55,
		1
	]),
	circOut: /*@__PURE__*/ aa([
		.55,
		0,
		1,
		.45
	]),
	backIn: /*@__PURE__*/ aa([
		.31,
		.01,
		.66,
		-.59
	]),
	backOut: /*@__PURE__*/ aa([
		.33,
		1.53,
		.69,
		.99
	])
};
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/waapi/easing/map-easing.mjs
function sa(e, t) {
	if (e) return typeof e == "function" ? ia() ? Jr(e, t) : "ease-out" : /* @__PURE__ */ Mn(e) ? aa(e) : Array.isArray(e) ? e.map((e) => sa(e, t) || oa.easeOut) : oa[e];
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/waapi/start-waapi-animation.mjs
function ca(e, t, n, { delay: r = 0, duration: i = 300, repeat: a = 0, repeatType: o = "loop", ease: s = "easeOut", times: c } = {}, l = void 0) {
	let u = { [t]: n };
	c && (u.offset = c);
	let d = sa(s, i);
	Array.isArray(d) && (u.easing = d);
	let f = {
		delay: r,
		duration: i,
		easing: Array.isArray(d) ? "linear" : d,
		fill: "both",
		iterations: a + 1,
		direction: o === "reverse" ? "alternate" : "normal"
	};
	return l && (f.pseudoElement = l), e.animate(u, f);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/generators/utils/is-generator.mjs
function la(e) {
	return typeof e == "function" && "applyToOptions" in e;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/waapi/utils/apply-generator.mjs
function ua({ type: e, ...t }) {
	return la(e) && ia() ? e.applyToOptions(t) : (t.duration ??= 300, t.ease ??= "easeOut", t);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/NativeAnimation.mjs
var da = class extends Si {
	constructor(e) {
		if (super(), this.finishedTime = null, this.isStopped = !1, this.manualStartTime = null, !e) return;
		let { element: t, name: n, keyframes: r, pseudoElement: i, allowFlatten: a = !1, finalKeyframe: o, onComplete: s } = e;
		this.isPseudoElement = !!i, this.allowFlatten = a, this.options = e, j(typeof e.type != "string", "Mini animate() doesn't support \"type\" as a string.", "mini-spring");
		let c = ua(e);
		this.animation = ca(t, n, r, c, i), c.autoplay === !1 && this.animation.pause(), this.animation.onfinish = () => {
			if (this.finishedTime = this.time, !i) {
				let e = yi(r, this.options, o, this.speed);
				this.updateMotionValue && this.updateMotionValue(e), ea(t, n, e), this.animation.cancel();
			}
			s?.(), this.notifyFinished();
		};
	}
	play() {
		this.isStopped || (this.manualStartTime = null, this.animation.play(), this.state === "finished" && this.updateFinished());
	}
	pause() {
		this.animation.pause();
	}
	complete() {
		this.animation.finish?.();
	}
	cancel() {
		try {
			this.animation.cancel();
		} catch {}
	}
	stop() {
		if (this.isStopped) return;
		this.isStopped = !0;
		let { state: e } = this;
		e !== "idle" && e !== "finished" && (this.updateMotionValue ? this.updateMotionValue() : this.commitStyles(), this.isPseudoElement || this.cancel());
	}
	commitStyles() {
		let e = this.options?.element;
		!this.isPseudoElement && e?.isConnected && this.animation.commitStyles?.();
	}
	get duration() {
		let e = this.animation.effect?.getComputedTiming?.().duration || 0;
		return /* @__PURE__ */ F(Number(e));
	}
	get iterationDuration() {
		let { delay: e = 0 } = this.options || {};
		return this.duration + /* @__PURE__ */ F(e);
	}
	get time() {
		return /* @__PURE__ */ F(Number(this.animation.currentTime) || 0);
	}
	set time(e) {
		let t = this.finishedTime !== null;
		this.manualStartTime = null, this.finishedTime = null, this.animation.currentTime = /* @__PURE__ */ P(e), t && this.animation.pause();
	}
	get speed() {
		return this.animation.playbackRate;
	}
	set speed(e) {
		e < 0 && (this.finishedTime = null), this.animation.playbackRate = e;
	}
	get state() {
		return this.finishedTime === null ? this.animation.playState : "finished";
	}
	get startTime() {
		return this.manualStartTime ?? Number(this.animation.startTime);
	}
	set startTime(e) {
		this.manualStartTime = this.animation.startTime = e;
	}
	attachTimeline({ timeline: e, rangeStart: t, rangeEnd: n, observe: r }) {
		return this.allowFlatten && this.animation.effect?.updateTiming({ easing: "linear" }), this.animation.onfinish = null, e && ra() ? (this.animation.timeline = e, t && (this.animation.rangeStart = t), n && (this.animation.rangeEnd = n), N) : r(this);
	}
}, fa = {
	anticipate: wn,
	backInOut: Cn,
	circInOut: Dn
};
function pa(e) {
	return e in fa;
}
function ma(e) {
	typeof e.ease == "string" && pa(e.ease) && (e.ease = fa[e.ease]);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/NativeAnimationExtended.mjs
var ha = 10, ga = class extends da {
	constructor(e) {
		ma(e), xi(e), super(e), e.startTime !== void 0 && e.autoplay !== !1 && (this.startTime = e.startTime), this.options = e;
	}
	updateMotionValue(e) {
		let { motionValue: t, onUpdate: n, onComplete: r, element: i, ...a } = this.options;
		if (!t) return;
		if (e !== void 0) {
			t.set(e);
			return;
		}
		let o = new wi({
			...a,
			autoplay: !1
		}), s = Math.max(ha, R.now() - this.startTime), c = A(0, ha, s - ha), l = o.sample(s).value, { name: u } = this.options;
		i && u && ea(i, u, l), t.setWithVelocity(o.sample(Math.max(0, s - c)).value, l, c), o.stop();
	}
}, _a = (e, t) => t !== "zIndex" && !!(typeof e == "number" || Array.isArray(e) || typeof e == "string" && (U.test(e) || e === "0") && !e.startsWith("url("));
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/can-animate.mjs
function va(e) {
	let t = e[0];
	if (e.length === 1) return !0;
	for (let n = 0; n < e.length; n++) if (e[n] !== t) return !0;
}
function ya(e, t, n, r) {
	let i = e[0];
	if (i === null) return !1;
	if (t === "display" || t === "visibility") return !0;
	let a = e[e.length - 1], o = _a(i, t), s = _a(a, t);
	return nn(o === s, `You are trying to animate ${t} from "${i}" to "${a}". "${o ? a : i}" is not an animatable value.`, "value-not-animatable"), !o || !s ? !1 : va(e) || (n === "spring" || la(n)) && r;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/make-animation-instant.mjs
function ba(e) {
	e.duration = 0, e.type = "keyframes";
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/waapi/utils/accelerated-values.mjs
var xa = /* @__PURE__ */ new Set([
	"opacity",
	"clipPath",
	"filter",
	"transform",
	"backgroundColor"
]), Sa = /^(?:oklch|oklab|lab|lch|color|color-mix|light-dark)\(/;
function Ca(e) {
	for (let t = 0; t < e.length; t++) if (typeof e[t] == "string" && Sa.test(e[t])) return !0;
	return !1;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/waapi/supports/waapi.mjs
var wa = /* @__PURE__ */ new Set([
	"color",
	"backgroundColor",
	"outlineColor",
	"fill",
	"stroke",
	"borderColor",
	"borderTopColor",
	"borderRightColor",
	"borderBottomColor",
	"borderLeftColor"
]), Ta = /*@__PURE__*/ sn(() => Object.hasOwnProperty.call(Element.prototype, "animate"));
function Ea(e) {
	let { motionValue: t, name: n, repeatDelay: r, repeatType: i, damping: a, type: o, keyframes: s } = e, c = t?.owner?.current;
	if (!(c instanceof HTMLElement) && !(c instanceof SVGElement)) return !1;
	let { onUpdate: l, transformTemplate: u } = t.owner.getProps();
	return Ta() && n && (xa.has(n) || wa.has(n) && Ca(s)) && (n !== "transform" || !u) && !l && !r && i !== "mirror" && a !== 0 && o !== "inertia";
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/AsyncMotionValueAnimation.mjs
var Da = 40, Oa = class extends Si {
	constructor({ autoplay: e = !0, delay: t = 0, type: n = "keyframes", repeat: r = 0, repeatDelay: i = 0, repeatType: a = "loop", keyframes: o, name: s, motionValue: c, element: l, ...u }) {
		super(), this.stop = () => {
			this._animation && (this._animation.stop(), this.stopTimeline?.()), this.keyframeResolver?.cancel();
		}, this.createdAt = R.now();
		let d = {
			autoplay: e,
			delay: t,
			type: n,
			repeat: r,
			repeatDelay: i,
			repeatType: a,
			name: s,
			motionValue: c,
			element: l,
			...u
		}, f = l?.KeyframeResolver || Qi;
		this.keyframeResolver = new f(o, (e, t, n) => this.onKeyframesResolved(e, t, d, !n), s, c, l), this.keyframeResolver?.scheduleResolve();
	}
	onKeyframesResolved(e, t, n, r) {
		this.keyframeResolver = void 0;
		let { name: i, type: a, velocity: o, delay: s, isHandoff: c, onUpdate: l } = n;
		this.resolvedAt = R.now();
		let u = !0;
		ya(e, i, a, o) || (u = !1, (M.instantAnimations || !s) && l?.(yi(e, n, t)), e[0] = e[e.length - 1], ba(n), n.repeat = 0);
		let d = {
			startTime: r ? this.resolvedAt && this.resolvedAt - this.createdAt > Da ? this.resolvedAt : this.createdAt : void 0,
			finalKeyframe: t,
			...n,
			keyframes: e
		}, f = u && !c && Ea(d), p = d.motionValue?.owner?.current, m;
		if (f) try {
			m = new ga({
				...d,
				element: p
			});
		} catch {
			m = new wi(d);
		}
		else m = new wi(d);
		m.finished.then(() => {
			this.notifyFinished();
		}).catch(N), this.pendingTimeline &&= (this.stopTimeline = m.attachTimeline(this.pendingTimeline), void 0), this._animation = m;
	}
	get finished() {
		return this._animation ? this.animation.finished : this._finished;
	}
	then(e, t) {
		return this.finished.finally(e).then(() => {});
	}
	get animation() {
		return this._animation || (this.keyframeResolver?.resume(), Zi()), this._animation;
	}
	get duration() {
		return this.animation.duration;
	}
	get iterationDuration() {
		return this.animation.iterationDuration;
	}
	get time() {
		return this.animation.time;
	}
	set time(e) {
		this.animation.time = e;
	}
	get speed() {
		return this.animation.speed;
	}
	get state() {
		return this.animation.state;
	}
	set speed(e) {
		this.animation.speed = e;
	}
	get startTime() {
		return this.animation.startTime;
	}
	attachTimeline(e) {
		return this._animation ? this.stopTimeline = this.animation.attachTimeline(e) : this.pendingTimeline = e, () => this.stop();
	}
	play() {
		this.animation.play();
	}
	pause() {
		this.animation.pause();
	}
	complete() {
		this.animation.complete();
	}
	cancel() {
		this._animation && this.animation.cancel(), this.keyframeResolver?.cancel();
	}
};
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/calc-child-stagger.mjs
function ka(e, t, n, r = 0, i = 1) {
	let a = Array.from(e).sort((e, t) => e.sortNodePosition(t)).indexOf(t), o = e.size, s = (o - 1) * r;
	return typeof n == "function" ? n(a, o) : i === 1 ? a * r : s - a * r;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/index.mjs
var Aa = 30, ja = (e) => !isNaN(parseFloat(e)), Ma = { current: void 0 }, Na = class {
	constructor(e, t = {}) {
		this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (e) => {
			let t = R.now();
			if (this.updatedAt !== t && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(e), this.current !== this.prev && (this.events.change?.notify(this.current), this.dependents)) for (let e of this.dependents) e.dirty();
		}, this.hasAnimated = !1, this.setCurrent(e), this.owner = t.owner;
	}
	setCurrent(e) {
		this.current = e, this.updatedAt = R.now(), this.canTrackVelocity === null && e !== void 0 && (this.canTrackVelocity = ja(this.current));
	}
	setPrevFrameValue(e = this.current) {
		this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt;
	}
	onChange(e) {
		return process.env.NODE_ENV !== "production" && pn(!1, "value.onChange(callback) is deprecated. Switch to value.on(\"change\", callback)."), this.on("change", e);
	}
	on(e, t) {
		this.events[e] || (this.events[e] = new un());
		let n = this.events[e].add(t);
		return e === "change" ? () => {
			n(), I.read(() => {
				this.events.change.getSize() || this.stop();
			});
		} : n;
	}
	clearListeners() {
		for (let e in this.events) this.events[e].clear();
	}
	attach(e, t) {
		this.passiveEffect = e, this.stopPassiveEffect = t;
	}
	set(e) {
		this.passiveEffect ? this.passiveEffect(e, this.updateAndNotify) : this.updateAndNotify(e);
	}
	setWithVelocity(e, t, n) {
		this.set(t), this.prev = void 0, this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt - n;
	}
	jump(e, t = !0) {
		this.updateAndNotify(e), this.prev = e, this.prevUpdatedAt = this.prevFrameValue = void 0, t && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect();
	}
	dirty() {
		this.events.change?.notify(this.current);
	}
	addDependent(e) {
		this.dependents ||= /* @__PURE__ */ new Set(), this.dependents.add(e);
	}
	removeDependent(e) {
		this.dependents && this.dependents.delete(e);
	}
	get() {
		return Ma.current && Ma.current.push(this), this.current;
	}
	getPrevious() {
		return this.prev;
	}
	getVelocity() {
		let e = R.now();
		if (!this.canTrackVelocity || this.prevFrameValue === void 0 || e - this.updatedAt > Aa) return 0;
		let t = Math.min(this.updatedAt - this.prevUpdatedAt, Aa);
		return /* @__PURE__ */ dn(parseFloat(this.current) - parseFloat(this.prevFrameValue), t);
	}
	start(e) {
		return this.stop(), new Promise((t) => {
			this.hasAnimated = !0, this.animation = e(t), this.events.animationStart && this.events.animationStart.notify();
		}).then(() => {
			this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation();
		});
	}
	stop() {
		this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation();
	}
	isAnimating() {
		return !!this.animation;
	}
	clearAnimation() {
		delete this.animation;
	}
	destroy() {
		this.dependents?.clear(), this.events.destroy?.notify(), this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect();
	}
};
function Pa(e, t) {
	return new Na(e, t);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/resolve-transition.mjs
function Fa(e, t) {
	if (e?.inherit && t) {
		let { inherit: n, ...r } = e;
		return {
			...t,
			...r
		};
	}
	return e;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/get-value-transition.mjs
function Ia(e, t) {
	let n = e?.[t] ?? e?.default ?? e;
	return n === e ? n : Fa(n, e);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/default-transitions.mjs
var La = {
	type: "spring",
	stiffness: 500,
	damping: 25,
	restSpeed: 10
}, Ra = (e) => ({
	type: "spring",
	stiffness: 550,
	damping: e === 0 ? 2 * Math.sqrt(550) : 30,
	restSpeed: 10
}), za = {
	type: "keyframes",
	duration: .8
}, Ba = {
	type: "keyframes",
	ease: [
		.25,
		.1,
		.35,
		1
	],
	duration: .3
}, Va = (e, { keyframes: t }) => t.length > 2 ? za : zi.has(e) ? e.startsWith("scale") ? Ra(t[1]) : La : Ba, Ha = /* @__PURE__ */ new Set([
	"when",
	"delay",
	"delayChildren",
	"staggerChildren",
	"staggerDirection",
	"repeat",
	"repeatType",
	"repeatDelay",
	"from",
	"elapsed"
]);
function Ua(e) {
	for (let t in e) if (!Ha.has(t)) return !0;
	return !1;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/interfaces/motion-value.mjs
var Wa = (e, t, n, r = {}, i, a) => (o) => {
	let s = Ia(r, e) || {}, c = s.delay || r.delay || 0, { elapsed: l = 0 } = r;
	l -= /* @__PURE__ */ P(c);
	let u = {
		keyframes: Array.isArray(n) ? n : [null, n],
		ease: "easeOut",
		velocity: t.getVelocity(),
		...s,
		delay: -l,
		onUpdate: (e) => {
			t.set(e), s.onUpdate && s.onUpdate(e);
		},
		onComplete: () => {
			o(), s.onComplete && s.onComplete();
		},
		name: e,
		motionValue: t,
		element: a ? void 0 : i
	};
	Ua(s) || Object.assign(u, Va(e, u)), u.duration &&= /* @__PURE__ */ P(u.duration), u.repeatDelay &&= /* @__PURE__ */ P(u.repeatDelay), u.from !== void 0 && (u.keyframes[0] = u.from);
	let d = !1;
	if ((u.type === !1 || u.duration === 0 && !u.repeatDelay) && (ba(u), u.delay === 0 && (d = !0)), (M.instantAnimations || M.skipAnimations || i?.shouldSkipAnimations || s.skipAnimations) && (d = !0, ba(u), u.delay = 0), u.allowFlatten = !s.type && !s.ease, d && !a && t.get() !== void 0) {
		let e = yi(u.keyframes, s);
		if (e !== void 0) {
			I.update(() => {
				u.onUpdate(e), u.onComplete();
			});
			return;
		}
	}
	return s.isSync ? new wi(u) : new Oa(u);
}, Ga = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
function Ka(e) {
	let t = Ga.exec(e);
	if (!t) return [,];
	let [, n, r, i] = t;
	return [`--${n ?? r}`, i];
}
var qa = 4;
function Ja(e, t, n = 1) {
	j(n <= qa, `Max CSS variable fallback depth detected in property "${e}". This may indicate a circular fallback dependency.`, "max-css-var-depth");
	let [r, i] = Ka(e);
	if (!r) return;
	let a = window.getComputedStyle(t).getPropertyValue(r);
	if (a) {
		let e = a.trim();
		return rn(e) ? parseFloat(e) : e;
	}
	return qn(i) ? Ja(i, t, n + 1) : i;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/resolve-variants.mjs
function Ya(e) {
	let t = [{}, {}];
	return e?.values.forEach((e, n) => {
		t[0][n] = e.get(), t[1][n] = e.getVelocity();
	}), t;
}
function Xa(e, t, n, r) {
	if (typeof t == "function") {
		let [i, a] = Ya(r);
		t = t(n === void 0 ? e.custom : n, i, a);
	}
	if (typeof t == "string" && (t = e.variants && e.variants[t]), typeof t == "function") {
		let [i, a] = Ya(r);
		t = t(n === void 0 ? e.custom : n, i, a);
	}
	return t;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/resolve-dynamic-variants.mjs
function Za(e, t, n) {
	let r = e.getProps();
	return Xa(r, t, n === void 0 ? r.custom : n, e);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/keys-position.mjs
var Qa = /* @__PURE__ */ new Set([
	"width",
	"height",
	"top",
	"left",
	"right",
	"bottom",
	...Ri
]), $a = (e) => Array.isArray(e);
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/setters.mjs
function eo(e, t, n) {
	e.hasValue(t) ? e.getValue(t).set(n) : e.addValue(t, Pa(n));
}
function to(e) {
	return $a(e) ? e[e.length - 1] || 0 : e;
}
function no(e, t) {
	let { transitionEnd: n = {}, transition: r = {}, ...i } = Za(e, t) || {};
	i = {
		...i,
		...n
	};
	for (let t in i) eo(e, t, to(i[t]));
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/utils/is-motion-value.mjs
var K = (e) => !!(e && e.getVelocity);
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/will-change/is.mjs
function ro(e) {
	return !!(K(e) && e.add);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/will-change/add-will-change.mjs
function io(e, t) {
	let n = e.getValue("willChange");
	if (ro(n)) return n.add(t);
	if (!n && M.WillChange) {
		let n = new M.WillChange("auto");
		e.addValue("willChange", n), n.add(t);
	}
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/dom/utils/camel-to-dash.mjs
function ao(e) {
	return e.replace(/([A-Z])/g, (e) => `-${e.toLowerCase()}`);
}
var oo = "data-" + ao("framerAppearId");
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/optimized-appear/get-appear-id.mjs
function so(e) {
	return e.props[oo];
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/interfaces/visual-element-target.mjs
function co({ protectedKeys: e, needsAnimating: t }, n) {
	let r = e.hasOwnProperty(n) && t[n] !== !0;
	return t[n] = !1, r;
}
function lo(e, t, { delay: n = 0, transitionOverride: r, type: i } = {}) {
	let { transition: a, transitionEnd: o, ...s } = t, c = e.getDefaultTransition();
	a = a ? Fa(a, c) : c;
	let l = a?.reduceMotion, u = a?.skipAnimations;
	r && (a = r);
	let d = [], f = i && e.animationState && e.animationState.getState()[i], p = a?.path;
	p && p.animateVisualElement(e, s, a, n, d);
	for (let t in s) {
		let r = e.getValue(t, e.latestValues[t] ?? null), i = s[t];
		if (i === void 0 || f && co(f, t)) continue;
		let o = {
			delay: n,
			...Ia(a || {}, t)
		};
		u && (o.skipAnimations = !0);
		let c = r.get();
		if (c !== void 0 && !r.isAnimating() && !Array.isArray(i) && i === c && !o.velocity) {
			I.update(() => r.set(i));
			continue;
		}
		let p = !1;
		if (window.MotionHandoffAnimation) {
			let n = so(e);
			if (n) {
				let e = window.MotionHandoffAnimation(n, t, I);
				e !== null && (o.startTime = e, p = !0);
			}
		}
		io(e, t);
		let m = l ?? e.shouldReduceMotion;
		r.start(Wa(t, r, i, m && Qa.has(t) ? { type: !1 } : o, e, p));
		let h = r.animation;
		h && d.push(h);
	}
	if (o) {
		let t = () => I.update(() => {
			o && no(e, o);
		});
		d.length ? Promise.all(d).then(t) : t();
	}
	return d;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/interfaces/visual-element-variant.mjs
function uo(e, t, n = {}) {
	let r = Za(e, t, n.type === "exit" ? e.presenceContext?.custom : void 0), { transition: i = e.getDefaultTransition() || {} } = r || {};
	n.transitionOverride && (i = n.transitionOverride);
	let a = r ? () => Promise.all(lo(e, r, n)) : () => Promise.resolve(), o = e.variantChildren && e.variantChildren.size ? (r = 0) => {
		let { delayChildren: a = 0, staggerChildren: o, staggerDirection: s } = i;
		return fo(e, t, r, a, o, s, n);
	} : () => Promise.resolve(), { when: s } = i;
	if (s) {
		let [e, t] = s === "beforeChildren" ? [a, o] : [o, a];
		return e().then(() => t());
	}
	return Promise.all([a(), o(n.delay)]);
}
function fo(e, t, n = 0, r = 0, i = 0, a = 1, o) {
	let s = [];
	for (let c of e.variantChildren) c.notify("AnimationStart", t), s.push(uo(c, t, {
		...o,
		delay: n + (typeof r == "function" ? 0 : r) + ka(e.variantChildren, c, r, i, a)
	}).then(() => c.notify("AnimationComplete", t)));
	return Promise.all(s);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/interfaces/visual-element.mjs
function po(e, t, n = {}) {
	e.notify("AnimationStart", t);
	let r;
	if (Array.isArray(t)) {
		let i = t.map((t) => uo(e, t, n));
		r = Promise.all(i);
	} else if (typeof t == "string") r = uo(e, t, n);
	else {
		let i = typeof t == "function" ? Za(e, t, n.custom) : t;
		r = Promise.all(lo(e, i, n));
	}
	return r.then(() => {
		e.notify("AnimationComplete", t);
	});
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/auto.mjs
var mo = {
	test: (e) => e === "auto",
	parse: (e) => e
}, ho = (e) => (t) => t.test(e), go = [
	Xn,
	V,
	B,
	z,
	fr,
	dr,
	mo
], _o = (e) => go.find(ho(e));
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/utils/is-none.mjs
function vo(e) {
	return typeof e == "number" ? e === 0 : e === null || e === "none" || e === "0" || on(e);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/complex/filter.mjs
var yo = /* @__PURE__ */ new Set([
	"brightness",
	"contrast",
	"saturate",
	"opacity"
]);
function bo(e) {
	let [t, n] = e.slice(0, -1).split("(");
	if (t === "drop-shadow") return e;
	let [r] = n.match(er) || [];
	if (!r) return e;
	let i = n.replace(r, ""), a = +!!yo.has(t);
	return r !== n && (a *= 100), t + "(" + a + i + ")";
}
var xo = /\b([a-z-]*)\(.*?\)/gu, So = {
	...U,
	getAnimatableNone: (e) => {
		let t = e.match(xo);
		return t ? t.map(bo).join(" ") : e;
	}
}, Co = {
	...U,
	getAnimatableNone: (e) => {
		let t = U.parse(e);
		return U.createTransformer(e)(t.map((e) => typeof e == "number" ? 0 : typeof e == "object" ? {
			...e,
			alpha: 1
		} : e));
	}
}, wo = {
	...Xn,
	transform: Math.round
}, To = {
	borderWidth: V,
	borderTopWidth: V,
	borderRightWidth: V,
	borderBottomWidth: V,
	borderLeftWidth: V,
	borderRadius: V,
	borderTopLeftRadius: V,
	borderTopRightRadius: V,
	borderBottomRightRadius: V,
	borderBottomLeftRadius: V,
	width: V,
	maxWidth: V,
	height: V,
	maxHeight: V,
	top: V,
	right: V,
	bottom: V,
	left: V,
	inset: V,
	insetBlock: V,
	insetBlockStart: V,
	insetBlockEnd: V,
	insetInline: V,
	insetInlineStart: V,
	insetInlineEnd: V,
	padding: V,
	paddingTop: V,
	paddingRight: V,
	paddingBottom: V,
	paddingLeft: V,
	paddingBlock: V,
	paddingBlockStart: V,
	paddingBlockEnd: V,
	paddingInline: V,
	paddingInlineStart: V,
	paddingInlineEnd: V,
	margin: V,
	marginTop: V,
	marginRight: V,
	marginBottom: V,
	marginLeft: V,
	marginBlock: V,
	marginBlockStart: V,
	marginBlockEnd: V,
	marginInline: V,
	marginInlineStart: V,
	marginInlineEnd: V,
	fontSize: V,
	backgroundPositionX: V,
	backgroundPositionY: V,
	rotate: z,
	pathRotation: z,
	rotateX: z,
	rotateY: z,
	rotateZ: z,
	scale: Qn,
	scaleX: Qn,
	scaleY: Qn,
	scaleZ: Qn,
	skew: z,
	skewX: z,
	skewY: z,
	distance: V,
	translateX: V,
	translateY: V,
	translateZ: V,
	x: V,
	y: V,
	z: V,
	perspective: V,
	transformPerspective: V,
	opacity: Zn,
	originX: pr,
	originY: pr,
	originZ: V,
	zIndex: wo,
	fillOpacity: Zn,
	strokeOpacity: Zn,
	numOctaves: wo
}, Eo = {
	...To,
	color: H,
	backgroundColor: H,
	outlineColor: H,
	fill: H,
	stroke: H,
	borderColor: H,
	borderTopColor: H,
	borderRightColor: H,
	borderBottomColor: H,
	borderLeftColor: H,
	filter: So,
	WebkitFilter: So,
	mask: Co,
	WebkitMask: Co
}, Do = (e) => Eo[e], Oo = /*@__PURE__*/ new Set([So, Co]);
function ko(e, t) {
	let n = Do(e);
	return Oo.has(n) || (n = U), n.getAnimatableNone ? n.getAnimatableNone(t) : void 0;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/utils/make-none-animatable.mjs
var Ao = /* @__PURE__ */ new Set([
	"auto",
	"none",
	"0"
]);
function jo(e, t, n) {
	let r = 0, i;
	for (; r < e.length && !i;) {
		let t = e[r];
		typeof t == "string" && !Ao.has(t) && Cr(t).values.length && (i = e[r]), r++;
	}
	if (i && n) for (let r of t) e[r] = ko(n, i);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/DOMKeyframesResolver.mjs
var Mo = class extends Qi {
	constructor(e, t, n, r, i) {
		super(e, t, n, r, i, !0);
	}
	readKeyframes() {
		let { unresolvedKeyframes: e, element: t, name: n } = this;
		if (!t || !t.current) return;
		super.readKeyframes();
		for (let n = 0; n < e.length; n++) {
			let r = e[n];
			if (typeof r == "string" && (r = r.trim(), qn(r))) {
				let i = Ja(r, t.current);
				i !== void 0 && (e[n] = i), n === e.length - 1 && (this.finalKeyframe = r);
			}
		}
		if (this.resolveNoneKeyframes(), !Qa.has(n) || e.length !== 2) return;
		let [r, i] = e, a = _o(r), o = _o(i);
		if (Yn(r) !== Yn(i) && Wi[n]) this.needsMeasurement = !0;
		else if (a !== o) {
			if (Bi(a) && Bi(o)) for (let t = 0; t < e.length; t++) {
				let n = e[t];
				typeof n == "string" && (e[t] = parseFloat(n));
			}
			else Wi[n] && (this.needsMeasurement = !0);
		}
	}
	resolveNoneKeyframes() {
		let { unresolvedKeyframes: e, name: t } = this, n = [];
		for (let t = 0; t < e.length; t++) (e[t] === null || vo(e[t])) && n.push(t);
		n.length && jo(e, n, t);
	}
	measureInitialState() {
		let { element: e, unresolvedKeyframes: t, name: n } = this;
		if (!e || !e.current) return;
		n === "height" && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = Wi[n](e.measureViewportBox(), window.getComputedStyle(e.current)), t[0] = this.measuredOrigin;
		let r = t[t.length - 1];
		r !== void 0 && e.getValue(n, r).jump(r, !1);
	}
	measureEndState() {
		let { element: e, name: t, unresolvedKeyframes: n } = this;
		if (!e || !e.current) return;
		let r = e.getValue(t);
		r && r.jump(this.measuredOrigin, !1);
		let i = n.length - 1, a = n[i];
		n[i] = Wi[t](e.measureViewportBox(), window.getComputedStyle(e.current)), a !== null && this.finalKeyframe === void 0 && (this.finalKeyframe = a), this.removedTransforms?.length && this.removedTransforms.forEach(([t, n]) => {
			e.getValue(t).set(n);
		}), this.resolveNoneKeyframes();
	}
}, No = [
	"borderTopLeftRadius",
	"borderTopRightRadius",
	"borderBottomRightRadius",
	"borderBottomLeftRadius"
];
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/resolve-elements.mjs
function Po(e, t, n) {
	if (e == null) return [];
	if (e instanceof EventTarget) return [e];
	if (typeof e == "string") {
		let r = document;
		t && (r = t.current);
		let i = n?.[e] ?? r.querySelectorAll(e);
		return i ? Array.from(i) : [];
	}
	return Array.from(e).filter((e) => e != null);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/utils/get-as-type.mjs
var Fo = (e, t) => t && typeof e == "number" ? t.transform(e) : e;
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/is-html-element.mjs
function Io(e) {
	return an(e) && "offsetHeight" in e && !("ownerSVGElement" in e);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/frameloop/microtask.mjs
var { schedule: Lo, cancel: Ro } = /* @__PURE__ */ zn(queueMicrotask, !1), q = {
	x: !1,
	y: !1
};
function zo() {
	return q.x || q.y;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/gestures/drag/state/set-active.mjs
function Bo(e) {
	return e === "x" || e === "y" ? q[e] ? null : (q[e] = !0, () => {
		q[e] = !1;
	}) : q.x || q.y ? null : (q.x = q.y = !0, () => {
		q.x = q.y = !1;
	});
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/gestures/utils/setup.mjs
function Vo(e, t) {
	let n = Po(e), r = new AbortController();
	return [
		n,
		{
			passive: !0,
			...t,
			signal: r.signal
		},
		() => r.abort()
	];
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/gestures/hover.mjs
function Ho(e) {
	return !(e.pointerType === "touch" || zo());
}
function Uo(e, t, n = {}) {
	let [r, i, a] = Vo(e, n);
	return r.forEach((e) => {
		let n = !1, r = !1, a, o = () => {
			e.removeEventListener("pointerleave", u);
		}, s = (e) => {
			a &&= (a(e), void 0), o();
		}, c = (e) => {
			n = !1, window.removeEventListener("pointerup", c), window.removeEventListener("pointercancel", c), r && (r = !1, s(e));
		}, l = () => {
			n = !0, window.addEventListener("pointerup", c, i), window.addEventListener("pointercancel", c, i);
		}, u = (e) => {
			e.pointerType !== "touch" && (n ? r = !0 : s(e));
		};
		e.addEventListener("pointerenter", (n) => {
			if (!Ho(n)) return;
			r = !1;
			let o = t(e, n);
			typeof o == "function" && (a = o, e.addEventListener("pointerleave", u, i));
		}, i), e.addEventListener("pointerdown", l, i);
	}), a;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/gestures/utils/is-node-or-child.mjs
var Wo = (e, t) => t ? e === t || Wo(e, t.parentElement) : !1, Go = (e) => e.pointerType === "mouse" ? typeof e.button != "number" || e.button <= 0 : e.isPrimary !== !1, Ko = /* @__PURE__ */ new Set([
	"BUTTON",
	"INPUT",
	"SELECT",
	"TEXTAREA",
	"A"
]);
function qo(e) {
	return Ko.has(e.tagName) || e.isContentEditable === !0;
}
var Jo = /* @__PURE__ */ new Set([
	"INPUT",
	"SELECT",
	"TEXTAREA"
]);
function Yo(e) {
	return Jo.has(e.tagName) || e.isContentEditable === !0;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/gestures/press/utils/state.mjs
var Xo = /* @__PURE__ */ new WeakSet();
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/gestures/press/utils/keyboard.mjs
function Zo(e) {
	return (t) => {
		t.key === "Enter" && e(t);
	};
}
function Qo(e, t) {
	e.dispatchEvent(new PointerEvent("pointer" + t, {
		isPrimary: !0,
		bubbles: !0
	}));
}
var $o = (e, t) => {
	let n = e.currentTarget;
	if (!n) return;
	let r = Zo(() => {
		if (Xo.has(n)) return;
		Qo(n, "down");
		let e = Zo(() => {
			Qo(n, "up");
		});
		n.addEventListener("keyup", e, t), n.addEventListener("blur", () => Qo(n, "cancel"), t);
	});
	n.addEventListener("keydown", r, t), n.addEventListener("blur", () => n.removeEventListener("keydown", r), t);
};
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/gestures/press/index.mjs
function es(e) {
	return Go(e) && !zo();
}
var ts = /* @__PURE__ */ new WeakSet();
function ns(e, t, n = {}) {
	let [r, i, a] = Vo(e, n), o = (e) => {
		let r = e.currentTarget;
		if (!es(e) || ts.has(e)) return;
		Xo.add(r), n.stopPropagation && ts.add(e);
		let a = t(r, e), o = {
			...i,
			capture: !0
		}, s = (e, t) => {
			window.removeEventListener("pointerup", c, o), window.removeEventListener("pointercancel", l, o), Xo.has(r) && Xo.delete(r), es(e) && typeof a == "function" && a(e, { success: t });
		}, c = (e) => {
			s(e, r === window || r === document || n.useGlobalTarget || Wo(r, e.target));
		}, l = (e) => {
			s(e, !1);
		};
		window.addEventListener("pointerup", c, o), window.addEventListener("pointercancel", l, o);
	};
	return r.forEach((e) => {
		(n.useGlobalTarget ? window : e).addEventListener("pointerdown", o, i), Io(e) && (e.addEventListener("focus", (e) => $o(e, i)), !qo(e) && !e.hasAttribute("tabindex") && (e.tabIndex = 0));
	}), a;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/is-svg-element.mjs
function rs(e) {
	return an(e) && "ownerSVGElement" in e;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/resize/handle-element.mjs
var is = /* @__PURE__ */ new WeakMap(), as, os = (e, t, n) => (r, i) => i && i[0] ? i[0][e + "Size"] : rs(r) && "getBBox" in r ? r.getBBox()[t] : r[n], ss = /*@__PURE__*/ os("inline", "width", "offsetWidth"), cs = /*@__PURE__*/ os("block", "height", "offsetHeight");
function ls({ target: e, borderBoxSize: t }) {
	is.get(e)?.forEach((n) => {
		n(e, {
			get width() {
				return ss(e, t);
			},
			get height() {
				return cs(e, t);
			}
		});
	});
}
function us(e) {
	e.forEach(ls);
}
function ds() {
	typeof ResizeObserver < "u" && (as = new ResizeObserver(us));
}
function fs(e, t) {
	as || ds();
	let n = Po(e);
	return n.forEach((e) => {
		let n = is.get(e);
		n || (n = /* @__PURE__ */ new Set(), is.set(e, n)), n.add(t), as?.observe(e);
	}), () => {
		n.forEach((e) => {
			let n = is.get(e);
			n?.delete(t), n?.size || as?.unobserve(e);
		});
	};
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/resize/handle-window.mjs
var ps = /* @__PURE__ */ new Set(), ms;
function hs() {
	ms = () => {
		let e = {
			get width() {
				return window.innerWidth;
			},
			get height() {
				return window.innerHeight;
			}
		};
		ps.forEach((t) => t(e));
	}, window.addEventListener("resize", ms);
}
function gs(e) {
	return ps.add(e), ms || hs(), () => {
		ps.delete(e), !ps.size && typeof ms == "function" && (window.removeEventListener("resize", ms), ms = void 0);
	};
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/resize/index.mjs
function _s(e, t) {
	return typeof e == "function" ? gs(e) : fs(e, t);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/stats/buffer.mjs
var vs = {
	value: null,
	addProjectionMetrics: null
};
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/is-svg-svg-element.mjs
function ys(e) {
	return rs(e) && e.tagName === "svg";
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/utils/find.mjs
var bs = [
	...go,
	H,
	U
], xs = (e) => bs.find(ho(e)), Ss = () => ({
	translate: 0,
	scale: 1,
	origin: 0,
	originPoint: 0
}), Cs = () => ({
	x: Ss(),
	y: Ss()
}), ws = () => ({
	min: 0,
	max: 0
}), J = () => ({
	x: ws(),
	y: ws()
}), Ts = /* @__PURE__ */ new WeakMap();
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/is-animation-controls.mjs
function Es(e) {
	return typeof e == "object" && !!e && typeof e.start == "function";
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/is-variant-label.mjs
function Ds(e) {
	return typeof e == "string" || Array.isArray(e);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/variant-props.mjs
var Os = [
	"animate",
	"whileInView",
	"whileFocus",
	"whileHover",
	"whileTap",
	"whileDrag",
	"exit"
], ks = ["initial", ...Os];
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/is-controlling-variants.mjs
function As(e) {
	return Es(e.animate) || ks.some((t) => Ds(e[t]));
}
function js(e) {
	return !!(As(e) || e.variants);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/motion-values.mjs
function Ms(e, t, n) {
	for (let r in t) {
		let i = t[r], a = n[r];
		if (K(i)) e.addValue(r, i);
		else if (K(a)) e.addValue(r, Pa(i, { owner: e }));
		else if (a !== i) {
			if (e.hasValue(r)) {
				let t = e.getValue(r);
				t.liveStyle === !0 ? t.jump(i) : t.hasAnimated || t.set(i);
			} else {
				let t = e.getStaticValue(r);
				e.addValue(r, Pa(t === void 0 ? i : t, { owner: e }));
			}
		}
	}
	for (let r in n) t[r] === void 0 && e.removeValue(r);
	return t;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/reduced-motion/state.mjs
var Ns = { current: null }, Ps = { current: !1 }, Fs = typeof window < "u";
function Is() {
	if (Ps.current = !0, Fs) {
		if (window.matchMedia) {
			let e = window.matchMedia("(prefers-reduced-motion)"), t = () => Ns.current = e.matches;
			e.addEventListener("change", t), t();
		} else Ns.current = !1;
	}
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/VisualElement.mjs
var Ls = [
	"AnimationStart",
	"AnimationComplete",
	"Update",
	"BeforeLayoutMeasure",
	"LayoutMeasure",
	"LayoutAnimationStart",
	"LayoutAnimationComplete"
], Rs = {};
function zs(e) {
	Rs = e;
}
function Bs() {
	return Rs;
}
var Vs = class {
	scrapeMotionValuesFromProps(e, t, n) {
		return {};
	}
	constructor({ parent: e, props: t, presenceContext: n, reducedMotionConfig: r, skipAnimations: i, blockInitialAnimation: a, visualState: o }, s = {}) {
		this.current = null, this.children = /* @__PURE__ */ new Set(), this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.shouldSkipAnimations = !1, this.values = /* @__PURE__ */ new Map(), this.KeyframeResolver = Qi, this.features = {}, this.valueSubscriptions = /* @__PURE__ */ new Map(), this.prevMotionValues = {}, this.hasBeenMounted = !1, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
			this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection));
		}, this.renderScheduledAt = 0, this.scheduleRender = () => {
			let e = R.now();
			this.renderScheduledAt < e && (this.renderScheduledAt = e, I.render(this.render, !1, !0));
		};
		let { latestValues: c, renderState: l } = o;
		this.latestValues = c, this.baseTarget = { ...c }, this.initialValues = t.initial ? { ...c } : {}, this.renderState = l, this.parent = e, this.props = t, this.presenceContext = n, this.depth = e ? e.depth + 1 : 0, this.reducedMotionConfig = r, this.skipAnimationsConfig = i, this.options = s, this.blockInitialAnimation = !!a, this.isControllingVariants = As(t), this.isVariantNode = js(t), this.isVariantNode && (this.variantChildren = /* @__PURE__ */ new Set()), this.manuallyAnimateOnMount = !!(e && e.current);
		let { willChange: u, ...d } = this.scrapeMotionValuesFromProps(t, {}, this);
		for (let e in d) {
			let t = d[e];
			c[e] !== void 0 && K(t) && t.set(c[e]);
		}
	}
	mount(e) {
		if (this.hasBeenMounted) for (let e in this.initialValues) this.values.get(e)?.jump(this.initialValues[e]), this.latestValues[e] = this.initialValues[e];
		this.current = e, Ts.set(e, this), this.projection && !this.projection.instance && this.projection.mount(e), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((e, t) => this.bindToMotionValue(t, e)), this.reducedMotionConfig === "never" ? this.shouldReduceMotion = !1 : this.reducedMotionConfig === "always" ? this.shouldReduceMotion = !0 : (Ps.current || Is(), this.shouldReduceMotion = Ns.current), process.env.NODE_ENV !== "production" && pn(this.shouldReduceMotion !== !0, "You have Reduced Motion enabled on your device. Animations may not appear as expected.", "reduced-motion-disabled"), this.shouldSkipAnimations = this.skipAnimationsConfig ?? !1, this.parent?.addChild(this), this.update(this.props, this.presenceContext), this.hasBeenMounted = !0;
	}
	unmount() {
		this.projection && this.projection.unmount(), Bn(this.notifyUpdate), Bn(this.render), this.valueSubscriptions.forEach((e) => e()), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent?.removeChild(this);
		for (let e in this.events) this.events[e].clear();
		for (let e in this.features) {
			let t = this.features[e];
			t && (t.unmount(), t.isMounted = !1);
		}
		this.current = null;
	}
	addChild(e) {
		this.children.add(e), this.enteringChildren ??= /* @__PURE__ */ new Set(), this.enteringChildren.add(e);
	}
	removeChild(e) {
		this.children.delete(e), this.enteringChildren && this.enteringChildren.delete(e);
	}
	bindToMotionValue(e, t) {
		if (this.valueSubscriptions.has(e) && this.valueSubscriptions.get(e)(), t.accelerate && xa.has(e) && this.current instanceof HTMLElement) {
			let { factory: n, keyframes: r, times: i, ease: a, duration: o } = t.accelerate, s = new da({
				element: this.current,
				name: e,
				keyframes: r,
				times: i,
				ease: a,
				duration: /* @__PURE__ */ P(o)
			}), c = n(s);
			this.valueSubscriptions.set(e, () => {
				c(), s.cancel();
			});
			return;
		}
		let n = zi.has(e);
		n && this.onBindTransform && this.onBindTransform();
		let r = t.on("change", (t) => {
			this.latestValues[e] = t, this.props.onUpdate && I.preRender(this.notifyUpdate), n && this.projection && (this.projection.isTransformDirty = !0), this.scheduleRender();
		}), i;
		typeof window < "u" && window.MotionCheckAppearSync && (i = window.MotionCheckAppearSync(this, e, t)), this.valueSubscriptions.set(e, () => {
			r(), i && i();
		});
	}
	sortNodePosition(e) {
		return !this.current || !this.sortInstanceNodePosition || this.type !== e.type ? 0 : this.sortInstanceNodePosition(this.current, e.current);
	}
	updateFeatures() {
		let e = "animation";
		for (e in Rs) {
			let t = Rs[e];
			if (!t) continue;
			let { isEnabled: n, Feature: r } = t;
			if (!this.features[e] && r && n(this.props) && (this.features[e] = new r(this)), this.features[e]) {
				let t = this.features[e];
				t.isMounted ? t.update() : (t.mount(), t.isMounted = !0);
			}
		}
	}
	triggerBuild() {
		this.build(this.renderState, this.latestValues, this.props);
	}
	measureViewportBox() {
		return this.current ? this.measureInstanceViewportBox(this.current, this.props) : J();
	}
	getStaticValue(e) {
		return this.latestValues[e];
	}
	setStaticValue(e, t) {
		this.latestValues[e] = t;
	}
	update(e, t) {
		(e.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = e, this.prevPresenceContext = this.presenceContext, this.presenceContext = t;
		for (let t = 0; t < Ls.length; t++) {
			let n = Ls[t];
			this.propEventSubscriptions[n] && (this.propEventSubscriptions[n](), delete this.propEventSubscriptions[n]);
			let r = e["on" + n];
			r && (this.propEventSubscriptions[n] = this.on(n, r));
		}
		this.prevMotionValues = Ms(this, this.scrapeMotionValuesFromProps(e, this.prevProps || {}, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue();
	}
	getProps() {
		return this.props;
	}
	getVariant(e) {
		return this.props.variants ? this.props.variants[e] : void 0;
	}
	getDefaultTransition() {
		return this.props.transition;
	}
	getTransformPagePoint() {
		return this.props.transformPagePoint;
	}
	getClosestVariantNode() {
		return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0;
	}
	addVariantChild(e) {
		let t = this.getClosestVariantNode();
		if (t) return t.variantChildren && t.variantChildren.add(e), () => t.variantChildren.delete(e);
	}
	addValue(e, t) {
		let n = this.values.get(e);
		t !== n && (n && this.removeValue(e), this.bindToMotionValue(e, t), this.values.set(e, t), this.latestValues[e] = t.get());
	}
	removeValue(e) {
		this.values.delete(e);
		let t = this.valueSubscriptions.get(e);
		t && (t(), this.valueSubscriptions.delete(e)), delete this.latestValues[e], this.removeValueFromRenderState(e, this.renderState);
	}
	hasValue(e) {
		return this.values.has(e);
	}
	getValue(e, t) {
		if (this.props.values && this.props.values[e]) return this.props.values[e];
		let n = this.values.get(e);
		return n === void 0 && t !== void 0 && (n = Pa(t === null ? void 0 : t, { owner: this }), this.addValue(e, n)), n;
	}
	readValue(e, t) {
		let n = this.latestValues[e] !== void 0 || !this.current ? this.latestValues[e] : this.getBaseTargetFromProps(this.props, e) ?? this.readValueFromInstance(this.current, e, this.options);
		return n != null && (typeof n == "string" && (rn(n) || on(n)) ? n = parseFloat(n) : !xs(n) && U.test(t) && (n = ko(e, t)), this.setBaseTarget(e, K(n) ? n.get() : n)), K(n) ? n.get() : n;
	}
	setBaseTarget(e, t) {
		this.baseTarget[e] = t;
	}
	getBaseTarget(e) {
		let { initial: t } = this.props, n;
		if (typeof t == "string" || typeof t == "object") {
			let r = Xa(this.props, t, this.presenceContext?.custom);
			r && (n = r[e]);
		}
		if (t && n !== void 0) return n;
		let r = this.getBaseTargetFromProps(this.props, e);
		return r !== void 0 && !K(r) ? r : this.initialValues[e] !== void 0 && n === void 0 ? void 0 : this.baseTarget[e];
	}
	on(e, t) {
		return this.events[e] || (this.events[e] = new un()), this.events[e].add(t);
	}
	notify(e, ...t) {
		this.events[e] && this.events[e].notify(...t);
	}
	scheduleRenderMicrotask() {
		Lo.render(this.render);
	}
}, Hs = class extends Vs {
	constructor() {
		super(...arguments), this.KeyframeResolver = Mo;
	}
	sortInstanceNodePosition(e, t) {
		return e.compareDocumentPosition(t) & 2 ? 1 : -1;
	}
	getBaseTargetFromProps(e, t) {
		let n = e.style;
		return n ? n[t] : void 0;
	}
	removeValueFromRenderState(e, { vars: t, style: n }) {
		delete t[e], delete n[e];
	}
	handleChildMotionValue() {
		this.childSubscription && (this.childSubscription(), delete this.childSubscription);
		let { children: e } = this.props;
		K(e) && (this.childSubscription = e.on("change", (e) => {
			this.current && (this.current.textContent = `${e}`);
		}));
	}
}, Us = class {
	constructor(e) {
		this.isMounted = !1, this.node = e;
	}
	update() {}
};
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/geometry/conversion.mjs
function Ws({ top: e, left: t, right: n, bottom: r }) {
	return {
		x: {
			min: t,
			max: n
		},
		y: {
			min: e,
			max: r
		}
	};
}
function Gs({ x: e, y: t }) {
	return {
		top: t.min,
		right: e.max,
		bottom: t.max,
		left: e.min
	};
}
function Ks(e, t) {
	if (!t) return e;
	let n = t({
		x: e.left,
		y: e.top
	}), r = t({
		x: e.right,
		y: e.bottom
	});
	return {
		top: n.y,
		left: n.x,
		bottom: r.y,
		right: r.x
	};
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/utils/has-transform.mjs
function qs(e) {
	return e === void 0 || e === 1;
}
function Js({ scale: e, scaleX: t, scaleY: n }) {
	return !qs(e) || !qs(t) || !qs(n);
}
function Ys(e) {
	return Js(e) || Xs(e) || e.z || e.rotate || e.rotateX || e.rotateY || e.skewX || e.skewY;
}
function Xs(e) {
	return Zs(e.x) || Zs(e.y);
}
function Zs(e) {
	return e && e !== "0%";
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/geometry/delta-apply.mjs
function Qs(e, t, n) {
	return n + t * (e - n);
}
function $s(e, t, n, r, i) {
	return i !== void 0 && (e = Qs(e, i, r)), Qs(e, n, r) + t;
}
function ec(e, t = 0, n = 1, r, i) {
	e.min = $s(e.min, t, n, r, i), e.max = $s(e.max, t, n, r, i);
}
function tc(e, { x: t, y: n }) {
	ec(e.x, t.translate, t.scale, t.originPoint), ec(e.y, n.translate, n.scale, n.originPoint);
}
var nc = .999999999999, rc = 1.0000000000001;
function ic(e, t, n, r = !1) {
	let i = n.length;
	if (!i) return;
	t.x = t.y = 1;
	let a, o;
	for (let s = 0; s < i; s++) {
		a = n[s], o = a.projectionDelta;
		let { visualElement: i } = a.options;
		i && i.props.style && i.props.style.display === "contents" || (r && a.options.layoutScroll && a.scroll && a !== a.root && (Y(e.x, -a.scroll.offset.x), Y(e.y, -a.scroll.offset.y)), o && (t.x *= o.x.scale, t.y *= o.y.scale, tc(e, o)), r && Ys(a.latestValues) && sc(e, a.latestValues, a.layout?.layoutBox));
	}
	t.x < rc && t.x > nc && (t.x = 1), t.y < rc && t.y > nc && (t.y = 1);
}
function Y(e, t) {
	e.min += t, e.max += t;
}
function ac(e, t, n, r, i = .5) {
	ec(e, t, n, W(e.min, e.max, i), r);
}
function oc(e, t) {
	return typeof e == "string" ? parseFloat(e) / 100 * (t.max - t.min) : e;
}
function sc(e, t, n) {
	let r = n ?? e;
	ac(e.x, oc(t.x, r.x), t.scaleX, t.scale, t.originX), ac(e.y, oc(t.y, r.y), t.scaleY, t.scale, t.originY);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/utils/measure.mjs
function cc(e, t) {
	return Ws(Ks(e.getBoundingClientRect(), t));
}
function lc(e, t, n) {
	let r = cc(e, n), { scroll: i } = t;
	return i && (Y(r.x, i.offset.x), Y(r.y, i.offset.y)), r;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/html/utils/build-transform.mjs
var uc = {
	x: "translateX",
	y: "translateY",
	z: "translateZ",
	transformPerspective: "perspective"
}, dc = Ri.length;
function fc(e, t, n) {
	let r = "", i = !0;
	for (let a = 0; a < dc; a++) {
		let o = Ri[a], s = e[o];
		if (s === void 0) continue;
		let c = !0;
		if (typeof s == "number") c = s === +!!o.startsWith("scale");
		else {
			let e = parseFloat(s);
			c = o.startsWith("scale") ? e === 1 : e === 0;
		}
		if (!c || n) {
			let e = Fo(s, To[o]);
			if (!c) {
				i = !1;
				let t = uc[o] || o;
				r += `${t}(${e}) `;
			}
			n && (t[o] = e);
		}
	}
	let a = e.pathRotation;
	return a && (i = !1, r += `rotate(${Fo(a, To.pathRotation)}) `), r = r.trim(), n ? r = n(t, i ? "" : r) : i && (r = "none"), r;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/html/utils/build-styles.mjs
function pc(e, t, n) {
	let { style: r, vars: i, transformOrigin: a } = e, o = !1, s = !1;
	for (let e in t) {
		let n = t[e];
		if (zi.has(e)) o = !0;
		else if (Gn(e)) i[e] = n;
		else {
			let t = Fo(n, To[e]);
			e.startsWith("origin") ? (s = !0, a[e] = t) : r[e] = t;
		}
	}
	if (t.transform || (o || n ? r.transform = fc(t, e.transform, n) : r.transform &&= "none"), s) {
		let { originX: e = "50%", originY: t = "50%", originZ: n = 0 } = a;
		r.transformOrigin = `${e} ${t} ${n}`;
	}
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/html/utils/render.mjs
function mc(e, { style: t, vars: n }, r, i) {
	let a = e.style, o;
	for (o in t) a[o] = t[o];
	for (o in i?.applyProjectionStyles(a, r), n) a.setProperty(o, n[o]);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/styles/scale-border-radius.mjs
function hc(e, t) {
	return t.max === t.min ? 0 : e / (t.max - t.min) * 100;
}
var gc = { correct: (e, t) => {
	if (!t.target) return e;
	if (typeof e == "string") {
		if (V.test(e)) e = parseFloat(e);
		else return e;
	}
	return `${hc(e, t.target.x)}% ${hc(e, t.target.y)}%`;
} }, _c = { correct: (e, { treeScale: t, projectionDelta: n }) => {
	let r = e, i = U.parse(e);
	if (i.length > 5) return r;
	let a = U.createTransformer(e), o = typeof i[0] == "number" ? 0 : 1, s = n.x.scale * t.x, c = n.y.scale * t.y;
	i[0 + o] /= s, i[1 + o] /= c;
	let l = W(s, c, .5);
	return typeof i[2 + o] == "number" && (i[2 + o] /= l), typeof i[3 + o] == "number" && (i[3 + o] /= l), a(i);
} }, vc = {
	borderRadius: {
		...gc,
		applyTo: [...No]
	},
	borderTopLeftRadius: gc,
	borderTopRightRadius: gc,
	borderBottomLeftRadius: gc,
	borderBottomRightRadius: gc,
	boxShadow: _c
};
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/is-forced-motion-value.mjs
function yc(e, { layout: t, layoutId: n }) {
	return zi.has(e) || e.startsWith("origin") || (t || n !== void 0) && (!!vc[e] || e === "opacity");
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/html/utils/scrape-motion-values.mjs
function bc(e, t, n) {
	let r = e.style, i = t?.style, a = {};
	if (!r) return a;
	for (let t in r) (K(r[t]) || i && K(i[t]) || yc(t, e) || n?.getValue(t)?.liveStyle !== void 0) && (a[t] = r[t]);
	return a;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/html/HTMLVisualElement.mjs
function xc(e) {
	return window.getComputedStyle(e);
}
var Sc = class extends Hs {
	constructor() {
		super(...arguments), this.type = "html", this.renderInstance = mc;
	}
	mount(e) {
		j(!!e.style, "motion.create() components must forward their ref to a HTML or SVG element", "custom-component-ref"), super.mount(e);
	}
	readValueFromInstance(e, t) {
		if (zi.has(t)) return this.projection?.isProjecting ? Pi(t) : Ii(e, t);
		{
			let n = xc(e), r = (Gn(t) ? n.getPropertyValue(t) : n[t]) || 0;
			return typeof r == "string" ? r.trim() : r;
		}
	}
	measureInstanceViewportBox(e, { transformPagePoint: t }) {
		return cc(e, t);
	}
	build(e, t, n) {
		pc(e, t, n.transformTemplate);
	}
	scrapeMotionValuesFromProps(e, t, n) {
		return bc(e, t, n);
	}
}, Cc = {
	offset: "stroke-dashoffset",
	array: "stroke-dasharray"
}, wc = {
	offset: "strokeDashoffset",
	array: "strokeDasharray"
};
function Tc(e, t, n = 1, r = 0, i = !0) {
	e.pathLength = 1;
	let a = i ? Cc : wc;
	e[a.offset] = `${-r}`, e[a.array] = `${t} ${n}`;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/svg/utils/build-attrs.mjs
var Ec = [
	"offsetDistance",
	"offsetPath",
	"offsetRotate",
	"offsetAnchor"
];
function Dc(e, { attrX: t, attrY: n, attrScale: r, pathLength: i, pathSpacing: a = 1, pathOffset: o = 0, ...s }, c, l, u) {
	if (pc(e, s, l), c) {
		e.style.viewBox && (e.attrs.viewBox = e.style.viewBox);
		return;
	}
	e.attrs = e.style, e.style = {};
	let { attrs: d, style: f } = e;
	d.transform && (f.transform = d.transform, delete d.transform), (f.transform || d.transformOrigin) && (f.transformOrigin = d.transformOrigin ?? "50% 50%", delete d.transformOrigin), f.transform && (f.transformBox = u?.transformBox ?? "fill-box", delete d.transformBox);
	for (let e of Ec) d[e] !== void 0 && (f[e] = d[e], delete d[e]);
	t !== void 0 && (d.x = t), n !== void 0 && (d.y = n), r !== void 0 && (d.scale = r), i !== void 0 && Tc(d, i, a, o, !1);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/svg/utils/camel-case-attrs.mjs
var Oc = /* @__PURE__ */ new Set([
	"baseFrequency",
	"diffuseConstant",
	"kernelMatrix",
	"kernelUnitLength",
	"keySplines",
	"keyTimes",
	"limitingConeAngle",
	"markerHeight",
	"markerWidth",
	"numOctaves",
	"targetX",
	"targetY",
	"surfaceScale",
	"specularConstant",
	"specularExponent",
	"stdDeviation",
	"tableValues",
	"viewBox",
	"gradientTransform",
	"pathLength",
	"startOffset",
	"textLength",
	"lengthAdjust"
]), kc = (e) => typeof e == "string" && e.toLowerCase() === "svg";
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/svg/utils/render.mjs
function Ac(e, t, n, r) {
	mc(e, t, void 0, r);
	for (let n in t.attrs) e.setAttribute(Oc.has(n) ? n : ao(n), t.attrs[n]);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/svg/utils/scrape-motion-values.mjs
function jc(e, t, n) {
	let r = bc(e, t, n);
	for (let n in e) if (K(e[n]) || K(t[n])) {
		let t = Ri.indexOf(n) === -1 ? n : "attr" + n.charAt(0).toUpperCase() + n.substring(1);
		r[t] = e[n];
	}
	return r;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/svg/SVGVisualElement.mjs
var Mc = class extends Hs {
	constructor() {
		super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = J;
	}
	getBaseTargetFromProps(e, t) {
		return e[t];
	}
	readValueFromInstance(e, t) {
		if (zi.has(t)) {
			let e = Do(t);
			return e && e.default || 0;
		}
		return t = Oc.has(t) ? t : ao(t), e.getAttribute(t);
	}
	scrapeMotionValuesFromProps(e, t, n) {
		return jc(e, t, n);
	}
	build(e, t, n) {
		Dc(e, t, this.isSVGTag, n.transformTemplate, n.style);
	}
	renderInstance(e, t, n, r) {
		Ac(e, t, n, r);
	}
	mount(e) {
		this.isSVGTag = kc(e.tagName), super.mount(e);
	}
}, Nc = ks.length;
function Pc(e) {
	if (!e) return;
	if (!e.isControllingVariants) {
		let t = e.parent && Pc(e.parent) || {};
		return e.props.initial !== void 0 && (t.initial = e.props.initial), t;
	}
	let t = {};
	for (let n = 0; n < Nc; n++) {
		let r = ks[n], i = e.props[r];
		(Ds(i) || i === !1) && (t[r] = i);
	}
	return t;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/shallow-compare.mjs
function Fc(e, t) {
	if (!Array.isArray(t)) return !1;
	let n = t.length;
	if (n !== e.length) return !1;
	for (let r = 0; r < n; r++) if (t[r] !== e[r]) return !1;
	return !0;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/animation-state.mjs
var Ic = [...Os].reverse(), Lc = Os.length;
function Rc(e) {
	return (t) => Promise.all(t.map(({ animation: t, options: n }) => po(e, t, n)));
}
function zc(e) {
	let t = Rc(e), n = Hc(), r = !0, i = !1, a = (t) => (n, r) => {
		let i = Za(e, r, t === "exit" ? e.presenceContext?.custom : void 0);
		if (i) {
			let { transition: e, transitionEnd: t, ...r } = i;
			n = {
				...n,
				...r,
				...t
			};
		}
		return n;
	};
	function o(n) {
		t = n(e);
	}
	function s(o) {
		let { props: s } = e, c = Pc(e.parent) || {}, l = [], u = /* @__PURE__ */ new Set(), d = {}, f = Infinity;
		for (let t = 0; t < Lc; t++) {
			let p = Ic[t], m = n[p], h = s[p] === void 0 ? c[p] : s[p], g = Ds(h), _ = p === o ? m.isActive : null;
			_ === !1 && (f = t);
			let v = h === c[p] && h !== s[p] && g;
			if (v && (r || i) && e.manuallyAnimateOnMount && (v = !1), m.protectedKeys = { ...d }, !m.isActive && _ === null || !h && !m.prevProp || Es(h) || typeof h == "boolean") continue;
			if (p === "exit" && m.isActive && _ !== !0) {
				m.prevResolvedValues && (d = {
					...d,
					...m.prevResolvedValues
				});
				continue;
			}
			let y = Bc(m.prevProp, h), b = y || p === o && m.isActive && !v && g || t > f && g, x = !1, S = Array.isArray(h) ? h : [h], C = S.reduce(a(p), {});
			_ === !1 && (C = {});
			let { prevResolvedValues: w = {} } = m, T = {
				...w,
				...C
			}, E = (t) => {
				b = !0, u.has(t) && (x = !0, u.delete(t)), m.needsAnimating[t] = !0;
				let n = e.getValue(t);
				n && (n.liveStyle = !1);
			};
			for (let e in T) {
				let t = C[e], n = w[e];
				if (d.hasOwnProperty(e)) continue;
				let r = !1;
				r = $a(t) && $a(n) ? !Fc(t, n) || y : t !== n, r ? t == null ? u.add(e) : E(e) : t !== void 0 && u.has(e) ? E(e) : m.protectedKeys[e] = !0;
			}
			m.prevProp = h, m.prevResolvedValues = C, m.isActive && (d = {
				...d,
				...C
			}), (r || i) && e.blockInitialAnimation && (b = !1);
			let ee = v && y;
			b && (!ee || x) && l.push(...S.map((t) => {
				let n = { type: p };
				if (typeof t == "string" && (r || i) && !ee && e.manuallyAnimateOnMount && e.parent) {
					let { parent: r } = e, i = Za(r, t);
					if (r.enteringChildren && i) {
						let { delayChildren: t } = i.transition || {};
						n.delay = ka(r.enteringChildren, e, t);
					}
				}
				return {
					animation: t,
					options: n
				};
			}));
		}
		if (u.size) {
			let t = {};
			if (typeof s.initial != "boolean") {
				let n = Za(e, Array.isArray(s.initial) ? s.initial[0] : s.initial);
				n && n.transition && (t.transition = n.transition);
			}
			u.forEach((n) => {
				let r = e.getBaseTarget(n), i = e.getValue(n);
				i && (i.liveStyle = !0), t[n] = r ?? null;
			}), l.push({ animation: t });
		}
		let p = !!l.length;
		return r && (s.initial === !1 || s.initial === s.animate) && !e.manuallyAnimateOnMount && (p = !1), r = !1, i = !1, p ? t(l) : Promise.resolve();
	}
	function c(t, r) {
		if (n[t].isActive === r) return Promise.resolve();
		e.variantChildren?.forEach((e) => e.animationState?.setActive(t, r)), n[t].isActive = r;
		let i = s(t);
		for (let e in n) n[e].protectedKeys = {};
		return i;
	}
	return {
		animateChanges: s,
		setActive: c,
		setAnimateFunction: o,
		getState: () => n,
		reset: () => {
			n = Hc(), i = !0;
		}
	};
}
function Bc(e, t) {
	return typeof t == "string" ? t !== e : Array.isArray(t) ? !Fc(t, e) : !1;
}
function Vc(e = !1) {
	return {
		isActive: e,
		protectedKeys: {},
		needsAnimating: {},
		prevResolvedValues: {}
	};
}
function Hc() {
	return {
		animate: Vc(!0),
		whileInView: Vc(),
		whileHover: Vc(),
		whileTap: Vc(),
		whileDrag: Vc(),
		whileFocus: Vc(),
		exit: Vc()
	};
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/geometry/copy.mjs
function Uc(e, t) {
	e.min = t.min, e.max = t.max;
}
function X(e, t) {
	Uc(e.x, t.x), Uc(e.y, t.y);
}
function Wc(e, t) {
	e.translate = t.translate, e.scale = t.scale, e.originPoint = t.originPoint, e.origin = t.origin;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/geometry/delta-calc.mjs
var Gc = .9999, Kc = 1.0001, qc = -.01, Jc = .01;
function Z(e) {
	return e.max - e.min;
}
function Yc(e, t, n) {
	return Math.abs(e - t) <= n;
}
function Xc(e, t, n, r = .5) {
	e.origin = r, e.originPoint = W(t.min, t.max, e.origin), e.scale = Z(n) / Z(t), e.translate = W(n.min, n.max, e.origin) - e.originPoint, (e.scale >= Gc && e.scale <= Kc || isNaN(e.scale)) && (e.scale = 1), (e.translate >= qc && e.translate <= Jc || isNaN(e.translate)) && (e.translate = 0);
}
function Zc(e, t, n, r) {
	Xc(e.x, t.x, n.x, r ? r.originX : void 0), Xc(e.y, t.y, n.y, r ? r.originY : void 0);
}
function Qc(e, t, n, r = 0) {
	e.min = (r ? W(n.min, n.max, r) : n.min) + t.min, e.max = e.min + Z(t);
}
function $c(e, t, n, r) {
	Qc(e.x, t.x, n.x, r?.x), Qc(e.y, t.y, n.y, r?.y);
}
function el(e, t, n, r = 0) {
	let i = r ? W(n.min, n.max, r) : n.min;
	e.min = t.min - i, e.max = e.min + Z(t);
}
function tl(e, t, n, r) {
	el(e.x, t.x, n.x, r?.x), el(e.y, t.y, n.y, r?.y);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/geometry/delta-remove.mjs
function nl(e, t, n, r, i) {
	return e -= t, e = Qs(e, 1 / n, r), i !== void 0 && (e = Qs(e, 1 / i, r)), e;
}
function rl(e, t = 0, n = 1, r = .5, i, a = e, o = e) {
	if (B.test(t) && (t = parseFloat(t), t = W(o.min, o.max, t / 100) - o.min), typeof t != "number") return;
	let s = W(a.min, a.max, r);
	e === a && (s -= t), e.min = nl(e.min, t, n, s, i), e.max = nl(e.max, t, n, s, i);
}
function il(e, t, [n, r, i], a, o) {
	rl(e, t[n], t[r], t[i], t.scale, a, o);
}
var al = [
	"x",
	"scaleX",
	"originX"
], ol = [
	"y",
	"scaleY",
	"originY"
];
function sl(e, t, n, r) {
	il(e.x, t, al, n ? n.x : void 0, r ? r.x : void 0), il(e.y, t, ol, n ? n.y : void 0, r ? r.y : void 0);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/geometry/utils.mjs
function cl(e) {
	return e.translate === 0 && e.scale === 1;
}
function ll(e) {
	return cl(e.x) && cl(e.y);
}
function ul(e, t) {
	return e.min === t.min && e.max === t.max;
}
function dl(e, t) {
	return ul(e.x, t.x) && ul(e.y, t.y);
}
function fl(e, t) {
	return Math.round(e.min) === Math.round(t.min) && Math.round(e.max) === Math.round(t.max);
}
function pl(e, t) {
	return fl(e.x, t.x) && fl(e.y, t.y);
}
function ml(e) {
	return Z(e.x) / Z(e.y);
}
function hl(e, t) {
	return e.translate === t.translate && e.scale === t.scale && e.originPoint === t.originPoint;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/utils/each-axis.mjs
function Q(e) {
	return [e("x"), e("y")];
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/styles/transform.mjs
function gl(e, t, n) {
	let r = "", i = e.x.translate / t.x, a = e.y.translate / t.y, o = n?.z || 0;
	if ((i || a || o) && (r = `translate3d(${i}px, ${a}px, ${o}px) `), (t.x !== 1 || t.y !== 1) && (r += `scale(${1 / t.x}, ${1 / t.y}) `), n) {
		let { transformPerspective: e, rotate: t, pathRotation: i, rotateX: a, rotateY: o, skewX: s, skewY: c } = n;
		e && (r = `perspective(${e}px) ${r}`), t && (r += `rotate(${t}deg) `), i && (r += `rotate(${i}deg) `), a && (r += `rotateX(${a}deg) `), o && (r += `rotateY(${o}deg) `), s && (r += `skewX(${s}deg) `), c && (r += `skewY(${c}deg) `);
	}
	let s = e.x.scale * t.x, c = e.y.scale * t.y;
	return (s !== 1 || c !== 1) && (r += `scale(${s}, ${c})`), r || "none";
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/animation/mix-values.mjs
var _l = No.length, vl = (e) => typeof e == "string" ? parseFloat(e) : e, yl = (e) => typeof e == "number" || V.test(e);
function bl(e, t, n, r, i, a) {
	i ? (e.opacity = W(0, n.opacity ?? 1, Sl(r)), e.opacityExit = W(t.opacity ?? 1, 0, Cl(r))) : a && (e.opacity = W(t.opacity ?? 1, n.opacity ?? 1, r));
	for (let i = 0; i < _l; i++) {
		let a = No[i], o = xl(t, a), s = xl(n, a);
		(o !== void 0 || s !== void 0) && (o ||= 0, s ||= 0, o === 0 || s === 0 || yl(o) === yl(s) ? (e[a] = Math.max(W(vl(o), vl(s), r), 0), (B.test(s) || B.test(o)) && (e[a] += "%")) : e[a] = s);
	}
	(t.rotate || n.rotate) && (e.rotate = W(t.rotate || 0, n.rotate || 0, r));
}
function xl(e, t) {
	return e[t] === void 0 ? e.borderRadius : e[t];
}
var Sl = /*@__PURE__*/ wl(0, .5, En), Cl = /*@__PURE__*/ wl(.5, .95, N);
function wl(e, t, n) {
	return (r) => r < e ? 0 : r > t ? 1 : n(/* @__PURE__ */ ln(e, t, r));
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/animate/single-value.mjs
function Tl(e, t, n) {
	let r = K(e) ? e : Pa(e);
	return r.start(Wa("", r, t, n)), r.animation;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/events/add-dom-event.mjs
function El(e, t, n, r = { passive: !0 }) {
	return e.addEventListener(t, n, r), () => e.removeEventListener(t, n, r);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/utils/compare-by-depth.mjs
var Dl = (e, t) => e.depth - t.depth, Ol = class {
	constructor() {
		this.children = [], this.isDirty = !1;
	}
	add(e) {
		$t(this.children, e), this.isDirty = !0;
	}
	remove(e) {
		en(this.children, e), this.isDirty = !0;
	}
	forEach(e) {
		this.isDirty && this.children.sort(Dl), this.isDirty = !1, this.children.forEach(e);
	}
};
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/delay.mjs
function kl(e, t) {
	let n = R.now(), r = ({ timestamp: i }) => {
		let a = i - n;
		a >= t && (Bn(r), e(a - t));
	};
	return I.setup(r, !0), () => Bn(r);
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/utils/resolve-motion-value.mjs
function Al(e) {
	return K(e) ? e.get() : e;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/shared/stack.mjs
var jl = class {
	constructor() {
		this.members = [];
	}
	add(e) {
		$t(this.members, e);
		for (let t = this.members.length - 1; t >= 0; t--) {
			let n = this.members[t];
			if (n === e || n === this.lead || n === this.prevLead) continue;
			let r = n.instance;
			r && r.isConnected !== !1 || n.snapshot || (en(this.members, n), n.unmount());
		}
		e.scheduleRender();
	}
	remove(e) {
		if (en(this.members, e), e === this.prevLead && (this.prevLead = void 0), e === this.lead) {
			let e = this.members[this.members.length - 1];
			e && this.promote(e);
		}
	}
	relegate(e) {
		for (let t = this.members.indexOf(e) - 1; t >= 0; t--) {
			let e = this.members[t];
			if (e.isPresent !== !1 && e.instance?.isConnected !== !1) return this.promote(e), !0;
		}
		return !1;
	}
	promote(e, t) {
		let n = this.lead;
		if (e !== n && (this.prevLead = n, this.lead = e, e.show(), n)) {
			n.updateSnapshot(), e.scheduleRender();
			let { layoutDependency: r } = n.options, { layoutDependency: i } = e.options;
			(r === void 0 || r !== i) && (e.resumeFrom = n, t && (n.preserveOpacity = !0), n.snapshot && (e.snapshot = n.snapshot, e.snapshot.latestValues = n.animationValues || n.latestValues), e.root?.isUpdating && (e.isLayoutDirty = !0)), e.options.crossfade === !1 && n.hide();
		}
	}
	exitAnimationComplete() {
		this.members.forEach((e) => {
			e.options.onExitComplete?.(), e.resumingFrom?.options.onExitComplete?.();
		});
	}
	scheduleRender() {
		this.members.forEach((e) => e.instance && e.scheduleRender(!1));
	}
	removeLeadSnapshot() {
		this.lead?.snapshot && (this.lead.snapshot = void 0);
	}
}, Ml = {
	hasAnimatedSinceResize: !0,
	hasEverUpdated: !1
}, Nl = {
	nodes: 0,
	calculatedTargetDeltas: 0,
	calculatedProjections: 0
}, Pl = [
	"",
	"X",
	"Y",
	"Z"
], Fl = 1e3, Il = 0;
function Ll(e, t, n, r) {
	let { latestValues: i } = t;
	i[e] && (n[e] = i[e], t.setStaticValue(e, 0), r && (r[e] = 0));
}
function Rl(e) {
	if (e.hasCheckedOptimisedAppear = !0, e.root === e) return;
	let { visualElement: t } = e.options;
	if (!t) return;
	let n = so(t);
	if (window.MotionHasOptimisedAnimation(n, "transform")) {
		let { layout: t, layoutId: r } = e.options;
		window.MotionCancelOptimisedAnimation(n, "transform", I, !(t || r));
	}
	let { parent: r } = e;
	r && !r.hasCheckedOptimisedAppear && Rl(r);
}
function zl({ attachResizeListener: e, defaultParent: t, measureScroll: n, checkIsScrollRoot: r, resetTransform: i }) {
	return class {
		constructor(e = {}, n = t?.()) {
			this.id = Il++, this.animationId = 0, this.animationCommitId = 0, this.children = /* @__PURE__ */ new Set(), this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
				x: 1,
				y: 1
			}, this.eventHandlers = /* @__PURE__ */ new Map(), this.hasTreeAnimated = !1, this.layoutVersion = 0, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
				this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots());
			}, this.updateProjection = () => {
				this.projectionUpdateScheduled = !1, vs.value && (Nl.nodes = Nl.calculatedTargetDeltas = Nl.calculatedProjections = 0), this.nodes.forEach(Hl), this.nodes.forEach(Zl), this.nodes.forEach(Ql), this.nodes.forEach(Ul), vs.addProjectionMetrics && vs.addProjectionMetrics(Nl);
			}, this.resolvedRelativeTargetAt = 0, this.linkedParentVersion = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = /* @__PURE__ */ new Map(), this.latestValues = e, this.root = n ? n.root || n : this, this.path = n ? [...n.path, n] : [], this.parent = n, this.depth = n ? n.depth + 1 : 0;
			for (let e = 0; e < this.path.length; e++) this.path[e].shouldResetTransform = !0;
			this.root === this && (this.nodes = new Ol());
		}
		addEventListener(e, t) {
			return this.eventHandlers.has(e) || this.eventHandlers.set(e, new un()), this.eventHandlers.get(e).add(t);
		}
		notifyListeners(e, ...t) {
			let n = this.eventHandlers.get(e);
			n && n.notify(...t);
		}
		hasListeners(e) {
			return this.eventHandlers.has(e);
		}
		mount(t) {
			if (this.instance) return;
			this.isSVG = rs(t) && !ys(t), this.instance = t;
			let { layoutId: n, layout: r, visualElement: i } = this.options;
			if (i && !i.current && i.mount(t), this.root.nodes.add(this), this.parent && this.parent.children.add(this), this.root.hasTreeAnimated && (r || n) && (this.isLayoutDirty = !0), e) {
				let n, r = 0, i = () => this.root.updateBlockedByResize = !1;
				I.read(() => {
					r = window.innerWidth;
				}), e(t, () => {
					let e = window.innerWidth;
					e !== r && (r = e, this.root.updateBlockedByResize = !0, n && n(), n = kl(i, 250), Ml.hasAnimatedSinceResize && (Ml.hasAnimatedSinceResize = !1, this.nodes.forEach(Xl)));
				});
			}
			n && this.root.registerSharedNode(n, this), this.options.animate !== !1 && i && (n || r) && this.addEventListener("didUpdate", ({ delta: e, hasLayoutChanged: t, hasRelativeLayoutChanged: n, layout: r }) => {
				if (this.isTreeAnimationBlocked()) {
					this.target = void 0, this.relativeTarget = void 0;
					return;
				}
				let a = this.options.transition || i.getDefaultTransition() || au, { onLayoutAnimationStart: o, onLayoutAnimationComplete: s } = i.getProps(), c = !this.targetLayout || !pl(this.targetLayout, r), l = !t && n;
				if (this.options.layoutRoot || this.resumeFrom || l || t && (c || !this.currentAnimation)) {
					this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0);
					let t = {
						...Ia(a, "layout"),
						onPlay: o,
						onComplete: s
					};
					(i.shouldReduceMotion || this.options.layoutRoot) && (t.delay = 0, t.type = !1), this.startAnimation(t), this.setAnimationOrigin(e, l, t.path);
				} else t || Xl(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
				this.targetLayout = r;
			});
		}
		unmount() {
			this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
			let e = this.getStack();
			e && e.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, this.eventHandlers.clear(), Bn(this.updateProjection);
		}
		blockUpdate() {
			this.updateManuallyBlocked = !0;
		}
		unblockUpdate() {
			this.updateManuallyBlocked = !1;
		}
		isUpdateBlocked() {
			return this.updateManuallyBlocked || this.updateBlockedByResize;
		}
		isTreeAnimationBlocked() {
			return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1;
		}
		startUpdate() {
			this.isUpdateBlocked() || (this.isUpdating = !0, this.nodes && this.nodes.forEach($l), this.animationId++);
		}
		getTransformTemplate() {
			let { visualElement: e } = this.options;
			return e && e.getProps().transformTemplate;
		}
		willUpdate(e = !0) {
			if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
				this.options.onExitComplete && this.options.onExitComplete();
				return;
			}
			if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && Rl(this), !this.root.isUpdating && this.root.startUpdate(), this.isLayoutDirty) return;
			this.isLayoutDirty = !0;
			for (let e = 0; e < this.path.length; e++) {
				let t = this.path[e];
				t.shouldResetTransform = !0, (typeof t.latestValues.x == "string" || typeof t.latestValues.y == "string") && (t.isLayoutDirty = !0), t.updateScroll("snapshot"), t.options.layoutRoot && t.willUpdate(!1);
			}
			let { layoutId: t, layout: n } = this.options;
			if (t === void 0 && !n) return;
			let r = this.getTransformTemplate();
			this.prevTransformTemplateValue = r ? r(this.latestValues, "") : void 0, this.updateSnapshot(), e && this.notifyListeners("willUpdate");
		}
		update() {
			if (this.updateScheduled = !1, this.isUpdateBlocked()) {
				let e = this.updateBlockedByResize;
				this.unblockUpdate(), this.updateBlockedByResize = !1, this.clearAllSnapshots(), e && this.nodes.forEach(Kl), this.nodes.forEach(Gl);
				return;
			}
			if (this.animationId <= this.animationCommitId) {
				this.nodes.forEach(ql);
				return;
			}
			this.animationCommitId = this.animationId, this.isUpdating ? (this.isUpdating = !1, this.nodes.forEach(Jl), this.nodes.forEach(Yl), this.nodes.forEach(Bl), this.nodes.forEach(Vl)) : this.nodes.forEach(ql), this.clearAllSnapshots();
			let e = R.now();
			L.delta = A(0, 1e3 / 60, e - L.timestamp), L.timestamp = e, L.isProcessing = !0, Vn.update.process(L), Vn.preRender.process(L), Vn.render.process(L), L.isProcessing = !1;
		}
		didUpdate() {
			this.updateScheduled || (this.updateScheduled = !0, Lo.read(this.scheduleUpdate));
		}
		clearAllSnapshots() {
			this.nodes.forEach(Wl), this.sharedNodes.forEach(eu);
		}
		scheduleUpdateProjection() {
			this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, I.preRender(this.updateProjection, !1, !0));
		}
		scheduleCheckAfterUnmount() {
			I.postRender(() => {
				this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed();
			});
		}
		updateSnapshot() {
			!this.snapshot && this.instance && (this.snapshot = this.measure(), this.snapshot && !Z(this.snapshot.measuredBox.x) && !Z(this.snapshot.measuredBox.y) && (this.snapshot = void 0));
		}
		updateLayout() {
			if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
			if (this.resumeFrom && !this.resumeFrom.instance) for (let e = 0; e < this.path.length; e++) this.path[e].updateScroll();
			let e = this.layout;
			this.layout = this.measure(!1), this.layoutVersion++, this.layoutCorrected ||= J(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
			let { visualElement: t } = this.options;
			t && t.notify("LayoutMeasure", this.layout.layoutBox, e ? e.layoutBox : void 0);
		}
		updateScroll(e = "measure") {
			let t = !!(this.options.layoutScroll && this.instance);
			if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === e && (t = !1), t && this.instance) {
				let t = r(this.instance);
				this.scroll = {
					animationId: this.root.animationId,
					phase: e,
					isRoot: t,
					offset: n(this.instance),
					wasRoot: this.scroll ? this.scroll.isRoot : t
				};
			}
		}
		resetTransform() {
			if (!i) return;
			let e = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout, t = this.projectionDelta && !ll(this.projectionDelta), n = this.getTransformTemplate(), r = n ? n(this.latestValues, "") : void 0, a = r !== this.prevTransformTemplateValue;
			e && this.instance && (t || Ys(this.latestValues) || a) && (i(this.instance, r), this.shouldResetTransform = !1, this.scheduleRender());
		}
		measure(e = !0) {
			let t = this.measurePageBox(), n = this.removeElementScroll(t);
			return e && (n = this.removeTransform(n)), lu(n), {
				animationId: this.root.animationId,
				measuredBox: t,
				layoutBox: n,
				latestValues: {},
				source: this.id
			};
		}
		measurePageBox() {
			let { visualElement: e } = this.options;
			if (!e) return J();
			let t = e.measureViewportBox();
			if (!(this.scroll?.wasRoot || this.path.some(du))) {
				let { scroll: e } = this.root;
				e && (Y(t.x, e.offset.x), Y(t.y, e.offset.y));
			}
			return t;
		}
		removeElementScroll(e) {
			let t = J();
			if (X(t, e), this.scroll?.wasRoot) return t;
			for (let n = 0; n < this.path.length; n++) {
				let r = this.path[n], { scroll: i, options: a } = r;
				r !== this.root && i && a.layoutScroll && (i.wasRoot && X(t, e), Y(t.x, i.offset.x), Y(t.y, i.offset.y));
			}
			return t;
		}
		applyTransform(e, t = !1, n) {
			let r = n || J();
			X(r, e);
			for (let e = 0; e < this.path.length; e++) {
				let n = this.path[e];
				!t && n.options.layoutScroll && n.scroll && n !== n.root && (Y(r.x, -n.scroll.offset.x), Y(r.y, -n.scroll.offset.y)), Ys(n.latestValues) && sc(r, n.latestValues, n.layout?.layoutBox);
			}
			return Ys(this.latestValues) && sc(r, this.latestValues, this.layout?.layoutBox), r;
		}
		removeTransform(e) {
			let t = J();
			X(t, e);
			for (let e = 0; e < this.path.length; e++) {
				let n = this.path[e];
				if (!Ys(n.latestValues)) continue;
				let r;
				n.instance && (Js(n.latestValues) && n.updateSnapshot(), r = J(), X(r, n.measurePageBox())), sl(t, n.latestValues, n.snapshot?.layoutBox, r);
			}
			return Ys(this.latestValues) && sl(t, this.latestValues), t;
		}
		setTargetDelta(e) {
			this.targetDelta = e, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0;
		}
		setOptions(e) {
			this.options = {
				...this.options,
				...e,
				crossfade: e.crossfade === void 0 || e.crossfade
			};
		}
		clearMeasurements() {
			this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1;
		}
		forceRelativeParentToResolveTarget() {
			this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== L.timestamp && this.relativeParent.resolveTargetDelta(!0);
		}
		resolveTargetDelta(e = !1) {
			let t = this.getLead();
			this.isProjectionDirty ||= t.isProjectionDirty, this.isTransformDirty ||= t.isTransformDirty, this.isSharedProjectionDirty ||= t.isSharedProjectionDirty;
			let n = !!this.resumingFrom || this !== t;
			if (!(e || n && this.isSharedProjectionDirty || this.isProjectionDirty || this.parent?.isProjectionDirty || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
			let { layout: r, layoutId: i } = this.options;
			if (!this.layout || !(r || i)) return;
			this.resolvedRelativeTargetAt = L.timestamp;
			let a = this.getClosestProjectingParent();
			a && this.linkedParentVersion !== a.layoutVersion && !a.options.layoutRoot && this.removeRelativeTarget(), !this.targetDelta && !this.relativeTarget && (this.options.layoutAnchor !== !1 && a && a.layout ? this.createRelativeTarget(a, this.layout.layoutBox, a.layout.layoutBox) : this.removeRelativeTarget()), (this.relativeTarget || this.targetDelta) && (this.target || (this.target = J(), this.targetWithTransforms = J()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target ? (this.forceRelativeParentToResolveTarget(), $c(this.target, this.relativeTarget, this.relativeParent.target, this.options.layoutAnchor || void 0)) : this.targetDelta ? (this.resumingFrom ? this.applyTransform(this.layout.layoutBox, !1, this.target) : X(this.target, this.layout.layoutBox), tc(this.target, this.targetDelta)) : X(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget && (this.attemptToResolveRelativeTarget = !1, this.options.layoutAnchor !== !1 && a && !!a.resumingFrom == !!this.resumingFrom && !a.options.layoutScroll && a.target && this.animationProgress !== 1 ? this.createRelativeTarget(a, this.target, a.target) : this.relativeParent = this.relativeTarget = void 0), vs.value && Nl.calculatedTargetDeltas++);
		}
		getClosestProjectingParent() {
			if (!(!this.parent || Js(this.parent.latestValues) || Xs(this.parent.latestValues))) return this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent();
		}
		isProjecting() {
			return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout);
		}
		createRelativeTarget(e, t, n) {
			this.relativeParent = e, this.linkedParentVersion = e.layoutVersion, this.forceRelativeParentToResolveTarget(), this.relativeTarget = J(), this.relativeTargetOrigin = J(), tl(this.relativeTargetOrigin, t, n, this.options.layoutAnchor || void 0), X(this.relativeTarget, this.relativeTargetOrigin);
		}
		removeRelativeTarget() {
			this.relativeParent = this.relativeTarget = void 0;
		}
		calcProjection() {
			let e = this.getLead(), t = !!this.resumingFrom || this !== e, n = !0;
			if ((this.isProjectionDirty || this.parent?.isProjectionDirty) && (n = !1), t && (this.isSharedProjectionDirty || this.isTransformDirty) && (n = !1), this.resolvedRelativeTargetAt === L.timestamp && (n = !1), n) return;
			let { layout: r, layoutId: i } = this.options;
			if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(r || i)) return;
			X(this.layoutCorrected, this.layout.layoutBox);
			let a = this.treeScale.x, o = this.treeScale.y;
			ic(this.layoutCorrected, this.treeScale, this.path, t), e.layout && !e.target && (this.treeScale.x !== 1 || this.treeScale.y !== 1) && (e.target = e.layout.layoutBox, e.targetWithTransforms = J());
			let { target: s } = e;
			s ? (!this.projectionDelta || !this.prevProjectionDelta ? this.createProjectionDeltas() : (Wc(this.prevProjectionDelta.x, this.projectionDelta.x), Wc(this.prevProjectionDelta.y, this.projectionDelta.y)), Zc(this.projectionDelta, this.layoutCorrected, s, this.latestValues), this.treeScale.x === a && this.treeScale.y === o && hl(this.projectionDelta.x, this.prevProjectionDelta.x) && hl(this.projectionDelta.y, this.prevProjectionDelta.y) || (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", s)), vs.value && Nl.calculatedProjections++) : this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender());
		}
		hide() {
			this.isVisible = !1;
		}
		show() {
			this.isVisible = !0;
		}
		scheduleRender(e = !0) {
			if (this.options.visualElement?.scheduleRender(), e) {
				let e = this.getStack();
				e && e.scheduleRender();
			}
			this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0);
		}
		createProjectionDeltas() {
			this.prevProjectionDelta = Cs(), this.projectionDelta = Cs(), this.projectionDeltaWithTransform = Cs();
		}
		setAnimationOrigin(e, t = !1, n) {
			let r = this.snapshot, i = r ? r.latestValues : {}, a = { ...this.latestValues }, o = Cs();
			this.relativeParent && this.relativeParent.options.layoutRoot || (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !t;
			let s = J(), c = (r ? r.source : void 0) !== (this.layout ? this.layout.source : void 0), l = this.getStack(), u = !l || l.members.length <= 1, d = !(!c || u || this.options.crossfade !== !0 || this.path.some(iu));
			this.animationProgress = 0;
			let f, p = n?.interpolateProjection(e);
			this.mixTargetDelta = (t) => {
				let n = t / 1e3, r = p?.(n);
				r ? (o.x.translate = r.x, o.x.scale = W(e.x.scale, 1, n), o.x.origin = e.x.origin, o.x.originPoint = e.x.originPoint, o.y.translate = r.y, o.y.scale = W(e.y.scale, 1, n), o.y.origin = e.y.origin, o.y.originPoint = e.y.originPoint) : (tu(o.x, e.x, n), tu(o.y, e.y, n)), this.setTargetDelta(o), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout && (tl(s, this.layout.layoutBox, this.relativeParent.layout.layoutBox, this.options.layoutAnchor || void 0), ru(this.relativeTarget, this.relativeTargetOrigin, s, n), f && dl(this.relativeTarget, f) && (this.isProjectionDirty = !1), f ||= J(), X(f, this.relativeTarget)), c && (this.animationValues = a, bl(a, i, this.latestValues, n, d, u)), r && r.rotate !== void 0 && (this.animationValues ||= a, this.animationValues.pathRotation = r.rotate), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = n;
			}, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0);
		}
		startAnimation(e) {
			this.notifyListeners("animationStart"), this.currentAnimation?.stop(), this.resumingFrom?.currentAnimation?.stop(), this.pendingAnimation &&= (Bn(this.pendingAnimation), void 0), this.pendingAnimation = I.update(() => {
				Ml.hasAnimatedSinceResize = !0, this.motionValue ||= Pa(0), this.motionValue.jump(0, !1), this.currentAnimation = Tl(this.motionValue, [0, 1e3], {
					...e,
					velocity: 0,
					isSync: !0,
					onUpdate: (t) => {
						this.mixTargetDelta(t), e.onUpdate && e.onUpdate(t);
					},
					onComplete: () => {
						e.onComplete && e.onComplete(), this.completeAnimation();
					}
				}), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0;
			});
		}
		completeAnimation() {
			this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
			let e = this.getStack();
			e && e.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete");
		}
		finishAnimation() {
			this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(Fl), this.currentAnimation.stop()), this.completeAnimation();
		}
		applyTransformsToTarget() {
			let e = this.getLead(), { targetWithTransforms: t, target: n, layout: r, latestValues: i } = e;
			if (t && n && r) {
				if (this !== e && this.layout && r && uu(this.options.animationType, this.layout.layoutBox, r.layoutBox)) {
					n = this.target || J();
					let t = Z(this.layout.layoutBox.x);
					n.x.min = e.target.x.min, n.x.max = n.x.min + t;
					let r = Z(this.layout.layoutBox.y);
					n.y.min = e.target.y.min, n.y.max = n.y.min + r;
				}
				X(t, n), sc(t, i), Zc(this.projectionDeltaWithTransform, this.layoutCorrected, t, i);
			}
		}
		registerSharedNode(e, t) {
			this.sharedNodes.has(e) || this.sharedNodes.set(e, new jl()), this.sharedNodes.get(e).add(t);
			let n = t.options.initialPromotionConfig;
			t.promote({
				transition: n ? n.transition : void 0,
				preserveFollowOpacity: n && n.shouldPreserveFollowOpacity ? n.shouldPreserveFollowOpacity(t) : void 0
			});
		}
		isLead() {
			let e = this.getStack();
			return !e || e.lead === this;
		}
		getLead() {
			let { layoutId: e } = this.options;
			return e && this.getStack()?.lead || this;
		}
		getPrevLead() {
			let { layoutId: e } = this.options;
			return e ? this.getStack()?.prevLead : void 0;
		}
		getStack() {
			let { layoutId: e } = this.options;
			if (e) return this.root.sharedNodes.get(e);
		}
		promote({ needsReset: e, transition: t, preserveFollowOpacity: n } = {}) {
			let r = this.getStack();
			r && r.promote(this, n), e && (this.projectionDelta = void 0, this.needsReset = !0), t && this.setOptions({ transition: t });
		}
		relegate() {
			let e = this.getStack();
			return e ? e.relegate(this) : !1;
		}
		resetSkewAndRotation() {
			let { visualElement: e } = this.options;
			if (!e) return;
			let t = !1, { latestValues: n } = e;
			if ((n.z || n.rotate || n.rotateX || n.rotateY || n.rotateZ || n.skewX || n.skewY) && (t = !0), !t) return;
			let r = {};
			n.z && Ll("z", e, r, this.animationValues);
			for (let t = 0; t < Pl.length; t++) Ll(`rotate${Pl[t]}`, e, r, this.animationValues), Ll(`skew${Pl[t]}`, e, r, this.animationValues);
			e.render();
			for (let t in r) e.setStaticValue(t, r[t]), this.animationValues && (this.animationValues[t] = r[t]);
			e.scheduleRender();
		}
		applyProjectionStyles(e, t) {
			if (!this.instance || this.isSVG) return;
			if (!this.isVisible) {
				e.visibility = "hidden";
				return;
			}
			let n = this.getTransformTemplate();
			if (this.needsReset) {
				this.needsReset = !1, e.visibility = "", e.opacity = "", e.pointerEvents = Al(t?.pointerEvents) || "", e.transform = n ? n(this.latestValues, "") : "none";
				return;
			}
			let r = this.getLead();
			if (!this.projectionDelta || !this.layout || !r.target) {
				this.options.layoutId && (e.opacity = this.latestValues.opacity === void 0 ? 1 : this.latestValues.opacity, e.pointerEvents = Al(t?.pointerEvents) || ""), this.hasProjected && !Ys(this.latestValues) && (e.transform = n ? n({}, "") : "none", this.hasProjected = !1);
				return;
			}
			e.visibility = "";
			let i = r.animationValues || r.latestValues;
			this.applyTransformsToTarget();
			let a = gl(this.projectionDeltaWithTransform, this.treeScale, i);
			n && (a = n(i, a)), e.transform = a;
			let { x: o, y: s } = this.projectionDelta;
			e.transformOrigin = `${o.origin * 100}% ${s.origin * 100}% 0`, e.opacity = r.animationValues ? r === this ? i.opacity ?? this.latestValues.opacity ?? 1 : this.preserveOpacity ? this.latestValues.opacity : i.opacityExit : r === this ? i.opacity === void 0 ? "" : i.opacity : i.opacityExit === void 0 ? 0 : i.opacityExit;
			for (let t in vc) {
				if (i[t] === void 0) continue;
				let { correct: n, applyTo: o, isCSSVariable: s } = vc[t], c = a === "none" ? i[t] : n(i[t], r);
				if (o) {
					let t = o.length;
					for (let n = 0; n < t; n++) e[o[n]] = c;
				} else s ? this.options.visualElement.renderState.vars[t] = c : e[t] = c;
			}
			this.options.layoutId && (e.pointerEvents = r === this ? Al(t?.pointerEvents) || "" : "none");
		}
		clearSnapshot() {
			this.resumeFrom = this.snapshot = void 0;
		}
		resetTree() {
			this.root.nodes.forEach((e) => e.currentAnimation?.stop()), this.root.nodes.forEach(Gl), this.root.sharedNodes.clear();
		}
	};
}
function Bl(e) {
	e.updateLayout();
}
function Vl(e) {
	let t = e.resumeFrom?.snapshot || e.snapshot;
	if (e.isLead() && e.layout && t && e.hasListeners("didUpdate")) {
		let { layoutBox: n, measuredBox: r } = e.layout, { animationType: i } = e.options, a = t.source !== e.layout.source;
		if (i === "size") Q((e) => {
			let r = a ? t.measuredBox[e] : t.layoutBox[e], i = Z(r);
			r.min = n[e].min, r.max = r.min + i;
		});
		else if (i === "x" || i === "y") {
			let e = i === "x" ? "y" : "x";
			Uc(a ? t.measuredBox[e] : t.layoutBox[e], n[e]);
		} else uu(i, t.layoutBox, n) && Q((r) => {
			let i = a ? t.measuredBox[r] : t.layoutBox[r], o = Z(n[r]);
			i.max = i.min + o, e.relativeTarget && !e.currentAnimation && (e.isProjectionDirty = !0, e.relativeTarget[r].max = e.relativeTarget[r].min + o);
		});
		let o = Cs();
		Zc(o, n, t.layoutBox);
		let s = Cs();
		a ? Zc(s, e.applyTransform(r, !0), t.measuredBox) : Zc(s, n, t.layoutBox);
		let c = !ll(o), l = !1;
		if (!e.resumeFrom) {
			let r = e.getClosestProjectingParent();
			if (r && !r.resumeFrom) {
				let { snapshot: i, layout: a } = r;
				if (i && a) {
					let o = e.options.layoutAnchor || void 0, s = J();
					tl(s, t.layoutBox, i.layoutBox, o);
					let c = J();
					tl(c, n, a.layoutBox, o), pl(s, c) || (l = !0), r.options.layoutRoot && (e.relativeTarget = c, e.relativeTargetOrigin = s, e.relativeParent = r);
				}
			}
		}
		e.notifyListeners("didUpdate", {
			layout: n,
			snapshot: t,
			delta: s,
			layoutDelta: o,
			hasLayoutChanged: c,
			hasRelativeLayoutChanged: l
		});
	} else if (e.isLead()) {
		let { onExitComplete: t } = e.options;
		t && t();
	}
	e.options.transition = void 0;
}
function Hl(e) {
	vs.value && Nl.nodes++, e.parent && (e.isProjecting() || (e.isProjectionDirty = e.parent.isProjectionDirty), e.isSharedProjectionDirty ||= !!(e.isProjectionDirty || e.parent.isProjectionDirty || e.parent.isSharedProjectionDirty), e.isTransformDirty ||= e.parent.isTransformDirty);
}
function Ul(e) {
	e.isProjectionDirty = e.isSharedProjectionDirty = e.isTransformDirty = !1;
}
function Wl(e) {
	e.clearSnapshot();
}
function Gl(e) {
	e.clearMeasurements();
}
function Kl(e) {
	e.isLayoutDirty = !0, e.updateLayout();
}
function ql(e) {
	e.isLayoutDirty = !1;
}
function Jl(e) {
	e.isAnimationBlocked && e.layout && !e.isLayoutDirty && (e.snapshot = e.layout, e.isLayoutDirty = !0);
}
function Yl(e) {
	let { visualElement: t } = e.options;
	t && t.getProps().onBeforeLayoutMeasure && t.notify("BeforeLayoutMeasure"), e.resetTransform();
}
function Xl(e) {
	e.finishAnimation(), e.targetDelta = e.relativeTarget = e.target = void 0, e.isProjectionDirty = !0;
}
function Zl(e) {
	e.resolveTargetDelta();
}
function Ql(e) {
	e.calcProjection();
}
function $l(e) {
	e.resetSkewAndRotation();
}
function eu(e) {
	e.removeLeadSnapshot();
}
function tu(e, t, n) {
	e.translate = W(t.translate, 0, n), e.scale = W(t.scale, 1, n), e.origin = t.origin, e.originPoint = t.originPoint;
}
function nu(e, t, n, r) {
	e.min = W(t.min, n.min, r), e.max = W(t.max, n.max, r);
}
function ru(e, t, n, r) {
	nu(e.x, t.x, n.x, r), nu(e.y, t.y, n.y, r);
}
function iu(e) {
	return e.animationValues && e.animationValues.opacityExit !== void 0;
}
var au = {
	duration: .45,
	ease: [
		.4,
		0,
		.1,
		1
	]
}, ou = (e) => typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().includes(e), su = ou("applewebkit/") && !ou("chrome/") ? Math.round : N;
function cu(e) {
	e.min = su(e.min), e.max = su(e.max);
}
function lu(e) {
	cu(e.x), cu(e.y);
}
function uu(e, t, n) {
	return e === "position" || e === "preserve-aspect" && !Yc(ml(t), ml(n), .2);
}
function du(e) {
	return e !== e.root && e.scroll?.wasRoot;
}
// node_modules/.pnpm/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/node/DocumentProjectionNode.mjs
var fu = zl({
	attachResizeListener: (e, t) => El(e, "resize", t),
	measureScroll: () => ({
		x: document.documentElement.scrollLeft || document.body?.scrollLeft || 0,
		y: document.documentElement.scrollTop || document.body?.scrollTop || 0
	}),
	checkIsScrollRoot: () => !0
}), pu = { current: void 0 }, mu = zl({
	measureScroll: (e) => ({
		x: e.scrollLeft,
		y: e.scrollTop
	}),
	defaultParent: () => {
		if (!pu.current) {
			let e = new fu({});
			e.mount(window), e.setOptions({ layoutScroll: !0 }), pu.current = e;
		}
		return pu.current;
	},
	resetTransform: (e, t) => {
		e.style.transform = t === void 0 ? "none" : t;
	},
	checkIsScrollRoot: (e) => window.getComputedStyle(e).position === "fixed"
}), hu = a({
	transformPagePoint: (e) => e,
	isStatic: !1,
	reducedMotion: "never"
});
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/utils/use-composed-ref.mjs
function gu(e, t) {
	if (typeof e == "function") return e(t);
	e != null && (e.current = t);
}
function _u(...e) {
	return (t) => {
		let n = !1, r = e.map((e) => {
			let r = gu(e, t);
			return !n && typeof r == "function" && (n = !0), r;
		});
		if (n) return () => {
			for (let t = 0; t < r.length; t++) {
				let n = r[t];
				typeof n == "function" ? n() : gu(e[t], null);
			}
		};
	};
}
function vu(...t) {
	return e.useCallback(_u(...t), t);
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/components/AnimatePresence/PopChild.mjs
var yu = class extends e.Component {
	getSnapshotBeforeUpdate(e) {
		let t = this.props.childRef.current;
		if (Io(t) && e.isPresent && !this.props.isPresent && this.props.pop !== !1) {
			let e = t.offsetParent, n = Io(e) && e.offsetWidth || 0, r = Io(e) && e.offsetHeight || 0, i = getComputedStyle(t), a = this.props.sizeRef.current;
			a.height = parseFloat(i.height), a.width = parseFloat(i.width), a.top = t.offsetTop, a.left = t.offsetLeft, a.right = n - a.width - a.left, a.bottom = r - a.height - a.top, a.direction = i.direction;
		}
		return null;
	}
	componentDidUpdate() {}
	render() {
		return this.props.children;
	}
};
function bu({ children: t, isPresent: n, anchorX: r, anchorY: i, root: a, pop: o }) {
	let s = p(), c = _(null), l = _({
		width: 0,
		height: 0,
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		direction: "ltr"
	}), { nonce: u } = d(hu), f = vu(c, t.props?.ref ?? t?.ref);
	return m(() => {
		let { width: e, height: t, top: d, left: f, right: p, bottom: m, direction: h } = l.current;
		if (n || o === !1 || !c.current || !e || !t) return;
		let g = h === "rtl", _ = r === "left" ? g ? `right: ${p}` : `left: ${f}` : g ? `left: ${f}` : `right: ${p}`, v = i === "bottom" ? `bottom: ${m}` : `top: ${d}`;
		c.current.dataset.motionPopId = s;
		let y = document.createElement("style");
		u && (y.nonce = u);
		let b = a ?? document.head;
		return b.appendChild(y), y.sheet && y.sheet.insertRule(`
          [data-motion-pop-id="${s}"] {
            position: absolute !important;
            width: ${e}px !important;
            height: ${t}px !important;
            ${_}px !important;
            ${v}px !important;
          }
        `), () => {
			c.current?.removeAttribute("data-motion-pop-id"), b.contains(y) && b.removeChild(y);
		};
	}, [n]), x(yu, {
		isPresent: n,
		childRef: c,
		sizeRef: l,
		pop: o,
		children: o === !1 ? t : e.cloneElement(t, { ref: f })
	});
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/components/AnimatePresence/PresenceChild.mjs
var xu = ({ children: t, initial: n, isPresent: r, onExitComplete: i, custom: a, presenceAffectsLayout: o, mode: s, anchorX: c, anchorY: l, root: u }) => {
	let d = Xt(Su), f = p(), m = _(r), h = _(i);
	Zt(() => {
		m.current = r, h.current = i;
	});
	let v = !0, y = g(() => (v = !1, {
		id: f,
		initial: n,
		isPresent: r,
		custom: a,
		onExitComplete: (e) => {
			d.set(e, !0);
			for (let e of d.values()) if (!e) return;
			i && i();
		},
		register: (e) => (d.set(e, !1), () => {
			d.delete(e), !m.current && !d.size && h.current?.();
		})
	}), [
		r,
		d,
		i
	]);
	return o && v && (y = { ...y }), g(() => {
		d.forEach((e, t) => d.set(t, !1));
	}, [r]), e.useEffect(() => {
		!r && !d.size && i && i();
	}, [r]), t = x(bu, {
		pop: s === "popLayout",
		isPresent: r,
		anchorX: c,
		anchorY: l,
		root: u,
		children: t
	}), x(Qt.Provider, {
		value: y,
		children: t
	});
};
function Su() {
	return /* @__PURE__ */ new Map();
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/components/AnimatePresence/use-presence.mjs
function Cu(e = !0) {
	let t = d(Qt);
	if (t === null) return [!0, null];
	let { isPresent: n, onExitComplete: r, register: i } = t, a = p();
	f(() => {
		if (e) return i(a);
	}, [e]);
	let o = u(() => e && r && r(a), [
		a,
		r,
		e
	]);
	return !n && r ? [!1, o] : [!0];
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/components/AnimatePresence/utils.mjs
var wu = (e) => e.key || "";
function Tu(e) {
	let t = [];
	return n.forEach(e, (e) => {
		c(e) && t.push(e);
	}), t;
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs
var Eu = ({ children: e, custom: t, initial: n = !0, onExitComplete: r, presenceAffectsLayout: i = !0, mode: a = "sync", propagate: o = !1, anchorX: s = "left", anchorY: c = "top", root: l }) => {
	let [u, f] = Cu(o), p = g(() => Tu(e), [e]), m = o && !u ? [] : p.map(wu), h = _(!0), y = _(p), S = Xt(() => /* @__PURE__ */ new Map()), C = _(/* @__PURE__ */ new Set()), [w, T] = v(p), [E, ee] = v(p);
	Zt(() => {
		h.current = !1, y.current = p;
		for (let e = 0; e < E.length; e++) {
			let t = wu(E[e]);
			m.includes(t) ? (S.delete(t), C.current.delete(t)) : S.get(t) !== !0 && S.set(t, !1);
		}
	}, [
		E,
		m.length,
		m.join("-")
	]);
	let D = [];
	if (p !== w) {
		let e = [...p];
		for (let t = 0; t < E.length; t++) {
			let n = E[t], r = wu(n);
			m.includes(r) || (e.splice(t, 0, n), D.push(n));
		}
		return a === "wait" && D.length && (e = D), ee(Tu(e)), T(p), null;
	}
	process.env.NODE_ENV !== "production" && a === "wait" && E.length > 1 && console.warn("You're attempting to animate multiple children within AnimatePresence, but its mode is set to \"wait\". This will lead to odd visual behaviour.");
	let { forceRender: te } = d(Yt);
	return x(b, { children: E.map((e) => {
		let d = wu(e), g = o && !u ? !1 : p === E || m.includes(d);
		return x(xu, {
			isPresent: g,
			initial: !h.current || n ? void 0 : !1,
			custom: t,
			presenceAffectsLayout: i,
			mode: a,
			root: l,
			onExitComplete: g ? void 0 : () => {
				if (C.current.has(d)) return;
				if (S.has(d)) C.current.add(d), S.set(d, !0);
				else return;
				let e = !0;
				S.forEach((t) => {
					t || (e = !1);
				}), e && (te?.(), ee(y.current), o && f?.(), r && r());
			},
			anchorX: s,
			anchorY: c,
			children: e
		}, d);
	}) });
}, Du = a({ strict: !1 }), Ou = {
	animation: [
		"animate",
		"variants",
		"whileHover",
		"whileTap",
		"exit",
		"whileInView",
		"whileFocus",
		"whileDrag"
	],
	exit: ["exit"],
	drag: ["drag", "dragControls"],
	focus: ["whileFocus"],
	hover: [
		"whileHover",
		"onHoverStart",
		"onHoverEnd"
	],
	tap: [
		"whileTap",
		"onTap",
		"onTapStart",
		"onTapCancel"
	],
	pan: [
		"onPan",
		"onPanStart",
		"onPanSessionStart",
		"onPanEnd"
	],
	inView: [
		"whileInView",
		"onViewportEnter",
		"onViewportLeave"
	],
	layout: ["layout", "layoutId"]
}, ku = !1;
function Au() {
	if (ku) return;
	let e = {};
	for (let t in Ou) e[t] = { isEnabled: (e) => Ou[t].some((t) => !!e[t]) };
	zs(e), ku = !0;
}
function ju() {
	return Au(), Bs();
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/motion/features/load-features.mjs
function Mu(e) {
	let t = ju();
	for (let n in e) t[n] = {
		...t[n],
		...e[n]
	};
	zs(t);
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/motion/utils/valid-prop.mjs
var Nu = /* @__PURE__ */ new Set(/* @__PURE__ */ "animate.exit.variants.initial.style.values.variants.transition.transformTemplate.custom.inherit.onBeforeLayoutMeasure.onAnimationStart.onAnimationComplete.onUpdate.onDragStart.onDrag.onDragEnd.onMeasureDragConstraints.onDirectionLock.onDragTransitionEnd._dragX._dragY.onHoverStart.onHoverEnd.onViewportEnter.onViewportLeave.globalTapTarget.propagate.ignoreStrict.viewport".split("."));
function Pu(e) {
	return e.startsWith("while") || e.startsWith("drag") && e !== "draggable" || e.startsWith("layout") || e.startsWith("onTap") || e.startsWith("onPan") || e.startsWith("onLayout") || Nu.has(e);
}
// __vite-optional-peer-dep:@emotion/is-prop-valid:framer-motion
var Fu = /* @__PURE__ */ ue({ default: () => Iu }), Iu, Lu = le((() => {
	throw Iu = {}, Error("Could not resolve \"@emotion/is-prop-valid\" imported by \"framer-motion\". Is it installed?");
})), Ru = (e) => !Pu(e);
function zu(e) {
	typeof e == "function" && (Ru = (t) => t.startsWith("on") ? !Pu(t) : e(t));
}
try {
	zu((Lu(), fe(Fu)).default);
} catch {}
function Bu(e, t, n) {
	let r = {};
	for (let i in e) i === "values" && typeof e.values == "object" || K(e[i]) || (Ru(i) || n === !0 && Pu(i) || !t && !Pu(i) || e.draggable && i.startsWith("onDrag")) && (r[i] = e[i]);
	return r;
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/context/MotionContext/index.mjs
var Vu = /* @__PURE__ */ a({});
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/context/MotionContext/utils.mjs
function Hu(e, t) {
	if (As(e)) {
		let { initial: t, animate: n } = e;
		return {
			initial: t === !1 || Ds(t) ? t : void 0,
			animate: Ds(n) ? n : void 0
		};
	}
	return e.inherit === !1 ? {} : t;
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/context/MotionContext/create.mjs
function Uu(e) {
	let { initial: t, animate: n } = Hu(e, d(Vu));
	return g(() => ({
		initial: t,
		animate: n
	}), [Wu(t), Wu(n)]);
}
function Wu(e) {
	return Array.isArray(e) ? e.join(" ") : e;
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/render/html/utils/create-render-state.mjs
var Gu = () => ({
	style: {},
	transform: {},
	transformOrigin: {},
	vars: {}
});
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/render/html/use-props.mjs
function Ku(e, t, n) {
	for (let r in t) !K(t[r]) && !yc(r, n) && (e[r] = t[r]);
}
function qu({ transformTemplate: e }, t) {
	return g(() => {
		let n = Gu();
		return pc(n, t, e), Object.assign({}, n.vars, n.style);
	}, [t]);
}
function Ju(e, t) {
	let n = e.style || {}, r = {};
	return Ku(r, n, e), Object.assign(r, qu(e, t)), r;
}
function Yu(e, t) {
	let n = {}, r = Ju(e, t);
	return e.drag && e.dragListener !== !1 && (n.draggable = !1, r.userSelect = r.WebkitUserSelect = r.WebkitTouchCallout = "none", r.touchAction = e.drag === !0 ? "none" : `pan-${e.drag === "x" ? "y" : "x"}`), e.tabIndex === void 0 && (e.onTap || e.onTapStart || e.whileTap) && (n.tabIndex = 0), n.style = r, n;
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/render/svg/utils/create-render-state.mjs
var Xu = () => ({
	...Gu(),
	attrs: {}
});
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/render/svg/use-props.mjs
function Zu(e, t, n, r) {
	let i = g(() => {
		let n = Xu();
		return Dc(n, t, kc(r), e.transformTemplate, e.style), {
			...n.attrs,
			style: { ...n.style }
		};
	}, [t]);
	if (e.style) {
		let t = {};
		Ku(t, e.style, e), i.style = {
			...t,
			...i.style
		};
	}
	return i;
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/render/svg/lowercase-elements.mjs
var Qu = [
	"animate",
	"circle",
	"defs",
	"desc",
	"ellipse",
	"g",
	"image",
	"line",
	"filter",
	"marker",
	"mask",
	"metadata",
	"path",
	"pattern",
	"polygon",
	"polyline",
	"rect",
	"stop",
	"switch",
	"symbol",
	"svg",
	"text",
	"tspan",
	"use",
	"view"
];
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/render/dom/utils/is-svg-component.mjs
function $u(e) {
	return typeof e != "string" || e.includes("-") ? !1 : !!(Qu.indexOf(e) > -1 || /[A-Z]/u.test(e));
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/render/dom/use-render.mjs
function ed(e, t, n, { latestValues: r }, a, s = !1, c) {
	let l = (c ?? $u(e) ? Zu : Yu)(t, r, a, e), u = Bu(t, typeof e == "string", s), d = e === i ? {} : {
		...u,
		...l,
		ref: n
	}, { children: f } = t, p = g(() => K(f) ? f.get() : f, [f]);
	return o(e, {
		...d,
		children: p
	});
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/motion/utils/use-visual-state.mjs
function td({ scrapeMotionValuesFromProps: e, createRenderState: t }, n, r, i) {
	return {
		latestValues: nd(n, r, i, e),
		renderState: t()
	};
}
function nd(e, t, n, r) {
	let i = {}, a = r(e, {});
	for (let e in a) i[e] = Al(a[e]);
	let { initial: o, animate: s } = e, c = As(e), l = js(e);
	t && l && !c && e.inherit !== !1 && (o === void 0 && (o = t.initial), s === void 0 && (s = t.animate));
	let u = n ? n.initial === !1 : !1;
	u ||= o === !1;
	let d = u ? s : o;
	if (d && typeof d != "boolean" && !Es(d)) {
		let t = Array.isArray(d) ? d : [d];
		for (let n = 0; n < t.length; n++) {
			let r = Xa(e, t[n]);
			if (r) {
				let { transitionEnd: e, transition: t, ...n } = r;
				for (let e in n) {
					let t = n[e];
					if (Array.isArray(t)) {
						let e = u ? t.length - 1 : 0;
						t = t[e];
					}
					t !== null && (i[e] = t);
				}
				for (let t in e) i[t] = e[t];
			}
		}
	}
	return i;
}
var rd = (e) => (t, n) => {
	let r = d(Vu), i = d(Qt), a = () => td(e, t, r, i);
	return n ? a() : Xt(a);
}, id = /*@__PURE__*/ rd({
	scrapeMotionValuesFromProps: bc,
	createRenderState: Gu
}), ad = /*@__PURE__*/ rd({
	scrapeMotionValuesFromProps: jc,
	createRenderState: Xu
}), od = Symbol.for("motionComponentSymbol");
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/motion/utils/use-motion-ref.mjs
function sd(e, t, n) {
	let r = _(n);
	m(() => {
		r.current = n;
	});
	let i = _(null);
	return u((n) => {
		n && e.onMount?.(n), t && (n ? t.mount(n) : t.unmount());
		let a = r.current;
		if (typeof a == "function") {
			if (n) {
				let e = a(n);
				typeof e == "function" && (i.current = e);
			} else i.current ? (i.current(), i.current = null) : a(n);
		} else a && (a.current = n);
	}, [t]);
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/context/SwitchLayoutGroupContext.mjs
var cd = a({});
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/utils/is-ref-object.mjs
function ld(e) {
	return e && typeof e == "object" && Object.prototype.hasOwnProperty.call(e, "current");
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/motion/utils/use-visual-element.mjs
function ud(e, t, n, r, i, a) {
	let { visualElement: o } = d(Vu), s = d(Du), c = d(Qt), l = d(hu), u = l.reducedMotion, p = l.skipAnimations, h = _(null), g = _(!1);
	r ||= s.renderer, !h.current && r && (h.current = r(e, {
		visualState: t,
		parent: o,
		props: n,
		presenceContext: c,
		blockInitialAnimation: c ? c.initial === !1 : !1,
		reducedMotionConfig: u,
		skipAnimations: p,
		isSVG: a
	}), g.current && h.current && (h.current.manuallyAnimateOnMount = !0));
	let v = h.current, y = d(cd);
	v && !v.projection && i && (v.type === "html" || v.type === "svg") && dd(h.current, n, i, y);
	let b = _(!1);
	m(() => {
		v && b.current && v.update(n, c);
	});
	let x = n[oo], S = _(!!x && typeof window < "u" && !window.MotionHandoffIsComplete?.(x) && window.MotionHasOptimisedAnimation?.(x));
	return Zt(() => {
		g.current = !0, v && (b.current = !0, window.MotionIsMounted = !0, v.updateFeatures(), v.scheduleRenderMicrotask(), S.current && v.animationState && v.animationState.animateChanges());
	}), f(() => {
		v && (!S.current && v.animationState && v.animationState.animateChanges(), S.current &&= (queueMicrotask(() => {
			window.MotionHandoffMarkAsComplete?.(x);
		}), !1), v.enteringChildren = void 0);
	}), v;
}
function dd(e, t, n, r) {
	let { layoutId: i, layout: a, drag: o, dragConstraints: s, layoutScroll: c, layoutRoot: l, layoutAnchor: u, layoutCrossfade: d } = t;
	e.projection = new n(e.latestValues, t["data-framer-portal-id"] ? void 0 : fd(e.parent)), e.projection.setOptions({
		layoutId: i,
		layout: a,
		alwaysMeasureLayout: !!o || s && ld(s),
		visualElement: e,
		animationType: typeof a == "string" ? a : "both",
		initialPromotionConfig: r,
		crossfade: d,
		layoutScroll: c,
		layoutRoot: l,
		layoutAnchor: u
	});
}
function fd(e) {
	if (e) return e.options.allowProjection === !1 ? fd(e.parent) : e.projection;
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/motion/index.mjs
function pd(e, { forwardMotionProps: t = !1, type: n } = {}, r, i) {
	r && Mu(r);
	let a = n ? n === "svg" : $u(e), o = a ? ad : id;
	function c(n, s) {
		let c, l = {
			...d(hu),
			...n,
			layoutId: md(n)
		}, { isStatic: u } = l, f = Uu(n), p = o(n, u);
		if (!u && typeof window < "u") {
			hd(l, r);
			let t = gd(l);
			c = t.MeasureLayout, f.visualElement = ud(e, p, l, i, t.ProjectionNode, a);
		}
		return S(Vu.Provider, {
			value: f,
			children: [c && f.visualElement ? x(c, {
				visualElement: f.visualElement,
				...l
			}) : null, ed(e, n, sd(p, f.visualElement, s), p, u, t, a)]
		});
	}
	c.displayName = `motion.${typeof e == "string" ? e : `create(${e.displayName ?? e.name ?? ""})`}`;
	let l = s(c);
	return l[od] = e, l;
}
function md({ layoutId: e }) {
	let t = d(Yt).id;
	return t && e !== void 0 ? t + "-" + e : e;
}
function hd(e, t) {
	let n = d(Du).strict;
	if (process.env.NODE_ENV !== "production" && t && n) {
		let t = "You have rendered a `motion` component within a `LazyMotion` component. This will break tree shaking. Import and render a `m` component instead.";
		e.ignoreStrict ? nn(!1, t, "lazy-strict-mode") : j(!1, t, "lazy-strict-mode");
	}
}
function gd(e) {
	let { drag: t, layout: n } = ju();
	if (!t && !n) return {};
	let r = {
		...t,
		...n
	};
	return {
		MeasureLayout: t?.isEnabled(e) || n?.isEnabled(e) ? r.MeasureLayout : void 0,
		ProjectionNode: r.ProjectionNode
	};
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/render/components/create-proxy.mjs
function _d(e, t) {
	if (typeof Proxy > "u") return pd;
	let n = /* @__PURE__ */ new Map(), r = (n, r) => pd(n, r, e, t);
	return new Proxy((e, t) => (process.env.NODE_ENV !== "production" && pn(!1, "motion() is deprecated. Use motion.create() instead."), r(e, t)), { get: (i, a) => a === "create" ? r : (n.has(a) || n.set(a, pd(a, void 0, e, t)), n.get(a)) });
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/render/dom/create-visual-element.mjs
var vd = (e, t) => t.isSVG ?? $u(e) ? new Mc(t) : new Sc(t, { allowProjection: e !== i }), yd = class extends Us {
	constructor(e) {
		super(e), e.animationState ||= zc(e);
	}
	updateAnimationControlsSubscription() {
		let { animate: e } = this.node.getProps();
		Es(e) && (this.unmountControls = e.subscribe(this.node));
	}
	mount() {
		this.updateAnimationControlsSubscription();
	}
	update() {
		let { animate: e } = this.node.getProps(), { animate: t } = this.node.prevProps || {};
		e !== t && this.updateAnimationControlsSubscription();
	}
	unmount() {
		this.node.animationState.reset(), this.unmountControls?.();
	}
}, bd = 0, xd = {
	animation: { Feature: yd },
	exit: { Feature: class extends Us {
		constructor() {
			super(...arguments), this.id = bd++, this.isExitComplete = !1;
		}
		update() {
			if (!this.node.presenceContext) return;
			let { isPresent: e, onExitComplete: t } = this.node.presenceContext, { isPresent: n } = this.node.prevPresenceContext || {};
			if (!this.node.animationState || e === n) return;
			if (e && n === !1) {
				if (this.isExitComplete) {
					let { initial: e, custom: t } = this.node.getProps();
					if (typeof e == "string" || typeof e == "object" && e && !Array.isArray(e)) {
						let n = Za(this.node, e, t);
						if (n) {
							let { transition: e, transitionEnd: t, ...r } = n;
							for (let e in r) this.node.getValue(e)?.jump(r[e]);
						}
					}
					this.node.animationState.reset(), this.node.animationState.animateChanges();
				} else this.node.animationState.setActive("exit", !1);
				this.isExitComplete = !1;
				return;
			}
			let r = this.node.animationState.setActive("exit", !e);
			t && !e && r.then(() => {
				this.isExitComplete = !0, t(this.id);
			});
		}
		mount() {
			let { register: e, onExitComplete: t } = this.node.presenceContext || {};
			t && t(this.id), e && (this.unmount = e(this.id));
		}
		unmount() {}
	} }
};
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/events/event-info.mjs
function Sd(e) {
	return { point: {
		x: e.pageX,
		y: e.pageY
	} };
}
var Cd = (e) => (t) => Go(t) && e(t, Sd(t));
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/events/add-pointer-event.mjs
function wd(e, t, n, r) {
	return El(e, t, Cd(n), r);
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/utils/get-context-window.mjs
var Td = ({ current: e }) => e ? e.ownerDocument.defaultView : null, Ed = (e, t) => Math.abs(e - t);
function Dd(e, t) {
	let n = Ed(e.x, t.x), r = Ed(e.y, t.y);
	return Math.sqrt(n ** 2 + r ** 2);
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/gestures/pan/PanSession.mjs
var Od = /*#__PURE__*/ new Set(["auto", "scroll"]), kd = class {
	constructor(e, t, { transformPagePoint: n, contextWindow: r = window, dragSnapToOrigin: i = !1, distanceThreshold: a = 3, element: o } = {}) {
		if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.lastRawMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.scrollPositions = /* @__PURE__ */ new Map(), this.removeScrollListeners = null, this.onElementScroll = (e) => {
			this.handleScroll(e.target);
		}, this.onWindowScroll = () => {
			this.handleScroll(window);
		}, this.updatePoint = () => {
			if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
			this.lastRawMoveEventInfo && (this.lastMoveEventInfo = Ad(this.lastRawMoveEventInfo, this.transformPagePoint));
			let e = Md(this.lastMoveEventInfo, this.history), t = this.startEvent !== null, n = Dd(e.offset, {
				x: 0,
				y: 0
			}) >= this.distanceThreshold;
			if (!t && !n) return;
			let { point: r } = e, { timestamp: i } = L;
			this.history.push({
				...r,
				timestamp: i
			});
			let { onStart: a, onMove: o } = this.handlers;
			t || (a && a(this.lastMoveEvent, e), this.startEvent = this.lastMoveEvent), o && o(this.lastMoveEvent, e);
		}, this.handlePointerMove = (e, t) => {
			this.lastMoveEvent = e, this.lastRawMoveEventInfo = t, this.lastMoveEventInfo = Ad(t, this.transformPagePoint), I.update(this.updatePoint, !0);
		}, this.handlePointerUp = (e, t) => {
			this.end();
			let { onEnd: n, onSessionEnd: r, resumeAnimation: i } = this.handlers;
			if ((this.dragSnapToOrigin || !this.startEvent) && i && i(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
			let a = Md(e.type === "pointercancel" ? this.lastMoveEventInfo : Ad(t, this.transformPagePoint), this.history);
			this.startEvent && n && n(e, a), r && r(e, a);
		}, !Go(e)) return;
		this.dragSnapToOrigin = i, this.handlers = t, this.transformPagePoint = n, this.distanceThreshold = a, this.contextWindow = r || window;
		let s = Ad(Sd(e), this.transformPagePoint), { point: c } = s, { timestamp: l } = L;
		this.history = [{
			...c,
			timestamp: l
		}];
		let { onSessionStart: u } = t;
		u && u(e, Md(s, this.history));
		let d = {
			passive: !0,
			capture: !0
		};
		this.removeListeners = cn(wd(this.contextWindow, "pointermove", this.handlePointerMove, d), wd(this.contextWindow, "pointerup", this.handlePointerUp, d), wd(this.contextWindow, "pointercancel", this.handlePointerUp, d)), o && this.startScrollTracking(o);
	}
	startScrollTracking(e) {
		let t = e.parentElement;
		for (; t;) {
			let e = getComputedStyle(t);
			(Od.has(e.overflowX) || Od.has(e.overflowY)) && this.scrollPositions.set(t, {
				x: t.scrollLeft,
				y: t.scrollTop
			}), t = t.parentElement;
		}
		this.scrollPositions.set(window, {
			x: window.scrollX,
			y: window.scrollY
		}), window.addEventListener("scroll", this.onElementScroll, { capture: !0 }), window.addEventListener("scroll", this.onWindowScroll), this.removeScrollListeners = () => {
			window.removeEventListener("scroll", this.onElementScroll, { capture: !0 }), window.removeEventListener("scroll", this.onWindowScroll);
		};
	}
	handleScroll(e) {
		let t = this.scrollPositions.get(e);
		if (!t) return;
		let n = e === window, r = n ? {
			x: window.scrollX,
			y: window.scrollY
		} : {
			x: e.scrollLeft,
			y: e.scrollTop
		}, i = {
			x: r.x - t.x,
			y: r.y - t.y
		};
		(i.x !== 0 || i.y !== 0) && (n ? this.lastMoveEventInfo && (this.lastMoveEventInfo.point.x += i.x, this.lastMoveEventInfo.point.y += i.y) : this.history.length > 0 && (this.history[0].x -= i.x, this.history[0].y -= i.y), this.scrollPositions.set(e, r), I.update(this.updatePoint, !0));
	}
	updateHandlers(e) {
		this.handlers = e;
	}
	end() {
		this.removeListeners && this.removeListeners(), this.removeScrollListeners && this.removeScrollListeners(), this.scrollPositions.clear(), Bn(this.updatePoint);
	}
};
function Ad(e, t) {
	return t ? { point: t(e.point) } : e;
}
function jd(e, t) {
	return {
		x: e.x - t.x,
		y: e.y - t.y
	};
}
function Md({ point: e }, t) {
	return {
		point: e,
		delta: jd(e, Pd(t)),
		offset: jd(e, Nd(t)),
		velocity: Fd(t, .1)
	};
}
function Nd(e) {
	return e[0];
}
function Pd(e) {
	return e[e.length - 1];
}
function Fd(e, t) {
	if (e.length < 2) return {
		x: 0,
		y: 0
	};
	let n = e.length - 1, r = null, i = Pd(e);
	for (; n >= 0 && (r = e[n], !(i.timestamp - r.timestamp > /* @__PURE__ */ P(t)));) n--;
	if (!r) return {
		x: 0,
		y: 0
	};
	r === e[0] && e.length > 2 && i.timestamp - r.timestamp > /* @__PURE__ */ P(t) * 2 && (r = e[1]);
	let a = /* @__PURE__ */ F(i.timestamp - r.timestamp);
	if (a === 0) return {
		x: 0,
		y: 0
	};
	let o = {
		x: (i.x - r.x) / a,
		y: (i.y - r.y) / a
	};
	return o.x === Infinity && (o.x = 0), o.y === Infinity && (o.y = 0), o;
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/gestures/drag/utils/constraints.mjs
function Id(e, { min: t, max: n }, r) {
	return t !== void 0 && e < t ? e = r ? W(t, e, r.min) : Math.max(e, t) : n !== void 0 && e > n && (e = r ? W(n, e, r.max) : Math.min(e, n)), e;
}
function Ld(e, t, n) {
	return {
		min: t === void 0 ? void 0 : e.min + t,
		max: n === void 0 ? void 0 : e.max + n - (e.max - e.min)
	};
}
function Rd(e, { top: t, left: n, bottom: r, right: i }) {
	return {
		x: Ld(e.x, n, i),
		y: Ld(e.y, t, r)
	};
}
function zd(e, t) {
	let n = t.min - e.min, r = t.max - e.max;
	return t.max - t.min < e.max - e.min && ([n, r] = [r, n]), {
		min: n,
		max: r
	};
}
function Bd(e, t) {
	return {
		x: zd(e.x, t.x),
		y: zd(e.y, t.y)
	};
}
function Vd(e, t) {
	let n = .5, r = Z(e), i = Z(t);
	return i > r ? n = /* @__PURE__ */ ln(t.min, t.max - r, e.min) : r > i && (n = /* @__PURE__ */ ln(e.min, e.max - i, t.min)), A(0, 1, n);
}
function Hd(e, t) {
	let n = {};
	return t.min !== void 0 && (n.min = t.min - e.min), t.max !== void 0 && (n.max = t.max - e.min), n;
}
var Ud = .35;
function Wd(e = Ud) {
	return e === !1 ? e = 0 : e === !0 && (e = Ud), {
		x: Gd(e, "left", "right"),
		y: Gd(e, "top", "bottom")
	};
}
function Gd(e, t, n) {
	return {
		min: Kd(e, t),
		max: Kd(e, n)
	};
}
function Kd(e, t) {
	return typeof e == "number" ? e : e[t] || 0;
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/gestures/drag/VisualElementDragControls.mjs
var qd = /* @__PURE__ */ new WeakMap(), Jd = class {
	constructor(e) {
		this.openDragLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
			x: 0,
			y: 0
		}, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = J(), this.latestPointerEvent = null, this.latestPanInfo = null, this.visualElement = e;
	}
	start(e, { snapToCursor: t = !1, distanceThreshold: n } = {}) {
		let { presenceContext: r } = this.visualElement;
		if (r && r.isPresent === !1) return;
		let i = (e) => {
			t && this.snapToCursor(Sd(e).point), this.stopAnimation();
		}, a = (e, t) => {
			let { drag: n, dragPropagation: r, onDragStart: i } = this.getProps();
			if (n && !r && (this.openDragLock && this.openDragLock(), this.openDragLock = Bo(n), !this.openDragLock)) return;
			this.latestPointerEvent = e, this.latestPanInfo = t, this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), Q((e) => {
				let t = this.getAxisMotionValue(e).get() || 0;
				if (B.test(t)) {
					let { projection: n } = this.visualElement;
					if (n && n.layout) {
						let r = n.layout.layoutBox[e];
						r && (t = Z(r) * (parseFloat(t) / 100));
					}
				}
				this.originPoint[e] = t;
			}), i && I.update(() => i(e, t), !1, !0), io(this.visualElement, "transform");
			let { animationState: a } = this.visualElement;
			a && a.setActive("whileDrag", !0);
		}, o = (e, t) => {
			this.latestPointerEvent = e, this.latestPanInfo = t;
			let { dragPropagation: n, dragDirectionLock: r, onDirectionLock: i, onDrag: a } = this.getProps();
			if (!n && !this.openDragLock) return;
			let { offset: o } = t;
			r && this.currentDirection === null ? (this.currentDirection = Qd(o), this.currentDirection !== null && i && i(this.currentDirection)) : (this.updateAxis("x", t.point, o), this.updateAxis("y", t.point, o), this.visualElement.render(), a && I.update(() => a(e, t), !1, !0));
		}, s = (e, t) => {
			this.latestPointerEvent = e, this.latestPanInfo = t, this.stop(e, t), this.latestPointerEvent = null, this.latestPanInfo = null;
		}, c = () => {
			let { dragSnapToOrigin: e } = this.getProps();
			(e || this.constraints) && this.startAnimation({
				x: 0,
				y: 0
			});
		}, { dragSnapToOrigin: l } = this.getProps();
		this.panSession = new kd(e, {
			onSessionStart: i,
			onStart: a,
			onMove: o,
			onSessionEnd: s,
			resumeAnimation: c
		}, {
			transformPagePoint: this.visualElement.getTransformPagePoint(),
			dragSnapToOrigin: l,
			distanceThreshold: n,
			contextWindow: Td(this.visualElement),
			element: this.visualElement.current
		});
	}
	stop(e, t) {
		let n = e || this.latestPointerEvent, r = t || this.latestPanInfo, i = this.isDragging;
		if (this.cancel(), !i || !r || !n) return;
		let { velocity: a } = r;
		this.startAnimation(a);
		let { onDragEnd: o } = this.getProps();
		o && I.postRender(() => o(n, r));
	}
	cancel() {
		this.isDragging = !1;
		let { projection: e, animationState: t } = this.visualElement;
		e && (e.isAnimationBlocked = !1), this.endPanSession();
		let { dragPropagation: n } = this.getProps();
		!n && this.openDragLock && (this.openDragLock(), this.openDragLock = null), t && t.setActive("whileDrag", !1);
	}
	endPanSession() {
		this.panSession && this.panSession.end(), this.panSession = void 0;
	}
	updateAxis(e, t, n) {
		let { drag: r } = this.getProps();
		if (!n || !Zd(e, r, this.currentDirection)) return;
		let i = this.getAxisMotionValue(e), a = this.originPoint[e] + n[e];
		this.constraints && this.constraints[e] && (a = Id(a, this.constraints[e], this.elastic[e])), i.set(a);
	}
	resolveConstraints() {
		let { dragConstraints: e, dragElastic: t } = this.getProps(), n = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : this.visualElement.projection?.layout, r = this.constraints;
		e && ld(e) ? this.constraints ||= this.resolveRefConstraints() : this.constraints = e && n ? Rd(n.layoutBox, e) : !1, this.elastic = Wd(t), r !== this.constraints && !ld(e) && n && this.constraints && !this.hasMutatedConstraints && Q((e) => {
			this.constraints !== !1 && this.getAxisMotionValue(e) && (this.constraints[e] = Hd(n.layoutBox[e], this.constraints[e]));
		});
	}
	resolveRefConstraints() {
		let { dragConstraints: e, onMeasureDragConstraints: t } = this.getProps();
		if (!e || !ld(e)) return !1;
		let n = e.current;
		j(n !== null, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.", "drag-constraints-ref");
		let { projection: r } = this.visualElement;
		if (!r || !r.layout) return !1;
		r.root && (r.root.scroll = void 0, r.root.updateScroll());
		let i = lc(n, r.root, this.visualElement.getTransformPagePoint()), a = Bd(r.layout.layoutBox, i);
		if (t) {
			let e = t(Gs(a));
			this.hasMutatedConstraints = !!e, e && (a = Ws(e));
		}
		return a;
	}
	startAnimation(e) {
		let { drag: t, dragMomentum: n, dragElastic: r, dragTransition: i, dragSnapToOrigin: a, onDragTransitionEnd: o } = this.getProps(), s = this.constraints || {}, c = Q((o) => {
			if (!Zd(o, t, this.currentDirection)) return;
			let c = s && s[o] || {};
			(a === !0 || a === o) && (c = {
				min: 0,
				max: 0
			});
			let l = r ? 200 : 1e6, u = r ? 40 : 1e7, d = {
				type: "inertia",
				velocity: n ? e[o] : 0,
				bounceStiffness: l,
				bounceDamping: u,
				timeConstant: 750,
				restDelta: 1,
				restSpeed: 10,
				...i,
				...c
			};
			return this.startAxisValueAnimation(o, d);
		});
		return Promise.all(c).then(o);
	}
	startAxisValueAnimation(e, t) {
		let n = this.getAxisMotionValue(e);
		return io(this.visualElement, e), n.start(Wa(e, n, 0, t, this.visualElement, !1));
	}
	stopAnimation() {
		Q((e) => this.getAxisMotionValue(e).stop());
	}
	getAxisMotionValue(e) {
		let t = `_drag${e.toUpperCase()}`;
		return this.visualElement.getProps()[t] || this.visualElement.getValue(e, this.visualElement.latestValues[e] ?? 0);
	}
	snapToCursor(e) {
		Q((t) => {
			let { drag: n } = this.getProps();
			if (!Zd(t, n, this.currentDirection)) return;
			let { projection: r } = this.visualElement, i = this.getAxisMotionValue(t);
			if (r && r.layout) {
				let { min: n, max: a } = r.layout.layoutBox[t], o = i.get() || 0;
				i.set(e[t] - W(n, a, .5) + o);
			}
		});
	}
	scalePositionWithinConstraints() {
		if (!this.visualElement.current) return;
		let { drag: e, dragConstraints: t } = this.getProps(), { projection: n } = this.visualElement;
		if (!ld(t) || !n || !this.constraints) return;
		this.stopAnimation();
		let r = {
			x: 0,
			y: 0
		};
		Q((e) => {
			let t = this.getAxisMotionValue(e);
			if (t && this.constraints !== !1) {
				let n = t.get();
				r[e] = Vd({
					min: n,
					max: n
				}, this.constraints[e]);
			}
		});
		let { transformTemplate: i } = this.visualElement.getProps();
		this.visualElement.current.style.transform = i ? i({}, "") : "none", n.root && n.root.updateScroll(), n.updateLayout(), this.constraints = !1, this.resolveConstraints(), Q((t) => {
			if (!Zd(t, e, null)) return;
			let n = this.getAxisMotionValue(t), { min: i, max: a } = this.constraints[t];
			n.set(W(i, a, r[t]));
		}), this.visualElement.render();
	}
	addListeners() {
		if (!this.visualElement.current) return;
		qd.set(this.visualElement, this);
		let e = this.visualElement.current, t = wd(e, "pointerdown", (t) => {
			let { drag: n, dragListener: r = !0 } = this.getProps(), i = t.target, a = i !== e && Yo(i);
			n && r && !a && this.start(t);
		}), n, r = () => {
			let { dragConstraints: t } = this.getProps();
			ld(t) && t.current && (this.constraints = this.resolveRefConstraints(), n ||= Xd(e, t.current, () => this.scalePositionWithinConstraints()));
		}, { projection: i } = this.visualElement, a = i.addEventListener("measure", r);
		i && !i.layout && (i.root && i.root.updateScroll(), i.updateLayout()), I.read(r);
		let o = El(window, "resize", () => this.scalePositionWithinConstraints()), s = i.addEventListener("didUpdate", (({ delta: e, hasLayoutChanged: t }) => {
			this.isDragging && t && (Q((t) => {
				let n = this.getAxisMotionValue(t);
				n && (this.originPoint[t] += e[t].translate, n.set(n.get() + e[t].translate));
			}), this.visualElement.render());
		}));
		return () => {
			o(), t(), a(), s && s(), n && n();
		};
	}
	getProps() {
		let e = this.visualElement.getProps(), { drag: t = !1, dragDirectionLock: n = !1, dragPropagation: r = !1, dragConstraints: i = !1, dragElastic: a = Ud, dragMomentum: o = !0 } = e;
		return {
			...e,
			drag: t,
			dragDirectionLock: n,
			dragPropagation: r,
			dragConstraints: i,
			dragElastic: a,
			dragMomentum: o
		};
	}
};
function Yd(e) {
	let t = !0;
	return () => {
		t ? t = !1 : e();
	};
}
function Xd(e, t, n) {
	let r = _s(e, Yd(n)), i = _s(t, Yd(n));
	return () => {
		r(), i();
	};
}
function Zd(e, t, n) {
	return (t === !0 || t === e) && (n === null || n === e);
}
function Qd(e, t = 10) {
	let n = null;
	return Math.abs(e.y) > t ? n = "y" : Math.abs(e.x) > t && (n = "x"), n;
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/gestures/drag/index.mjs
var $d = class extends Us {
	constructor(e) {
		super(e), this.removeGroupControls = N, this.removeListeners = N, this.controls = new Jd(e);
	}
	mount() {
		let { dragControls: e } = this.node.getProps();
		e && (this.removeGroupControls = e.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || N;
	}
	update() {
		let { dragControls: e } = this.node.getProps(), { dragControls: t } = this.node.prevProps || {};
		e !== t && (this.removeGroupControls(), e && (this.removeGroupControls = e.subscribe(this.controls)));
	}
	unmount() {
		this.removeGroupControls(), this.removeListeners(), this.controls.isDragging || this.controls.endPanSession();
	}
}, ef = (e) => (t, n) => {
	e && I.update(() => e(t, n), !1, !0);
}, tf = class extends Us {
	constructor() {
		super(...arguments), this.removePointerDownListener = N;
	}
	onPointerDown(e) {
		this.session = new kd(e, this.createPanHandlers(), {
			transformPagePoint: this.node.getTransformPagePoint(),
			contextWindow: Td(this.node)
		});
	}
	createPanHandlers() {
		let { onPanSessionStart: e, onPanStart: t, onPan: n, onPanEnd: r } = this.node.getProps();
		return {
			onSessionStart: ef(e),
			onStart: ef(t),
			onMove: ef(n),
			onEnd: (e, t) => {
				delete this.session, r && I.postRender(() => r(e, t));
			}
		};
	}
	mount() {
		this.removePointerDownListener = wd(this.node.current, "pointerdown", (e) => this.onPointerDown(e));
	}
	update() {
		this.session && this.session.updateHandlers(this.createPanHandlers());
	}
	unmount() {
		this.removePointerDownListener(), this.session && this.session.end();
	}
}, nf = !1, rf = class extends r {
	componentDidMount() {
		let { visualElement: e, layoutGroup: t, switchLayoutGroup: n, layoutId: r } = this.props, { projection: i } = e;
		i && (t.group && t.group.add(i), n && n.register && r && n.register(i), nf && i.root.didUpdate(), i.addEventListener("animationComplete", () => {
			this.safeToRemove();
		}), i.setOptions({
			...i.options,
			layoutDependency: this.props.layoutDependency,
			onExitComplete: () => this.safeToRemove()
		})), Ml.hasEverUpdated = !0;
	}
	getSnapshotBeforeUpdate(e) {
		let { layoutDependency: t, visualElement: n, drag: r, isPresent: i } = this.props, { projection: a } = n;
		return a && (a.isPresent = i, e.layoutDependency !== t && a.setOptions({
			...a.options,
			layoutDependency: t
		}), nf = !0, r || e.layoutDependency !== t || t === void 0 || e.isPresent !== i ? a.willUpdate() : this.safeToRemove(), e.isPresent !== i && (i ? a.promote() : a.relegate() || I.postRender(() => {
			let e = a.getStack();
			e && e.members.length || this.safeToRemove();
		}))), null;
	}
	componentDidUpdate() {
		let { visualElement: e, layoutAnchor: t } = this.props, { projection: n } = e;
		n && (n.options.layoutAnchor = t, n.root.didUpdate(), Lo.postRender(() => {
			!n.currentAnimation && n.isLead() && this.safeToRemove();
		}));
	}
	componentWillUnmount() {
		let { visualElement: e, layoutGroup: t, switchLayoutGroup: n } = this.props, { projection: r } = e;
		nf = !0, r && (r.scheduleCheckAfterUnmount(), t && t.group && t.group.remove(r), n && n.deregister && n.deregister(r));
	}
	safeToRemove() {
		let { safeToRemove: e } = this.props;
		e && e();
	}
	render() {
		return null;
	}
};
function af(e) {
	let [t, n] = Cu(), r = d(Yt);
	return x(rf, {
		...e,
		layoutGroup: r,
		switchLayoutGroup: d(cd),
		isPresent: t,
		safeToRemove: n
	});
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/motion/features/drag.mjs
var of = {
	pan: { Feature: tf },
	drag: {
		Feature: $d,
		ProjectionNode: mu,
		MeasureLayout: af
	}
};
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/gestures/hover.mjs
function sf(e, t, n) {
	let { props: r } = e;
	e.animationState && r.whileHover && e.animationState.setActive("whileHover", n === "Start");
	let i = r["onHover" + n];
	i && I.postRender(() => i(t, Sd(t)));
}
var cf = class extends Us {
	mount() {
		let { current: e } = this.node;
		e && (this.unmount = Uo(e, (e, t) => (sf(this.node, t, "Start"), (e) => sf(this.node, e, "End"))));
	}
	unmount() {}
}, lf = class extends Us {
	constructor() {
		super(...arguments), this.isActive = !1;
	}
	onFocus() {
		let e = !1;
		try {
			e = this.node.current.matches(":focus-visible");
		} catch {
			e = !0;
		}
		e && this.node.animationState && (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0);
	}
	onBlur() {
		this.isActive && this.node.animationState && (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1);
	}
	mount() {
		this.unmount = cn(El(this.node.current, "focus", () => this.onFocus()), El(this.node.current, "blur", () => this.onBlur()));
	}
	unmount() {}
};
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/gestures/press.mjs
function uf(e, t, n) {
	let { props: r } = e;
	if (e.current instanceof HTMLButtonElement && e.current.disabled) return;
	e.animationState && r.whileTap && e.animationState.setActive("whileTap", n === "Start");
	let i = r["onTap" + (n === "End" ? "" : n)];
	i && I.postRender(() => i(t, Sd(t)));
}
var df = class extends Us {
	mount() {
		let { current: e } = this.node;
		if (!e) return;
		let { globalTapTarget: t, propagate: n } = this.node.props;
		this.unmount = ns(e, (e, t) => (uf(this.node, t, "Start"), (e, { success: t }) => uf(this.node, e, t ? "End" : "Cancel")), {
			useGlobalTarget: t,
			stopPropagation: n?.tap === !1
		});
	}
	unmount() {}
}, ff = /* @__PURE__ */ new WeakMap(), pf = /* @__PURE__ */ new WeakMap(), mf = (e) => {
	let t = ff.get(e.target);
	t && t(e);
}, hf = (e) => {
	e.forEach(mf);
};
function gf({ root: e, ...t }) {
	let n = e || document;
	pf.has(n) || pf.set(n, {});
	let r = pf.get(n), i = JSON.stringify(t);
	return r[i] || (r[i] = new IntersectionObserver(hf, {
		root: e,
		...t
	})), r[i];
}
function _f(e, t, n) {
	let r = gf(t);
	return ff.set(e, n), r.observe(e), () => {
		ff.delete(e), r.unobserve(e);
	};
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/motion/features/viewport/index.mjs
var vf = {
	some: 0,
	all: 1
}, yf = class extends Us {
	constructor() {
		super(...arguments), this.hasEnteredView = !1, this.isInView = !1;
	}
	startObserver() {
		this.stopObserver?.();
		let { viewport: e = {} } = this.node.getProps(), { root: t, margin: n, amount: r = "some", once: i } = e, a = {
			root: t ? t.current : void 0,
			rootMargin: n,
			threshold: typeof r == "number" ? r : vf[r]
		}, o = (e) => {
			let { isIntersecting: t } = e;
			if (this.isInView === t || (this.isInView = t, i && !t && this.hasEnteredView)) return;
			t && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", t);
			let { onViewportEnter: n, onViewportLeave: r } = this.node.getProps(), a = t ? n : r;
			a && a(e);
		};
		this.stopObserver = _f(this.node.current, a, o);
	}
	mount() {
		this.startObserver();
	}
	update() {
		if (typeof IntersectionObserver > "u") return;
		let { props: e, prevProps: t } = this.node;
		[
			"amount",
			"margin",
			"root"
		].some(bf(e, t)) && this.startObserver();
	}
	unmount() {
		this.stopObserver?.(), this.hasEnteredView = !1, this.isInView = !1;
	}
};
function bf({ viewport: e = {} }, { viewport: t = {} } = {}) {
	return (n) => e[n] !== t[n];
}
// node_modules/.pnpm/framer-motion@12.42.2_react_f3ba0e82349dc228ac700238c5269e02/node_modules/framer-motion/dist/es/motion/features/gestures.mjs
var xf = {
	inView: { Feature: yf },
	tap: { Feature: df },
	focus: { Feature: lf },
	hover: { Feature: cf }
}, Sf = { layout: {
	ProjectionNode: mu,
	MeasureLayout: af
} }, Cf = /*@__PURE__*/ _d({
	...xd,
	...xf,
	...of,
	...Sf
}, vd), wf = (e, t, n) => {
	let r = e.document.readSnapshot(), i = structuredClone(r.metadata);
	n(i);
	let a = e.document.applyEdit([{
		op: "setMetadata",
		entries: i
	}], `Metadata ${t}`, { expectedRevision: r.revision });
	return a.ok || e.ui.notify({
		level: "error",
		message: e.i18n.t("editFailed"),
		detail: a.error.message
	}), a;
}, Tf = (e) => e.split(/[\n,;/，；、|\\]/).map((e) => e.trim()).filter(Boolean);
function Ef(e) {
	let t = e.filter((e) => e.trim());
	return new Set(t).size !== t.length;
}
function Df(e, t, n, r) {
	return wf(e, "update value", (e) => {
		let i = e.find((e) => e.key === t);
		i || (i = {
			key: t,
			values: []
		}, e.push(i)), i.values[n] = r;
	});
}
function Of(e, t, n = "") {
	return wf(e, "add value", (e) => {
		let r = e.find((e) => e.key === t);
		r || (r = {
			key: t,
			values: []
		}, e.push(r)), r.values.push(n);
	});
}
function kf(e, t, n) {
	return wf(e, "remove value", (e) => {
		let r = e.findIndex((e) => e.key === t);
		r < 0 || (e[r].values.splice(n, 1), e[r].values.length || e.splice(r, 1));
	});
}
function Af(e, t, n) {
	let r = Tf(n);
	if (r.length) return wf(e, "append dropped values", (e) => {
		let n = e.find((e) => e.key === t);
		n || (n = {
			key: t,
			values: []
		}, e.push(n));
		let i = new Set(n.values.filter((e) => e.trim())), a = n.values.flatMap((e, t) => e.trim() ? [] : [t]);
		for (let e of r) {
			if (i.has(e)) continue;
			let t = a.shift();
			t == null ? n.values.push(e) : n.values[t] = e, i.add(e);
		}
	});
}
function jf(e, t) {
	let n = t.trim();
	return n ? (wf(e, "add custom key", (e) => {
		e.some((e) => e.key === n) || e.push({
			key: n,
			values: []
		});
	}), !0) : !1;
}
function Mf(e) {
	return wf(e, "clear all", (e) => {
		e.splice(0);
	});
}
// src/styles.ts
var $ = {
	contentTransition: "amll-metadata-contentTransition",
	customKeyForm: "amll-metadata-customKeyForm",
	dialogContent: "amll-metadata-dialogContent",
	dialogFooter: "amll-metadata-dialogFooter",
	dragOverCategory: "amll-metadata-dragOverCategory",
	dragOverInput: "amll-metadata-dragOverInput",
	editorPanel: "amll-metadata-editorPanel",
	emptyState: "amll-metadata-emptyState",
	header: "amll-metadata-header",
	mainPane: "amll-metadata-mainPane",
	metadataInput: "amll-metadata-metadataInput",
	navBadge: "amll-metadata-navBadge",
	navIcon: "amll-metadata-navIcon",
	navItem: "amll-metadata-navItem",
	navItemText: "amll-metadata-navItemText",
	navList: "amll-metadata-navList",
	pageTitle: "amll-metadata-pageTitle",
	scrollContent: "amll-metadata-scrollContent",
	sidebar: "amll-metadata-sidebar",
	sidebarTitle: "amll-metadata-sidebarTitle",
	srOnly: "amll-metadata-srOnly",
	titleBlock: "amll-metadata-titleBlock",
	titleMeta: "amll-metadata-titleMeta",
	valueList: "amll-metadata-valueList",
	valueRow: "amll-metadata-valueRow"
}, Nf = ".amll-metadata-dialogContent {\n	display: grid;\n	grid-template-columns: 240px minmax(0, 1fr);\n	gap: 0;\n	width: min(920px, calc(100vw - 48px));\n	height: min(680px, calc(100vh - 48px));\n	max-width: none;\n	max-height: none;\n	padding: 0;\n	overflow: hidden;\n}\n\n.amll-metadata-srOnly {\n	position: absolute;\n	width: 1px;\n	height: 1px;\n	padding: 0;\n	margin: -1px;\n	overflow: hidden;\n	clip: rect(0, 0, 0, 0);\n	white-space: nowrap;\n	border: 0;\n}\n\n.amll-metadata-sidebar {\n	display: flex;\n	min-width: 0;\n	min-height: 0;\n	flex-direction: column;\n	padding: var(--space-5) var(--space-2) var(--space-4);\n	border-right: 1px solid var(--gray-a4);\n}\n\n.amll-metadata-sidebarTitle {\n	padding: 0 var(--space-3) var(--space-3);\n}\n\n.amll-metadata-navList {\n	display: flex;\n	min-height: 0;\n	flex: 1 1 auto;\n	flex-direction: column;\n	gap: 4px;\n	overflow-y: auto;\n}\n\n.amll-metadata-navItem {\n	position: relative;\n	display: flex;\n	align-items: center;\n	gap: var(--space-3);\n	width: 100%;\n	min-height: 36px;\n	padding: 0 var(--space-3);\n	color: var(--gray-11);\n	font: inherit;\n	font-size: 14px;\n	text-align: left;\n	background: transparent;\n	border: 0;\n	border-radius: var(--radius-3);\n	cursor: pointer;\n}\n\n.amll-metadata-navItem:hover {\n	color: var(--gray-12);\n	background: var(--gray-a3);\n}\n\n.amll-metadata-navItem[data-active] {\n	color: var(--gray-12);\n	background: var(--accent-a3);\n}\n\n.amll-metadata-navItem[data-active]::before {\n	position: absolute;\n	left: 0;\n	width: 3px;\n	height: 18px;\n	content: \"\";\n	background: var(--accent-9);\n	border-radius: var(--radius-full);\n}\n\n.amll-metadata-navIcon {\n	display: flex;\n	width: 20px;\n	height: 20px;\n	flex: 0 0 auto;\n	align-items: center;\n	justify-content: center;\n	color: inherit;\n}\n\n.amll-metadata-navItemText {\n	min-width: 0;\n	flex: 1 1 auto;\n	overflow: hidden;\n	text-overflow: ellipsis;\n	white-space: nowrap;\n}\n\n.amll-metadata-navBadge {\n	min-width: 18px;\n	height: 18px;\n	padding: 0 6px;\n	color: var(--accent-11);\n	font-size: 12px;\n	line-height: 18px;\n	text-align: center;\n	background: var(--accent-a4);\n	border-radius: var(--radius-full);\n}\n\n.amll-metadata-customKeyForm {\n	display: flex;\n	flex: 0 0 auto;\n	gap: var(--space-2);\n	padding: var(--space-3) var(--space-1) 0;\n	border-top: 1px solid var(--gray-a4);\n}\n\n.amll-metadata-customKeyForm > :first-child {\n	min-width: 0;\n	flex: 1 1 auto;\n}\n\n.amll-metadata-mainPane {\n	display: flex;\n	min-width: 0;\n	min-height: 0;\n	flex-direction: column;\n}\n\n.amll-metadata-header {\n	flex: 0 0 auto;\n	padding: var(--space-5) var(--space-5) var(--space-4);\n}\n\n.amll-metadata-titleBlock {\n	display: inline-flex;\n	align-items: flex-end;\n	gap: var(--space-3);\n	max-width: 100%;\n}\n\n.amll-metadata-pageTitle {\n	line-height: 1.1;\n}\n\n.amll-metadata-titleMeta {\n	padding-bottom: 0.15em;\n}\n\n.amll-metadata-scrollContent {\n	min-height: 0;\n	flex: 1 1 auto;\n	padding: 0 var(--space-5) var(--space-5);\n	overflow: auto;\n}\n\n.amll-metadata-contentTransition {\n	min-height: 100%;\n	will-change: opacity, transform, filter;\n}\n\n.amll-metadata-editorPanel {\n	display: flex;\n	min-height: 100%;\n	flex-direction: column;\n	gap: var(--space-3);\n	padding: var(--space-4);\n	background: var(--gray-a2);\n	border: 1px solid var(--gray-a4);\n	border-radius: var(--radius-3);\n}\n\n.amll-metadata-valueList {\n	display: flex;\n	flex-direction: column;\n	gap: var(--space-2);\n}\n\n.amll-metadata-valueRow {\n	min-width: 0;\n}\n\n.amll-metadata-metadataInput {\n	flex: 1 1 auto;\n	min-width: 0;\n}\n\n.amll-metadata-emptyState {\n	display: flex;\n	min-height: 96px;\n	align-items: center;\n	justify-content: center;\n	text-align: center;\n	border: 1px dashed var(--gray-a6);\n	border-radius: var(--radius-3);\n}\n\n.amll-metadata-dragOverInput {\n	box-shadow: 0 0 0 2px var(--accent-9);\n	background-color: var(--accent-3);\n}\n\n.amll-metadata-dragOverCategory {\n	outline: 2px solid var(--accent-9);\n	background-color: var(--gray-3);\n}\n\n.amll-metadata-dialogFooter {\n	padding: var(--space-4) var(--space-5);\n	border-top: 1px solid var(--gray-a4);\n	flex-shrink: 0;\n	background: var(--color-bg-1);\n}\n\n@media (max-width: 720px) {\n	.amll-metadata-dialogContent {\n		grid-template-columns: 1fr;\n		width: min(100vw - 24px, 560px);\n		height: min(100vh - 24px, 720px);\n	}\n\n	.amll-metadata-sidebar {\n		padding: var(--space-3);\n		border-right: 0;\n		border-bottom: 1px solid var(--gray-a4);\n	}\n\n	.amll-metadata-sidebarTitle {\n		padding: 0 var(--space-1) var(--space-2);\n	}\n\n	.amll-metadata-navList {\n		flex: 0 0 auto;\n		flex-direction: row;\n		overflow-x: auto;\n		overflow-y: hidden;\n	}\n\n	.amll-metadata-navItem {\n		width: auto;\n		flex: 0 0 auto;\n		padding: 0 var(--space-3);\n	}\n\n	.amll-metadata-navItem[data-active]::before {\n		display: none;\n	}\n\n	.amll-metadata-customKeyForm {\n		padding: var(--space-3) 0 0;\n	}\n\n	.amll-metadata-header {\n		padding: var(--space-4) var(--space-4) var(--space-3);\n	}\n\n	.amll-metadata-scrollContent {\n		padding: 0 var(--space-4) var(--space-4);\n	}\n\n	.amll-metadata-dialogFooter {\n		padding: var(--space-4);\n	}\n}\n\n/* Keep the host-owned accessible dialog, with the original edge-to-edge body. */\n[role=\"dialog\"]:has(> [data-amll-plugin-scope=\"builtin.metadata\"]) {\n width: min(920px, calc(100vw - 48px));\n padding: 0;\n overflow: hidden;\n}\n[role=\"dialog\"]:has(> [data-amll-plugin-scope=\"builtin.metadata\"]) > :is(h1, h2) {\n position: absolute;\n width: 1px;\n height: 1px;\n padding: 0;\n margin: -1px;\n overflow: hidden;\n clip: rect(0, 0, 0, 0);\n white-space: nowrap;\n border: 0;\n}\n", Pf = (e) => /* @__PURE__ */ S("svg", {
	width: "16",
	height: "16",
	viewBox: "0 0 24 24",
	xmlns: "http://www.w3.org/2000/svg",
	...e,
	children: [
		/* @__PURE__ */ x("title", { children: "NetEase Cloud Music" }),
		/* @__PURE__ */ x("circle", {
			cx: "12",
			cy: "12",
			r: "10",
			fill: "white"
		}),
		/* @__PURE__ */ x("path", {
			d: "M13.046 9.388a3.919 3.919 0 0 0-.66.19c-.809.312-1.447.991-1.666 1.775a2.269 2.269 0 0 0-.074.81c.048.546.333 1.05.764 1.35a1.483 1.483 0 0 0 2.01-.286c.406-.531.355-1.183.24-1.636-.098-.387-.22-.816-.345-1.249a64.76 64.76 0 0 1-.269-.954zm-.82 10.07c-3.984 0-7.224-3.24-7.224-7.223 0-.98.226-3.02 1.884-4.822A7.188 7.188 0 0 1 9.502 5.6a.792.792 0 1 1 .587 1.472 5.619 5.619 0 0 0-2.795 2.462 5.538 5.538 0 0 0-.707 2.7 5.645 5.645 0 0 0 5.638 5.638c1.844 0 3.627-.953 4.542-2.428 1.042-1.68.772-3.931-.627-5.238a3.299 3.299 0 0 0-1.437-.777c.172.589.334 1.18.494 1.772.284 1.12.1 2.181-.519 2.989-.39.51-.956.888-1.592 1.064a3.038 3.038 0 0 1-2.58-.44 3.45 3.45 0 0 1-1.44-2.514c-.04-.467.002-.93.128-1.376.35-1.256 1.356-2.339 2.622-2.826a5.5 5.5 0 0 1 .823-.246l-.134-.505c-.37-1.371.25-2.579 1.547-3.007.329-.109.68-.145 1.025-.105.792.09 1.476.592 1.709 1.023.258.507-.096 1.153-.706 1.153a.788.788 0 0 1-.54-.213c-.088-.08-.163-.174-.259-.247a.825.825 0 0 0-.632-.166.807.807 0 0 0-.634.551c-.056.191-.031.406.02.595.07.256.159.597.217.82 1.11.098 2.162.54 2.97 1.296 1.974 1.844 2.35 4.886.892 7.233-1.197 1.93-3.509 3.177-5.889 3.177zM0 12c0 6.627 5.373 12 12 12s12-5.373 12-12S18.627 0 12 0 0 5.373 0 12Z",
			fill: "#D43C33"
		})
	]
}), Ff = (e) => /* @__PURE__ */ S("svg", {
	width: "16",
	height: "16",
	viewBox: "0 0 1024 1024",
	version: "1.1",
	xmlns: "http://www.w3.org/2000/svg",
	...e,
	children: [
		/* @__PURE__ */ x("title", { children: "QQ Music" }),
		/* @__PURE__ */ x("path", {
			d: "M35.84 529.92c0 263.68 215.04 478.72 478.72 478.72 263.68 0 478.72-215.04 478.72-478.72C993.28 266.24 780.8 51.2 514.56 51.2 250.88 51.2 35.84 266.24 35.84 529.92z",
			fill: "#FFDF3D"
		}),
		/* @__PURE__ */ x("path", {
			d: "M660.48 10.24c-17.92 20.48-56.32 38.4-107.52 51.2-87.04 20.48-104.96 25.6-130.56 40.96-15.36 7.68-33.28 20.48-43.52 30.72-20.48 17.92-35.84 51.2-30.72 61.44 2.56 5.12 51.2 74.24 110.08 158.72 58.88 81.92 115.2 163.84 128 181.76 12.8 17.92 20.48 33.28 20.48 33.28 0 2.56-10.24 0-20.48-2.56-40.96-12.8-112.64 0-163.84 25.6-38.4 20.48-81.92 64-99.84 99.84-20.48 40.96-23.04 97.28-7.68 135.68 15.36 40.96 48.64 74.24 92.16 97.28 33.28 17.92 40.96 17.92 84.48 20.48 35.84 2.56 56.32 0 76.8-5.12 94.72-28.16 163.84-102.4 168.96-189.44 2.56-48.64-2.56-64-66.56-176.64-99.84-174.08-189.44-332.8-189.44-335.36 0 0 17.92-2.56 40.96-5.12 66.56-2.56 120.32-35.84 148.48-89.6 12.8-23.04 12.8-30.72 12.8-79.36 0-30.72-2.56-58.88-5.12-61.44-2.56-7.68-5.12-5.12-17.92 7.68z",
			fill: "#00C079"
		})
	]
}), If = (e) => /* @__PURE__ */ S("svg", {
	width: "16",
	height: "16",
	viewBox: "0 0 24 24",
	xmlns: "http://www.w3.org/2000/svg",
	...e,
	children: [
		/* @__PURE__ */ x("title", { children: "Spotify" }),
		/* @__PURE__ */ x("circle", {
			cx: "12",
			cy: "12",
			r: "10",
			fill: "black"
		}),
		/* @__PURE__ */ x("path", {
			d: "M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z",
			fill: "#1ED760"
		})
	]
}), Lf = (e) => /* @__PURE__ */ S("svg", {
	width: "16",
	height: "16",
	viewBox: "0 0 24 24",
	xmlns: "http://www.w3.org/2000/svg",
	...e,
	children: [
		/* @__PURE__ */ x("title", { children: "Apple Music" }),
		/* @__PURE__ */ x("circle", {
			cx: "12",
			cy: "12",
			r: "10",
			fill: "white"
		}),
		/* @__PURE__ */ x("path", {
			d: "M23.994 6.124a9.23 9.23 0 00-.24-2.19c-.317-1.31-1.062-2.31-2.18-3.043a5.022 5.022 0 00-1.877-.726 10.496 10.496 0 00-1.564-.15c-.04-.003-.083-.01-.124-.013H5.986c-.152.01-.303.017-.455.026-.747.043-1.49.123-2.193.4-1.336.53-2.3 1.452-2.865 2.78-.192.448-.292.925-.363 1.408-.056.392-.088.785-.1 1.18 0 .032-.007.062-.01.093v12.223c.01.14.017.283.027.424.05.815.154 1.624.497 2.373.65 1.42 1.738 2.353 3.234 2.801.42.127.856.187 1.293.228.555.053 1.11.06 1.667.06h11.03a12.5 12.5 0 001.57-.1c.822-.106 1.596-.35 2.295-.81a5.046 5.046 0 001.88-2.207c.186-.42.293-.87.37-1.324.113-.675.138-1.358.137-2.04-.002-3.8 0-7.595-.003-11.393zm-6.423 3.99v5.712c0 .417-.058.827-.244 1.206-.29.59-.76.962-1.388 1.14-.35.1-.706.157-1.07.173-.95.045-1.773-.6-1.943-1.536a1.88 1.88 0 011.038-2.022c.323-.16.67-.25 1.018-.324.378-.082.758-.153 1.134-.24.274-.063.457-.23.51-.516a.904.904 0 00.02-.193c0-1.815 0-3.63-.002-5.443a.725.725 0 00-.026-.185c-.04-.15-.15-.243-.304-.234-.16.01-.318.035-.475.066-.76.15-1.52.303-2.28.456l-2.325.47-1.374.278c-.016.003-.032.01-.048.013-.277.077-.377.203-.39.49-.002.042 0 .086 0 .13-.002 2.602 0 5.204-.003 7.805 0 .42-.047.836-.215 1.227-.278.64-.77 1.04-1.434 1.233-.35.1-.71.16-1.075.172-.96.036-1.755-.6-1.92-1.544-.14-.812.23-1.685 1.154-2.075.357-.15.73-.232 1.108-.31.287-.06.575-.116.86-.177.383-.083.583-.323.6-.714v-.15c0-2.96 0-5.922.002-8.882 0-.123.013-.25.042-.37.07-.285.273-.448.546-.518.255-.066.515-.112.774-.165.733-.15 1.466-.296 2.2-.444l2.27-.46c.67-.134 1.34-.27 2.01-.403.22-.043.442-.088.663-.106.31-.025.523.17.554.482.008.073.012.148.012.223.002 1.91.002 3.822 0 5.732z",
			fill: "#FA243C"
		})
	]
}), Rf = (e) => /* @__PURE__ */ S("svg", {
	width: "16",
	height: "16",
	viewBox: "0 0 24 24",
	fill: "currentColor",
	xmlns: "http://www.w3.org/2000/svg",
	...e,
	children: [/* @__PURE__ */ x("title", { children: "GitHub" }), /* @__PURE__ */ x("path", { d: "M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12" })]
}), zf = {
	duration: .25,
	ease: [
		.4,
		0,
		.2,
		1
	]
}, Bf = {
	initial: {
		opacity: 0,
		y: 12
	},
	animate: {
		opacity: 1,
		y: 0
	}
}, Vf = l(({ entry: e, option: t, host: n, service: r }) => {
	y(r.subscribe, r.getVersion, r.getVersion);
	let [i, a] = v(null), o = _(!1), s = (e, t) => n.i18n.t(e), c = _([]), [l, d] = v(null), [p, m] = v(!1), [h, b] = v(null), C = e?.values ?? [], w = t.validation;
	f(() => {
		if (l === null) return;
		let e = c.current[l];
		if (e) {
			e.focus();
			let t = e.value.length;
			e.setSelectionRange(t, t);
		}
		d(null);
	}, [l]);
	let E = u((e, r) => Df(n, t.value, e, r), [n, t.value]), ee = u((e = "") => {
		Of(n, t.value, e), d(C.length);
	}, [
		n,
		t.value,
		C.length
	]), te = u((e) => {
		kf(n, t.value, e);
	}, [n, t.value]), ae = u((e) => {
		Af(n, t.value, e);
	}, [n, t.value]), oe = w ? C.some((e) => e.trim() !== "" && !w.verifier(e)) : !1, se = g(() => Ef(C), [C]);
	return /* @__PURE__ */ S("div", {
		className: `${$.editorPanel} ${p ? $.dragOverCategory : ""}`,
		onDragOver: (e) => {
			e.preventDefault(), m(!0);
		},
		onDragLeave: (e) => {
			e.currentTarget.contains(e.relatedTarget) || m(!1);
		},
		onDrop: (e) => {
			e.preventDefault(), m(!1), ae(e.dataTransfer.getData("text"));
		},
		children: [
			/* @__PURE__ */ S("div", {
				className: $.valueList,
				children: [C.length === 0 && /* @__PURE__ */ x("div", {
					className: $.emptyState,
					children: /* @__PURE__ */ x(O, {
						color: "gray",
						children: s("metadataDialog.emptyItem", "此项尚未添加任何条目")
					})
				}), C.map((e, l) => {
					let u = w ? e.trim() !== "" && !w.verifier(e) : !1, f = e.trim() !== "" && C.filter((t) => t === e).length > 1, p = u || f, g = t.urlFormatter?.(e), _ = !w || w.verifier(e), v = !!g && _;
					return /* @__PURE__ */ S(D, {
						gap: "2",
						align: "center",
						className: $.valueRow,
						children: [
							/* @__PURE__ */ x(ie.Root, {
								"aria-label": t.label,
								"data-metadata-input": "true",
								ref: (e) => {
									c.current[l] = e;
								},
								value: e,
								className: `${$.metadataInput} ${h === l ? $.dragOverInput : ""}`,
								onChange: (e) => E(l, e.currentTarget.value),
								onKeyDown: (e) => {
									if (e.key === "Enter") e.preventDefault(), ee();
									else if (e.key === "Backspace" && e.currentTarget.value === "") {
										if (e.repeat) return;
										e.preventDefault(), te(l), d(l > 0 ? l - 1 : 0);
									}
								},
								onDragOver: (e) => {
									e.preventDefault(), e.stopPropagation(), b(l);
								},
								onDragLeave: () => b(null),
								onDrop: (e) => {
									e.preventDefault(), e.stopPropagation(), b(null), m(!1);
									let t = e.dataTransfer.getData("text");
									t && E(l, t);
								},
								variant: p ? "soft" : "surface",
								color: u ? w?.severe ? "red" : "orange" : f ? "red" : void 0
							}),
							r.selected(t.value).length > 0 && /* @__PURE__ */ x(ne, {
								variant: "soft",
								disabled: i !== null || !e.trim() || !_,
								title: s("providers.fetch"),
								"aria-label": s("providers.fetch"),
								onClick: async () => {
									if (!o.current) {
										o.current = !0, a(l);
										try {
											await r.fetch(t.value, e.trim());
										} catch (e) {
											r.isActive() && n.ui.notify({
												level: "warning",
												message: s("providers.fetchFailed"),
												detail: String(e)
											});
										} finally {
											o.current = !1, a(null);
										}
									}
								},
								children: i === l ? /* @__PURE__ */ x(re, { size: "1" }) : /* @__PURE__ */ x(Bt, {})
							}),
							t.isLinkable && /* @__PURE__ */ x(ne, {
								disabled: !v,
								asChild: v,
								variant: "soft",
								title: s("metadataDialog.openLink", "打开链接"),
								children: v ? /* @__PURE__ */ x("a", {
									href: g || "",
									target: "_blank",
									rel: "noopener noreferrer",
									children: /* @__PURE__ */ x(Vt, {})
								}) : /* @__PURE__ */ x(Vt, {})
							}),
							/* @__PURE__ */ x(ne, {
								variant: "soft",
								"aria-label": s("deleteValue"),
								onClick: () => te(l),
								children: /* @__PURE__ */ x(Jt, {})
							})
						]
					}, `${t.value}-${l}`);
				})]
			}),
			w && oe && /* @__PURE__ */ x(O, {
				color: w.severe ? "red" : "orange",
				size: "1",
				wrap: "wrap",
				children: w.message
			}),
			se && /* @__PURE__ */ x(O, {
				color: "red",
				size: "1",
				wrap: "wrap",
				children: s("metadataDialog.duplicateMsg", "存在重复的元数据值")
			}),
			/* @__PURE__ */ S(T, {
				variant: "soft",
				onClick: () => ee(),
				children: [/* @__PURE__ */ x(Ut, {}), s("metadataDialog.addValue", "添加")]
			})
		]
	});
}), Hf = ({ host: e, service: t }) => {
	let [n, r] = v("");
	y((t) => {
		let n = e.document.onChanged(t);
		return () => n.dispose();
	}, () => e.document.revision, () => e.document.revision);
	let i = y((t) => {
		let n = e.i18n.onLocaleChanged(t);
		return () => n.dispose();
	}, () => e.i18n.locale, () => e.i18n.locale), a = e.document.readSnapshot(), o = u((t, n) => e.i18n.t(t), [e, i]), s = g(() => {
		let e = (e) => /^\d+$/.test(e), t = (e) => /^[a-zA-Z0-9]+$/.test(e), n = (e, t) => {
			if (!t?.trim()) return null;
			switch (e) {
				case "ncmMusicId": return `https://music.163.com/#/song?id=${t}`;
				case "qqMusicId": return `https://y.qq.com/n/ryqq/songDetail/${t}`;
				case "spotifyId": return `https://open.spotify.com/track/${t}`;
				case "appleMusicId": return `https://music.apple.com/song/${t}`;
				case "ttmlAuthorGithubLogin": return `https://github.com/${t}`;
				case "isrc": return `https://isrcsearch.ifpi.org/?tab=%22code%22&isrcCode=%22${t}%22`;
				default: return null;
			}
		};
		return [
			{
				label: o("metadataDialog.builtinOptions.musicName", "歌曲名称"),
				value: "musicName",
				icon: /* @__PURE__ */ x(Lt, {})
			},
			{
				label: o("metadataDialog.builtinOptions.artists", "歌曲的艺术家"),
				value: "artists",
				icon: /* @__PURE__ */ x(zt, {}),
				validation: {
					verifier: (e) => !/^.+[,;&，；、].+$/.test(e),
					message: o("metadataDialog.builtinOptions.artistsInvalidMsg", "如果有多个艺术家，请多次添加该键值，避免使用分隔符")
				}
			},
			{
				label: o("metadataDialog.builtinOptions.songwriter", "词曲作者"),
				value: "songwriter",
				icon: /* @__PURE__ */ x(zt, {}),
				validation: {
					verifier: (e) => !/^.+[,;&，；、].+$/.test(e),
					message: o("metadataDialog.builtinOptions.songwriterInvalidMsg", "如果有多个词曲作者，请多次添加该键值，避免使用分隔符")
				}
			},
			{
				label: o("metadataDialog.builtinOptions.album", "歌曲的专辑名"),
				value: "album",
				icon: /* @__PURE__ */ x(It, {})
			},
			{
				label: o("metadataDialog.builtinOptions.ncmMusicId", "网易云音乐 ID"),
				value: "ncmMusicId",
				icon: /* @__PURE__ */ x(Pf, {}),
				isLinkable: !0,
				urlFormatter: (e) => n("ncmMusicId", e),
				validation: {
					verifier: e,
					message: o("metadataDialog.builtinOptions.ncmMusicIdInvalidMsg", "网易云音乐 ID 应为纯数字"),
					severe: !0
				}
			},
			{
				label: o("metadataDialog.builtinOptions.qqMusicId", "QQ 音乐 ID"),
				value: "qqMusicId",
				icon: /* @__PURE__ */ x(Ff, {}),
				isLinkable: !0,
				urlFormatter: (e) => n("qqMusicId", e),
				validation: {
					verifier: t,
					message: o("metadataDialog.builtinOptions.qqMusicIdInvalidMsg", "QQ 音乐 ID 应为字母或数字"),
					severe: !0
				}
			},
			{
				label: o("metadataDialog.builtinOptions.spotifyId", "Spotify 音乐 ID"),
				value: "spotifyId",
				icon: /* @__PURE__ */ x(If, {}),
				isLinkable: !0,
				urlFormatter: (e) => n("spotifyId", e),
				validation: {
					verifier: t,
					message: o("metadataDialog.builtinOptions.spotifyIdInvalidMsg", "Spotify ID 应为字母或数字"),
					severe: !0
				}
			},
			{
				label: o("metadataDialog.builtinOptions.appleMusicId", "Apple Music 音乐 ID"),
				value: "appleMusicId",
				icon: /* @__PURE__ */ x(Lf, {}),
				isLinkable: !0,
				urlFormatter: (e) => n("appleMusicId", e),
				validation: {
					verifier: e,
					message: o("metadataDialog.builtinOptions.appleMusicIdInvalidMsg", "Apple Music ID 应为纯数字"),
					severe: !0
				}
			},
			{
				label: o("metadataDialog.builtinOptions.isrc", "歌曲的 ISRC 号码"),
				value: "isrc",
				icon: /* @__PURE__ */ x(Rt, {}),
				isLinkable: !0,
				urlFormatter: (e) => n("isrc", e),
				validation: {
					verifier: (e) => /^[A-Z]{2}-?[A-Z0-9]{3}-?\d{2}-?\d{5}$/.test(e),
					message: o("metadataDialog.builtinOptions.isrcInvalidMsg", "ISRC 编码格式应为 CC-XXX-YY-NNNNN"),
					severe: !0
				}
			},
			{
				label: o("metadataDialog.builtinOptions.ttmlAuthorGithub", "歌词作者 GitHub ID"),
				value: "ttmlAuthorGithub",
				icon: /* @__PURE__ */ x(Rf, {}),
				validation: {
					verifier: e,
					message: o("metadataDialog.builtinOptions.ttmlAuthorGithubInvalidMsg", "GitHub ID 应为纯数字"),
					severe: !0
				}
			},
			{
				label: o("metadataDialog.builtinOptions.ttmlAuthorGithubLogin", "歌词作者 GitHub 用户名"),
				value: "ttmlAuthorGithubLogin",
				icon: /* @__PURE__ */ x(Rf, {}),
				isLinkable: !0,
				urlFormatter: (e) => n("ttmlAuthorGithubLogin", e),
				validation: {
					verifier: (e) => /^(?!.*--)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,37}[a-zA-Z0-9])?$/.test(e),
					message: o("metadataDialog.builtinOptions.ttmlAuthorGithubLoginInvalidMsg", "GitHub username should be alphanumeric or hyphens, up to 39 characters"),
					severe: !0
				}
			}
		];
	}, [o]), c = g(() => a.metadata.filter((e) => !s.some((t) => t.value === e.key)).map((e) => ({
		label: e.key,
		value: e.key,
		icon: /* @__PURE__ */ x(Ht, {})
	})), [s, a.metadata]), l = g(() => [...s, ...c], [s, c]), [d, p] = v(() => s[0]?.value ?? ""), m = l.find((e) => e.value === d) ?? l[0], h = a.metadata.find((e) => e.key === m?.value) ?? null;
	f(() => {
		m || p(s[0]?.value ?? "");
	}, [m, s]);
	let _ = u(() => {
		let t = n.trim();
		t && (jf(e, t), p(t), r(""));
	}, [e, n]), b = u(() => {
		Mf(e), p(s[0]?.value ?? "");
	}, [e, s]);
	return /* @__PURE__ */ S("div", {
		className: $.dialogContent,
		children: [
			/* @__PURE__ */ x("style", { children: Nf }),
			/* @__PURE__ */ S("aside", {
				className: $.sidebar,
				children: [
					/* @__PURE__ */ x(O, {
						as: "div",
						weight: "bold",
						size: "2",
						className: $.sidebarTitle,
						children: o("metadataDialog.title", "元数据编辑器")
					}),
					/* @__PURE__ */ x("nav", {
						className: $.navList,
						children: l.map((e) => {
							let t = m?.value === e.value, n = a.metadata.find((t) => t.key === e.value)?.values.filter((e) => e.trim() !== "").length ?? 0;
							return /* @__PURE__ */ S("button", {
								type: "button",
								className: $.navItem,
								"data-active": t || void 0,
								onClick: () => p(e.value),
								children: [
									/* @__PURE__ */ x("span", {
										className: $.navIcon,
										children: e.icon
									}),
									/* @__PURE__ */ x("span", {
										className: $.navItemText,
										children: e.label
									}),
									n > 0 && /* @__PURE__ */ x("span", {
										className: $.navBadge,
										children: n
									})
								]
							}, e.value);
						})
					}),
					/* @__PURE__ */ S("div", {
						className: $.customKeyForm,
						children: [/* @__PURE__ */ x(ie.Root, {
							placeholder: o("metadataDialog.customKey", "自定义键名"),
							value: n,
							onChange: (e) => r(e.currentTarget.value),
							onKeyDown: (e) => {
								e.key === "Enter" && (e.preventDefault(), _());
							}
						}), /* @__PURE__ */ x(ne, {
							variant: "soft",
							"aria-label": o("metadataDialog.addValue"),
							onClick: _,
							children: /* @__PURE__ */ x(Ut, {})
						})]
					})
				]
			}),
			/* @__PURE__ */ S("section", {
				className: $.mainPane,
				children: [
					/* @__PURE__ */ x("header", {
						className: $.header,
						children: /* @__PURE__ */ S("div", {
							className: $.titleBlock,
							children: [/* @__PURE__ */ x(te, {
								size: "7",
								className: $.pageTitle,
								children: m?.label
							}), m && /* @__PURE__ */ x(O, {
								size: "2",
								color: "gray",
								className: $.titleMeta,
								children: m.value
							})]
						})
					}),
					/* @__PURE__ */ x("div", {
						className: $.scrollContent,
						children: /* @__PURE__ */ x(Eu, {
							mode: "wait",
							initial: !1,
							children: m && /* @__PURE__ */ x(Cf.div, {
								className: $.contentTransition,
								variants: Bf,
								initial: "initial",
								animate: "animate",
								transition: zf,
								children: /* @__PURE__ */ x(Vf, {
									host: e,
									service: t,
									entry: h,
									option: m
								})
							}, m.value)
						})
					}),
					/* @__PURE__ */ S(D, {
						gap: "2",
						direction: {
							sm: "row",
							initial: "column"
						},
						className: $.dialogFooter,
						children: [/* @__PURE__ */ S(T, {
							style: { flex: "1 0 auto" },
							color: "red",
							variant: "solid",
							onClick: b,
							children: [/* @__PURE__ */ x(Jt, {}), o("metadataDialog.clear", "清空")]
						}), /* @__PURE__ */ x(T, {
							asChild: !0,
							variant: "soft",
							children: /* @__PURE__ */ S("a", {
								target: "_blank",
								rel: "noreferrer",
								href: "https://github.com/amll-dev/amll-ttml-tool/wiki/%E6%AD%8C%E8%AF%8D%E5%85%83%E6%95%B0%E6%8D%AE",
								children: [/* @__PURE__ */ x(Ht, {}), o("metadataDialog.info", "了解详情")]
							})
						})]
					})
				]
			})
		]
	});
}, Uf = {
	"metadataDialog.openLink": {
		"cs-CZ": "Otevřít odkaz",
		"da-DK": "Åbn link",
		"en-US": "Open link",
		"es-ES": "Abrir enlace",
		"fr-FR": "Ouvrir le lien",
		"id-ID": "Buka Tautan",
		"pl-PL": "Otwórz link",
		"pt-BR": "Abrir link",
		"ru-RU": "Открыть ссылку",
		"sk-SK": "Otvoriť odkaz",
		"zh-CN": "打开链接",
		default: "Open link"
	},
	"metadataDialog.duplicateMsg": {
		"cs-CZ": "Nalezeny duplicitní hodnoty metadat",
		"da-DK": "Fandt duplikerede metadataværdier",
		"en-US": "Found duplicate metadata values",
		"es-ES": "Se encontraron valores de metadatos duplicados",
		"fr-FR": "Valeurs de métadonnées en double trouvées",
		"id-ID": "Ada nilai metadata yang duplikat",
		"pl-PL": "Znaleziono zduplikowane wartości metadanych",
		"pt-BR": "Encontrados valores de metadados duplicados",
		"ru-RU": "Найдены дублирующиеся значения метаданных",
		"sk-SK": "Nájdené duplicitné hodnoty metadát",
		"zh-CN": "存在重复的元数据值",
		default: "Found duplicate metadata values"
	},
	"metadataDialog.addValue": {
		"cs-CZ": "Přidat",
		"da-DK": "Tilføj",
		"en-US": "Add",
		"es-ES": "Añadir",
		"fr-FR": "Ajouter",
		"id-ID": "Tambah",
		"pl-PL": "Dodaj",
		"pt-BR": "Adicionar",
		"ru-RU": "Добавить",
		"sk-SK": "Pridať",
		"zh-CN": "添加",
		default: "Add"
	},
	"metadataDialog.builtinOptions.musicName": {
		"cs-CZ": "Název skladby",
		"da-DK": "Sangnavn",
		"en-US": "Track Name",
		"es-ES": "Nombre de la pista",
		"fr-FR": "Nom de la piste",
		"id-ID": "Judul Lagu",
		"pl-PL": "Nazwa utworu",
		"pt-BR": "Nome da faixa",
		"ru-RU": "Название трека",
		"sk-SK": "Názov skladby",
		"zh-CN": "歌曲名称",
		default: "Track Name"
	},
	"metadataDialog.builtinOptions.artists": {
		"cs-CZ": "Umělci skladby",
		"da-DK": "Sangkunstnere",
		"en-US": "Track Artists",
		"es-ES": "Artistas de la pista",
		"fr-FR": "Artistes de la piste",
		"id-ID": "Artis Lagu",
		"pl-PL": "Artyści",
		"pt-BR": "Artistas da faixa",
		"ru-RU": "Исполнители трека",
		"sk-SK": "Umelci skladby",
		"zh-CN": "歌曲的艺术家",
		default: "Track Artists"
	},
	"metadataDialog.builtinOptions.artistsInvalidMsg": {
		"cs-CZ": "Pokud je více umělců, přidejte tento klíč vícekrát místo použití oddělovačů; pokud jméno umělce obsahuje oddělovače, ignorujte tuto zprávu",
		"da-DK": "Hvis der er flere kunstnere, tilføj venligst denne nøgle flere gange i stedet for at bruge afgrænsere; hvis et kunstnernavn indeholder afgrænsere, ignorer venligst denne besked",
		"en-US": "If there are multiple artists, please add this key multiple times instead of using delimiters; if an artist name contains delimiters, please ignore this message",
		"es-ES": "Si hay múltiples artistas, añade esta clave múltiples veces en lugar de usar delimitadores; si un nombre de artista contiene delimitadores, ignora este mensaje",
		"fr-FR": "S'il y a plusieurs artistes, ajoutez cette clé plusieurs fois au lieu d'utiliser des délimiteurs ; si un nom d'artiste contient des délimiteurs, ignorez ce message",
		"id-ID": "Jika ada lebih dari satu artis, silakan tambahkan kunci ini beberapa kali tanpa tanda pemisah; abaikan jika nama artis itu sendiri mengandung tanda pemisah",
		"pl-PL": "Jeśli jest wielu artystów, dodaj ten klucz wielokrotnie zamiast używać separatorów; jeśli nazwa artysty zawiera separatory, zignoruj tę wiadomość",
		"pt-BR": "Se houver múltiplos artistas, adicione esta chave várias vezes em vez de usar delimitadores; se um nome de artista contiver delimitadores, ignore esta mensagem",
		"ru-RU": "Если несколько исполнителей, добавьте этот ключ несколько раз вместо использования разделителей; если имя исполнителя содержит разделители, проигнорируйте это сообщение",
		"sk-SK": "Ak je viac umelcov, pridajte tento kľúč viackrát namiesto použitia oddeľovačov; ak meno umelca obsahuje oddeľovače, ignorujte túto správu",
		"zh-CN": "如果有多个艺术家，请多次添加该键值，避免使用分隔符号；若艺术家名本身包含分隔符号，请忽略此提示",
		default: "If there are multiple artists, please add this key multiple times instead of using delimiters; if an artist name contains delimiters, please ignore this message"
	},
	"metadataDialog.builtinOptions.songwriter": {
		"cs-CZ": "Skladatel",
		"da-DK": "Sangskriver",
		"en-US": "Songwriter",
		"es-ES": "Compositor",
		"fr-FR": "Auteur-compositeur",
		"id-ID": "Penulis Lagu",
		"pl-PL": "Autor tekstu",
		"pt-BR": "Compositor",
		"ru-RU": "Автор песни",
		"sk-SK": "Skladateľ",
		"zh-CN": "词曲作者",
		default: "Songwriter"
	},
	"metadataDialog.builtinOptions.songwriterInvalidMsg": {
		"cs-CZ": "Pokud je více skladatelů, přidejte tento klíč vícekrát místo použití oddělovačů",
		"da-DK": "Hvis der er flere sangskrivere, tilføj venligst denne nøgle flere gange i stedet for at bruge afgrænsere",
		"en-US": "If there are multiple songwriters, please add this key multiple times instead of using delimiters",
		"es-ES": "Si hay múltiples compositores, añade esta clave múltiples veces en lugar de usar delimitadores",
		"fr-FR": "S'il y a plusieurs auteurs-compositeurs, ajoutez cette clé plusieurs fois au lieu d'utiliser des délimiteurs",
		"id-ID": "Jika ada lebih dari satu penulis lagu, silakan tambahkan kunci ini beberapa kali tanpa tanda pemisah",
		"pl-PL": "Jeśli jest wielu autorów, dodaj ten klucz wielokrotnie zamiast używać separatorów",
		"pt-BR": "Se houver múltiplos compositores, adicione esta chave várias vezes em vez de usar delimitadores",
		"ru-RU": "Если несколько авторов, добавьте этот ключ несколько раз вместо использования разделителей",
		"sk-SK": "Ak je viac skladateľov, pridajte tento kľúč viackrát namiesto použitia oddeľovačov",
		"zh-CN": "如果有多个词曲作者，请多次添加该键值，避免使用分隔符",
		default: "If there are multiple songwriters, please add this key multiple times instead of using delimiters"
	},
	"metadataDialog.builtinOptions.album": {
		"cs-CZ": "Název alba",
		"da-DK": "Albumnavn",
		"en-US": "Album Name",
		"es-ES": "Nombre del álbum",
		"fr-FR": "Nom de l'album",
		"id-ID": "Nama Album Lagu",
		"pl-PL": "Nazwa albumu",
		"pt-BR": "Nome do álbum",
		"ru-RU": "Название альбома",
		"sk-SK": "Názov albumu",
		"zh-CN": "歌曲的专辑名",
		default: "Album Name"
	},
	"metadataDialog.builtinOptions.ncmMusicId": {
		"cs-CZ": "ID NetEase Music",
		"da-DK": "NetEase Music ID",
		"en-US": "NetEase Music ID",
		"es-ES": "ID de NetEase Music",
		"fr-FR": "ID NetEase Music",
		"id-ID": "ID Musik NetEase",
		"pl-PL": "ID NetEase Music",
		"pt-BR": "ID do NetEase Music",
		"ru-RU": "ID NetEase Music",
		"sk-SK": "ID NetEase Music",
		"zh-CN": "网易云音乐 ID",
		default: "NetEase Music ID"
	},
	"metadataDialog.builtinOptions.ncmMusicIdInvalidMsg": {
		"cs-CZ": "ID NetEase Music musí být číselné",
		"da-DK": "NetEase Music ID skal være numerisk",
		"en-US": "NetEase Music ID should be numeric",
		"es-ES": "El ID de NetEase Music debe ser numérico",
		"fr-FR": "L'ID NetEase Music doit être numérique",
		"id-ID": "ID Musik NetEase harus berupa angka",
		"pl-PL": "ID NetEase Music powinno być liczbowe",
		"pt-BR": "O ID do NetEase Music deve ser numérico",
		"ru-RU": "ID NetEase Music должен быть числовым",
		"sk-SK": "ID NetEase Music musí byť číselné",
		"zh-CN": "网易云音乐 ID 应为纯数字",
		default: "NetEase Music ID should be numeric"
	},
	"metadataDialog.builtinOptions.qqMusicId": {
		"cs-CZ": "ID QQ Music",
		"da-DK": "QQ Music ID",
		"en-US": "QQ Music ID",
		"es-ES": "ID de QQ Music",
		"fr-FR": "ID QQ Music",
		"id-ID": "ID Musik QQ",
		"pl-PL": "ID QQ Music",
		"pt-BR": "ID do QQ Music",
		"ru-RU": "ID QQ Music",
		"sk-SK": "ID QQ Music",
		"zh-CN": "QQ 音乐 ID",
		default: "QQ Music ID"
	},
	"metadataDialog.builtinOptions.qqMusicIdInvalidMsg": {
		"cs-CZ": "ID QQ Music musí být alfanumerické",
		"da-DK": "QQ Music ID skal være alfanumerisk",
		"en-US": "QQ Music ID should be alphanumeric",
		"es-ES": "El ID de QQ Music debe ser alfanumérico",
		"fr-FR": "L'ID QQ Music doit être alphanumérique",
		"id-ID": "ID Musik QQ harus berupa huruf atau angka",
		"pl-PL": "ID QQ Music powinno być alfanumeryczne",
		"pt-BR": "O ID do QQ Music deve ser alfanumérico",
		"ru-RU": "ID QQ Music должен быть буквенно-цифровым",
		"sk-SK": "ID QQ Music musí byť alfanumerické",
		"zh-CN": "QQ 音乐 ID 应为字母或数字",
		default: "QQ Music ID should be alphanumeric"
	},
	"metadataDialog.builtinOptions.spotifyId": {
		"cs-CZ": "ID skladby Spotify",
		"da-DK": "Spotify Sang-ID",
		"en-US": "Spotify Track ID",
		"es-ES": "ID de pista de Spotify",
		"fr-FR": "ID de piste Spotify",
		"id-ID": "ID Musik Spotify",
		"pl-PL": "ID utworu Spotify",
		"pt-BR": "ID da faixa do Spotify",
		"ru-RU": "ID трека Spotify",
		"sk-SK": "ID skladby Spotify",
		"zh-CN": "Spotify 音乐 ID",
		default: "Spotify Track ID"
	},
	"metadataDialog.builtinOptions.spotifyIdInvalidMsg": {
		"cs-CZ": "ID skladby Spotify musí být alfanumerické",
		"da-DK": "Spotify Sang-ID skal være alfanumerisk",
		"en-US": "Spotify Track ID should be alphanumeric",
		"es-ES": "El ID de pista de Spotify debe ser alfanumérico",
		"fr-FR": "L'ID de piste Spotify doit être alphanumérique",
		"id-ID": "ID Musik Spotify harus berupa huruf atau angka",
		"pl-PL": "ID utworu Spotify powinno być alfanumeryczne",
		"pt-BR": "O ID da faixa do Spotify deve ser alfanumérico",
		"ru-RU": "ID трека Spotify должен быть буквенно-цифровым",
		"sk-SK": "ID skladby Spotify musí byť alfanumerické",
		"zh-CN": "Spotify 音乐 ID 应为字母或数字",
		default: "Spotify Track ID should be alphanumeric"
	},
	"metadataDialog.builtinOptions.appleMusicId": {
		"cs-CZ": "ID skladby Apple Music",
		"da-DK": "Apple Music Sang-ID",
		"en-US": "Apple Music Track ID",
		"es-ES": "ID de pista de Apple Music",
		"fr-FR": "ID de piste Apple Music",
		"id-ID": "ID Musik Apple Music",
		"pl-PL": "ID utworu Apple Music",
		"pt-BR": "ID da faixa do Apple Music",
		"ru-RU": "ID трека Apple Music",
		"sk-SK": "ID skladby Apple Music",
		"zh-CN": "Apple Music 音乐 ID",
		default: "Apple Music Track ID"
	},
	"metadataDialog.builtinOptions.appleMusicIdInvalidMsg": {
		"cs-CZ": "ID skladby Apple Music musí být číselné",
		"da-DK": "Apple Music Sang-ID skal være numerisk",
		"en-US": "Apple Music Track ID should be numeric",
		"es-ES": "El ID de pista de Apple Music debe ser numérico",
		"fr-FR": "L'ID de piste Apple Music doit être numérique",
		"id-ID": "ID Musik Apple Music harus berupa angka",
		"pl-PL": "ID utworu Apple Music powinno być liczbowe",
		"pt-BR": "O ID da faixa do Apple Music deve ser numérico",
		"ru-RU": "ID трека Apple Music должен быть числовым",
		"sk-SK": "ID skladby Apple Music musí byť číselné",
		"zh-CN": "Apple Music 音乐 ID 应为纯数字",
		default: "Apple Music Track ID should be numeric"
	},
	"metadataDialog.builtinOptions.isrc": {
		"cs-CZ": "ISRC kód skladby",
		"da-DK": "Sang ISRC-kode",
		"en-US": "Track ISRC Code",
		"es-ES": "Código ISRC de la pista",
		"fr-FR": "Code ISRC de la piste",
		"id-ID": "Nomor ISRC Lagu",
		"pl-PL": "Kod ISRC utworu",
		"pt-BR": "Código ISRC da faixa",
		"ru-RU": "Код ISRC трека",
		"sk-SK": "ISRC kód skladby",
		"zh-CN": "歌曲的 ISRC 号码",
		default: "Track ISRC Code"
	},
	"metadataDialog.builtinOptions.isrcInvalidMsg": {
		"cs-CZ": "Formát ISRC kódu musí být CC-XXX-YY-NNNNN",
		"da-DK": "ISRC-kodeformat skal være CC-XXX-YY-NNNNN",
		"en-US": "ISRC code format should be CC-XXX-YY-NNNNN",
		"es-ES": "El formato del código ISRC debe ser CC-XXX-YY-NNNNN",
		"fr-FR": "Le format du code ISRC doit être CC-XXX-YY-NNNNN",
		"id-ID": "Format nomor ISRC harus CC-XXX-YY-NNNNN",
		"pl-PL": "Format kodu ISRC powinien być CC-XXX-YY-NNNNN",
		"pt-BR": "O formato do código ISRC deve ser CC-XXX-YY-NNNNN",
		"ru-RU": "Формат кода ISRC должен быть CC-XXX-YY-NNNNN",
		"sk-SK": "Formát ISRC kódu musí byť CC-XXX-YY-NNNNN",
		"zh-CN": "ISRC 号码格式应为 CC-XXX-YY-NNNNN",
		default: "ISRC code format should be CC-XXX-YY-NNNNN"
	},
	"metadataDialog.builtinOptions.ttmlAuthorGithub": {
		"cs-CZ": "GitHub ID autora titulek",
		"da-DK": "Sangtekstforfatter GitHub ID",
		"en-US": "Lyrics Author GitHub ID",
		"es-ES": "ID de GitHub del autor de letras",
		"fr-FR": "ID GitHub de l'auteur des paroles",
		"id-ID": "GitHub ID Penulis Lirik",
		"pl-PL": "ID GitHub autora tekstów",
		"pt-BR": "ID do GitHub do autor das letras",
		"ru-RU": "GitHub ID автора текста",
		"sk-SK": "GitHub ID autora textov",
		"zh-CN": "歌词作者 GitHub ID",
		default: "Lyrics Author GitHub ID"
	},
	"metadataDialog.builtinOptions.ttmlAuthorGithubInvalidMsg": {
		"cs-CZ": "GitHub ID musí být číselné",
		"da-DK": "GitHub ID skal være numerisk",
		"en-US": "GitHub ID should be numeric",
		"es-ES": "El ID de GitHub debe ser numérico",
		"fr-FR": "L'ID GitHub doit être numérique",
		"id-ID": "GitHub ID harus berupa angka",
		"pl-PL": "ID GitHub powinno być liczbowe",
		"pt-BR": "O ID do GitHub deve ser numérico",
		"ru-RU": "GitHub ID должен быть числовым",
		"sk-SK": "GitHub ID musí byť číselné",
		"zh-CN": "GitHub ID 应为纯数字",
		default: "GitHub ID should be numeric"
	},
	"metadataDialog.builtinOptions.ttmlAuthorGithubLogin": {
		"cs-CZ": "GitHub uživatelské jméno autora titulek",
		"da-DK": "Sangtekstforfatter GitHub-brugernavn",
		"en-US": "Lyrics Author GitHub Username",
		"es-ES": "Nombre de usuario de GitHub del autor de letras",
		"fr-FR": "Nom d'utilisateur GitHub de l'auteur des paroles",
		"id-ID": "Username GitHub Penulis Lirik",
		"pl-PL": "Nazwa użytkownika GitHub autora tekstów",
		"pt-BR": "Nome de usuário do GitHub do autor das letras",
		"ru-RU": "GitHub имя пользователя автора текста",
		"sk-SK": "GitHub používateľské meno autora textov",
		"zh-CN": "歌词作者 GitHub 用户名",
		default: "Lyrics Author GitHub Username"
	},
	"metadataDialog.builtinOptions.ttmlAuthorGithubLoginInvalidMsg": {
		"cs-CZ": "GitHub uživatelské jméno musí být alfanumerické nebo obsahovat pomlčky, max. 39 znaků",
		"da-DK": "GitHub-brugernavn skal være alfanumerisk eller bindestreger, op til 39 tegn",
		"en-US": "GitHub username should be alphanumeric or hyphens, up to 39 characters",
		"es-ES": "El nombre de usuario de GitHub debe ser alfanumérico o guiones, hasta 39 caracteres",
		"fr-FR": "Le nom d'utilisateur GitHub doit être alphanumérique ou contenir des tirets, jusqu'à 39 caractères",
		"id-ID": "Username GitHub tidak boleh lebih dari 39 karakter yang terdiri dari huruf, angka, atau tanda minus",
		"pl-PL": "Nazwa użytkownika GitHub powinna być alfanumeryczna lub zawierać myślniki, do 39 znaków",
		"pt-BR": "O nome de usuário do GitHub deve ser alfanumérico ou hífens, até 39 caracteres",
		"ru-RU": "GitHub имя пользователя должно быть буквенно-цифровым или содержать дефисы, до 39 символов",
		"sk-SK": "GitHub používateľské meno musí byť alfanumerické alebo obsahovať pomlčky, max. 39 znakov",
		"zh-CN": "GitHub 用户名应为不长于 39 字符的字母、数字或短横线",
		default: "GitHub username should be alphanumeric or hyphens, up to 39 characters"
	},
	"metadataDialog.title": {
		"cs-CZ": "Editor metadat",
		"da-DK": "Metadataeditor",
		"en-US": "Metadata Editor",
		"es-ES": "Editor de metadatos",
		"fr-FR": "Éditeur de métadonnées",
		"id-ID": "Editor Metadata",
		"pl-PL": "Edytor metadanych",
		"pt-BR": "Editor de metadados",
		"ru-RU": "Редактор метаданных",
		"sk-SK": "Editor metadát",
		"zh-CN": "元数据编辑器",
		default: "Metadata Editor"
	},
	"metadataDialog.key": {
		"cs-CZ": "Klíč",
		"da-DK": "Nøgle",
		"es-ES": "Clave",
		"fr-FR": "Clé",
		"id-ID": "Tipe Metadata",
		"pl-PL": "Klucz",
		"pt-BR": "Chave",
		"ru-RU": "Ключ",
		"sk-SK": "Kľúč",
		default: "Klíč"
	},
	"metadataDialog.value": {
		"cs-CZ": "Hodnota",
		"da-DK": "Værdi",
		"es-ES": "Valor",
		"fr-FR": "Valeur",
		"id-ID": "Nilai",
		"pl-PL": "Wartość",
		"pt-BR": "Valor",
		"ru-RU": "Значение",
		"sk-SK": "Hodnota",
		default: "Hodnota"
	},
	"metadataDialog.empty": {
		"cs-CZ": "Žádná metadata",
		"da-DK": "Ingen metadata",
		"es-ES": "Sin metadatos",
		"fr-FR": "Aucune métadonnée",
		"id-ID": "Tidak ada metadata",
		"pl-PL": "Brak metadanych",
		"pt-BR": "Sem metadados",
		"ru-RU": "Нет метаданных",
		"sk-SK": "Žiadne metadáta",
		default: "Žádná metadata"
	},
	"metadataDialog.addKeyValue": {
		"cs-CZ": "Přidat nový pár klíč-hodnota",
		"da-DK": "Tilføj nyt nøgle-værdi-par",
		"es-ES": "Añadir nuevo par clave-valor",
		"fr-FR": "Ajouter une nouvelle paire clé-valeur",
		"id-ID": "Tambah Key-Value Baru",
		"pl-PL": "Dodaj nową parę klucz-wartość",
		"pt-BR": "Adicionar novo par chave-valor",
		"ru-RU": "Добавить новую пару ключ-значение",
		"sk-SK": "Pridať nový pár kľúč-hodnota",
		default: "Přidat nový pár klíč-hodnota"
	},
	"metadataDialog.customKey": {
		"cs-CZ": "Vlastní klíč",
		"da-DK": "Brugerdefineret nøgle",
		"en-US": "Custom Key",
		"es-ES": "Clave personalizada",
		"fr-FR": "Clé personnalisée",
		"id-ID": "Nama Kunci Kustom",
		"pl-PL": "Klucz niestandardowy",
		"pt-BR": "Chave personalizada",
		"ru-RU": "Пользовательский ключ",
		"sk-SK": "Vlastný kľúč",
		"zh-CN": "自定义键名",
		default: "Custom Key"
	},
	"metadataDialog.addPresets": {
		"cs-CZ": "Přidat všechny předdefinované klíče",
		"da-DK": "Tilføj alle forudindstillede nøgler",
		"es-ES": "Añadir todas las claves predefinidas",
		"fr-FR": "Ajouter toutes les clés prédéfinies",
		"id-ID": "Tambah Semua Kunci Standar",
		"pl-PL": "Dodaj wszystkie predefiniowane klucze",
		"pt-BR": "Adicionar todas as chaves predefinidas",
		"ru-RU": "Добавить все предустановленные ключи",
		"sk-SK": "Pridať všetky preddefinované kľúče",
		default: "Přidat všechny předdefinované klíče"
	},
	"metadataDialog.clear": {
		"cs-CZ": "Vymazat",
		"da-DK": "Ryd",
		"en-US": "Clear",
		"es-ES": "Limpiar",
		"fr-FR": "Effacer",
		"id-ID": "Kosongkan",
		"pl-PL": "Wyczyść",
		"pt-BR": "Limpar",
		"ru-RU": "Очистить",
		"sk-SK": "Vymazať",
		"zh-CN": "清空",
		default: "Clear"
	},
	"metadataDialog.info": {
		"cs-CZ": "Více informací",
		"da-DK": "Lær mere",
		"en-US": "Learn more",
		"es-ES": "Más información",
		"fr-FR": "En savoir plus",
		"id-ID": "Pelajari Lebih Lanjut",
		"pl-PL": "Dowiedz się więcej",
		"pt-BR": "Saiba mais",
		"ru-RU": "Подробнее",
		"sk-SK": "Viac informácií",
		"zh-CN": "了解详情",
		default: "Learn more"
	},
	"command.title": {
		"cs-CZ": "Upravit metadata titulek…",
		"da-DK": "Rediger sangtekstmetadata…",
		"en-US": "Edit lyrics metadata…",
		"es-ES": "Editar metadatos de letras…",
		"fr-FR": "Modifier les métadonnées des paroles…",
		"id-ID": "Edit Metadata Lirik",
		"pl-PL": "Edytuj metadane tekstu…",
		"pt-BR": "Editar metadados das letras…",
		"ru-RU": "Редактировать метаданные текста…",
		"sk-SK": "Upraviť metadáta textov…",
		"zh-CN": "编辑歌词元数据",
		default: "Edit lyrics metadata…"
	},
	"metadataDialog.emptyItem": {
		"en-US": "No entries have been added to this section yet.",
		"zh-CN": "此项尚未添加任何条目",
		default: "No entries have been added to this section yet."
	},
	editFailed: {
		default: "Could not edit metadata",
		"zh-CN": "元数据修改失败"
	},
	deleteValue: {
		default: "Delete value",
		"zh-CN": "删除条目"
	},
	"providers.title": {
		"zh-CN": "元数据提供者",
		"en-US": "Metadata providers",
		default: "Metadata providers"
	},
	"providers.description": {
		"zh-CN": "每个平台可勾选多个来源；获取时合并结果并追加去重。至少有一个已勾选的可用来源时显示获取按钮。",
		"en-US": "Select multiple sources per platform. Fetching merges and deduplicates their results. The button appears when at least one selected source is available.",
		default: "Select multiple sources per platform. Fetching merges and deduplicates their results. The button appears when at least one selected source is available."
	},
	"providers.none": {
		"zh-CN": "不使用",
		"en-US": "None",
		default: "None"
	},
	"providers.docs": {
		"zh-CN": "开发文档",
		"en-US": "Developer guide",
		default: "Developer guide"
	},
	"providers.fetch": {
		"zh-CN": "获取元数据",
		"en-US": "Fetch metadata",
		default: "Fetch metadata"
	},
	"providers.fetchFailed": {
		"zh-CN": "获取元数据失败",
		"en-US": "Failed to fetch metadata",
		default: "Failed to fetch metadata"
	},
	"providers.saveFailed": {
		"zh-CN": "保存来源设置失败",
		"en-US": "Failed to save provider settings",
		default: "Failed to save provider settings"
	},
	"providers.loadFailed": {
		"zh-CN": "加载来源设置失败",
		"en-US": "Failed to load provider settings",
		default: "Failed to load provider settings"
	},
	"providers.unavailable": {
		"zh-CN": "元数据来源不可用",
		"en-US": "Metadata provider unavailable",
		default: "Metadata provider unavailable"
	},
	"providers.stale": {
		"zh-CN": "来源或项目已变更，请重新获取",
		"en-US": "Provider or project changed; fetch again",
		default: "Provider or project changed; fetch again"
	},
	"providers.intro": {
		"zh-CN": "为不同音乐平台连接你信任的资料来源，在编辑歌词时一键补全曲名、艺术家与专辑信息。",
		"en-US": "Connect trusted sources for each music platform to fill in song titles, artists and albums while editing lyrics.",
		default: "Connect trusted sources for each music platform to fill in song titles, artists and albums while editing lyrics."
	},
	"providers.platforms": {
		"zh-CN": "平台与来源",
		"en-US": "Platforms & sources",
		default: "Platforms & sources"
	},
	"providers.activeCount": {
		"zh-CN": "已启用 {count} / 4",
		"en-US": "{count} / 4 enabled",
		default: "{count} / 4 enabled"
	},
	"providers.sourceCount": {
		"zh-CN": "{count} 个可用来源",
		"en-US": "{count} available sources",
		default: "{count} available sources"
	},
	"providers.enabled": {
		"zh-CN": "已启用",
		"en-US": "Enabled",
		default: "Enabled"
	},
	"providers.disabled": {
		"zh-CN": "未启用",
		"en-US": "Disabled",
		default: "Disabled"
	},
	"providers.missing": {
		"zh-CN": "来源不可用",
		"en-US": "Unavailable",
		default: "Unavailable"
	},
	"providers.sourceLabel": {
		"zh-CN": "元数据来源（可多选）",
		"en-US": "Metadata sources (multiple)",
		default: "Metadata sources (multiple)"
	},
	"providers.enabledHint": {
		"zh-CN": "点击获取将合并已勾选来源的结果，追加去重且可一次撤销。",
		"en-US": "Fetching merges results from selected sources in one undoable edit.",
		default: "Fetching merges results from selected sources in one undoable edit."
	},
	"providers.disabledHint": {
		"zh-CN": "勾选一个或多个来源后显示获取按钮；全部取消则隐藏。",
		"en-US": "Select one or more sources to show the fetch button; clear all to hide it.",
		default: "Select one or more sources to show the fetch button; clear all to hide it."
	},
	"providers.missingHint": {
		"zh-CN": "已保存的来源当前不可用，重新启用来源插件后会自动恢复。",
		"en-US": "The saved source is unavailable. Re-enable its plugin to restore it.",
		default: "The saved source is unavailable. Re-enable its plugin to restore it."
	},
	"providers.emptyHint": {
		"zh-CN": "还没有可用来源。请先启用提供元数据的插件，再回来为平台选择来源。",
		"en-US": "No sources are available yet. Enable a metadata provider plugin, then select it for a platform.",
		default: "No sources are available yet. Enable a metadata provider plugin, then select it for a platform."
	},
	"providers.developerTitle": {
		"zh-CN": "接入你自己的元数据来源",
		"en-US": "Connect your own metadata source",
		default: "Connect your own metadata source"
	},
	"providers.developerDescription": {
		"zh-CN": "提供者可以是插件的一部分功能。了解如何注册来源、调用元数据接口；文档可离线阅读并导出。",
		"en-US": "Providers can be one feature of a plugin. Learn to register sources and use the metadata API; read offline or export the guide.",
		default: "Providers can be one feature of a plugin. Learn to register sources and use the metadata API; read offline or export the guide."
	},
	"providers.footer": {
		"zh-CN": "设置自动保存 · 获取结果追加去重 · 文档修改支持撤销",
		"en-US": "Settings save automatically · Fetched values are appended and deduplicated · Document edits can be undone",
		default: "Settings save automatically · Fetched values are appended and deduplicated · Document edits can be undone"
	},
	"providers.back": {
		"zh-CN": "返回元数据提供者",
		"en-US": "Back to metadata providers",
		default: "Back to metadata providers"
	},
	"providers.exportMarkdown": {
		"zh-CN": "导出 Markdown",
		"en-US": "Export Markdown",
		default: "Export Markdown"
	},
	"providers.noSources": {
		"zh-CN": "暂无可用来源",
		"en-US": "No available sources",
		default: "No available sources"
	},
	"providers.partialFailed": {
		"zh-CN": "部分来源未能获取元数据，已合并其他来源的结果",
		"en-US": "Some sources failed; results from other sources were merged",
		default: "Some sources failed; results from other sources were merged"
	}
}, Wf = [
	"ncmMusicId",
	"qqMusicId",
	"spotifyId",
	"appleMusicId"
];
// src/providers.ts
function Gf(e) {
	if (!Array.isArray(e) || e.some((e) => !e || typeof e.key != "string" || !e.key.trim() || !Array.isArray(e.values) || e.values.some((e) => typeof e != "string")) || new Set(e.map((e) => e.key)).size !== e.length) throw Error("Expected metadata entries with unique non-empty keys and string[] values");
}
function Kf(e, t) {
	let n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), i = {}, a = 0, o = !1, s = () => {
		a++;
		for (let e of r) e();
	}, c = () => t.throwIfAborted(), l = (t, n, r) => (c(), e.document.applyEdit([{
		op: "setMetadata",
		entries: t
	}], r, { expectedRevision: n })), u = (t, n, r, i) => {
		if (c(), Gf([{
			key: n,
			values: r
		}]), i !== void 0 && (!Number.isSafeInteger(i) || i < 0)) throw Error("Invalid revision");
		let a = e.document.readSnapshot(), o = structuredClone(a.metadata), s = o.findIndex((e) => e.key === n);
		if (t === "create" && s >= 0) throw Error("Metadata key already exists");
		if (t !== "create" && s < 0) throw Error("Metadata key does not exist");
		return t === "create" ? o.push({
			key: n,
			values: [...r]
		}) : t === "update" ? o[s].values = [...r] : o.splice(s, 1), l(o, i ?? a.revision, `Metadata ${t}`);
	}, d = Object.freeze({
		version: 1,
		read() {
			c();
			let { revision: t, metadata: n } = e.document.readSnapshot();
			return {
				revision: t,
				metadata: structuredClone(n)
			};
		},
		create: (e, t, n) => u("create", e, t, n),
		update: (e, t, n) => u("update", e, t, n),
		delete: (e, t) => u("delete", e, [], t),
		registerProvider(e) {
			if (c(), !e || typeof e.id != "string" || !/^[a-zA-Z0-9_-]+(?:\.[a-zA-Z0-9_-]+)+$/.test(e.id) || typeof e.title != "string" || !e.title.trim() || typeof e.fetch != "function" || !(e.signal instanceof AbortSignal) || !Array.isArray(e.platforms) || !e.platforms.length || e.platforms.some((e) => !Wf.includes(e))) throw Error("Invalid metadata provider");
			if (e.signal.throwIfAborted(), n.has(e.id)) throw Error("Metadata provider already registered");
			let r = {
				...e,
				platforms: [...new Set(e.platforms)]
			}, i = () => {
				e.signal.removeEventListener("abort", i), t.removeEventListener("abort", i), n.get(r.id) === r && (n.delete(r.id), s());
			};
			return n.set(r.id, r), e.signal.addEventListener("abort", i, { once: !0 }), t.addEventListener("abort", i, { once: !0 }), s(), { dispose: i };
		}
	}), f = e.storage.kv.get("providers.v1").then((e) => {
		if (c(), e && typeof e == "object" && !Array.isArray(e)) for (let t of Wf) {
			let n = e[t];
			i[t] = typeof n == "string" ? n ? [n] : [] : Array.isArray(n) ? [...new Set(n.filter((e) => typeof e == "string" && !!e))] : [];
		}
		s();
	}).catch((n) => {
		t.aborted || e.ui.notify({
			level: "warning",
			message: e.i18n.t("providers.loadFailed"),
			detail: String(n)
		});
	}), p = (e) => Wf.includes(e) ? (i[e] ?? []).flatMap((t) => {
		let r = n.get(t);
		return r?.platforms.includes(e) ? [r] : [];
	}) : [];
	return {
		api: d,
		ready: f,
		isActive: () => !t.aborted,
		subscribe(e) {
			return r.add(e), () => {
				r.delete(e);
			};
		},
		getVersion: () => a,
		list: (e) => [...n.values()].filter((t) => t.platforms.includes(e)),
		selected: p,
		selectionIds: (e) => [...i[e] ?? []],
		async select(t, r) {
			if (await f, c(), o) throw Error("Settings save already in progress");
			if (!Wf.includes(t) || !Array.isArray(r) || r.some((e) => typeof e != "string" || !e || !n.get(e)?.platforms.includes(t) && !i[t]?.includes(e))) throw Error("Provider unavailable");
			let a = {
				...i,
				[t]: [...new Set(r)]
			};
			o = !0;
			try {
				await e.storage.kv.set("providers.v1", a), c(), i = a, s();
			} finally {
				o = !1;
			}
		},
		async fetch(r, a) {
			c();
			let o = p(r), s = i[r];
			if (!o.length) throw Error(e.i18n.t("providers.unavailable"));
			if (typeof a != "string" || !(r === "ncmMusicId" || r === "appleMusicId" ? /^\d+$/ : /^[a-zA-Z0-9]+$/).test(a)) throw Error("Invalid platform ID");
			let u = e.document.readSnapshot(), d = e.project.getInfo().projectId, f = await Promise.allSettled(o.map(async (e) => {
				let n = AbortSignal.any([
					t,
					e.signal,
					AbortSignal.timeout(3e4)
				]), i = () => {};
				try {
					let t = await Promise.race([Promise.resolve().then(() => (n.throwIfAborted(), e.fetch({
						platform: r,
						id: a,
						signal: n
					}))), new Promise((e, t) => {
						i = () => t(n.reason), n.addEventListener("abort", i, { once: !0 }), n.aborted && i();
					})]);
					return n.throwIfAborted(), Gf(t), structuredClone(t);
				} finally {
					n.removeEventListener("abort", i);
				}
			}));
			if (c(), i[r] !== s || e.project.getInfo().projectId !== d) throw Error(e.i18n.t("providers.stale"));
			let m = structuredClone(u.metadata), h = [], g = 0;
			for (let [t, r] of f.entries()) {
				let i = o[t];
				if (r.status === "rejected" || n.get(i.id) !== i) h.push(`${i.title}: ${r.status === "rejected" ? String(r.reason) : e.i18n.t("providers.unavailable")}`);
				else {
					g++;
					for (let e of r.value) {
						let t = e.values.map((e) => e.trim()).filter(Boolean);
						if (!t.length) continue;
						let n = m.find((t) => t.key === e.key);
						n || (n = {
							key: e.key,
							values: []
						}, m.push(n)), n.values = [.../* @__PURE__ */ new Set([...n.values.map((e) => e.trim()).filter(Boolean), ...t])];
					}
				}
			}
			if (!g) throw Error(h.join("\n"));
			let _ = l(m, u.revision, "Metadata fetch");
			if (!_.ok) throw Error(_.error.message);
			return h.length && e.ui.notify({
				level: "warning",
				message: e.i18n.t("providers.partialFailed"),
				detail: h.join("\n")
			}), _;
		}
	};
}
// docs/development-guide.html?raw
var qf = "<h1>Metadata Editor 插件开发指南</h1>\n<h2>1. 使用与接入</h2>\n<p>启用 Metadata Editor 后，在插件管理侧栏打开“元数据提供者”。每个平台默认不勾选来源，只有显式选择当前已注册、支持该平台的来源，编辑器对应 ID 行才显示“获取元数据”。空值或无效 ID 不可获取，请求期间显示加载状态。</p>\n<p>支持 ncmMusicId、qqMusicId、spotifyId、appleMusicId；ISRC 和歌词作者 GitHub 字段不是这四个音乐平台 ID。插件不自带任何远端来源，也不要求网络权限；网络请求及相应 capability 由提供者负责。</p>\n<p>通过命令获取接口对象：</p>\n<pre><code>import type { MetadataApiV1 } from &quot;./metadata-api&quot;;\n\nconst api = await host.commands.execute(&quot;builtin.metadata.getApi&quot;) as MetadataApiV1;\nif (api.version !== 1) throw new Error(&quot;Unsupported metadata API&quot;);</code></pre>\n<p>将本插件 src/api.ts 复制为消费插件的 metadata-api.ts 可获得类型；类型导入不会把实现打入消费插件。getApi 不接收参数，返回同进程接口对象，不能序列化或传给 Worker。不要把回调或 AbortSignal 作为 commands.execute 的 JSON 参数传入。</p>\n<p>宿主不会根据本插件 API 自动排序激活，也没有公开的通用插件激活事件。Metadata Editor 必须先启用；命令缺失/禁用时 execute 拒绝，消费方应捕获并以 warning 级别提示用户启用后重试，不应因此中断插件的其他功能。Metadata Editor 重启会清空注册，旧 API 失效；来源插件须重新获取 API 并注册（例如重新启用来源插件）。不要永久缓存失效接口。</p>\n<h2>2. 元数据增删改查</h2>\n<p>所有操作面向当前文档，只操作元数据，不替换歌词行。key 为非空字符串（保留原文），values 为 string[]，允许空数组和空字符串；与编辑器一样支持自定义键。读取返回独立副本。</p>\n<div class=\"amll-metadata-doc-table\"><table><thead><tr><th scope=\"col\">方法</th><th scope=\"col\">返回值与语义</th></tr></thead><tbody><tr><td>read()</td><td>{ revision, metadata: { key, values }[] }</td></tr><tr><td>create(key, values, expectedRevision?)</td><td>新增整个键；已存在则抛异常</td></tr><tr><td>update(key, values, expectedRevision?)</td><td>替换指定键的全部值；不存在则抛异常</td></tr><tr><td>delete(key, expectedRevision?)</td><td>删除整个键；不存在则抛异常</td></tr><tr><td>registerProvider(provider)</td><td>返回 { dispose() }，见下节</td></tr></tbody></table></div>\n<p>写入同步返回宿主 HostResult&lt;ApplyEditResult&gt;，一次调用是一条可撤销事务。必须判断 result.ok，失败读取 result.error.code/message。参数非法、键存在性不符合要求或 API 已卸载则抛异常。传入 expectedRevision 可防止基于旧快照覆盖新编辑；不传时以调用瞬间的 revision 写入。</p>\n<pre><code>const snapshot = api.read();\nconst existing = snapshot.metadata.find(entry =&gt; entry.key === &quot;musicName&quot;);\nconst result = existing\n  ? api.update(&quot;musicName&quot;, [&quot;新曲名&quot;], snapshot.revision)\n  : api.create(&quot;musicName&quot;, [&quot;新曲名&quot;], snapshot.revision);\nif (!result.ok) host.ui.notify({ level: &quot;warning&quot;, message: result.error.message });\n\nconst current = api.read();\nif (current.metadata.some(entry =&gt; entry.key === &quot;custom&quot;)) {\n  const removed = api.delete(&quot;custom&quot;, current.revision);\n  if (!removed.ok) throw new Error(removed.error.message);\n}</code></pre>\n<p>这些方法属于 trusted-js 同进程合作接口，不是权限隔离边界。事务归属 builtin.metadata；调用方名称不会自动传递到宿主事务来源中。读取或写入无需在设置页选择来源；来源选择只控制获取按钮。</p>\n<h2>3. 注册元数据提供者</h2>\n<p>元数据提供者可以只是插件的一部分功能，不要求开发或安装独立的提供者插件。已有插件可在注册自身其他功能时同时调用 registerProvider；接入暂时不可用时显示警告，保留其余功能正常运行。</p>\n<pre><code>import type { TrustedJsActivationContextV0 } from &quot;@amll-ttml-tool/plugin-sdk-js&quot;;\nimport type { MetadataApiV1 } from &quot;./metadata-api&quot;;\n\nexport async function activate({ host, pluginId, signal }: TrustedJsActivationContextV0) {\n  try {\n    const api = await host.commands.execute(&quot;builtin.metadata.getApi&quot;) as MetadataApiV1;\n    if (api.version !== 1) throw new Error(&quot;Unsupported metadata API&quot;);\n    const registration = api.registerProvider({\n      id: `${pluginId}.catalog`,\n      title: &quot;示例元数据源&quot;,\n      platforms: [&quot;ncmMusicId&quot;, &quot;qqMusicId&quot;],\n      signal,\n      async fetch({ platform, id, signal: requestSignal }) {\n        requestSignal.throwIfAborted();\n        // 演示返回结构；实际实现应在此查询自己的数据源并校验响应。\n        return [\n          { key: &quot;musicName&quot;, values: [&quot;示例曲名&quot;, &quot;别名&quot;] },\n          { key: &quot;artists&quot;, values: [&quot;歌手 A&quot;, &quot;歌手 B&quot;] },\n          { key: platform, values: [id] },\n        ];\n      },\n    });\n    return () =&gt; registration.dispose();\n  } catch (error) {\n    if (!signal.aborted) host.ui.notify({\n      level: &quot;warning&quot;, message: &quot;元数据接入暂不可用，请启用 Metadata Editor 后重试&quot;, detail: String(error),\n    });\n  }\n}</code></pre>\n<div class=\"amll-metadata-doc-table\"><table><thead><tr><th scope=\"col\">字段</th><th scope=\"col\">合同</th></tr></thead><tbody><tr><td>id</td><td>稳定且唯一；建议 &lt;pluginId&gt;.&lt;source&gt;，各段由字母、数字、下划线、连字符组成，至少两段；重复注册拒绝</td></tr><tr><td>title</td><td>非空显示名称</td></tr><tr><td>platforms</td><td>非空受支持平台数组；一个来源可支持多个平台</td></tr><tr><td>signal</td><td>必须使用来源插件 activate 的 AbortSignal；卸载自动注销</td></tr><tr><td>fetch</td><td>接收 { platform, id, signal }，返回 Promise&lt;{ key, values }[]&gt;</td></tr></tbody></table></div>\n<p>手动 dispose 幂等，立即注销来源；提供者卸载、Metadata Editor 卸载时也会注销。请求信号合并双方生命周期和 30 秒超时；即使提供者忽略取消，超时或卸载也会结束等待，迟到结果不会写入。提供者仍应尊重 signal，以停止不必要的请求。不要在 fetch 中自行写当前文档，应只返回数据。</p>\n<p>返回键必须唯一且非空，值必须全部为字符串。每个来源的响应先完整校验，非法响应不会部分写入。值会 trim、去除空值并按键追加去重，保留已有的非空值及未涉及的键；已有值同时规范化、去重。点击获取时并行请求全部已勾选且可用的来源，按勾选顺序合并成功响应并去重，所有有效返回项在一个事务中写入，可一次撤销。单个来源失败或卸载不影响其他有效来源；部分成功时显示 warning 通知，全部失败则不写入，并由编辑器显示 warning 通知。返回 [] 不增加字段。</p>\n<p>请求开始时记录文档 revision 和项目 ID，完成时检查当前来源及项目，再使用 expectedRevision 提交。期间文档编辑、切换项目、修改该平台勾选项或 Metadata Editor 卸载均不会覆盖新数据。注销、卸载或超时的来源结果会被丢弃；请求未能完成的提示以 warning 级别显示，用户可重新获取。并发请求基于旧 revision 的后续提交同样会被拒绝。</p>\n<h2>4. 来源设置与存储</h2>\n<p>每个平台可勾选多个来源，也可全部取消勾选以隐藏获取按钮。选项仅包含实时注册并声明支持该平台的来源，注册本身不会自动选中。设置写入 host.storage.kv 的 providers.v1，每个平台保存来源 ID 数组；旧版单个字符串会自动读取为单项数组，下次保存时写入新格式；保存成功后更新 UI，失败显示 warning 通知并保留先前选择。</p>\n<p>已保存来源暂时缺席时，UI 保留带警告状态的勾选项，可以取消勾选。该来源重新注册后恢复使用；只要该平台还有一个已勾选的可用来源，获取按钮就保持显示。设置不存入歌词文件，也不参与文档撤销。存储读取失败会通知并使用默认关闭状态。</p>\n<h2>5. 本地开发与验收</h2>\n<pre><code>pnpm install --frozen-lockfile\npnpm test\npnpm run pack\npnpm serve</code></pre>\n<p>使用 vendor/ 锁定的 API/SDK/toolkit，不直接导入宿主源码。React 和 Radix 由宿主共享。pack 生成 dist/plugins/catalog.json 与内容寻址 ZIP；build、test、pack 会先运行 scripts/render-docs.mjs，将 Markdown 预渲染为 HTML；原始 Markdown 同时随包保存供导出，不引入 Markdown 运行时依赖。渲染器仅支持本文使用的标题、段落、行内代码、代码块和表格，扩展语法时需同步渲染器及测试。</p>\n<p>验收重点：默认隐藏按钮；注册和设置选择后仅对应平台出现；空 ID 禁用；获取结果追加去重且可一次撤销；来源卸载即时隐藏；读取/保存失败通知；请求期间编辑或切换项目不覆盖；非法响应不产生部分写入；设置页文档离线可读。自动化测试不等同于真实第三方服务、Tauri 或各操作系统验收。</p>\n", Jf = "# Metadata Editor 插件开发指南\r\n\r\n## 1. 使用与接入\r\n\r\n启用 Metadata Editor 后，在插件管理侧栏打开“元数据提供者”。每个平台默认不勾选来源，只有显式选择当前已注册、支持该平台的来源，编辑器对应 ID 行才显示“获取元数据”。空值或无效 ID 不可获取，请求期间显示加载状态。\r\n\r\n支持 ncmMusicId、qqMusicId、spotifyId、appleMusicId；ISRC 和歌词作者 GitHub 字段不是这四个音乐平台 ID。插件不自带任何远端来源，也不要求网络权限；网络请求及相应 capability 由提供者负责。\r\n\r\n通过命令获取接口对象：\r\n\r\n```ts\r\nimport type { MetadataApiV1 } from \"./metadata-api\";\r\n\r\nconst api = await host.commands.execute(\"builtin.metadata.getApi\") as MetadataApiV1;\r\nif (api.version !== 1) throw new Error(\"Unsupported metadata API\");\r\n```\r\n\r\n将本插件 src/api.ts 复制为消费插件的 metadata-api.ts 可获得类型；类型导入不会把实现打入消费插件。getApi 不接收参数，返回同进程接口对象，不能序列化或传给 Worker。不要把回调或 AbortSignal 作为 commands.execute 的 JSON 参数传入。\r\n\r\n宿主不会根据本插件 API 自动排序激活，也没有公开的通用插件激活事件。Metadata Editor 必须先启用；命令缺失/禁用时 execute 拒绝，消费方应捕获并以 warning 级别提示用户启用后重试，不应因此中断插件的其他功能。Metadata Editor 重启会清空注册，旧 API 失效；来源插件须重新获取 API 并注册（例如重新启用来源插件）。不要永久缓存失效接口。\r\n\r\n## 2. 元数据增删改查\r\n\r\n所有操作面向当前文档，只操作元数据，不替换歌词行。key 为非空字符串（保留原文），values 为 string[]，允许空数组和空字符串；与编辑器一样支持自定义键。读取返回独立副本。\r\n\r\n| 方法 | 返回值与语义 |\r\n| --- | --- |\r\n| read() | { revision, metadata: { key, values }[] } |\r\n| create(key, values, expectedRevision?) | 新增整个键；已存在则抛异常 |\r\n| update(key, values, expectedRevision?) | 替换指定键的全部值；不存在则抛异常 |\r\n| delete(key, expectedRevision?) | 删除整个键；不存在则抛异常 |\r\n| registerProvider(provider) | 返回 { dispose() }，见下节 |\r\n\r\n写入同步返回宿主 HostResult<ApplyEditResult>，一次调用是一条可撤销事务。必须判断 result.ok，失败读取 result.error.code/message。参数非法、键存在性不符合要求或 API 已卸载则抛异常。传入 expectedRevision 可防止基于旧快照覆盖新编辑；不传时以调用瞬间的 revision 写入。\r\n\r\n```ts\r\nconst snapshot = api.read();\r\nconst existing = snapshot.metadata.find(entry => entry.key === \"musicName\");\r\nconst result = existing\r\n  ? api.update(\"musicName\", [\"新曲名\"], snapshot.revision)\r\n  : api.create(\"musicName\", [\"新曲名\"], snapshot.revision);\r\nif (!result.ok) host.ui.notify({ level: \"warning\", message: result.error.message });\r\n\r\nconst current = api.read();\r\nif (current.metadata.some(entry => entry.key === \"custom\")) {\r\n  const removed = api.delete(\"custom\", current.revision);\r\n  if (!removed.ok) throw new Error(removed.error.message);\r\n}\r\n```\r\n\r\n这些方法属于 trusted-js 同进程合作接口，不是权限隔离边界。事务归属 builtin.metadata；调用方名称不会自动传递到宿主事务来源中。读取或写入无需在设置页选择来源；来源选择只控制获取按钮。\r\n\r\n## 3. 注册元数据提供者\r\n\r\n元数据提供者可以只是插件的一部分功能，不要求开发或安装独立的提供者插件。已有插件可在注册自身其他功能时同时调用 registerProvider；接入暂时不可用时显示警告，保留其余功能正常运行。\r\n\r\n```ts\r\nimport type { TrustedJsActivationContextV0 } from \"@amll-ttml-tool/plugin-sdk-js\";\r\nimport type { MetadataApiV1 } from \"./metadata-api\";\r\n\r\nexport async function activate({ host, pluginId, signal }: TrustedJsActivationContextV0) {\r\n  try {\r\n    const api = await host.commands.execute(\"builtin.metadata.getApi\") as MetadataApiV1;\r\n    if (api.version !== 1) throw new Error(\"Unsupported metadata API\");\r\n    const registration = api.registerProvider({\r\n      id: `${pluginId}.catalog`,\r\n      title: \"示例元数据源\",\r\n      platforms: [\"ncmMusicId\", \"qqMusicId\"],\r\n      signal,\r\n      async fetch({ platform, id, signal: requestSignal }) {\r\n        requestSignal.throwIfAborted();\r\n        // 演示返回结构；实际实现应在此查询自己的数据源并校验响应。\r\n        return [\r\n          { key: \"musicName\", values: [\"示例曲名\", \"别名\"] },\r\n          { key: \"artists\", values: [\"歌手 A\", \"歌手 B\"] },\r\n          { key: platform, values: [id] },\r\n        ];\r\n      },\r\n    });\r\n    return () => registration.dispose();\r\n  } catch (error) {\r\n    if (!signal.aborted) host.ui.notify({\r\n      level: \"warning\", message: \"元数据接入暂不可用，请启用 Metadata Editor 后重试\", detail: String(error),\r\n    });\r\n  }\r\n}\r\n```\r\n\r\n| 字段 | 合同 |\r\n| --- | --- |\r\n| id | 稳定且唯一；建议 <pluginId>.<source>，各段由字母、数字、下划线、连字符组成，至少两段；重复注册拒绝 |\r\n| title | 非空显示名称 |\r\n| platforms | 非空受支持平台数组；一个来源可支持多个平台 |\r\n| signal | 必须使用来源插件 activate 的 AbortSignal；卸载自动注销 |\r\n| fetch | 接收 { platform, id, signal }，返回 Promise<{ key, values }[]> |\r\n\r\n手动 dispose 幂等，立即注销来源；提供者卸载、Metadata Editor 卸载时也会注销。请求信号合并双方生命周期和 30 秒超时；即使提供者忽略取消，超时或卸载也会结束等待，迟到结果不会写入。提供者仍应尊重 signal，以停止不必要的请求。不要在 fetch 中自行写当前文档，应只返回数据。\r\n\r\n返回键必须唯一且非空，值必须全部为字符串。每个来源的响应先完整校验，非法响应不会部分写入。值会 trim、去除空值并按键追加去重，保留已有的非空值及未涉及的键；已有值同时规范化、去重。点击获取时并行请求全部已勾选且可用的来源，按勾选顺序合并成功响应并去重，所有有效返回项在一个事务中写入，可一次撤销。单个来源失败或卸载不影响其他有效来源；部分成功时显示 warning 通知，全部失败则不写入，并由编辑器显示 warning 通知。返回 [] 不增加字段。\r\n\r\n请求开始时记录文档 revision 和项目 ID，完成时检查当前来源及项目，再使用 expectedRevision 提交。期间文档编辑、切换项目、修改该平台勾选项或 Metadata Editor 卸载均不会覆盖新数据。注销、卸载或超时的来源结果会被丢弃；请求未能完成的提示以 warning 级别显示，用户可重新获取。并发请求基于旧 revision 的后续提交同样会被拒绝。\r\n\r\n## 4. 来源设置与存储\r\n\r\n每个平台可勾选多个来源，也可全部取消勾选以隐藏获取按钮。选项仅包含实时注册并声明支持该平台的来源，注册本身不会自动选中。设置写入 host.storage.kv 的 providers.v1，每个平台保存来源 ID 数组；旧版单个字符串会自动读取为单项数组，下次保存时写入新格式；保存成功后更新 UI，失败显示 warning 通知并保留先前选择。\r\n\r\n已保存来源暂时缺席时，UI 保留带警告状态的勾选项，可以取消勾选。该来源重新注册后恢复使用；只要该平台还有一个已勾选的可用来源，获取按钮就保持显示。设置不存入歌词文件，也不参与文档撤销。存储读取失败会通知并使用默认关闭状态。\r\n\r\n## 5. 本地开发与验收\r\n\r\n```sh\r\npnpm install --frozen-lockfile\r\npnpm test\r\npnpm run pack\r\npnpm serve\r\n```\r\n\r\n使用 vendor/ 锁定的 API/SDK/toolkit，不直接导入宿主源码。React 和 Radix 由宿主共享。pack 生成 dist/plugins/catalog.json 与内容寻址 ZIP；build、test、pack 会先运行 scripts/render-docs.mjs，将 Markdown 预渲染为 HTML；原始 Markdown 同时随包保存供导出，不引入 Markdown 运行时依赖。渲染器仅支持本文使用的标题、段落、行内代码、代码块和表格，扩展语法时需同步渲染器及测试。\r\n\r\n验收重点：默认隐藏按钮；注册和设置选择后仅对应平台出现；空 ID 禁用；获取结果追加去重且可一次撤销；来源卸载即时隐藏；读取/保存失败通知；请求期间编辑或切换项目不覆盖；非法响应不产生部分写入；设置页文档离线可读。自动化测试不等同于真实第三方服务、Tauri 或各操作系统验收。\r\n";
// src/Settings.tsx
function Yf({ host: e, onBack: t }) {
	return /* @__PURE__ */ S("div", {
		className: "amll-metadata-settings",
		children: [/* @__PURE__ */ S(D, {
			align: "center",
			justify: "between",
			gap: "3",
			wrap: "wrap",
			children: [/* @__PURE__ */ S(T, {
				variant: "ghost",
				onClick: t,
				children: [/* @__PURE__ */ x(Kt, {}), e.i18n.t("providers.back")]
			}), /* @__PURE__ */ x(T, {
				asChild: !0,
				variant: "soft",
				children: /* @__PURE__ */ S("a", {
					download: "metadata-development-guide.md",
					href: `data:text/markdown;charset=utf-8,${encodeURIComponent(Jf)}`,
					children: [/* @__PURE__ */ x(Gt, {}), e.i18n.t("providers.exportMarkdown")]
				})
			})]
		}), /* @__PURE__ */ x("article", {
			className: "amll-metadata-doc",
			dangerouslySetInnerHTML: { __html: qf }
		})]
	});
}
function Xf({ host: e, service: t }) {
	y(t.subscribe, t.getVersion, t.getVersion), y((t) => {
		let n = e.i18n.onLocaleChanged(t);
		return () => n.dispose();
	}, () => e.i18n.locale, () => e.i18n.locale);
	let [n, r] = v(!1), [i, a] = v("settings"), o = _(null), s = _(!0);
	f(() => {
		s.current ? s.current = !1 : (o.current?.focus(), o.current?.scrollIntoView({ block: "start" }));
	}, [i]);
	let c = Wf.filter((e) => t.selected(e).length > 0).length, l = new Set(Wf.flatMap((e) => t.list(e).map((e) => e.id))).size, u = {
		ncmMusicId: Pf,
		qqMusicId: Ff,
		spotifyId: If,
		appleMusicId: Lf
	};
	return /* @__PURE__ */ S("div", {
		ref: o,
		tabIndex: -1,
		className: "amll-metadata-settings-page",
		"aria-label": e.i18n.t(i === "docs" ? "providers.docs" : "providers.title"),
		children: [/* @__PURE__ */ x("style", { children: Zf }), i === "docs" ? /* @__PURE__ */ x(Yf, {
			host: e,
			onBack: () => a("settings")
		}) : /* @__PURE__ */ S("div", {
			className: "amll-metadata-settings",
			children: [
				/* @__PURE__ */ S("header", {
					className: "amll-metadata-settings-header",
					children: [/* @__PURE__ */ x("div", {
						className: "amll-metadata-settings-mark",
						"aria-hidden": "true",
						children: /* @__PURE__ */ x(Bt, {})
					}), /* @__PURE__ */ S(w, {
						style: { flex: 1 },
						children: [
							/* @__PURE__ */ x(O, {
								as: "div",
								size: "2",
								color: "gray",
								mb: "2",
								children: e.i18n.t("metadataDialog.title")
							}),
							/* @__PURE__ */ x(te, {
								size: "7",
								mb: "3",
								children: e.i18n.t("providers.title")
							}),
							/* @__PURE__ */ x(O, {
								as: "p",
								color: "gray",
								size: "2",
								style: { lineHeight: 1.8 },
								children: e.i18n.t("providers.intro")
							})
						]
					})]
				}),
				/* @__PURE__ */ S("section", {
					"aria-labelledby": "metadata-platforms-title",
					children: [
						/* @__PURE__ */ S(D, {
							align: "center",
							justify: "between",
							gap: "3",
							mb: "4",
							wrap: "wrap",
							children: [/* @__PURE__ */ x(te, {
								id: "metadata-platforms-title",
								size: "4",
								children: e.i18n.t("providers.platforms")
							}), /* @__PURE__ */ x(C, {
								variant: "soft",
								color: c ? "green" : "gray",
								size: "2",
								children: e.i18n.t("providers.activeCount", { count: c })
							})]
						}),
						/* @__PURE__ */ x("div", {
							className: "amll-metadata-platform-grid",
							children: Wf.map((i) => {
								let a = u[i], o = t.list(i), s = t.selected(i).length > 0, c = t.selectionIds(i), l = c.length > 0 && !s;
								return /* @__PURE__ */ S(E, {
									size: "3",
									className: "amll-metadata-platform-card",
									"data-enabled": !!s,
									children: [
										/* @__PURE__ */ S(D, {
											align: "center",
											gap: "3",
											mb: "5",
											children: [
												/* @__PURE__ */ x("div", {
													className: "amll-metadata-platform-icon",
													"aria-hidden": "true",
													children: /* @__PURE__ */ x(a, {
														width: "28",
														height: "28"
													})
												}),
												/* @__PURE__ */ S(w, {
													style: {
														flex: 1,
														minWidth: 0
													},
													children: [/* @__PURE__ */ x(te, {
														as: "h3",
														size: "3",
														id: `metadata-${i}`,
														children: e.i18n.t(`metadataDialog.builtinOptions.${i}`)
													}), /* @__PURE__ */ x(O, {
														as: "div",
														size: "1",
														color: "gray",
														mt: "1",
														children: e.i18n.t("providers.sourceCount", { count: o.length })
													})]
												}),
												/* @__PURE__ */ x(C, {
													color: s ? "green" : l ? "orange" : "gray",
													variant: "soft",
													children: e.i18n.t(s ? "providers.enabled" : l ? "providers.missing" : "providers.disabled")
												})
											]
										}),
										/* @__PURE__ */ x(O, {
											as: "div",
											size: "2",
											weight: "medium",
											mb: "2",
											id: `metadata-source-${i}`,
											children: e.i18n.t("providers.sourceLabel")
										}),
										/* @__PURE__ */ S(D, {
											direction: "column",
											gap: "2",
											role: "group",
											"aria-labelledby": `metadata-${i} metadata-source-${i}`,
											children: [[...o.map((e) => ({
												id: e.id,
												title: e.title,
												available: !0
											})), ...c.filter((e) => !o.some((t) => t.id === e)).map((t) => ({
												id: t,
												title: e.i18n.t("providers.unavailable"),
												available: !1
											}))].map((a) => /* @__PURE__ */ S(O, {
												as: "label",
												size: "2",
												className: "amll-metadata-source-choice",
												color: a.available ? void 0 : "orange",
												children: [/* @__PURE__ */ x(ee, {
													checked: c.includes(a.id),
													disabled: n,
													onCheckedChange: async (n) => {
														r(!0);
														try {
															await t.select(i, n === !0 ? [...c, a.id] : c.filter((e) => e !== a.id));
														} catch (n) {
															t.isActive() && e.ui.notify({
																level: "warning",
																message: e.i18n.t("providers.saveFailed"),
																detail: String(n)
															});
														} finally {
															r(!1);
														}
													}
												}), /* @__PURE__ */ S("span", { children: [a.title, /* @__PURE__ */ x(O, {
													as: "span",
													size: "1",
													color: "gray",
													style: {
														display: "block",
														overflowWrap: "anywhere"
													},
													children: a.id
												})] })]
											}, a.id)), !o.length && !c.length && /* @__PURE__ */ x(O, {
												size: "2",
												color: "gray",
												children: e.i18n.t("providers.noSources")
											})]
										}),
										/* @__PURE__ */ x(O, {
											as: "p",
											size: "1",
											color: "gray",
											mt: "3",
											style: { lineHeight: 1.7 },
											children: e.i18n.t(s ? "providers.enabledHint" : l ? "providers.missingHint" : "providers.disabledHint")
										})
									]
								}, i);
							})
						}),
						l === 0 && /* @__PURE__ */ S(D, {
							gap: "2",
							align: "start",
							mt: "4",
							className: "amll-metadata-provider-note",
							children: [/* @__PURE__ */ x(Ht, {
								"aria-hidden": "true",
								style: {
									flexShrink: 0,
									marginTop: 3
								}
							}), /* @__PURE__ */ x(O, {
								size: "2",
								children: e.i18n.t("providers.emptyHint")
							})]
						})
					]
				}),
				/* @__PURE__ */ S("section", {
					className: "amll-metadata-developer-card",
					"aria-labelledby": "metadata-developer-title",
					children: [
						/* @__PURE__ */ x("div", {
							className: "amll-metadata-developer-icon",
							"aria-hidden": "true",
							children: /* @__PURE__ */ x(Wt, {})
						}),
						/* @__PURE__ */ S(w, {
							style: {
								flex: 1,
								minWidth: 180
							},
							children: [/* @__PURE__ */ x(te, {
								id: "metadata-developer-title",
								size: "4",
								mb: "2",
								children: e.i18n.t("providers.developerTitle")
							}), /* @__PURE__ */ x(O, {
								as: "p",
								size: "2",
								color: "gray",
								style: { lineHeight: 1.8 },
								children: e.i18n.t("providers.developerDescription")
							})]
						}),
						/* @__PURE__ */ S(T, {
							variant: "soft",
							onClick: () => a("docs"),
							children: [e.i18n.t("providers.docs"), /* @__PURE__ */ x(qt, {})]
						})
					]
				}),
				/* @__PURE__ */ x(O, {
					as: "p",
					size: "1",
					color: "gray",
					className: "amll-metadata-settings-footnote",
					children: e.i18n.t("providers.footer")
				})
			]
		})]
	});
}
var Zf = "\n.amll-metadata-settings-page { min-width: 0; outline: none; }\n.amll-metadata-doc { min-width: 0; color: var(--gray-12); font-size: 14px; line-height: 1.85; overflow-wrap: anywhere; }\n.amll-metadata-doc h1 { font-size: clamp(24px, 3vw, 32px); line-height: 1.35; margin: 0 0 24px; letter-spacing: -.025em; }\n.amll-metadata-doc h2 { margin: 40px 0 16px; padding-bottom: 10px; border-bottom: 1px solid var(--gray-a5); font-size: 21px; }\n.amll-metadata-doc p { margin: 14px 0; }\n.amll-metadata-doc code { font-family: var(--code-font-family, monospace); font-size: .9em; border-radius: 4px; background: var(--gray-a3); padding: 2px 5px; }\n.amll-metadata-doc pre { overflow-x: auto; padding: 20px; border: 1px solid var(--gray-a5); border-radius: var(--radius-3); background: var(--gray-a2); line-height: 1.65; }\n.amll-metadata-doc pre code { padding: 0; background: none; }\n.amll-metadata-doc-table { overflow-x: auto; margin: 20px 0; border: 1px solid var(--gray-a5); border-radius: var(--radius-3); }\n.amll-metadata-doc table { width: 100%; border-collapse: collapse; text-align: left; }\n.amll-metadata-doc th, .amll-metadata-doc td { padding: 12px 16px; border-bottom: 1px solid var(--gray-a4); vertical-align: top; }\n.amll-metadata-doc th { background: var(--gray-a3); font-weight: 600; }\n.amll-metadata-doc tbody tr:last-child td { border-bottom: 0; }\n\n.amll-metadata-settings { box-sizing: border-box; max-width: 1000px; margin: 0 auto; padding: clamp(20px, 4vw, 40px); display: flex; flex-direction: column; gap: 32px; }\n.amll-metadata-settings-header { display: flex; align-items: flex-start; gap: 20px; padding-bottom: 28px; border-bottom: 1px solid var(--gray-a5); }\n.amll-metadata-settings-mark { width: 52px; height: 52px; flex-shrink: 0; display: grid; place-items: center; border-radius: var(--radius-4); color: var(--accent-11); background: var(--accent-a3); border: 1px solid var(--accent-a4); }\n.amll-metadata-settings-mark svg { width: 28px; height: 28px; }\n.amll-metadata-platform-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 320px), 1fr)); gap: 16px; }\n.amll-metadata-platform-card { min-width: 0; }\n.amll-metadata-platform-card[data-enabled=\"true\"] { box-shadow: inset 0 0 0 1px var(--accent-a7); }\n.amll-metadata-platform-icon { width: 48px; height: 48px; display: grid; place-items: center; border-radius: var(--radius-3); background: var(--gray-a3); flex-shrink: 0; }\n.amll-metadata-source-choice { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border: 1px solid var(--gray-a5); border-radius: var(--radius-3); cursor: pointer; }\n.amll-metadata-source-choice:has([data-state=\"checked\"]) { background: var(--accent-a2); border-color: var(--accent-a6); }\n.amll-metadata-source-choice > span { min-width: 0; }\n.amll-metadata-provider-note { padding: 14px 16px; background: var(--gray-a2); border-radius: var(--radius-3); color: var(--gray-11); line-height: 1.7; }\n.amll-metadata-developer-card { display: flex; align-items: center; flex-wrap: wrap; gap: 20px; padding: 24px; border: 1px solid var(--accent-a5); border-radius: var(--radius-4); background: var(--accent-a2); }\n.amll-metadata-developer-icon { color: var(--accent-11); }\n.amll-metadata-settings-footnote { text-align: center; line-height: 1.8; }\n";
// src/plugin.ts
function Qf({ host: e, signal: t }) {
	let n = Kf(e, t);
	e.commands.register({
		id: "builtin.metadata.getApi",
		handler: () => n.api
	}), e.views.registerView({
		id: "builtin.metadata.settings",
		kind: "settings-view",
		title: Uf["providers.title"],
		view: () => o(Xf, {
			host: e,
			service: n
		})
	}), e.views.registerView({
		id: "builtin.metadata.dialog",
		kind: "dialog-view",
		title: Uf["metadataDialog.title"],
		size: "full",
		view: () => o(Hf, {
			host: e,
			service: n
		})
	}), e.commands.register({
		id: "builtin.metadata.run",
		title: Uf["command.title"],
		handler: () => e.ui.openView("builtin.metadata.dialog")
	}), e.menus.register({
		id: "builtin.metadata.menu.edit",
		command: "builtin.metadata.run",
		menu: "menu.edit"
	});
}
export { Qf as activate };
