import { createElement as e, useEffect as t, useRef as n, useState as r } from "react";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
// src/numbers.ts
function o(e) {
	let t = 0;
	return e.map((e, n) => (n && e.isBackground || t++, t));
}
// src/styles.ts
var s = {
	outlineContainer: "amll-outline-outlineContainer",
	itemWrapper: "amll-outline-itemWrapper",
	outlineItem: "amll-outline-outlineItem",
	dropIndicator: "amll-outline-dropIndicator",
	isDraggingGlobal: "amll-outline-isDraggingGlobal",
	emptyText: "amll-outline-emptyText",
	lineNumber: "amll-outline-lineNumber",
	textContent: "amll-outline-textContent",
	isDuet: "amll-outline-isDuet",
	primaryText: "amll-outline-primaryText",
	isBG: "amll-outline-isBG"
}, c = ".amll-outline-outlineContainer {\n	display: flex;\n	flex-direction: column;\n	height: 100%;\n	overflow-y: auto;\n	padding: var(--space-2);\n	gap: 2px;\n	position: relative;\n}\n\n.amll-outline-itemWrapper {\n	position: relative;\n	border-radius: var(--radius-2);\n}\n\n.amll-outline-outlineItem {\n	display: flex;\n	flex-direction: row;\n	align-items: center;\n	padding: var(--space-2) var(--space-3);\n	border-radius: var(--radius-2);\n	user-select: none;\n	background: transparent;\n	border: 1px solid transparent;\n	transition:\n		background-color 0.1s,\n		border-color 0.1s,\n		opacity 0.2s,\n		transform 0.2s;\n	gap: var(--space-3);\n	touch-action: none;\n}\n\n.amll-outline-outlineItem[data-is-dragged=\"true\"] {\n	opacity: 0.4;\n	transform: scale(0.95);\n}\n\n.amll-outline-outlineItem:hover {\n	background: var(--gray-a3);\n}\n\n.amll-outline-outlineItem[data-selected=\"true\"] {\n	background: var(--accent-a3);\n	border-color: var(--accent-a5);\n}\n\n.amll-outline-dropIndicator {\n	position: absolute;\n	left: 0;\n	right: 0;\n	height: 2px;\n	background-color: var(--accent-9);\n	border-radius: 2px;\n	z-index: 10;\n	pointer-events: none;\n\n	display: var(--drop-indicator-display, none);\n	transform: translateY(var(--drop-indicator-y, 0px));\n\n	will-change: transform;\n}\n\n\n\n.amll-outline-isDraggingGlobal {\n	cursor: grabbing;\n}\n.amll-outline-isDraggingGlobal * {\n	cursor: grabbing;\n}\n.amll-outline-isDraggingGlobal .amll-outline-outlineItem {\n	pointer-events: none;\n}\n\n.amll-outline-emptyText {\n	color: var(--gray-7);\n	font-style: italic;\n}\n\n.amll-outline-lineNumber {\n	flex: 0 0 15px;\n	font-size: 11px;\n	color: var(--gray-8);\n	text-align: left;\n	margin-top: 0;\n	font-variant-numeric: tabular-nums;\n}\n.amll-outline-textContent {\n	flex: 1 1 auto;\n	display: flex;\n	flex-direction: column;\n	min-width: 0;\n}\n.amll-outline-isDuet {\n	text-align: right;\n}\n.amll-outline-primaryText {\n	font-size: 13px;\n	color: var(--gray-12);\n	line-height: 1.5;\n	white-space: pre-wrap;\n	word-break: break-word;\n	transition: color 0.2s;\n}\n\n.amll-outline-isBG .amll-outline-primaryText {\n	color: var(--gray-9);\n}\n";
// src/Panel.tsx
function l({ host: e }) {
	let [l, u] = r(() => e.document.readSnapshot()), [d, f] = r(() => e.selection.get()), [, p] = r(0);
	t(() => {
		let t = e.document.onChanged(() => u(e.document.readSnapshot())), n = e.selection.onChanged(f), r = e.i18n.onLocaleChanged(() => p((e) => e + 1));
		return u(e.document.readSnapshot()), f(e.selection.get()), () => {
			t.dispose(), n.dispose(), r.dispose();
		};
	}, [e]);
	let m = n(null), { isDragging: h, isDraggingSource: g, onPointerDown: _ } = e.editor.useLineList(m), { LineContextMenu: v } = e.editor, y = o(l.lines), b = new Set(d.lineIds);
	return /* @__PURE__ */ a("div", {
		ref: m,
		className: s.outlineContainer + (h ? " " + s.isDraggingGlobal : ""),
		children: [
			/* @__PURE__ */ i("style", { children: c }),
			/* @__PURE__ */ i("div", { className: s.dropIndicator }),
			l.lines.map((t, n) => {
				let r = t.words.map((e) => e.text).join("");
				return /* @__PURE__ */ i("div", {
					className: s.itemWrapper,
					"data-line-id": t.id,
					"data-absolute-index": n,
					children: /* @__PURE__ */ i(v, {
						lineId: t.id,
						children: /* @__PURE__ */ a("div", {
							className: s.outlineItem,
							"data-selected": b.has(t.id),
							"data-is-dragged": g && b.has(t.id),
							onPointerDown: (e) => _(e, t.id),
							onDoubleClick: () => e.editor.revealLine(t.id),
							children: [/* @__PURE__ */ i("div", {
								className: s.lineNumber,
								children: y[n]
							}), /* @__PURE__ */ i("div", {
								className: [
									s.textContent,
									t.isBackground ? s.isBG : "",
									t.isDuet ? s.isDuet : ""
								].join(" "),
								children: /* @__PURE__ */ i("div", {
									className: s.primaryText,
									children: r.trim() ? r : /* @__PURE__ */ i("span", {
										className: s.emptyText,
										children: e.i18n.t("emptyLine")
									})
								})
							})]
						})
					})
				}, t.id);
			})
		]
	});
}
// src/plugin.ts
function u({ host: t }) {
	let n = t.views.registerView({
		id: "builtin.outline.sidebar",
		kind: "sidebar",
		title: {
			default: "Outline",
			"en-US": "Outline",
			"zh-CN": "大纲"
		},
		view: () => e(l, { host: t })
	});
	return () => n.dispose();
}
export { u as activate };
