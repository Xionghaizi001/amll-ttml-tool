import * as e from "react";
import t, { createContext as n, createElement as r, useContext as i, useEffect as a, useRef as o, useState as s } from "react";
import { Fragment as c, jsx as l, jsxs as u } from "react/jsx-runtime";
import { Badge as d, Box as f, Button as p, Card as ee, Checkbox as m, Dialog as h, Flex as g, IconButton as _, ScrollArea as te, Separator as ne, Skeleton as v, Spinner as re, Text as y, TextArea as ie, TextField as ae } from "@radix-ui/themes";
var b = {
	changed: {
		default: "The document changed. Please import again.",
		"zh-CN": "文档已发生变化，请重新导入。"
	},
	"command.title": {
		default: "Import from LRCLIB...",
		"cs-CZ": "Importovat z LRCLIB...",
		"da-DK": "Importér fra LRCLIB...",
		"en-US": "Import from LRCLIB...",
		"es-ES": "Importar desde LRCLIB...",
		"fr-FR": "Importer depuis LRCLIB...",
		"id-ID": "Impor dari LRCLIB...",
		"pl-PL": "Importuj z LRCLIB...",
		"pt-BR": "Importar do LRCLIB...",
		"ru-RU": "Импорт из LRCLIB...",
		"sk-SK": "Importovať z LRCLIB...",
		"zh-CN": "从 LRCLIB 导入..."
	},
	"common.cancel": {
		default: "Cancel",
		"cs-CZ": "Zrušit",
		"da-DK": "Annuller",
		"en-US": "Cancel",
		"es-ES": "Cancelar",
		"fr-FR": "Annuler",
		"id-ID": "Batal",
		"pl-PL": "Anuluj",
		"pt-BR": "Cancelar",
		"ru-RU": "Отмена",
		"sk-SK": "Zrušiť",
		"zh-CN": "取消"
	},
	"common.close": {
		default: "Close",
		"cs-CZ": "Zavřít",
		"da-DK": "Luk",
		"en-US": "Close",
		"es-ES": "Cerrar",
		"fr-FR": "Fermer",
		"id-ID": "Tutup",
		"pl-PL": "Zamknij",
		"pt-BR": "Fechar",
		"ru-RU": "Закрыть",
		"sk-SK": "Zavrieť",
		"zh-CN": "关闭"
	},
	"common.search": {
		default: "Search",
		"cs-CZ": "Hledat",
		"da-DK": "Søg",
		"en-US": "Search",
		"es-ES": "Buscar",
		"fr-FR": "Rechercher",
		"id-ID": "Cari",
		"pl-PL": "Szukaj",
		"pt-BR": "Pesquisar",
		"ru-RU": "Поиск",
		"sk-SK": "Hľadať",
		"zh-CN": "搜索"
	},
	"lrclib.autoSegment": {
		default: "Auto Segment",
		"cs-CZ": "Automatická segmentace",
		"da-DK": "Auto-segmentering",
		"en-US": "Auto Segment",
		"es-ES": "Segmentación automática",
		"fr-FR": "Segmentation automatique",
		"id-ID": "Segmentasi Otomatis",
		"pl-PL": "Automatyczna segmentacja",
		"pt-BR": "Segmentação automática",
		"ru-RU": "Автосегментация",
		"sk-SK": "Automatická segmentácia",
		"zh-CN": "自动分词"
	},
	"lrclib.extractBg": {
		default: "Extract parentheses as background vocals",
		"cs-CZ": "Extrahovat závorky jako doprovodný vokál",
		"da-DK": "Udtræk parenteser som baggrundsvokal",
		"en-US": "Extract parentheses as background vocals",
		"es-ES": "Extraer paréntesis como vocales de fondo",
		"fr-FR": "Extraire les parenthèses comme voix de fond",
		"id-ID": "Ekstrak konten dalam kurung sebagai vokal latar",
		"pl-PL": "Wyodrębnij nawiasy jako linia w tle",
		"pt-BR": "Extrair parênteses como vocais de fundo",
		"ru-RU": "Извлечь скобки как бэк-вокал",
		"sk-SK": "Extrahovať zátvorky ako sprievodný vokál",
		"zh-CN": "提取括号内容为背景人声"
	},
	"lrclib.import": {
		default: "Import Lyric",
		"cs-CZ": "Importovat titulky",
		"da-DK": "Importér sangtekst",
		"en-US": "Import Lyric",
		"es-ES": "Importar letra",
		"fr-FR": "Importer les paroles",
		"id-ID": "Impor Lirik",
		"pl-PL": "Importuj tekst",
		"pt-BR": "Importar letra",
		"ru-RU": "Импортировать текст",
		"sk-SK": "Importovať texty",
		"zh-CN": "导入歌词"
	},
	"lrclib.importError": {
		default: "Error occurred while importing lyrics",
		"cs-CZ": "Při importu titulek došlo k chybě",
		"da-DK": "Der opstod en fejl under import af sangtekster",
		"en-US": "Error occurred while importing lyrics",
		"es-ES": "Ocurrió un error al importar letras",
		"fr-FR": "Une erreur s'est produite lors de l'importation des paroles",
		"id-ID": "Terjadi kesalahan saat mengimpor lirik",
		"pl-PL": "Wystąpił błąd podczas importowania tekstów",
		"pt-BR": "Ocorreu um erro ao importar letras",
		"ru-RU": "Произошла ошибка при импорте текста",
		"sk-SK": "Pri importe textov sa vyskytla chyba",
		"zh-CN": "导入歌词时发生错误"
	},
	"lrclib.noLyrics": {
		default: "No lyrics content available for this track",
		"cs-CZ": "Pro tuto skladbu není k dispozici žádný obsah titulek",
		"da-DK": "Intet sangtekstindhold tilgængeligt for dette nummer",
		"en-US": "No lyrics content available for this track",
		"es-ES": "No hay contenido de letras disponible para esta pista",
		"fr-FR": "Aucun contenu de paroles disponible pour cette piste",
		"id-ID": "Lagu ini belum memiliki lirik",
		"pl-PL": "Brak dostępnych treści tekstu dla tego utworu",
		"pt-BR": "Nenhum conteúdo de letras disponível para esta faixa",
		"ru-RU": "Для этого трека нет доступного текста",
		"sk-SK": "Pre túto skladbu nie je k dispozícii žiadny obsah textov",
		"zh-CN": "该歌曲暂无歌词内容"
	},
	"lrclib.noResult": {
		default: "Enter keywords to start searching",
		"cs-CZ": "Zadejte klíčová slova pro zahájení vyhledávání",
		"da-DK": "Indtast søgeord for at starte søgning",
		"en-US": "Enter keywords to start searching",
		"es-ES": "Ingresa palabras clave para comenzar la búsqueda",
		"fr-FR": "Entrez des mots-clés pour commencer la recherche",
		"id-ID": "Masukkan kata kunci untuk mulai mencari",
		"pl-PL": "Wprowadź słowa kluczowe, aby rozpocząć wyszukiwanie",
		"pt-BR": "Digite palavras-chave para iniciar a pesquisa",
		"ru-RU": "Введите ключевые слова для начала поиска",
		"sk-SK": "Zadajte kľúčové slová pre začatie vyhľadávania",
		"zh-CN": "输入关键词开始搜索"
	},
	"lrclib.notFound": {
		default: "No results found, please try different keywords",
		"cs-CZ": "Žádné výsledky, zkuste jiná klíčová slova",
		"da-DK": "Ingen resultater fundet, prøv andre søgeord",
		"en-US": "No results found, please try different keywords",
		"es-ES": "No se encontraron resultados, intenta con otras palabras clave",
		"fr-FR": "Aucun résultat trouvé, essayez d'autres mots-clés",
		"id-ID": "Hasil tidak ditemukan, silakan coba ganti kata kunci",
		"pl-PL": "Nie znaleziono wyników, spróbuj innych słów kluczowych",
		"pt-BR": "Nenhum resultado encontrado, tente outras palavras-chave",
		"ru-RU": "Результаты не найдены, попробуйте другие ключевые слова",
		"sk-SK": "Žiadne výsledky, skúste iné kľúčové slová",
		"zh-CN": "未找到相关结果，请尝试更换关键词"
	},
	"lrclib.placeholder": {
		default: "Title Artist...",
		"cs-CZ": "Název Umělec...",
		"da-DK": "Titel Kunstner...",
		"en-US": "Title Artist...",
		"es-ES": "Título Artista...",
		"fr-FR": "Titre Artiste...",
		"id-ID": "Judul Lagu, Artis...",
		"pl-PL": "Tytułowy Artysta...",
		"pt-BR": "Título Artista...",
		"ru-RU": "Название Исполнитель...",
		"sk-SK": "Názov Umelec...",
		"zh-CN": "歌名 歌手..."
	},
	"lrclib.searchError": {
		default: "Search failed, please check network or try again later",
		"cs-CZ": "Vyhledávání selhalo, zkontrolujte síť nebo to zkuste později",
		"da-DK": "Søgning mislykkedes, kontroller netværket eller prøv igen senere",
		"en-US": "Search failed, please check network or try again later",
		"es-ES": "Búsqueda fallida, verifica la conexión o intenta más tarde",
		"fr-FR": "Échec de la recherche, vérifiez le réseau ou réessayez plus tard",
		"id-ID": "Pencarian gagal, periksa jaringan Anda atau coba lagi nanti",
		"pl-PL": "Wyszukiwanie nie powiodło się, sprawdź sieć lub spróbuj później",
		"pt-BR": "Falha na pesquisa, verifique a rede ou tente novamente mais tarde",
		"ru-RU": "Поиск не удался, проверьте сеть или попробуйте позже",
		"sk-SK": "Vyhľadávanie zlyhalo, skontrolujte sieť alebo to skúste neskôr",
		"zh-CN": "搜索失败，请检查网络或稍后重试"
	},
	"lrclib.synced": {
		default: "Synced",
		"cs-CZ": "Synchronizováno",
		"da-DK": "Synkroniseret",
		"en-US": "Synced",
		"es-ES": "Sincronizado",
		"fr-FR": "Synchronisé",
		"id-ID": "Ter-sinkronisasi",
		"pl-PL": "Zsynchronizowany",
		"pt-BR": "Sincronizado",
		"ru-RU": "Синхронизировано",
		"sk-SK": "Synchronizované",
		"zh-CN": "有时间轴"
	},
	"lrclib.title": {
		default: "Import Lyric from LRCLIB",
		"cs-CZ": "Importovat titulky z LRCLIB",
		"da-DK": "Importér sangtekst fra LRCLIB",
		"en-US": "Import Lyric from LRCLIB",
		"es-ES": "Importar letra desde LRCLIB",
		"fr-FR": "Importer des paroles depuis LRCLIB",
		"id-ID": "Impor lirik dari LRCLIB",
		"pl-PL": "Importuj tekst z LRCLIB",
		"pt-BR": "Importar letra do LRCLIB",
		"ru-RU": "Импорт текста из LRCLIB",
		"sk-SK": "Importovať texty z LRCLIB",
		"zh-CN": "从 LRCLIB 导入歌词"
	},
	"lrclib.unsynced": {
		default: "Unsynced",
		"cs-CZ": "Nesynchronizováno",
		"da-DK": "Ikke synkroniseret",
		"en-US": "Unsynced",
		"es-ES": "Sin sincronizar",
		"fr-FR": "Non synchronisé",
		"id-ID": "Tidak ter-sinkronisasi",
		"pl-PL": "Niezsynchronizowany",
		"pt-BR": "Não sincronizado",
		"ru-RU": "Не синхронизировано",
		"sk-SK": "Nesynchronizované",
		"zh-CN": "无时间轴"
	}
}, x = typeof window > "u" ? global : window, S = "@griffel/";
function C(e, t) {
	return x[Symbol.for(S + e)] || (x[Symbol.for(S + e)] = t), x[Symbol.for(S + e)];
}
var w = /*#__PURE__*/ C("DEBUG_RESET_CLASSES", {}), T = /*#__PURE__*/ C("DEFINITION_LOOKUP_TABLE", {}), E = "data-make-styles-bucket", D = "data-priority", O = "data-container", k = process.env.NODE_ENV === "production" ? 10 : 18;
// node_modules/.pnpm/@emotion+hash@0.9.2/node_modules/@emotion/hash/dist/emotion-hash.esm.js
function A(e) {
	for (var t = 0, n, r = 0, i = e.length; i >= 4; ++r, i -= 4) n = e.charCodeAt(r) & 255 | (e.charCodeAt(++r) & 255) << 8 | (e.charCodeAt(++r) & 255) << 16 | (e.charCodeAt(++r) & 255) << 24, n = (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16), n ^= n >>> 24, t = (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16) ^ (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
	switch (i) {
		case 3: t ^= (e.charCodeAt(r + 2) & 255) << 16;
		case 2: t ^= (e.charCodeAt(r + 1) & 255) << 8;
		case 1: t ^= e.charCodeAt(r) & 255, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
	}
	return t ^= t >>> 13, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16), ((t ^ t >>> 15) >>> 0).toString(36);
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/utils/hashSequence.js
function j(e) {
	let t = e.length;
	if (t === 7) return e;
	for (let n = t; n < 7; n++) e += "0";
	return e;
}
function M(e, t, n = []) {
	return process.env.NODE_ENV === "production" ? "___" + j(A(e + t)) : "___" + j(A(e + t)) + "_" + j(A(n.join("")));
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/reduceToClassNameForSlots.js
function N(e, t) {
	let n = "", r = "";
	for (let i in e) {
		let a = e[i];
		if (a === 0) {
			r += i + " ";
			continue;
		}
		let o = Array.isArray(a), s = t === "rtl" ? (o ? a[1] : a) + " " : (o ? a[0] : a) + " ";
		n += s, r += s;
	}
	return [n.slice(0, -1), r.slice(0, -1)];
}
function P(e, t) {
	let n = {};
	for (let r in e) {
		let [i, a] = N(e[r], t);
		if (a === "") {
			n[r] = "";
			continue;
		}
		let o = M(a, t), s = o + (i === "" ? "" : " " + i);
		T[o] = [e[r], t], n[r] = s;
	}
	return n;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/mergeClasses.js
var F = {};
function I() {
	let e = null, t = "", n = "", r = Array(arguments.length), i = "";
	for (let e = 0; e < arguments.length; e++) {
		let a = arguments[e];
		if (typeof a == "string" && a !== "") {
			let o = a.indexOf("___");
			if (o === -1) process.env.NODE_ENV !== "production" && a.split(" ").forEach((e) => {
				e.startsWith("r") && w[e] && (i ? console.error(`mergeClasses(): a passed string contains multiple classes produced by makeResetStyles (${a} & ${t}, this will lead to non-deterministic behavior. Learn more:https://griffel.js.org/react/api/make-reset-styles#limitations
Source string: ${a}`) : i = e);
			}), t += a + " ";
			else {
				let i = a.substr(o, k);
				o > 0 && (t += a.slice(0, o)), n += i, r[e] = i;
			}
			process.env.NODE_ENV !== "production" && a.indexOf("___", o + 1) !== -1 && console.error(`mergeClasses(): a passed string contains multiple identifiers of atomic classes (classes that start with "___"), it's possible that passed classes were concatenated in a wrong way. Source string: ${a}`);
		}
	}
	if (n === "") return t.slice(0, -1);
	let a = F[n];
	if (a !== void 0) return t + a;
	let o = [];
	for (let t = 0; t < arguments.length; t++) {
		let n = r[t];
		if (n) {
			let r = T[n];
			r ? (o.push(r[0]), process.env.NODE_ENV !== "production" && e !== null && e !== r[1] && console.error(`mergeClasses(): a passed string contains an identifier (${n}) that has different direction (dir="${r[1] ? "rtl" : "ltr"}") setting than other classes. This is not supported. Source string: ${arguments[t]}`), e = r[1]) : process.env.NODE_ENV !== "production" && console.error(`mergeClasses(): a passed string contains an identifier (${n}) that does not match any entry in cache. Source string: ${arguments[t]}`);
		}
	}
	let s = Object.assign.apply(Object, [{}].concat(o)), [c, l] = N(s, e), u = M(l, e, r), d = u + " " + c;
	return F[n] = d, T[u] = [s, e], t + d;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/store.js
var L = {}, R = /* @__PURE__ */ new Set(), z = {
	getChildrenSequences: (e) => {
		let t = Object.keys(F).find((t) => F[t].startsWith(e));
		return t ? t.split("___").filter((e) => e.length).map((e) => "___" + e) : [];
	},
	addCSSRule: (e) => {
		R.add(e);
	},
	addSequenceDetails: (e, t) => {
		Object.entries(e).forEach(([e, n]) => {
			L[n.substring(0, k)] = {
				slotName: e,
				sourceURL: t
			};
		});
	},
	getCSSRules: () => Array.from(R),
	getSequenceDetails: (e) => L[e]
};
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/utils.js
function B(e, t) {
	return Array.isArray(e) ? t === "rtl" ? e[1] : e[0] : e || "";
}
function oe(e, t, n, r) {
	let i = e[0], a = e[1];
	return Object.entries(i).map(([e, i]) => {
		let o = B(i, a), s;
		if (n && t) {
			let i = n.find(({ className: e }) => e === o);
			!i && t[0][e] ? s = B(t[0][e], t[1]) : i && t[0][e] ? s = r && r.filter(({ debugClassNames: e }) => e.filter(({ className: e }) => e === o).length > 0).length > 0 ? i.className : i.overriddenBy : (!i && !t[0][e] || i && !t[0][e]) && (s = void 0);
		}
		return {
			className: o,
			overriddenBy: s
		};
	});
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getAtomicDebugSequenceTree.js
function V(e, t) {
	let n = T[e];
	if (n === void 0) return;
	let r = oe(n, t ? T[t.sequenceHash] : void 0, t?.debugClassNames, t?.children), i = {
		sequenceHash: e,
		direction: n[1],
		children: [],
		debugClassNames: r
	};
	return z.getChildrenSequences(i.sequenceHash).reverse().forEach((e) => {
		let t = V(e, i);
		t && i.children.push(t);
	}), i.children.length || (i.rules = {}, i.debugClassNames.forEach(({ className: t }) => {
		let n = z.getSequenceDetails(e);
		n && (i.slot = n.slotName, i.sourceURL = n.sourceURL);
		let r = z.getCSSRules().find((e) => e.includes(t));
		i.rules[t] = r;
	})), i;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getResetDebugSequence.js
function se(e) {
	if (w[e] === void 0) return;
	let t = {
		sequenceHash: e,
		direction: "ltr",
		children: [],
		debugClassNames: [{ className: e }]
	};
	t.rules = {}, t.slot = "makeResetStyles()";
	let [{ className: n }] = t.debugClassNames, r = z.getCSSRules().filter((e) => e.includes(`.${n}`));
	return t.rules[n] = r.join(""), t;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/mergeDebugSequence.js
function ce(e, t) {
	let n = e ? V(e) : void 0, r = t ? se(t) : void 0;
	if (n || r) return n ? r ? {
		sequenceHash: n.sequenceHash + r.sequenceHash,
		direction: n.direction,
		children: [n, r],
		debugClassNames: [...n.debugClassNames, ...r.debugClassNames]
	} : n : r;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/injectDevTools.js
function le(e) {
	let t = e.defaultView;
	if (!t || t.__GRIFFEL_DEVTOOLS__) return;
	let n = { getInfo: (e) => {
		let t, n;
		for (let r of e.classList) r.startsWith("___") && (t = r), w[r] && (n = r);
		return ce(t, n);
	} };
	Object.defineProperty(t, "__GRIFFEL_DEVTOOLS__", {
		configurable: !1,
		enumerable: !1,
		get() {
			return n;
		}
	});
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/isDevToolsEnabled.js
var H = (() => {
	try {
		return !!(typeof window < "u" && window.sessionStorage?.getItem("__GRIFFEL_DEVTOOLS__"));
	} catch {
		return !1;
	}
})(), U = "<unknown>";
function ue(e) {
	return me(e) || _e(e) || ye(e);
}
var de = /^\s*at (.*?) ?\(((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/|[a-z]:\\|\\\\).*?)?\)?\s*$/i, fe = /^\s*at ()((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/|[a-z]:\\|\\\\).*?)\s*$/i, pe = /\((\S*)\)/;
function me(e) {
	let t = de.exec(e) || fe.exec(e);
	if (!t) return null;
	let n = t[2], r = n && n.indexOf("native") === 0, i = n && n.indexOf("eval") === 0, a = pe.exec(n);
	return i && a !== null && (n = a[1]), {
		loc: r ? null : t[2],
		name: t[1] || U
	};
}
var he = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|resource|\[native).*?|[^@]*bundle)\s*$/i, ge = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;
function _e(e) {
	let t = he.exec(e);
	if (!t) return null;
	let n = t[3], r = n && n.indexOf(" > eval") > -1, i = ge.exec(n);
	return r && i !== null && (n = i[1]), {
		loc: t[3],
		name: t[1] || U
	};
}
var ve = /^\s*(?:([^@]*)(?:\((.*?)\))?@)?(\S.*?)\s*$/i;
function ye(e) {
	let t = ve.exec(e);
	return t ? {
		loc: t[3],
		name: t[1] || U
	} : null;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getSourceURLfromError.js
function be() {
	let e = xe(String((/* @__PURE__ */ Error()).stack).split("\n"));
	return e === void 0 ? void 0 : ue(e)?.loc;
}
function xe(e) {
	for (let t = e.length - 1; t >= 0; --t) if (e[t].includes("at getSourceURLfromError")) return e[t + 3];
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/utils/normalizeCSSBucketEntry.js
function Se(e) {
	if (!Array.isArray(e)) return [e];
	if (process.env.NODE_ENV !== "production" && e.length > 2) throw Error("CSS Bucket contains an entry with greater than 2 items, please report this to https://github.com/microsoft/griffel/issues");
	return e;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/createIsomorphicStyleSheet.js
function Ce(e, t, n, r) {
	let i = [];
	if (r[E] = t, r[D] = String(n), e) for (let t in r) e.setAttribute(t, r[t]);
	function a(t) {
		return e?.sheet ? e.sheet.insertRule(t, e.sheet.cssRules.length) : i.push(t);
	}
	return {
		elementAttributes: r,
		insertRule: a,
		element: e,
		bucketName: t,
		cssRules() {
			return e?.sheet ? Array.from(e.sheet.cssRules).map((e) => e.cssText) : i;
		}
	};
}
var W = /*#__PURE__*/ [
	"r",
	"d",
	"l",
	"v",
	"w",
	"f",
	"i",
	"h",
	"a",
	"s",
	"k",
	"t",
	"m",
	"c",
	"x"
].reduce((e, t, n) => (e[t] = n, e), {});
function we(e, t, n) {
	return e === "m" || e === "x" ? e + t + n : e + n;
}
function Te(e, t, n, r, i = {}) {
	let a = e === "m", o = e === "x", s = i.m, c = i.x, l = i.p ?? 0, u = we(e, c ?? s ?? "0", l);
	if (!r.stylesheets[u]) {
		let d = t && t.createElement("style"), f = Ce(d, e, l, {
			...r.styleElementAttributes,
			...a && { media: s },
			...o && { "data-container": c }
		});
		r.stylesheets[u] = f, t?.head && d && t.head.insertBefore(d, De(t, n, e, r, i));
	}
	return r.stylesheets[u];
}
function Ee(e, t, n) {
	return e.getAttribute("data-make-styles-bucket") === t ? t === "m" ? n.m === e.media : t !== "x" || n.x === e.getAttribute(O) : !1;
}
function De(e, t, n, r, i = {}) {
	let a = W[n], o = i.m ?? "", s = i.x ?? "", c = i.p ?? 0, l = (e) => a - W[e.getAttribute(E)], u = e.head.querySelectorAll(`[${E}]`);
	if (n === "m" || n === "x") {
		let t = e.head.querySelectorAll(`[${E}="${n}"]`);
		t.length && (u = t, l = n === "m" ? (e) => r.compareMediaQueries(o, e.media) : (e) => r.compareContainerQueries(s, e.getAttribute("data-container") ?? ""));
	}
	let d = (e) => Ee(e, n, i) ? c - Number(e.getAttribute(D)) : l(e), f = u.length, p = f - 1;
	for (; p >= 0;) {
		let e = u.item(p);
		if (d(e) > 0) return e.nextSibling;
		p--;
	}
	return f > 0 ? u.item(0) : t ? t.nextSibling : null;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/safeInsertRule.js
var Oe = /*#__PURE__*/ RegExp(":(-moz-placeholder|-moz-focus-inner|-moz-focusring|-ms-input-placeholder|-moz-read-write|-moz-read-only)");
function G(e, t) {
	try {
		e.insertRule(t);
	} catch (e) {
		process.env.NODE_ENV !== "production" && !Oe.test(t) && console.error(`There was a problem inserting the following rule: "${t}"`, e);
	}
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/createDOMRenderer.js
var ke = 0, Ae = (e, t) => e < t ? -1 : +(e > t);
function je(e = typeof document > "u" ? void 0 : document, t = {}) {
	let { classNameHashSalt: n, unstable_filterCSSRule: r, insertionPoint: i, styleElementAttributes: a, compareMediaQueries: o = Ae, compareContainerQueries: s = o } = t, c = {
		classNameHashSalt: n,
		insertionCache: {},
		stylesheets: {},
		styleElementAttributes: Object.freeze(a),
		compareMediaQueries: o,
		compareContainerQueries: s,
		id: `d${ke++}`,
		insertCSSRules(t) {
			for (let n in t) {
				let a = t[n];
				for (let t = 0, o = a.length; t < o; t++) {
					let [o, s] = Se(a[t]), l = Te(n, e, i || null, c, s);
					c.insertionCache[o] || (c.insertionCache[o] = n, process.env.NODE_ENV !== "production" && H && z.addCSSRule(o), r ? r(o) && G(l, o) : G(l, o));
				}
			}
		}
	};
	return e && process.env.NODE_ENV !== "production" && H && le(e), c;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/insertionFactory.js
var Me = () => {
	let e = {};
	return function(t, n) {
		e[t.id] === void 0 && (t.insertCSSRules(n), e[t.id] = !0);
	};
};
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/__styles.js
function Ne(e, t, n = Me) {
	let r = n(), i = null, a = null, o;
	process.env.NODE_ENV !== "production" && H && (o = be());
	function s(n) {
		let { dir: s, renderer: c } = n, l = s === "ltr";
		l ? i === null && (i = P(e, s)) : a === null && (a = P(e, s)), r(c, t);
		let u = l ? i : a;
		return process.env.NODE_ENV !== "production" && H && z.addSequenceDetails(u, o), u;
	}
	return s;
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/utils/canUseDOM.js
function Pe() {
	return typeof window < "u" && !!(window.document && window.document.createElement);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/useInsertionEffect.js
var K = t.useInsertionEffect ? t.useInsertionEffect : void 0, Fe = () => {
	let e = {};
	return function(t, n) {
		K && Pe() ? K(() => {
			t.insertCSSRules(n);
		}, [t, n]) : e[t.id] === void 0 && (t.insertCSSRules(n), e[t.id] = !0);
	};
}, Ie = /*#__PURE__*/ n(/*#__PURE__*/ je());
function Le() {
	return i(Ie);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/TextDirectionContext.js
var Re = /*#__PURE__*/ n("ltr");
function ze() {
	return i(Re);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/__styles.js
function q(e, t) {
	let n = Ne(e, t, Fe);
	return function() {
		let e = ze(), t = Le();
		return n({
			dir: e,
			renderer: t
		});
	};
}
// node_modules/.pnpm/@fluentui+react-icons@2.0.333_react@19.2.7/node_modules/@fluentui/react-icons/lib/utils/useIconStyles.styles.js
var Be = q({
	root: {
		mc9l5x: "f1w7gpdv",
		Bg96gwp: "fez10in"
	},
	rtl: { Bz10aip: "f13rod7r" }
}, { d: [
	".f1w7gpdv{display:inline;}",
	".fez10in{line-height:0;}",
	".f13rod7r{transform:scaleX(-1);}"
] }), J = e.createContext(void 0), Ve = {};
J.Provider;
var He = () => e.useContext(J) ?? Ve, Ue = "fui-Icon", We = "data-fui-icon", Ge = (e, t) => {
	let { filled: n, idPrefix: r, title: i, primaryFill: a = "currentColor", ...o } = e, s = {
		...o,
		fill: a
	}, c = He(), l = !!(t?.flipInRtl && c?.textDirection === "rtl");
	return i && (s["aria-label"] = i), !s["aria-label"] && !s["aria-labelledby"] ? s["aria-hidden"] = !0 : s.role = "img", s[We] = "", {
		state: s,
		isRtlFlip: l
	};
}, Ke = (e, t) => {
	let n = Be(), { state: r, isRtlFlip: i } = Ge(e, t);
	return r.className = I(n.root, i && n.rtl, r.className), r;
}, qe = q({ root: { B8gzw0y: "f1dd5bof" } }, { m: [["@media (forced-colors: active){.f1dd5bof{forced-color-adjust:auto;}}", { m: "(forced-colors: active)" }]] }), Je = "url(#", Y = (t, n, r) => {
	let [i, a, ...o] = t, s = a;
	if (r && a) {
		let e = {};
		for (let t in a) {
			let n = a[t];
			if (typeof n != "string") e[t] = n;
			else if (t === "id") e[t] = r + n;
			else {
				let i = n.indexOf(Je);
				e[t] = i < 0 ? n : n.slice(0, i + 5) + r + n.slice(i + 5);
			}
		}
		s = e;
	}
	return e.createElement(i, {
		...s,
		key: n
	}, ...o.map((e, t) => Y(e, t, r)));
}, Ye = (e) => e === "1em" ? "20" : e, X = (e, t, n) => typeof e != "string" && (t?.color || Array.isArray(e[0])) ? e.map((e, t) => Y(e, t, n)) : void 0, Xe = () => void 0, Ze = (t, n) => {
	let r = X(t, n);
	return r ? function(i) {
		return e.useMemo(() => i ? X(t, n, i) : r, [i]);
	} : Xe;
}, Qe = (t, n, r) => typeof n == "string" ? e.createElement("svg", {
	...t,
	dangerouslySetInnerHTML: { __html: n }
}) : r ? e.createElement("svg", t, ...r) : e.createElement("svg", t, ...n.map((n) => e.createElement("path", {
	d: n,
	fill: t.fill
}))), Z = (t, n, r, i) => {
	let a = Ye(n), o = Ze(r, i), s = e.forwardRef((e, t) => {
		let s = qe(), c = Ke(e, { flipInRtl: i?.flipInRtl }), l = o(e.idPrefix);
		return Qe({
			...c,
			className: I(Ue, c.className, s.root),
			ref: t,
			width: n,
			height: n,
			viewBox: `0 0 ${a} ${a}`,
			xmlns: "http://www.w3.org/2000/svg"
		}, r, l);
	});
	return s.displayName = t, s;
}, $e = /*#__PURE__*/ Z("Search16Regular", "16", ["M11.02 11.73a5.5 5.5 0 1 1 .7-.7l3.13 3.12a.5.5 0 0 1-.7.7l-3.13-3.12ZM12 7.5a4.5 4.5 0 1 0-9 0 4.5 4.5 0 0 0 9 0Z"]), et = /*#__PURE__*/ Z("Search24Regular", "24", ["M16.1 17.16a8 8 0 1 1 1.06-1.06l4.62 4.62a.75.75 0 1 1-1.06 1.06l-4.62-4.62ZM17.5 11a6.5 6.5 0 1 0-13 0 6.5 6.5 0 0 0 13 0Z"]), tt = /*#__PURE__*/ Z("DocumentDismiss24Regular", "24", ["M6.5 12a5.5 5.5 0 1 1 0 11 5.5 5.5 0 0 1 0-11Zm5.63-10c.6 0 1.17.24 1.59.66l2.81 2.8 2.8 2.82c.43.42.67 1 .67 1.6v9.87c0 1.24-1.01 2.25-2.25 2.25h-6.56c.43-.44.79-.95 1.08-1.5h5.48c.41 0 .75-.34.75-.75V10h-4.25c-1.2 0-2.17-.92-2.25-2.1V3.5H6.25a.75.75 0 0 0-.75.75v6.83c-.52.08-1.03.22-1.5.42V4.25C4 3.01 5 2 6.25 2h5.88ZM8.85 15.15a.5.5 0 0 0-.7 0L6.5 16.79l-1.65-1.64a.5.5 0 1 0-.7.7l1.64 1.65-1.64 1.65a.5.5 0 1 0 .7.7l1.65-1.64 1.65 1.64a.5.5 0 1 0 .7-.7L7.21 17.5l1.64-1.65a.5.5 0 0 0 0-.7Zm4.65-7.4c0 .38.28.7.65.75H17.45L13.5 4.56v3.2Z"]), nt = /*#__PURE__*/ Z("Eye24Regular", "24", ["M12 9a4 4 0 1 1 0 8 4 4 0 0 1 0-8Zm0 1.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5Zm0-5a10 10 0 0 1 9.7 7.56.75.75 0 1 1-1.45.37 8.5 8.5 0 0 0-16.5 0 .75.75 0 0 1-1.45-.36A10 10 0 0 1 12 5.5Z"]), rt = /*#__PURE__*/ Z("CheckmarkCircle24Regular", "24", ["M12 2a10 10 0 1 1 0 20 10 10 0 0 1 0-20Zm0 1.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17Zm-1.25 9.94 4.47-4.47a.75.75 0 0 1 1.13.98l-.07.08-5 5a.75.75 0 0 1-.98.07l-.08-.07-2.5-2.5a.75.75 0 0 1 .98-1.13l.08.07 1.97 1.97 4.47-4.47-4.47 4.47Z"]), it = /*#__PURE__*/ Z("Timer24Regular", "24", ["M12 5a8.5 8.5 0 1 1 0 17 8.5 8.5 0 0 1 0-17Zm0 1.5a7 7 0 1 0 0 14 7 7 0 0 0 0-14ZM12 8c.38 0 .7.28.74.65l.01.1v4.5a.75.75 0 0 1-1.5.1v-4.6c0-.41.34-.75.75-.75Zm7.15-2.89.08.06 1.16.97a.75.75 0 0 1-.88 1.21l-.08-.06-1.16-.96a.75.75 0 0 1 .88-1.22Zm-4.9-2.61a.75.75 0 0 1 .1 1.5h-4.6a.75.75 0 0 1-.1-1.5h4.6Z"]), at = /*#__PURE__*/ Z("ErrorCircle24Regular", "24", ["M12 2a10 10 0 1 1 0 20 10 10 0 0 1 0-20Zm0 1.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17Zm0 11a1 1 0 1 1 0 2 1 1 0 0 1 0-2ZM12 7c.37 0 .69.28.74.65v4.6a.75.75 0 0 1-1.48.1l-.01-.1v-4.5c0-.41.33-.75.74-.75Z"]), ot = /*#__PURE__*/ Z("Dismiss24Regular", "24", ["m4.4 4.55.07-.08a.75.75 0 0 1 .98-.07l.08.07L12 10.94l6.47-6.47a.75.75 0 1 1 1.06 1.06L13.06 12l6.47 6.47c.27.27.3.68.07.98l-.07.08a.75.75 0 0 1-.98.07l-.08-.07L12 13.06l-6.47 6.47a.75.75 0 0 1-1.06-1.06L10.94 12 4.47 5.53a.75.75 0 0 1-.07-.98l.07-.08-.07.08Z"]), st = /*#__PURE__*/ Z("QuestionCircle24Regular", "24", ["M12 2a10 10 0 1 1 0 20 10 10 0 0 1 0-20Zm0 1.67a8.34 8.34 0 0 0 0 16.66 8.34 8.34 0 0 0 0-16.66Zm0 11.83a1 1 0 1 1 0 2 1 1 0 0 1 0-2Zm0-8.75a2.75 2.75 0 0 1 2.75 2.75c0 1.01-.3 1.57-1.05 2.36l-.17.17c-.62.62-.78.89-.78 1.47a.75.75 0 0 1-1.5 0c0-1.01.3-1.57 1.05-2.36l.17-.17c.62-.62.78-.89.78-1.47a1.25 1.25 0 0 0-2.5-.13v.13a.75.75 0 0 1-1.5 0A2.75 2.75 0 0 1 12 6.75Z"]);
// src/client.ts
function ct(e) {
	if (!Array.isArray(e) || e.length > 1e3) throw Error("Invalid LRCLIB results");
	return e.map((e) => {
		if (!e || typeof e != "object") throw Error("Invalid LRCLIB track");
		let t = e.name ?? e.trackName;
		if (!Number.isSafeInteger(e.id) || e.id < 0 || typeof t != "string" || typeof e.artistName != "string" || typeof e.albumName != "string" || !Number.isFinite(e.duration) || e.duration < 0 || typeof e.instrumental != "boolean" || ![e.plainLyrics, e.syncedLyrics].every((e) => e === null || typeof e == "string")) throw Error("Invalid LRCLIB track");
		return {
			id: e.id,
			name: t,
			artistName: e.artistName,
			albumName: e.albumName,
			duration: e.duration,
			instrumental: e.instrumental,
			plainLyrics: e.plainLyrics,
			syncedLyrics: e.syncedLyrics
		};
	});
}
async function lt(e, t) {
	if (!t.trim()) return [];
	let n = await e.network.request({ url: `https://lrclib.net/api/search?q=${encodeURIComponent(t.trim())}` });
	if (!n.ok) throw Error(n.error.code);
	if (!n.value.ok) throw Error(`LRCLIB HTTP ${n.value.status}`);
	return ct(JSON.parse(n.value.body));
}
// src/model.ts
var Q = () => ({
	text: "",
	startTime: 0,
	endTime: 0,
	emptyBeat: 0,
	romanText: ""
}), ut = () => ({
	words: [],
	translation: "",
	romanization: "",
	isBackground: !1,
	isDuet: !1,
	startTime: 0,
	endTime: 0,
	ignoreSync: !1
});
// src/parse-lrc.ts
function dt(e) {
	let t = e.split(/\r?\n/), n = [], r = /\[(\d{1,2}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g, i = 0;
	for (let e of t) {
		let t = e.replace(r, "").trim();
		for (let a of e.matchAll(r)) {
			let e = Number.parseInt(a[1], 10), r = Number.parseInt(a[2], 10), o = Number.parseFloat(a[3] ? `0.${a[3]}` : "0");
			n.push({
				time: Math.round((e * 60 + r + o) * 1e3),
				text: t,
				index: i++
			});
		}
	}
	n.sort((e, t) => e.time - t.time || e.index - t.index);
	let a = [], o = 0;
	for (; o < n.length;) {
		let e = n[o].time, t = [];
		for (; o < n.length && n[o].time === e;) t.push(n[o++]);
		let r = t.filter((e) => e.text.length > 0);
		if (r.length === 0) continue;
		let i = n[o]?.time ?? e + 1e4, s = (t) => {
			let n = ut(), r = Q();
			return r.text = t, r.startTime = e, r.endTime = i, n.words = [r], n.startTime = e, n.endTime = i, n;
		}, c = s(r[0].text);
		c.translation = r[1]?.text ?? "", c.romanization = r[2]?.text ?? "", a.push(c);
		for (let e of r.slice(3)) a.push(s(e.text));
	}
	return a;
}
// src/background.ts
var ft = (e) => e ? e.charAt(0).toUpperCase() + e.slice(1) : "";
function pt(e) {
	let t = e.words.map((e) => e.text).join(""), n = /([(（])(.*?)([)）])/g, r = Array.from(t.matchAll(n));
	if (r.length === 0) return [e];
	let i = ft(t.replace(n, "").replace(/\s+/g, " ").trim()), a = ft(r.map((e) => e[2].trim()).join(" "));
	if (!i) return [{
		...e,
		isBackground: !0,
		words: [{
			...e.words[0],
			text: a
		}]
	}];
	let o = e.endTime - e.startTime, s = i.length, c = s + a.length;
	if (c === 0) return [e];
	let l = Math.floor(s / c * o);
	return [{
		...e,
		words: [{
			...Q(),
			text: i,
			startTime: e.startTime,
			endTime: e.startTime + l
		}],
		endTime: e.startTime + l
	}, {
		...e,
		isBackground: !0,
		words: [{
			...Q(),
			text: a,
			startTime: e.startTime + l,
			endTime: e.endTime
		}],
		startTime: e.startTime + l
	}];
}
// src/import.ts
function mt(e) {
	return {
		lines: e.syncedLyrics ? dt(e.syncedLyrics) : (e.plainLyrics ?? "").split(/\r?\n/).map((e) => e.trim()).filter(Boolean).map((e) => ({
			...ut(),
			words: [{
				...Q(),
				text: e
			}]
		})),
		metadata: [
			{
				key: "musicName",
				values: [e.name]
			},
			{
				key: "artists",
				values: [e.artistName]
			},
			{
				key: "album",
				values: [e.albumName]
			}
		].filter((e) => e.values[0])
	};
}
async function ht(e, t, n, r) {
	if (r.aborted) return !1;
	let i = e.document.revision, a = e.project.getInfo().projectId, o = mt(t);
	if (!o.lines.length) throw Error("No lyrics to import");
	if (n.extractBackground && (o.lines = o.lines.flatMap(pt)), n.autoSegment) for (let t of o.lines) {
		if (r.aborted) return !1;
		let n = [];
		for (let r of t.words) {
			let t = await e.segmentation.segmentText({
				text: r.text,
				startTime: r.startTime,
				endTime: r.endTime
			});
			n.push(...t.map((e) => ({
				...Q(),
				...e
			})));
		}
		t.words = n;
	}
	if (r.aborted) return !1;
	if (e.document.revision !== i || e.project.getInfo().projectId !== a) throw Error(e.i18n.t("changed"));
	let s = await e.project.importDocument(o, "Import lyrics from LRCLIB");
	if (!s.ok && s.error.code !== "cancelled") throw Error(s.error.code);
	return s.ok;
}
// src/styles.ts
var gt = ".lrclib-dialogContent {\n	max-width: 800px;\n	height: 600px;\n	display: flex;\n	flex-direction: column;\n}\n\n.lrclib-searchBar {\n	flex: 1;\n}\n\n.lrclib-scrollArea {\n	flex: 1;\n	padding-right: 24px;\n}\n\n.lrclib-resultList {\n	padding: var(--space-1);\n}\n\n.lrclib-resultCard {\n	cursor: pointer;\n	transition:\n		background-color 0.15s ease,\n		transform 0.1s ease,\n		border-color 0.15s ease,\n		box-shadow 0.15s ease;\n	border: 1px solid var(--gray-alpha-4);\n}\n\n.lrclib-resultCard:hover {\n	background-color: var(--gray-3);\n	transform: translateY(-2px);\n	border-color: var(--gray-8);\n	box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);\n}\n\n.lrclib-resultCard:active {\n	transform: translateY(0);\n	background-color: var(--gray-4);\n	box-shadow: none;\n}\n\n.lrclib-skeletonTitleBox {\n	width: 50%;\n}\n\n.lrclib-skeletonArtistBox {\n	width: 35%;\n}\n\n.lrclib-smallIcon {\n	width: 14px;\n	height: 14px;\n}\n\n.lrclib-badgeIcon {\n	width: 12px;\n	height: 12px;\n	margin-right: 4px;\n}\n\n.lrclib-emptyState {\n	height: 200px;\n	color: var(--gray-8);\n	display: flex;\n	justify-content: center;\n	align-items: center;\n	flex-direction: column;\n}\n\n.lrclib-emptyStateIcon {\n	width: 48px;\n	height: 48px;\n	margin-bottom: var(--space-3);\n	opacity: 0.5;\n}\n\n.lrclib-previewEmptyState {\n	height: 400px;\n	display: flex;\n	flex-direction: column;\n	align-items: center;\n	justify-content: center;\n	color: var(--gray-8);\n}\n\n.lrclib-previewDialogContent {\n	max-width: 600px;\n}\n\n.lrclib-previewContainer {\n	background-color: var(--gray-2);\n	border-radius: var(--radius-3);\n	padding: var(--space-2);\n}\n\n.lrclib-previewTextArea {\n	height: 400px;\n	font-family: var(--code-font-family);\n	white-space: pre-wrap;\n}\n\n.rt-DialogContent:has(> [data-amll-plugin-scope=\"builtin.lrclib\"]) {max-width:800px;}\n", $ = {
	badgeIcon: "lrclib-badgeIcon",
	scrollArea: "lrclib-scrollArea",
	resultList: "lrclib-resultList",
	skeletonTitleBox: "lrclib-skeletonTitleBox",
	smallIcon: "lrclib-smallIcon",
	previewContainer: "lrclib-previewContainer",
	emptyState: "lrclib-emptyState",
	previewDialogContent: "lrclib-previewDialogContent",
	dialogContent: "lrclib-dialogContent",
	emptyStateIcon: "lrclib-emptyStateIcon",
	previewTextArea: "lrclib-previewTextArea",
	previewEmptyState: "lrclib-previewEmptyState",
	resultCard: "lrclib-resultCard",
	skeletonArtistBox: "lrclib-skeletonArtistBox",
	searchBar: "lrclib-searchBar"
}, _t = (e) => `${Math.floor(e / 60)}:${Math.floor(e % 60).toString().padStart(2, "0")}`, vt = ({ host: e, signal: t }) => {
	let n = (t, n) => e.i18n.t(t), r = o(!1), i = o(!1), [b, x] = s(!1);
	a(() => (r.current = !0, () => {
		r.current = !1;
	}), []);
	let S = () => r.current && !t.aborted, [C, w] = s(""), [T, E] = s([]), [D, O] = s(!1), [k, A] = s(!1), [j, M] = s(null), [N, P] = s(!1), [F, I] = s(!1), L = async () => {
		if (C.trim() && !i.current) {
			i.current = !0, O(!0), A(!0), E([]);
			try {
				let t = await lt(e, C);
				S() && E(t);
			} catch {
				S() && e.ui.notify({
					level: "error",
					message: n("lrclib.searchError")
				});
			} finally {
				i.current = !1, S() && O(!1);
			}
		}
	}, R = (e) => {
		e.key === "Enter" && !e.nativeEvent.isComposing && L();
	}, z = async (r) => {
		if (!i.current) {
			i.current = !0, x(!0);
			try {
				await ht(e, r, {
					extractBackground: F,
					autoSegment: N
				}, t) && S() && e.ui.closeView("builtin.lrclib.dialog");
			} catch {
				S() && e.ui.notify({
					level: "error",
					message: n("lrclib.importError")
				});
			} finally {
				i.current = !1, S() && x(!1);
			}
		}
	};
	return /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ l("style", { children: gt }),
		/* @__PURE__ */ u("div", {
			className: $.dialogContent,
			children: [
				/* @__PURE__ */ u(g, {
					gap: "3",
					mb: "4",
					children: [/* @__PURE__ */ l(ae.Root, {
						className: $.searchBar,
						placeholder: n("lrclib.placeholder", "歌名 歌手..."),
						value: C,
						onChange: (e) => w(e.target.value),
						onKeyDown: R,
						children: /* @__PURE__ */ l(ae.Slot, { children: /* @__PURE__ */ l($e, {}) })
					}), /* @__PURE__ */ l(p, {
						onClick: L,
						disabled: D,
						children: D ? /* @__PURE__ */ l(re, {}) : n("common.search", "搜索")
					})]
				}),
				/* @__PURE__ */ l(te, {
					type: "auto",
					scrollbars: "vertical",
					className: $.scrollArea,
					children: /* @__PURE__ */ u(g, {
						direction: "column",
						gap: "2",
						className: $.resultList,
						children: [D ? Array.from({ length: 5 }).map((e, t) => /* @__PURE__ */ l(ee, { children: /* @__PURE__ */ u(g, {
							justify: "between",
							align: "center",
							gap: "4",
							children: [/* @__PURE__ */ u(g, {
								direction: "column",
								gap: "1",
								style: { flex: 1 },
								children: [
									/* @__PURE__ */ l(f, {
										className: $.skeletonTitleBox,
										children: /* @__PURE__ */ l(v, {
											loading: !0,
											children: /* @__PURE__ */ l(y, {
												size: "3",
												weight: "bold",
												children: "Song Title"
											})
										})
									}),
									/* @__PURE__ */ u(g, {
										align: "center",
										gap: "2",
										children: [/* @__PURE__ */ l(v, {
											loading: !0,
											children: /* @__PURE__ */ u(g, {
												align: "center",
												gap: "1",
												children: [/* @__PURE__ */ l(it, { className: $.smallIcon }), /* @__PURE__ */ l(y, {
													size: "1",
													children: "04:00"
												})]
											})
										}), /* @__PURE__ */ l(v, {
											loading: !0,
											children: /* @__PURE__ */ l(d, {
												size: "1",
												children: "Synced Lyric"
											})
										})]
									}),
									/* @__PURE__ */ l(f, {
										className: $.skeletonArtistBox,
										children: /* @__PURE__ */ l(v, {
											loading: !0,
											children: /* @__PURE__ */ l(y, {
												size: "1",
												children: "Album"
											})
										})
									})
								]
							}), /* @__PURE__ */ l(f, {
								pr: "2",
								children: /* @__PURE__ */ l(v, {
									loading: !0,
									children: /* @__PURE__ */ l(_, {
										variant: "ghost",
										children: /* @__PURE__ */ l(nt, {})
									})
								})
							})]
						}) }, t)) : T.map((e) => /* @__PURE__ */ l(ee, {
							className: $.resultCard,
							onClick: () => M(e),
							role: "button",
							tabIndex: 0,
							onKeyDown: (t) => {
								(t.key === "Enter" || t.key === " ") && (t.preventDefault(), M(e));
							},
							children: /* @__PURE__ */ l(g, {
								justify: "between",
								align: "center",
								gap: "4",
								children: /* @__PURE__ */ u(g, {
									direction: "column",
									gap: "1",
									style: {
										flex: 1,
										minWidth: 0
									},
									children: [
										/* @__PURE__ */ l(y, {
											size: "3",
											weight: "bold",
											truncate: !0,
											children: e.name
										}),
										/* @__PURE__ */ u(g, {
											align: "center",
											gap: "2",
											children: [/* @__PURE__ */ u(g, {
												align: "center",
												gap: "1",
												children: [/* @__PURE__ */ l(it, { className: $.smallIcon }), /* @__PURE__ */ l(y, {
													size: "1",
													color: "gray",
													children: _t(e.duration)
												})]
											}), e.syncedLyrics ? /* @__PURE__ */ u(d, {
												color: "green",
												size: "1",
												children: [/* @__PURE__ */ l(rt, { className: $.badgeIcon }), n("lrclib.synced", "有时间轴")]
											}) : /* @__PURE__ */ u(d, {
												color: "gray",
												size: "1",
												children: [/* @__PURE__ */ l(at, { className: $.badgeIcon }), n("lrclib.unsynced", "无时间轴")]
											})]
										}),
										/* @__PURE__ */ u(y, {
											size: "1",
											color: "gray",
											truncate: !0,
											children: [
												e.artistName,
												" - ",
												e.albumName
											]
										})
									]
								})
							})
						}, e.id)), !D && T.length === 0 && /* @__PURE__ */ l(g, {
							className: $.emptyState,
							children: k ? /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l(st, { className: $.emptyStateIcon }), /* @__PURE__ */ l(y, { children: n("lrclib.notFound", "未找到相关结果，请尝试更换关键词") })] }) : /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l(et, { className: $.emptyStateIcon }), /* @__PURE__ */ l(y, { children: n("lrclib.noResult", "输入关键词开始搜索") })] })
						})]
					})
				}),
				/* @__PURE__ */ l(g, {
					justify: "end",
					mt: "4",
					children: /* @__PURE__ */ l(p, {
						variant: "soft",
						color: "gray",
						onClick: () => e.ui.closeView("builtin.lrclib.dialog"),
						children: n("common.close", "关闭")
					})
				})
			]
		}),
		/* @__PURE__ */ l(h.Root, {
			open: !!j,
			onOpenChange: (e) => !e && M(null),
			children: /* @__PURE__ */ u(h.Content, {
				className: $.previewDialogContent,
				"data-amll-modal-size": "large",
				children: [
					/* @__PURE__ */ u(g, {
						justify: "between",
						align: "center",
						mb: "2",
						children: [/* @__PURE__ */ l(h.Title, {
							style: { marginBottom: 0 },
							children: j?.name
						}), /* @__PURE__ */ l(h.Close, { children: /* @__PURE__ */ l(_, {
							variant: "ghost",
							color: "gray",
							"aria-label": n("common.close"),
							children: /* @__PURE__ */ l(ot, {})
						}) })]
					}),
					/* @__PURE__ */ u(h.Description, {
						size: "2",
						mb: "4",
						color: "gray",
						children: [
							j?.artistName,
							" - ",
							j?.albumName
						]
					}),
					/* @__PURE__ */ l(ne, {
						size: "4",
						mb: "4"
					}),
					/* @__PURE__ */ l(f, {
						className: $.previewContainer,
						children: j?.syncedLyrics || j?.plainLyrics ? /* @__PURE__ */ l(ie, {
							variant: "soft",
							className: $.previewTextArea,
							value: j.syncedLyrics || j.plainLyrics || "",
							readOnly: !0
						}) : /* @__PURE__ */ u(g, {
							className: $.previewEmptyState,
							children: [/* @__PURE__ */ l(tt, { className: $.emptyStateIcon }), /* @__PURE__ */ l(y, { children: n("lrclib.noLyrics", "该歌曲暂无歌词内容") })]
						})
					}),
					/* @__PURE__ */ u(g, {
						justify: "end",
						gap: "3",
						mt: "4",
						align: "center",
						children: [
							/* @__PURE__ */ l(y, {
								as: "label",
								size: "2",
								children: /* @__PURE__ */ u(g, {
									gap: "2",
									align: "center",
									children: [/* @__PURE__ */ l(m, {
										checked: F,
										onCheckedChange: (e) => I(!!e)
									}), n("lrclib.extractBg", "提取括号内容为背景人声")]
								})
							}),
							/* @__PURE__ */ l(y, {
								as: "label",
								size: "2",
								children: /* @__PURE__ */ u(g, {
									gap: "2",
									align: "center",
									children: [/* @__PURE__ */ l(m, {
										checked: N,
										onCheckedChange: (e) => P(!!e)
									}), n("lrclib.autoSegment", "自动分词")]
								})
							}),
							/* @__PURE__ */ l(h.Close, { children: /* @__PURE__ */ l(p, {
								variant: "soft",
								color: "gray",
								children: n("common.cancel", "取消")
							}) }),
							/* @__PURE__ */ l(p, {
								disabled: b || !(j?.syncedLyrics || j?.plainLyrics),
								onClick: () => j && z(j),
								children: n("lrclib.import", "导入歌词")
							})
						]
					})
				]
			})
		})
	] });
};
// src/plugin.ts
function yt({ host: e, signal: t }) {
	e.views.registerView({
		id: "builtin.lrclib.dialog",
		kind: "dialog-view",
		title: b["lrclib.title"],
		size: "full",
		view: () => r(vt, {
			host: e,
			signal: t
		})
	}), e.commands.register({
		id: "builtin.lrclib.run",
		title: b["command.title"],
		handler: () => e.ui.openView("builtin.lrclib.dialog")
	}), e.menus.register({
		id: "builtin.lrclib.menu.file",
		command: "builtin.lrclib.run",
		menu: "menu.file",
		group: "import",
		order: 110
	});
}
export { yt as activate };
