// strings/strings.json
var e = {
	"command.title": {
		default: "Sync Line Timestamps",
		"cs-CZ": "Synchronizovat časové značky řádků",
		"da-DK": "Synkroniser linjetidsstempler",
		"es-ES": "Sincronizar marcas de tiempo de líneas",
		"fr-FR": "Synchroniser les horodatages des lignes",
		"id-ID": "Sinkronkan Penanda Waktu Baris",
		"pl-PL": "Synchronizuj znaczniki czasu wierszy",
		"pt-BR": "Sincronizar marcas de tempo das linhas",
		"ru-RU": "Синхронизировать временные метки строк",
		"sk-SK": "Synchronizovať časové značky riadkov",
		"zh-CN": "同步行时间戳"
	},
	"confirm.title": {
		default: "Confirm Sync Line Timestamps",
		"cs-CZ": "Potvrdit synchronizaci časových značek",
		"da-DK": "Bekræft synkronisering af tidsstempler",
		"es-ES": "Confirmar sincronización de marcas de tiempo",
		"fr-FR": "Confirmer la synchronisation des horodatages",
		"id-ID": "Konfirmasi sinkronisasi penanda waktu baris",
		"pl-PL": "Potwierdź synchronizację znaczników czasu",
		"pt-BR": "Confirmar sincronização de marcas de tempo",
		"ru-RU": "Подтвердить синхронизацию временных меток строк",
		"sk-SK": "Potvrdiť synchronizáciu časových značiek",
		"zh-CN": "确认同步行时间戳"
	},
	"confirm.description": {
		default: "This action will automatically synchronize the start and end times of all lines based on the timestamps of each word in the line, matching the start and end times of the first and last syllables. Are you sure you want to proceed?",
		"cs-CZ": "Tato akce automaticky synchronizuje časy začátku a konce všech řádků na základě časových značek každého slova v řádku, odpovídající časům začátku a konce první a poslední slabiky. Opravdu chcete pokračovat?",
		"da-DK": "Denne handling vil automatisk synkronisere start- og sluttiderne for alle linjer baseret på tidsstemplerne for hvert ord i linjen, matchende start- og sluttiderne for første og sidste stavelse. Er du sikker på, at du vil fortsætte?",
		"es-ES": "Esta acción sincronizará automáticamente los tiempos de inicio y fin de todas las líneas según las marcas de tiempo de cada palabra en la línea, coincidiendo con los tiempos de inicio y fin de la primera y última sílaba. ¿Estás seguro de que deseas continuar?",
		"fr-FR": "Cette action synchronisera automatiquement les temps de début et de fin de toutes les lignes en fonction des horodatages de chaque mot dans la ligne, correspondant aux temps de début et de fin des première et dernière syllabes. Êtes-vous sûr de vouloir continuer ?",
		"id-ID": "Tindakan ini akan secara otomatis menyinkronkan waktu awal dan akhir semua baris berdasarkan penanda waktu kata pertama dan terakhir dalam setiap baris. Lanjutkan?",
		"pl-PL": "Ta akcja automatycznie zsynchronizuje czasy początkowe i końcowe wszystkich wierszy na podstawie znaczników czasu każdego słowa w wierszu, dopasowując czasy początkowe i końcowe pierwszej i ostatniej sylaby. Czy na pewno chcesz kontynuować?",
		"pt-BR": "Esta ação sincronizará automaticamente os tempos de início e fim de todas as linhas com base nas marcas de tempo de cada palavra na linha, correspondendo aos tempos de início e fim das primeira e última sílabas. Tem certeza de que deseja continuar?",
		"ru-RU": "Это действие автоматически синхронизирует время начала и окончания всех строк на основе временных меток каждого слова в строке, совмещая время начала и окончания первого и последнего слогов. Вы уверены, что хотите продолжить?",
		"sk-SK": "Táto akcia automaticky synchronizuje časy začiatku a konca všetkých riadkov na základe časových značiek každého slova v riadku, zodpovedajúce časom začiatku a konca prvej a poslednej slabiky. Naozaj chcete pokračovať?",
		"zh-CN": "此操作将根据每行单词的时间戳自动同步所有行的起始和结束时间为第一个和最后一个音节的开始和结束时间。确定要继续吗？"
	},
	"confirm.submit": {
		default: "Confirm",
		"cs-CZ": "Potvrdit",
		"da-DK": "Bekræft",
		"es-ES": "Confirmar",
		"fr-FR": "Confirmer",
		"id-ID": "Konfirmasi",
		"pl-PL": "Potwierdź",
		"pt-BR": "Confirmar",
		"ru-RU": "Подтвердить",
		"sk-SK": "Potvrdiť",
		"zh-CN": "确定"
	},
	"confirm.cancel": {
		default: "Cancel",
		"cs-CZ": "Zrušit",
		"da-DK": "Annuller",
		"es-ES": "Cancelar",
		"fr-FR": "Annuler",
		"id-ID": "Batal",
		"pl-PL": "Anuluj",
		"pt-BR": "Cancelar",
		"ru-RU": "Отмена",
		"sk-SK": "Zrušiť",
		"zh-CN": "取消"
	},
	"error.failed": {
		default: "Line timestamps were not synced",
		"zh-CN": "未能同步行时间戳"
	}
}, t = "builtin.sync-line-timestamps", n = `${t}.run`, r = (e) => {
	let t = [];
	return e.lines.forEach((n, r) => {
		if (n.words.length === 0) return;
		let i = n.words[0].startTime, a = n.words[n.words.length - 1].endTime, o = e.lines[r + 1];
		o?.isBackground && o.words.length > 0 && (i = Math.min(i, o.words[0].startTime), a = Math.max(a, o.words[o.words.length - 1].endTime)), (i !== n.startTime || a !== n.endTime) && t.push({
			op: "updateLine",
			lineId: n.id,
			patch: {
				startTime: i,
				endTime: a
			}
		});
	}), t;
}, i = (e) => ({
	title: e("confirm.title"),
	size: "small",
	fields: [{
		kind: "note",
		text: e("confirm.description")
	}],
	submitLabel: e("confirm.submit"),
	cancelLabel: e("confirm.cancel")
}), a = (a) => {
	a.commands.register({
		id: n,
		title: e["command.title"],
		handler: async () => {
			if (!(await a.ui.showForm(i(a.i18n.t))).submitted) return;
			let e = a.document.readSnapshot(), t = r(e);
			if (t.length === 0) return;
			let n = a.document.applyEdit(t, "Sync line timestamps", { expectedRevision: e.revision });
			n.ok || a.ui.notify({
				level: "error",
				message: a.i18n.t("error.failed"),
				detail: n.error.message
			});
		}
	}), a.menus.register({
		id: `${t}.menu.tool`,
		command: n,
		menu: "menu.tool",
		group: "timing",
		order: 100
	});
};
// src/plugin.ts
function o({ host: e }) {
	a(e);
}
export { o as activate };
