function e(e) {
	let t = e.length;
	for (; --t >= 0;) e[t] = 0;
}
var t = 29, n = 30, r = new Uint8Array([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0
]), i = new Uint8Array([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13
]), a = new Uint8Array([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2,
	3,
	7
]), o = new Uint8Array([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]), s = 512, c = Array(576);
e(c);
var l = Array(60);
e(l);
var u = Array(s);
e(u);
var d = Array(256);
e(d);
var f = Array(t);
e(f);
var p = Array(n);
e(p);
function m(e, t, n, r, i) {
	this.static_tree = e, this.extra_bits = t, this.extra_base = n, this.elems = r, this.max_length = i, this.has_stree = e && e.length;
}
var h, g, _;
function v(e, t) {
	this.dyn_tree = e, this.max_code = 0, this.stat_desc = t;
}
var y = (e) => e < 256 ? u[e] : u[256 + (e >>> 7)], b = (e, t) => {
	e.pending_buf[e.pending++] = t & 255, e.pending_buf[e.pending++] = t >>> 8 & 255;
}, x = (e, t, n) => {
	e.bi_valid > 16 - n ? (e.bi_buf |= t << e.bi_valid & 65535, b(e, e.bi_buf), e.bi_buf = t >> 16 - e.bi_valid, e.bi_valid += n - 16) : (e.bi_buf |= t << e.bi_valid & 65535, e.bi_valid += n);
}, S = (e, t, n) => {
	x(e, n[t * 2], n[t * 2 + 1]);
}, C = (e, t) => {
	let n = 0;
	do
		n |= e & 1, e >>>= 1, n <<= 1;
	while (--t > 0);
	return n >>> 1;
}, w = (e) => {
	e.bi_valid === 16 ? (b(e, e.bi_buf), e.bi_buf = 0, e.bi_valid = 0) : e.bi_valid >= 8 && (e.pending_buf[e.pending++] = e.bi_buf & 255, e.bi_buf >>= 8, e.bi_valid -= 8);
}, T = (e, t) => {
	let n = t.dyn_tree, r = t.max_code, i = t.stat_desc.static_tree, a = t.stat_desc.has_stree, o = t.stat_desc.extra_bits, s = t.stat_desc.extra_base, c = t.stat_desc.max_length, l, u, d, f, p, m, h = 0;
	for (f = 0; f <= 15; f++) e.bl_count[f] = 0;
	for (n[e.heap[e.heap_max] * 2 + 1] = 0, l = e.heap_max + 1; l < 573; l++) u = e.heap[l], f = n[n[u * 2 + 1] * 2 + 1] + 1, f > c && (f = c, h++), n[u * 2 + 1] = f, !(u > r) && (e.bl_count[f]++, p = 0, u >= s && (p = o[u - s]), m = n[u * 2], e.opt_len += m * (f + p), a && (e.static_len += m * (i[u * 2 + 1] + p)));
	if (h !== 0) {
		do {
			for (f = c - 1; e.bl_count[f] === 0;) f--;
			e.bl_count[f]--, e.bl_count[f + 1] += 2, e.bl_count[c]--, h -= 2;
		} while (h > 0);
		for (f = c; f !== 0; f--) for (u = e.bl_count[f]; u !== 0;) d = e.heap[--l], !(d > r) && (n[d * 2 + 1] !== f && (e.opt_len += (f - n[d * 2 + 1]) * n[d * 2], n[d * 2 + 1] = f), u--);
	}
}, E = (e, t, n) => {
	let r = Array(16), i = 0, a, o;
	for (a = 1; a <= 15; a++) i = i + n[a - 1] << 1, r[a] = i;
	for (o = 0; o <= t; o++) {
		let t = e[o * 2 + 1];
		t !== 0 && (e[o * 2] = C(r[t]++, t));
	}
}, D = () => {
	let e, t, o, s, v, y = Array(16);
	for (o = 0, s = 0; s < 28; s++) for (f[s] = o, e = 0; e < 1 << r[s]; e++) d[o++] = s;
	for (d[o - 1] = s, v = 0, s = 0; s < 16; s++) for (p[s] = v, e = 0; e < 1 << i[s]; e++) u[v++] = s;
	for (v >>= 7; s < n; s++) for (p[s] = v << 7, e = 0; e < 1 << i[s] - 7; e++) u[256 + v++] = s;
	for (t = 0; t <= 15; t++) y[t] = 0;
	for (e = 0; e <= 143;) c[e * 2 + 1] = 8, e++, y[8]++;
	for (; e <= 255;) c[e * 2 + 1] = 9, e++, y[9]++;
	for (; e <= 279;) c[e * 2 + 1] = 7, e++, y[7]++;
	for (; e <= 287;) c[e * 2 + 1] = 8, e++, y[8]++;
	for (E(c, 287, y), e = 0; e < n; e++) l[e * 2 + 1] = 5, l[e * 2] = C(e, 5);
	h = new m(c, r, 257, 286, 15), g = new m(l, i, 0, n, 15), _ = new m([], a, 0, 19, 7);
}, O = (e) => {
	let t = 0;
	for (; t < 286; t++) e.dyn_ltree[t * 2] = 0;
	for (t = 0; t < n; t++) e.dyn_dtree[t * 2] = 0;
	for (t = 0; t < 19; t++) e.bl_tree[t * 2] = 0;
	e.dyn_ltree[512] = 1, e.opt_len = e.static_len = 0, e.sym_next = e.matches = 0;
}, ee = (e) => {
	e.bi_valid > 8 ? b(e, e.bi_buf) : e.bi_valid > 0 && (e.pending_buf[e.pending++] = e.bi_buf), e.bi_buf = 0, e.bi_valid = 0;
}, te = (e, t, n, r) => {
	let i = t * 2, a = n * 2;
	return e[i] < e[a] || e[i] === e[a] && r[t] <= r[n];
}, k = (e, t, n) => {
	let r = e.heap[n], i = n << 1;
	for (; i <= e.heap_len && (i < e.heap_len && te(t, e.heap[i + 1], e.heap[i], e.depth) && i++, !te(t, r, e.heap[i], e.depth));) e.heap[n] = e.heap[i], n = i, i <<= 1;
	e.heap[n] = r;
}, ne = (e, t, n) => {
	let a, o, s = 0, c, l;
	if (e.sym_next !== 0) do
		a = e.pending_buf[e.sym_buf + s++] & 255, a += (e.pending_buf[e.sym_buf + s++] & 255) << 8, o = e.pending_buf[e.sym_buf + s++], a === 0 ? S(e, o, t) : (c = d[o], S(e, c + 256 + 1, t), l = r[c], l !== 0 && (o -= f[c], x(e, o, l)), a--, c = y(a), S(e, c, n), l = i[c], l !== 0 && (a -= p[c], x(e, a, l)));
	while (s < e.sym_next);
	S(e, 256, t);
}, re = (e, t) => {
	let n = t.dyn_tree, r = t.stat_desc.static_tree, i = t.stat_desc.has_stree, a = t.stat_desc.elems, o, s, c = -1, l;
	for (e.heap_len = 0, e.heap_max = 573, o = 0; o < a; o++) n[o * 2] === 0 ? n[o * 2 + 1] = 0 : (e.heap[++e.heap_len] = c = o, e.depth[o] = 0);
	for (; e.heap_len < 2;) l = e.heap[++e.heap_len] = c < 2 ? ++c : 0, n[l * 2] = 1, e.depth[l] = 0, e.opt_len--, i && (e.static_len -= r[l * 2 + 1]);
	for (t.max_code = c, o = e.heap_len >> 1; o >= 1; o--) k(e, n, o);
	l = a;
	do
		o = e.heap[1], e.heap[1] = e.heap[e.heap_len--], k(e, n, 1), s = e.heap[1], e.heap[--e.heap_max] = o, e.heap[--e.heap_max] = s, n[l * 2] = n[o * 2] + n[s * 2], e.depth[l] = (e.depth[o] >= e.depth[s] ? e.depth[o] : e.depth[s]) + 1, n[o * 2 + 1] = n[s * 2 + 1] = l, e.heap[1] = l++, k(e, n, 1);
	while (e.heap_len >= 2);
	e.heap[--e.heap_max] = e.heap[1], T(e, t), E(n, c, e.bl_count);
}, ie = (e, t, n) => {
	let r, i = -1, a, o = t[1], s = 0, c = 7, l = 4;
	for (o === 0 && (c = 138, l = 3), t[(n + 1) * 2 + 1] = 65535, r = 0; r <= n; r++) a = o, o = t[(r + 1) * 2 + 1], !(++s < c && a === o) && (s < l ? e.bl_tree[a * 2] += s : a === 0 ? s <= 10 ? e.bl_tree[34]++ : e.bl_tree[36]++ : (a !== i && e.bl_tree[a * 2]++, e.bl_tree[32]++), s = 0, i = a, o === 0 ? (c = 138, l = 3) : a === o ? (c = 6, l = 3) : (c = 7, l = 4));
}, ae = (e, t, n) => {
	let r, i = -1, a, o = t[1], s = 0, c = 7, l = 4;
	for (o === 0 && (c = 138, l = 3), r = 0; r <= n; r++) if (a = o, o = t[(r + 1) * 2 + 1], !(++s < c && a === o)) {
		if (s < l) do
			S(e, a, e.bl_tree);
		while (--s !== 0);
		else a === 0 ? s <= 10 ? (S(e, 17, e.bl_tree), x(e, s - 3, 3)) : (S(e, 18, e.bl_tree), x(e, s - 11, 7)) : (a !== i && (S(e, a, e.bl_tree), s--), S(e, 16, e.bl_tree), x(e, s - 3, 2));
		s = 0, i = a, o === 0 ? (c = 138, l = 3) : a === o ? (c = 6, l = 3) : (c = 7, l = 4);
	}
}, oe = (e) => {
	let t;
	for (ie(e, e.dyn_ltree, e.l_desc.max_code), ie(e, e.dyn_dtree, e.d_desc.max_code), re(e, e.bl_desc), t = 18; t >= 3 && e.bl_tree[o[t] * 2 + 1] === 0; t--);
	return e.opt_len += 3 * (t + 1) + 5 + 5 + 4, t;
}, se = (e, t, n, r) => {
	let i;
	for (x(e, t - 257, 5), x(e, n - 1, 5), x(e, r - 4, 4), i = 0; i < r; i++) x(e, e.bl_tree[o[i] * 2 + 1], 3);
	ae(e, e.dyn_ltree, t - 1), ae(e, e.dyn_dtree, n - 1);
}, ce = (e) => {
	let t = 4093624447, n = 0;
	for (; n <= 31; n++, t >>>= 1) if (t & 1 && e.dyn_ltree[n * 2] !== 0) return 0;
	if (e.dyn_ltree[18] !== 0 || e.dyn_ltree[20] !== 0 || e.dyn_ltree[26] !== 0) return 1;
	for (n = 32; n < 256; n++) if (e.dyn_ltree[n * 2] !== 0) return 1;
	return 0;
}, le = !1, ue = (e) => {
	le ||= (D(), !0), e.l_desc = new v(e.dyn_ltree, h), e.d_desc = new v(e.dyn_dtree, g), e.bl_desc = new v(e.bl_tree, _), e.bi_buf = 0, e.bi_valid = 0, O(e);
}, de = (e, t, n, r) => {
	x(e, 0 + +!!r, 3), ee(e), b(e, n), b(e, ~n), n && e.pending_buf.set(e.window.subarray(t, t + n), e.pending), e.pending += n;
}, fe = {
	_tr_init: ue,
	_tr_stored_block: de,
	_tr_flush_block: (e, t, n, r) => {
		let i, a, o = 0;
		e.level > 0 ? (e.strm.data_type === 2 && (e.strm.data_type = ce(e)), re(e, e.l_desc), re(e, e.d_desc), o = oe(e), i = e.opt_len + 3 + 7 >>> 3, a = e.static_len + 3 + 7 >>> 3, a <= i && (i = a)) : i = a = n + 5, n + 4 <= i && t !== -1 ? de(e, t, n, r) : e.strategy === 4 || a === i ? (x(e, 2 + +!!r, 3), ne(e, c, l)) : (x(e, 4 + +!!r, 3), se(e, e.l_desc.max_code + 1, e.d_desc.max_code + 1, o + 1), ne(e, e.dyn_ltree, e.dyn_dtree)), O(e), r && ee(e);
	},
	_tr_tally: (e, t, n) => (e.pending_buf[e.sym_buf + e.sym_next++] = t, e.pending_buf[e.sym_buf + e.sym_next++] = t >> 8, e.pending_buf[e.sym_buf + e.sym_next++] = n, t === 0 ? e.dyn_ltree[n * 2]++ : (e.matches++, t--, e.dyn_ltree[(d[n] + 256 + 1) * 2]++, e.dyn_dtree[y(t) * 2]++), e.sym_next === e.sym_end),
	_tr_align: (e) => {
		x(e, 2, 3), S(e, 256, c), w(e);
	}
}, pe = (e, t, n, r) => {
	let i = e & 65535, a = e >>> 16 & 65535, o = 0;
	for (; n !== 0;) {
		o = n > 2e3 ? 2e3 : n, n -= o;
		do
			i = i + t[r++] | 0, a = a + i | 0;
		while (--o);
		i %= 65521, a %= 65521;
	}
	return i | a << 16;
}, me = new Uint32Array((() => {
	let e, t = [];
	for (var n = 0; n < 256; n++) {
		e = n;
		for (var r = 0; r < 8; r++) e = e & 1 ? 3988292384 ^ e >>> 1 : e >>> 1;
		t[n] = e;
	}
	return t;
})()), A = (e, t, n, r) => {
	let i = me, a = r + n;
	e ^= -1;
	for (let n = r; n < a; n++) e = e >>> 8 ^ i[(e ^ t[n]) & 255];
	return e ^ -1;
}, he = {
	2: "need dictionary",
	1: "stream end",
	0: "",
	"-1": "file error",
	"-2": "stream error",
	"-3": "data error",
	"-4": "insufficient memory",
	"-5": "buffer error",
	"-6": "incompatible version"
}, ge = {
	Z_NO_FLUSH: 0,
	Z_PARTIAL_FLUSH: 1,
	Z_SYNC_FLUSH: 2,
	Z_FULL_FLUSH: 3,
	Z_FINISH: 4,
	Z_BLOCK: 5,
	Z_TREES: 6,
	Z_OK: 0,
	Z_STREAM_END: 1,
	Z_NEED_DICT: 2,
	Z_ERRNO: -1,
	Z_STREAM_ERROR: -2,
	Z_DATA_ERROR: -3,
	Z_MEM_ERROR: -4,
	Z_BUF_ERROR: -5,
	Z_NO_COMPRESSION: 0,
	Z_BEST_SPEED: 1,
	Z_BEST_COMPRESSION: 9,
	Z_DEFAULT_COMPRESSION: -1,
	Z_FILTERED: 1,
	Z_HUFFMAN_ONLY: 2,
	Z_RLE: 3,
	Z_FIXED: 4,
	Z_DEFAULT_STRATEGY: 0,
	Z_BINARY: 0,
	Z_TEXT: 1,
	Z_UNKNOWN: 2,
	Z_DEFLATED: 8
}, { _tr_init: _e, _tr_stored_block: ve, _tr_flush_block: ye, _tr_tally: j, _tr_align: be } = fe, { Z_NO_FLUSH: M, Z_PARTIAL_FLUSH: xe, Z_FULL_FLUSH: Se, Z_FINISH: N, Z_BLOCK: Ce, Z_OK: P, Z_STREAM_END: we, Z_STREAM_ERROR: F, Z_DATA_ERROR: Te, Z_BUF_ERROR: Ee, Z_DEFAULT_COMPRESSION: De, Z_FILTERED: Oe, Z_HUFFMAN_ONLY: ke, Z_RLE: Ae, Z_FIXED: je, Z_DEFAULT_STRATEGY: Me, Z_UNKNOWN: Ne, Z_DEFLATED: Pe } = ge, Fe = 9, Ie = 15, Le = 8, Re = 573, I = 3, ze = 258, L = 262, Be = 32, Ve = 42, He = 57, Ue = 69, We = 73, Ge = 91, Ke = 103, qe = 113, Je = 666, R = 1, Ye = 2, z = 3, Xe = 4, Ze = 3, B = (e, t) => (e.msg = he[t], t), Qe = (e) => e * 2 - (e > 4 ? 9 : 0), V = (e) => {
	let t = e.length;
	for (; --t >= 0;) e[t] = 0;
}, $e = (e) => {
	let t, n, r, i = e.w_size;
	t = e.hash_size, r = t;
	do
		n = e.head[--r], e.head[r] = n >= i ? n - i : 0;
	while (--t);
	t = i, r = t;
	do
		n = e.prev[--r], e.prev[r] = n >= i ? n - i : 0;
	while (--t);
}, et = (e, t, n) => (t << e.hash_shift ^ n) & e.hash_mask, H = (e, t) => {
	let n;
	if (e.legacy_hash) n = e.ins_h = et(e, e.ins_h, e.window[t + I - 1]);
	else {
		let r = e.window, i = r[t] | r[t + 1] << 8 | r[t + 2] << 16 | r[t + 3] << 24;
		n = e.ins_h = Math.imul(i, 66521) + 66521 >>> 16 & e.hash_mask;
	}
	let r = e.prev[t & e.w_mask] = e.head[n];
	return e.head[n] = t, r;
}, U = (e) => {
	let t = e.state, n = t.pending;
	n > e.avail_out && (n = e.avail_out), n !== 0 && (e.output.set(t.pending_buf.subarray(t.pending_out, t.pending_out + n), e.next_out), e.next_out += n, t.pending_out += n, e.total_out += n, e.avail_out -= n, t.pending -= n, t.pending === 0 && (t.pending_out = 0));
}, W = (e, t) => {
	ye(e, e.block_start >= 0 ? e.block_start : -1, e.strstart - e.block_start, t), e.block_start = e.strstart, U(e.strm);
}, G = (e, t) => {
	e.pending_buf[e.pending++] = t;
}, tt = (e, t) => {
	e.pending_buf[e.pending++] = t >>> 8 & 255, e.pending_buf[e.pending++] = t & 255;
}, nt = (e, t, n, r) => {
	let i = e.avail_in;
	return i > r && (i = r), i === 0 ? 0 : (e.avail_in -= i, t.set(e.input.subarray(e.next_in, e.next_in + i), n), e.state.wrap === 1 ? e.adler = pe(e.adler, t, i, n) : e.state.wrap === 2 && (e.adler = A(e.adler, t, i, n)), e.next_in += i, e.total_in += i, i);
}, rt = (e, t) => {
	let n = e.max_chain_length, r = e.strstart, i, a, o = e.prev_length, s = e.nice_match, c = e.strstart > e.w_size - L ? e.strstart - (e.w_size - L) : 0, l = e.window, u = e.w_mask, d = e.prev, f = e.strstart + ze, p = l[r + o - 1], m = l[r + o];
	e.prev_length >= e.good_match && (n >>= 2), s > e.lookahead && (s = e.lookahead);
	do
		if (i = t, l[i + o] === m && l[i + o - 1] === p && l[i] === l[r] && l[++i] === l[r + 1]) {
			r += 2, i++;
			do;
			while (l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && r < f);
			if (a = ze - (f - r), r = f - ze, a > o) {
				if (e.match_start = t, o = a, a >= s) break;
				p = l[r + o - 1], m = l[r + o];
			}
		}
	while ((t = d[t & u]) > c && --n !== 0);
	return o <= e.lookahead ? o : e.lookahead;
}, it = (e) => {
	let t = e.w_size, n, r, i;
	do {
		if (r = e.window_size - e.lookahead - e.strstart, e.strstart >= t + (t - L) && (e.window.set(e.window.subarray(t, t + t - r), 0), e.match_start -= t, e.strstart -= t, e.block_start -= t, e.insert > e.strstart && (e.insert = e.strstart), $e(e), r += t), e.strm.avail_in === 0) break;
		if (n = nt(e.strm, e.window, e.strstart + e.lookahead, r), e.lookahead += n, !e.legacy_hash) {
			if (e.lookahead + e.insert > I) for (i = e.strstart - e.insert; e.insert && (H(e, i), i++, e.insert--, !(e.lookahead + e.insert <= I)););
		} else if (e.lookahead + e.insert >= I) for (i = e.strstart - e.insert, e.ins_h = e.window[i], e.ins_h = et(e, e.ins_h, e.window[i + 1]); e.insert && (H(e, i), i++, e.insert--, !(e.lookahead + e.insert < I)););
	} while (e.lookahead < L && e.strm.avail_in !== 0);
}, at = (e, t) => {
	let n = e.pending_buf_size - 5 > e.w_size ? e.w_size : e.pending_buf_size - 5, r, i, a, o = 0, s = e.strm.avail_in;
	do {
		if (r = 65535, a = e.bi_valid + 42 >> 3, e.strm.avail_out < a || (a = e.strm.avail_out - a, i = e.strstart - e.block_start, r > i + e.strm.avail_in && (r = i + e.strm.avail_in), r > a && (r = a), r < n && (r === 0 && t !== N || t === M || r !== i + e.strm.avail_in))) break;
		o = +(t === N && r === i + e.strm.avail_in), ve(e, 0, 0, o), e.pending_buf[e.pending - 4] = r, e.pending_buf[e.pending - 3] = r >> 8, e.pending_buf[e.pending - 2] = ~r, e.pending_buf[e.pending - 1] = ~r >> 8, U(e.strm), i && (i > r && (i = r), e.strm.output.set(e.window.subarray(e.block_start, e.block_start + i), e.strm.next_out), e.strm.next_out += i, e.strm.avail_out -= i, e.strm.total_out += i, e.block_start += i, r -= i), r && (nt(e.strm, e.strm.output, e.strm.next_out, r), e.strm.next_out += r, e.strm.avail_out -= r, e.strm.total_out += r);
	} while (o === 0);
	return s -= e.strm.avail_in, s && (s >= e.w_size ? (e.matches = 2, e.window.set(e.strm.input.subarray(e.strm.next_in - e.w_size, e.strm.next_in), 0), e.strstart = e.w_size, e.insert = e.strstart) : (e.window_size - e.strstart <= s && (e.strstart -= e.w_size, e.window.set(e.window.subarray(e.w_size, e.w_size + e.strstart), 0), e.matches < 2 && e.matches++, e.insert > e.strstart && (e.insert = e.strstart)), e.window.set(e.strm.input.subarray(e.strm.next_in - s, e.strm.next_in), e.strstart), e.strstart += s, e.insert += s > e.w_size - e.insert ? e.w_size - e.insert : s), e.block_start = e.strstart), e.high_water < e.strstart && (e.high_water = e.strstart), o ? Xe : t !== M && t !== N && e.strm.avail_in === 0 && e.strstart === e.block_start ? Ye : (a = e.window_size - e.strstart, e.strm.avail_in > a && e.block_start >= e.w_size && (e.block_start -= e.w_size, e.strstart -= e.w_size, e.window.set(e.window.subarray(e.w_size, e.w_size + e.strstart), 0), e.matches < 2 && e.matches++, a += e.w_size, e.insert > e.strstart && (e.insert = e.strstart)), a > e.strm.avail_in && (a = e.strm.avail_in), a && (nt(e.strm, e.window, e.strstart, a), e.strstart += a, e.insert += a > e.w_size - e.insert ? e.w_size - e.insert : a), e.high_water < e.strstart && (e.high_water = e.strstart), a = e.bi_valid + 42 >> 3, a = e.pending_buf_size - a > 65535 ? 65535 : e.pending_buf_size - a, n = a > e.w_size ? e.w_size : a, i = e.strstart - e.block_start, (i >= n || (i || t === N) && t !== M && e.strm.avail_in === 0 && i <= a) && (r = i > a ? a : i, o = +(t === N && e.strm.avail_in === 0 && r === i), ve(e, e.block_start, r, o), e.block_start += r, U(e.strm)), o ? z : R);
}, ot = (e, t) => {
	let n, r;
	for (;;) {
		if (e.lookahead < L) {
			if (it(e), e.lookahead < L && t === M) return R;
			if (e.lookahead === 0) break;
		}
		if (n = 0, e.lookahead >= I && (n = H(e, e.strstart)), n !== 0 && e.strstart - n <= e.w_size - L && (e.match_length = rt(e, n)), e.match_length >= I) {
			if (r = j(e, e.strstart - e.match_start, e.match_length - I), e.lookahead -= e.match_length, e.match_length <= e.max_lazy_match && e.lookahead >= I) {
				e.match_length--;
				do
					e.strstart++, n = H(e, e.strstart);
				while (--e.match_length !== 0);
				e.strstart++;
			} else e.strstart += e.match_length, e.match_length = 0, e.legacy_hash && (e.ins_h = e.window[e.strstart], e.ins_h = et(e, e.ins_h, e.window[e.strstart + 1]));
		} else r = j(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++;
		if (r && (W(e, !1), e.strm.avail_out === 0)) return R;
	}
	return e.insert = e.strstart < 2 ? e.strstart : 2, t === N ? (W(e, !0), e.strm.avail_out === 0 ? z : Xe) : e.sym_next && (W(e, !1), e.strm.avail_out === 0) ? R : Ye;
}, st = (e, t) => {
	let n, r, i;
	for (;;) {
		if (e.lookahead < L) {
			if (it(e), e.lookahead < L && t === M) return R;
			if (e.lookahead === 0) break;
		}
		if (n = 0, e.lookahead >= I && (n = H(e, e.strstart)), e.prev_length = e.match_length, e.prev_match = e.match_start, e.match_length = 2, n !== 0 && e.prev_length < e.max_lazy_match && e.strstart - n <= e.w_size - L && (e.match_length = rt(e, n), e.match_length <= 5 && (e.strategy === Oe || e.match_length === I && e.strstart - e.match_start > 4096) && (e.match_length = 2)), e.prev_length >= I && e.match_length <= e.prev_length) {
			i = e.strstart + e.lookahead - I, r = j(e, e.strstart - 1 - e.prev_match, e.prev_length - I), e.lookahead -= e.prev_length - 1, e.prev_length -= 2;
			do
				++e.strstart <= i && (n = H(e, e.strstart));
			while (--e.prev_length !== 0);
			if (e.match_available = 0, e.match_length = 2, e.strstart++, r && (W(e, !1), e.strm.avail_out === 0)) return R;
		} else if (e.match_available) {
			if (r = j(e, 0, e.window[e.strstart - 1]), r && W(e, !1), e.strstart++, e.lookahead--, e.strm.avail_out === 0) return R;
		} else e.match_available = 1, e.strstart++, e.lookahead--;
	}
	return e.match_available &&= (r = j(e, 0, e.window[e.strstart - 1]), 0), e.insert = e.strstart < 2 ? e.strstart : 2, t === N ? (W(e, !0), e.strm.avail_out === 0 ? z : Xe) : e.sym_next && (W(e, !1), e.strm.avail_out === 0) ? R : Ye;
}, ct = (e, t) => {
	let n, r, i, a, o = e.window;
	for (;;) {
		if (e.lookahead <= ze) {
			if (it(e), e.lookahead <= ze && t === M) return R;
			if (e.lookahead === 0) break;
		}
		if (e.match_length = 0, e.lookahead >= I && e.strstart > 0 && (i = e.strstart - 1, r = o[i], r === o[++i] && r === o[++i] && r === o[++i])) {
			a = e.strstart + ze;
			do;
			while (r === o[++i] && r === o[++i] && r === o[++i] && r === o[++i] && r === o[++i] && r === o[++i] && r === o[++i] && r === o[++i] && i < a);
			e.match_length = ze - (a - i), e.match_length > e.lookahead && (e.match_length = e.lookahead);
		}
		if (e.match_length >= I ? (n = j(e, 1, e.match_length - I), e.lookahead -= e.match_length, e.strstart += e.match_length, e.match_length = 0) : (n = j(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++), n && (W(e, !1), e.strm.avail_out === 0)) return R;
	}
	return e.insert = 0, t === N ? (W(e, !0), e.strm.avail_out === 0 ? z : Xe) : e.sym_next && (W(e, !1), e.strm.avail_out === 0) ? R : Ye;
}, lt = (e, t) => {
	let n;
	for (;;) {
		if (e.lookahead === 0 && (it(e), e.lookahead === 0)) {
			if (t === M) return R;
			break;
		}
		if (e.match_length = 0, n = j(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++, n && (W(e, !1), e.strm.avail_out === 0)) return R;
	}
	return e.insert = 0, t === N ? (W(e, !0), e.strm.avail_out === 0 ? z : Xe) : e.sym_next && (W(e, !1), e.strm.avail_out === 0) ? R : Ye;
};
function K(e, t, n, r, i) {
	this.good_length = e, this.max_lazy = t, this.nice_length = n, this.max_chain = r, this.func = i;
}
var ut = [
	new K(0, 0, 0, 0, at),
	new K(4, 4, 8, 4, ot),
	new K(4, 5, 16, 8, ot),
	new K(4, 6, 32, 32, ot),
	new K(4, 4, 16, 16, st),
	new K(8, 16, 32, 32, st),
	new K(8, 16, 128, 128, st),
	new K(8, 32, 128, 256, st),
	new K(32, 128, 258, 1024, st),
	new K(32, 258, 258, 4096, st)
], dt = (e) => {
	e.window_size = 2 * e.w_size, V(e.head), e.max_lazy_match = ut[e.level].max_lazy, e.good_match = ut[e.level].good_length, e.nice_match = ut[e.level].nice_length, e.max_chain_length = ut[e.level].max_chain, e.strstart = 0, e.block_start = 0, e.lookahead = 0, e.insert = 0, e.match_length = e.prev_length = 2, e.match_available = 0, e.ins_h = 0;
};
function ft() {
	this.strm = null, this.status = 0, this.pending_buf = null, this.pending_buf_size = 0, this.pending_out = 0, this.pending = 0, this.wrap = 0, this.gzhead = null, this.gzindex = 0, this.method = Pe, this.last_flush = -1, this.w_size = 0, this.w_bits = 0, this.w_mask = 0, this.window = null, this.window_size = 0, this.prev = null, this.head = null, this.ins_h = 0, this.legacy_hash = 0, this.hash_size = 0, this.hash_bits = 0, this.hash_mask = 0, this.hash_shift = 0, this.block_start = 0, this.match_length = 0, this.prev_match = 0, this.match_available = 0, this.strstart = 0, this.match_start = 0, this.lookahead = 0, this.prev_length = 0, this.max_chain_length = 0, this.max_lazy_match = 0, this.level = 0, this.strategy = 0, this.good_match = 0, this.nice_match = 0, this.dyn_ltree = new Uint16Array(Re * 2), this.dyn_dtree = /* @__PURE__ */ new Uint16Array(122), this.bl_tree = /* @__PURE__ */ new Uint16Array(78), V(this.dyn_ltree), V(this.dyn_dtree), V(this.bl_tree), this.l_desc = null, this.d_desc = null, this.bl_desc = null, this.bl_count = /* @__PURE__ */ new Uint16Array(16), this.heap = /* @__PURE__ */ new Uint16Array(573), V(this.heap), this.heap_len = 0, this.heap_max = 0, this.depth = /* @__PURE__ */ new Uint16Array(573), V(this.depth), this.sym_buf = 0, this.lit_bufsize = 0, this.sym_next = 0, this.sym_end = 0, this.opt_len = 0, this.static_len = 0, this.matches = 0, this.insert = 0, this.bi_buf = 0, this.bi_valid = 0;
}
var pt = (e) => {
	if (!e) return 1;
	let t = e.state;
	return +(!t || t.strm !== e || t.status !== Ve && t.status !== He && t.status !== Ue && t.status !== We && t.status !== Ge && t.status !== Ke && t.status !== qe && t.status !== Je);
}, mt = (e) => {
	if (pt(e)) return B(e, F);
	e.total_in = e.total_out = 0, e.data_type = Ne;
	let t = e.state;
	return t.pending = 0, t.pending_out = 0, t.wrap < 0 && (t.wrap = -t.wrap), t.status = t.wrap === 2 ? He : t.wrap ? Ve : qe, e.adler = t.wrap === 2 ? 0 : 1, t.last_flush = -2, _e(t), P;
}, ht = (e) => {
	let t = mt(e);
	return t === P && dt(e.state), t;
}, gt = (e, t) => pt(e) || e.state.wrap !== 2 ? F : (e.state.gzhead = t, P), _t = (e, t, n, r, i, a, o) => {
	if (!e) return F;
	let s = 1;
	if (t === De && (t = 6), r < 0 ? (s = 0, r = -r) : r > 15 && (s = 2, r -= 16), i < 1 || i > Fe || n !== Pe || r < 8 || r > 15 || t < 0 || t > 9 || a < 0 || a > je || r === 8 && s !== 1) return B(e, F);
	r === 8 && (r = 9);
	let c = new ft();
	return e.state = c, c.strm = e, c.status = Ve, c.wrap = s, c.gzhead = null, c.w_bits = r, c.w_size = 1 << c.w_bits, c.w_mask = c.w_size - 1, c.legacy_hash = +!!o, c.hash_bits = i + 7, !c.legacy_hash && c.hash_bits < 15 && (c.hash_bits = 15), c.hash_size = 1 << c.hash_bits, c.hash_mask = c.hash_size - 1, c.hash_shift = ~~((c.hash_bits + I - 1) / I), c.window = new Uint8Array(c.w_size * 2), c.head = new Uint16Array(c.hash_size), c.prev = new Uint16Array(c.w_size), c.lit_bufsize = 1 << i + 6, c.pending_buf_size = c.lit_bufsize * 4, c.pending_buf = new Uint8Array(c.pending_buf_size), c.sym_buf = c.lit_bufsize, c.sym_end = (c.lit_bufsize - 1) * 3, c.level = t, c.strategy = a, c.method = n, ht(e);
}, vt = {
	deflateInit: (e, t) => _t(e, t, Pe, Ie, Le, Me),
	deflateInit2: _t,
	deflateReset: ht,
	deflateResetKeep: mt,
	deflateSetHeader: gt,
	deflate: (e, t) => {
		if (pt(e) || t > Ce || t < 0) return e ? B(e, F) : F;
		let n = e.state;
		if (!e.output || e.avail_in !== 0 && !e.input || n.status === Je && t !== N) return B(e, e.avail_out === 0 ? Ee : F);
		let r = n.last_flush;
		if (n.last_flush = t, n.pending !== 0) {
			if (U(e), e.avail_out === 0) return n.last_flush = -1, P;
		} else if (e.avail_in === 0 && Qe(t) <= Qe(r) && t !== N) return B(e, Ee);
		if (n.status === Je && e.avail_in !== 0) return B(e, Ee);
		if (n.status === Ve && n.wrap === 0 && (n.status = qe), n.status === Ve) {
			let t = Pe + (n.w_bits - 8 << 4) << 8, r = -1;
			if (r = n.strategy >= ke || n.level < 2 ? 0 : n.level < 6 ? 1 : n.level === 6 ? 2 : 3, t |= r << 6, n.strstart !== 0 && (t |= Be), t += 31 - t % 31, tt(n, t), n.strstart !== 0 && (tt(n, e.adler >>> 16), tt(n, e.adler & 65535)), e.adler = 1, n.status = qe, U(e), n.pending !== 0) return n.last_flush = -1, P;
		}
		if (n.status === He) {
			if (e.adler = 0, G(n, 31), G(n, 139), G(n, 8), n.gzhead) G(n, +!!n.gzhead.text + (n.gzhead.hcrc ? 2 : 0) + (n.gzhead.extra ? 4 : 0) + (n.gzhead.name ? 8 : 0) + (n.gzhead.comment ? 16 : 0)), G(n, n.gzhead.time & 255), G(n, n.gzhead.time >> 8 & 255), G(n, n.gzhead.time >> 16 & 255), G(n, n.gzhead.time >> 24 & 255), G(n, n.level === 9 ? 2 : n.strategy >= ke || n.level < 2 ? 4 : 0), G(n, n.gzhead.os & 255), n.gzhead.extra && n.gzhead.extra.length && (G(n, n.gzhead.extra.length & 255), G(n, n.gzhead.extra.length >> 8 & 255)), n.gzhead.hcrc && (e.adler = A(e.adler, n.pending_buf, n.pending, 0)), n.gzindex = 0, n.status = Ue;
			else if (G(n, 0), G(n, 0), G(n, 0), G(n, 0), G(n, 0), G(n, n.level === 9 ? 2 : n.strategy >= ke || n.level < 2 ? 4 : 0), G(n, Ze), n.status = qe, U(e), n.pending !== 0) return n.last_flush = -1, P;
		}
		if (n.status === Ue) {
			if (n.gzhead.extra) {
				let t = n.pending, r = (n.gzhead.extra.length & 65535) - n.gzindex;
				for (; n.pending + r > n.pending_buf_size;) {
					let i = n.pending_buf_size - n.pending;
					if (n.pending_buf.set(n.gzhead.extra.subarray(n.gzindex, n.gzindex + i), n.pending), n.pending = n.pending_buf_size, n.gzhead.hcrc && n.pending > t && (e.adler = A(e.adler, n.pending_buf, n.pending - t, t)), n.gzindex += i, U(e), n.pending !== 0) return n.last_flush = -1, P;
					t = 0, r -= i;
				}
				let i = new Uint8Array(n.gzhead.extra);
				n.pending_buf.set(i.subarray(n.gzindex, n.gzindex + r), n.pending), n.pending += r, n.gzhead.hcrc && n.pending > t && (e.adler = A(e.adler, n.pending_buf, n.pending - t, t)), n.gzindex = 0;
			}
			n.status = We;
		}
		if (n.status === We) {
			if (n.gzhead.name) {
				let t = n.pending, r;
				do {
					if (n.pending === n.pending_buf_size) {
						if (n.gzhead.hcrc && n.pending > t && (e.adler = A(e.adler, n.pending_buf, n.pending - t, t)), U(e), n.pending !== 0) return n.last_flush = -1, P;
						t = 0;
					}
					r = n.gzindex < n.gzhead.name.length ? n.gzhead.name.charCodeAt(n.gzindex++) & 255 : 0, G(n, r);
				} while (r !== 0);
				n.gzhead.hcrc && n.pending > t && (e.adler = A(e.adler, n.pending_buf, n.pending - t, t)), n.gzindex = 0;
			}
			n.status = Ge;
		}
		if (n.status === Ge) {
			if (n.gzhead.comment) {
				let t = n.pending, r;
				do {
					if (n.pending === n.pending_buf_size) {
						if (n.gzhead.hcrc && n.pending > t && (e.adler = A(e.adler, n.pending_buf, n.pending - t, t)), U(e), n.pending !== 0) return n.last_flush = -1, P;
						t = 0;
					}
					r = n.gzindex < n.gzhead.comment.length ? n.gzhead.comment.charCodeAt(n.gzindex++) & 255 : 0, G(n, r);
				} while (r !== 0);
				n.gzhead.hcrc && n.pending > t && (e.adler = A(e.adler, n.pending_buf, n.pending - t, t));
			}
			n.status = Ke;
		}
		if (n.status === Ke) {
			if (n.gzhead.hcrc) {
				if (n.pending + 2 > n.pending_buf_size && (U(e), n.pending !== 0)) return n.last_flush = -1, P;
				G(n, e.adler & 255), G(n, e.adler >> 8 & 255), e.adler = 0;
			}
			if (n.status = qe, U(e), n.pending !== 0) return n.last_flush = -1, P;
		}
		if (e.avail_in !== 0 || n.lookahead !== 0 || t !== M && n.status !== Je) {
			let r = n.level === 0 ? at(n, t) : n.strategy === ke ? lt(n, t) : n.strategy === Ae ? ct(n, t) : ut[n.level].func(n, t);
			if ((r === z || r === Xe) && (n.status = Je), r === R || r === z) return e.avail_out === 0 && (n.last_flush = -1), P;
			if (r === Ye && (t === xe ? be(n) : t !== Ce && (ve(n, 0, 0, !1), t === Se && (V(n.head), n.lookahead === 0 && (n.strstart = 0, n.block_start = 0, n.insert = 0))), U(e), e.avail_out === 0)) return n.last_flush = -1, P;
		}
		return t === N ? n.wrap <= 0 ? we : (n.wrap === 2 ? (G(n, e.adler & 255), G(n, e.adler >> 8 & 255), G(n, e.adler >> 16 & 255), G(n, e.adler >> 24 & 255), G(n, e.total_in & 255), G(n, e.total_in >> 8 & 255), G(n, e.total_in >> 16 & 255), G(n, e.total_in >> 24 & 255)) : (tt(n, e.adler >>> 16), tt(n, e.adler & 65535)), U(e), n.wrap > 0 && (n.wrap = -n.wrap), n.pending === 0 ? we : P) : P;
	},
	deflateEnd: (e) => {
		if (pt(e)) return F;
		let t = e.state.status;
		return e.state = null, t === qe ? B(e, Te) : P;
	},
	deflateSetDictionary: (e, t) => {
		let n = t.length;
		if (pt(e)) return F;
		let r = e.state, i = r.wrap;
		if (i === 2 || i === 1 && r.status !== Ve || r.lookahead) return F;
		if (i === 1 && (e.adler = pe(e.adler, t, n, 0)), r.wrap = 0, n >= r.w_size) {
			i === 0 && (V(r.head), r.strstart = 0, r.block_start = 0, r.insert = 0);
			let e = new Uint8Array(r.w_size);
			e.set(t.subarray(n - r.w_size, n), 0), t = e, n = r.w_size;
		}
		let a = e.avail_in, o = e.next_in, s = e.input;
		for (e.avail_in = n, e.next_in = 0, e.input = t, it(r); r.lookahead >= I;) {
			let e = r.strstart, t = r.lookahead - 2;
			do
				H(r, e), e++;
			while (--t);
			r.strstart = e, r.lookahead = 2, it(r);
		}
		return r.strstart += r.lookahead, r.block_start = r.strstart, r.insert = r.lookahead, r.lookahead = 0, r.match_length = r.prev_length = 2, r.match_available = 0, e.next_in = o, e.input = s, e.avail_in = a, r.wrap = i, P;
	},
	deflateInfo: "pako deflate (from Nodeca project)"
}, yt = (e, t) => Object.prototype.hasOwnProperty.call(e, t), bt = {
	assign: function(e) {
		let t = Array.prototype.slice.call(arguments, 1);
		for (; t.length;) {
			let n = t.shift();
			if (n) {
				if (typeof n != "object") throw TypeError(n + "must be non-object");
				for (let t in n) yt(n, t) && (e[t] = n[t]);
			}
		}
		return e;
	},
	flattenChunks: (e) => {
		let t = 0;
		for (let n = 0, r = e.length; n < r; n++) t += e[n].length;
		let n = new Uint8Array(t);
		for (let t = 0, r = 0, i = e.length; t < i; t++) {
			let i = e[t];
			n.set(i, r), r += i.length;
		}
		return n;
	}
}, xt = !0;
try {
	String.fromCharCode.apply(null, /* @__PURE__ */ new Uint8Array(1));
} catch {
	xt = !1;
}
var St = /* @__PURE__ */ new Uint8Array(256);
for (let e = 0; e < 256; e++) St[e] = e >= 252 ? 6 : e >= 248 ? 5 : e >= 240 ? 4 : e >= 224 ? 3 : e >= 192 ? 2 : 1;
St[254] = St[255] = 1;
var Ct = (e) => {
	if (typeof TextEncoder == "function" && TextEncoder.prototype.encode) return new TextEncoder().encode(e);
	let t, n, r, i, a, o = e.length, s = 0;
	for (i = 0; i < o; i++) n = e.charCodeAt(i), (n & 64512) == 55296 && i + 1 < o && (r = e.charCodeAt(i + 1), (r & 64512) == 56320 && (n = 65536 + (n - 55296 << 10) + (r - 56320), i++)), s += n < 128 ? 1 : n < 2048 ? 2 : n < 65536 ? 3 : 4;
	for (t = new Uint8Array(s), a = 0, i = 0; a < s; i++) n = e.charCodeAt(i), (n & 64512) == 55296 && i + 1 < o && (r = e.charCodeAt(i + 1), (r & 64512) == 56320 && (n = 65536 + (n - 55296 << 10) + (r - 56320), i++)), n < 128 ? t[a++] = n : n < 2048 ? (t[a++] = 192 | n >>> 6, t[a++] = 128 | n & 63) : n < 65536 ? (t[a++] = 224 | n >>> 12, t[a++] = 128 | n >>> 6 & 63, t[a++] = 128 | n & 63) : (t[a++] = 240 | n >>> 18, t[a++] = 128 | n >>> 12 & 63, t[a++] = 128 | n >>> 6 & 63, t[a++] = 128 | n & 63);
	return t;
}, wt = (e, t) => {
	if (t < 65534 && e.subarray && xt) return String.fromCharCode.apply(null, e.length === t ? e : e.subarray(0, t));
	let n = "";
	for (let r = 0; r < t; r++) n += String.fromCharCode(e[r]);
	return n;
}, Tt = {
	string2buf: Ct,
	buf2string: (e, t) => {
		let n = t || e.length;
		if (typeof TextDecoder == "function" && TextDecoder.prototype.decode) return new TextDecoder().decode(e.subarray(0, t));
		let r, i, a = Array(n * 2);
		for (i = 0, r = 0; r < n;) {
			let t = e[r++];
			if (t < 128) {
				a[i++] = t;
				continue;
			}
			let o = St[t];
			if (o > 4) a[i++] = 65533, r += o - 1;
			else {
				for (t &= o === 2 ? 31 : o === 3 ? 15 : 7; o > 1 && r < n;) t = t << 6 | e[r++] & 63, o--;
				o > 1 ? a[i++] = 65533 : t < 65536 ? a[i++] = t : (t -= 65536, a[i++] = 55296 | t >> 10 & 1023, a[i++] = 56320 | t & 1023);
			}
		}
		return wt(a, i);
	},
	utf8border: (e, t) => {
		t ||= e.length, t > e.length && (t = e.length);
		let n = t - 1;
		for (; n >= 0 && (e[n] & 192) == 128;) n--;
		return n < 0 || n === 0 ? t : n + St[e[n]] > t ? n : t;
	}
};
function Et() {
	this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, this.data_type = 2, this.adler = 0;
}
var Dt = Et, Ot = Object.prototype.toString, { Z_NO_FLUSH: kt, Z_SYNC_FLUSH: At, Z_FULL_FLUSH: jt, Z_FINISH: Mt, Z_OK: Nt, Z_STREAM_END: Pt, Z_DEFAULT_COMPRESSION: Ft, Z_DEFAULT_STRATEGY: It, Z_DEFLATED: Lt } = ge, Rt = {
	level: Ft,
	method: Lt,
	chunkSize: 16384,
	windowBits: 15,
	memLevel: 8,
	strategy: It,
	legacyHash: !0
};
function zt(e) {
	this.options = bt.assign({}, Rt, e || {});
	let t = this.options;
	t.raw && t.windowBits > 0 ? t.windowBits = -t.windowBits : t.gzip && t.windowBits > 0 && t.windowBits < 16 && (t.windowBits += 16), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new Dt(), this.strm.avail_out = 0;
	let n = vt.deflateInit2(this.strm, t.level, t.method, t.windowBits, t.memLevel, t.strategy, t.legacyHash);
	if (n !== Nt) throw Error(he[n]);
	if (t.header && vt.deflateSetHeader(this.strm, t.header), t.dictionary) {
		let e;
		if (e = typeof t.dictionary == "string" ? Tt.string2buf(t.dictionary) : Ot.call(t.dictionary) === "[object ArrayBuffer]" ? new Uint8Array(t.dictionary) : t.dictionary, n = vt.deflateSetDictionary(this.strm, e), n !== Nt) throw Error(he[n]);
		this._dict_set = !0;
	}
}
zt.prototype.push = function(e, t) {
	let n = this.strm, r = this.options.chunkSize, i, a;
	if (this.ended) return !1;
	for (a = t === ~~t ? t : t === !0 ? Mt : kt, n.input = typeof e == "string" ? Tt.string2buf(e) : Ot.call(e) === "[object ArrayBuffer]" ? new Uint8Array(e) : e, n.next_in = 0, n.avail_in = n.input.length;;) if (n.avail_out === 0 && (n.output = new Uint8Array(r), n.next_out = 0, n.avail_out = r), (a === At || a === jt) && n.avail_out <= 6) this.onData(n.output.subarray(0, n.next_out)), n.avail_out = 0;
	else {
		if (i = vt.deflate(n, a), i === Pt) return n.next_out > 0 && this.onData(n.output.subarray(0, n.next_out)), i = vt.deflateEnd(this.strm), this.onEnd(i), this.ended = !0, i === Nt;
		if (n.avail_out === 0) this.onData(n.output);
		else if (a > 0 && n.next_out > 0) this.onData(n.output.subarray(0, n.next_out)), n.avail_out = 0;
		else if (n.avail_in === 0) break;
	}
	return !0;
}, zt.prototype.onData = function(e) {
	this.chunks.push(e);
}, zt.prototype.onEnd = function(e) {
	e === Nt && (this.result = bt.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg;
};
function Bt(e, t) {
	let n = new zt(t);
	if (n.push(e, !0), n.err) throw n.msg || he[n.err];
	return n.result;
}
function Vt(e, t) {
	return t ||= {}, t.raw = !0, Bt(e, t);
}
function Ht(e, t) {
	return t ||= {}, t.gzip = !0, Bt(e, t);
}
var Ut = {
	Deflate: zt,
	deflate: Bt,
	deflateRaw: Vt,
	gzip: Ht,
	constants: ge
}, Wt = 16209, Gt = 16191, Kt = function(e, t) {
	let n, r, i, a, o, s, c, l, u, d, f, p, m, h, g, _, v, y, b, x, S, C, w, T, E = e.state;
	n = e.next_in, w = e.input, r = n + (e.avail_in - 5), i = e.next_out, T = e.output, a = i - (t - e.avail_out), o = i + (e.avail_out - 257), s = E.dmax, c = E.wsize, l = E.whave, u = E.wnext, d = E.window, f = E.hold, p = E.bits, m = E.lencode, h = E.distcode, g = (1 << E.lenbits) - 1, _ = (1 << E.distbits) - 1;
	top: do {
		p < 15 && (f += w[n++] << p, p += 8, f += w[n++] << p, p += 8), v = m[f & g];
		dolen: for (;;) {
			if (y = v >>> 24, f >>>= y, p -= y, y = v >>> 16 & 255, y === 0) T[i++] = v & 65535;
			else if (y & 16) {
				b = v & 65535, y &= 15, y && (p < y && (f += w[n++] << p, p += 8), b += f & (1 << y) - 1, f >>>= y, p -= y), p < 15 && (f += w[n++] << p, p += 8, f += w[n++] << p, p += 8), v = h[f & _];
				dodist: for (;;) {
					if (y = v >>> 24, f >>>= y, p -= y, y = v >>> 16 & 255, y & 16) {
						if (x = v & 65535, y &= 15, p < y && (f += w[n++] << p, p += 8, p < y && (f += w[n++] << p, p += 8)), x += f & (1 << y) - 1, x > s) {
							e.msg = "invalid distance too far back", E.mode = Wt;
							break top;
						}
						if (f >>>= y, p -= y, y = i - a, x > y) {
							if (y = x - y, y > l && E.sane) {
								e.msg = "invalid distance too far back", E.mode = Wt;
								break top;
							}
							if (S = 0, C = d, u === 0) {
								if (S += c - y, y < b) {
									b -= y;
									do
										T[i++] = d[S++];
									while (--y);
									S = i - x, C = T;
								}
							} else if (u < y) {
								if (S += c + u - y, y -= u, y < b) {
									b -= y;
									do
										T[i++] = d[S++];
									while (--y);
									if (S = 0, u < b) {
										y = u, b -= y;
										do
											T[i++] = d[S++];
										while (--y);
										S = i - x, C = T;
									}
								}
							} else if (S += u - y, y < b) {
								b -= y;
								do
									T[i++] = d[S++];
								while (--y);
								S = i - x, C = T;
							}
							for (; b > 2;) T[i++] = C[S++], T[i++] = C[S++], T[i++] = C[S++], b -= 3;
							b && (T[i++] = C[S++], b > 1 && (T[i++] = C[S++]));
						} else {
							S = i - x;
							do
								T[i++] = T[S++], T[i++] = T[S++], T[i++] = T[S++], b -= 3;
							while (b > 2);
							b && (T[i++] = T[S++], b > 1 && (T[i++] = T[S++]));
						}
					} else if (y & 64) {
						e.msg = "invalid distance code", E.mode = Wt;
						break top;
					} else {
						v = h[(v & 65535) + (f & (1 << y) - 1)];
						continue dodist;
					}
					break;
				}
			} else if (!(y & 64)) {
				v = m[(v & 65535) + (f & (1 << y) - 1)];
				continue dolen;
			} else if (y & 32) {
				E.mode = Gt;
				break top;
			} else {
				e.msg = "invalid literal/length code", E.mode = Wt;
				break top;
			}
			break;
		}
	} while (n < r && i < o);
	b = p >> 3, n -= b, p -= b << 3, f &= (1 << p) - 1, e.next_in = n, e.next_out = i, e.avail_in = n < r ? 5 + (r - n) : 5 - (n - r), e.avail_out = i < o ? 257 + (o - i) : 257 - (i - o), E.hold = f, E.bits = p;
}, qt = 15, Jt = 852, Yt = 592, Xt = 0, Zt = 1, Qt = 2, $t = new Uint16Array([
	3,
	4,
	5,
	6,
	7,
	8,
	9,
	10,
	11,
	13,
	15,
	17,
	19,
	23,
	27,
	31,
	35,
	43,
	51,
	59,
	67,
	83,
	99,
	115,
	131,
	163,
	195,
	227,
	258,
	0,
	0
]), en = new Uint8Array([
	16,
	16,
	16,
	16,
	16,
	16,
	16,
	16,
	17,
	17,
	17,
	17,
	18,
	18,
	18,
	18,
	19,
	19,
	19,
	19,
	20,
	20,
	20,
	20,
	21,
	21,
	21,
	21,
	16,
	199,
	75
]), tn = new Uint16Array([
	1,
	2,
	3,
	4,
	5,
	7,
	9,
	13,
	17,
	25,
	33,
	49,
	65,
	97,
	129,
	193,
	257,
	385,
	513,
	769,
	1025,
	1537,
	2049,
	3073,
	4097,
	6145,
	8193,
	12289,
	16385,
	24577,
	0,
	0
]), nn = new Uint8Array([
	16,
	16,
	16,
	16,
	17,
	17,
	18,
	18,
	19,
	19,
	20,
	20,
	21,
	21,
	22,
	22,
	23,
	23,
	24,
	24,
	25,
	25,
	26,
	26,
	27,
	27,
	28,
	28,
	29,
	29,
	64,
	64
]), rn = (e, t, n, r, i, a, o, s) => {
	let c = s.bits, l = 0, u = 0, d = 0, f = 0, p = 0, m = 0, h = 0, g = 0, _ = 0, v = 0, y, b, x, S, C, w = null, T, E = /* @__PURE__ */ new Uint16Array(16), D = /* @__PURE__ */ new Uint16Array(16), O = null, ee, te, k;
	for (l = 0; l <= qt; l++) E[l] = 0;
	for (u = 0; u < r; u++) E[t[n + u]]++;
	for (p = c, f = qt; f >= 1 && E[f] === 0; f--);
	if (p > f && (p = f), f === 0) return i[a++] = 20971520, i[a++] = 20971520, s.bits = 1, 0;
	for (d = 1; d < f && E[d] === 0; d++);
	for (p < d && (p = d), g = 1, l = 1; l <= qt; l++) if (g <<= 1, g -= E[l], g < 0) return -1;
	if (g > 0 && (e === Xt || f !== 1)) return -1;
	for (D[1] = 0, l = 1; l < qt; l++) D[l + 1] = D[l] + E[l];
	for (u = 0; u < r; u++) t[n + u] !== 0 && (o[D[t[n + u]]++] = u);
	if (e === Xt ? (w = O = o, T = 20) : e === Zt ? (w = $t, O = en, T = 257) : (w = tn, O = nn, T = 0), v = 0, u = 0, l = d, C = a, m = p, h = 0, x = -1, _ = 1 << p, S = _ - 1, e === Zt && _ > Jt || e === Qt && _ > Yt) return 1;
	for (;;) {
		ee = l - h, o[u] + 1 < T ? (te = 0, k = o[u]) : o[u] >= T ? (te = O[o[u] - T], k = w[o[u] - T]) : (te = 96, k = 0), y = 1 << l - h, b = 1 << m, d = b;
		do
			b -= y, i[C + (v >> h) + b] = ee << 24 | te << 16 | k;
		while (b !== 0);
		for (y = 1 << l - 1; v & y;) y >>= 1;
		if (y === 0 ? v = 0 : (v &= y - 1, v += y), u++, --E[l] === 0) {
			if (l === f) break;
			l = t[n + o[u]];
		}
		if (l > p && (v & S) !== x) {
			for (h === 0 && (h = p), C += d, m = l - h, g = 1 << m; m + h < f && (g -= E[m + h], !(g <= 0));) m++, g <<= 1;
			if (_ += 1 << m, e === Zt && _ > Jt || e === Qt && _ > Yt) return 1;
			x = v & S, i[x] = p << 24 | m << 16 | C - a;
		}
	}
	return v !== 0 && (i[C + v] = l - h << 24 | 4194304), s.bits = p, 0;
}, an = 0, on = 1, sn = 2, { Z_FINISH: cn, Z_BLOCK: ln, Z_TREES: un, Z_OK: q, Z_STREAM_END: dn, Z_NEED_DICT: fn, Z_STREAM_ERROR: J, Z_DATA_ERROR: pn, Z_MEM_ERROR: mn, Z_BUF_ERROR: hn, Z_DEFLATED: gn } = ge, _n = 16180, vn = 16181, yn = 16182, bn = 16183, xn = 16184, Sn = 16185, Cn = 16186, wn = 16187, Tn = 16188, En = 16189, Dn = 16190, Y = 16191, On = 16192, kn = 16193, An = 16194, jn = 16195, Mn = 16196, Nn = 16197, Pn = 16198, Fn = 16199, In = 16200, Ln = 16201, Rn = 16202, zn = 16203, Bn = 16204, Vn = 16205, Hn = 16206, Un = 16207, Wn = 16208, X = 16209, Gn = 16210, Kn = 16211, qn = 852, Jn = 592, Yn = 15, Xn = (e) => (e >>> 24 & 255) + (e >>> 8 & 65280) + ((e & 65280) << 8) + ((e & 255) << 24);
function Zn() {
	this.strm = null, this.mode = 0, this.last = !1, this.wrap = 0, this.havedict = !1, this.flags = 0, this.dmax = 0, this.check = 0, this.total = 0, this.head = null, this.wbits = 0, this.wsize = 0, this.whave = 0, this.wnext = 0, this.window = null, this.hold = 0, this.bits = 0, this.length = 0, this.offset = 0, this.extra = 0, this.lencode = null, this.distcode = null, this.lenbits = 0, this.distbits = 0, this.ncode = 0, this.nlen = 0, this.ndist = 0, this.have = 0, this.next = null, this.lens = /* @__PURE__ */ new Uint16Array(320), this.work = /* @__PURE__ */ new Uint16Array(288), this.lendyn = null, this.distdyn = null, this.sane = 0, this.back = 0, this.was = 0;
}
var Qn = (e) => {
	if (!e) return 1;
	let t = e.state;
	return +(!t || t.strm !== e || t.mode < _n || t.mode > Kn);
}, $n = (e) => {
	if (Qn(e)) return J;
	let t = e.state;
	return e.total_in = e.total_out = t.total = 0, e.msg = "", t.wrap && (e.adler = t.wrap & 1), t.mode = _n, t.last = 0, t.havedict = 0, t.flags = -1, t.dmax = 32768, t.head = null, t.hold = 0, t.bits = 0, t.lencode = t.lendyn = new Int32Array(qn), t.distcode = t.distdyn = new Int32Array(Jn), t.sane = 1, t.back = -1, q;
}, er = (e) => {
	if (Qn(e)) return J;
	let t = e.state;
	return t.wsize = 0, t.whave = 0, t.wnext = 0, $n(e);
}, tr = (e, t) => {
	let n;
	if (Qn(e)) return J;
	let r = e.state;
	return t < 0 ? (n = 0, t = -t) : (n = (t >> 4) + 5, t < 48 && (t &= 15)), t && (t < 8 || t > 15) ? J : (r.window !== null && r.wbits !== t && (r.window = null), r.wrap = n, r.wbits = t, er(e));
}, nr = (e, t) => {
	if (!e) return J;
	let n = new Zn();
	e.state = n, n.strm = e, n.window = null, n.mode = _n;
	let r = tr(e, t);
	return r !== q && (e.state = null), r;
}, rr = (e) => nr(e, Yn), ir = !0, ar, or, sr = (e) => {
	if (ir) {
		ar = /* @__PURE__ */ new Int32Array(512), or = /* @__PURE__ */ new Int32Array(32);
		let t = 0;
		for (; t < 144;) e.lens[t++] = 8;
		for (; t < 256;) e.lens[t++] = 9;
		for (; t < 280;) e.lens[t++] = 7;
		for (; t < 288;) e.lens[t++] = 8;
		for (rn(on, e.lens, 0, 288, ar, 0, e.work, { bits: 9 }), t = 0; t < 32;) e.lens[t++] = 5;
		rn(sn, e.lens, 0, 32, or, 0, e.work, { bits: 5 }), ir = !1;
	}
	e.lencode = ar, e.lenbits = 9, e.distcode = or, e.distbits = 5;
}, cr = (e, t, n, r) => {
	let i, a = e.state;
	return a.window === null && (a.window = new Uint8Array(1 << a.wbits)), a.wsize === 0 && (a.wsize = 1 << a.wbits, a.wnext = 0, a.whave = 0), r >= a.wsize ? (a.window.set(t.subarray(n - a.wsize, n), 0), a.wnext = 0, a.whave = a.wsize) : (i = a.wsize - a.wnext, i > r && (i = r), a.window.set(t.subarray(n - r, n - r + i), a.wnext), r -= i, r ? (a.window.set(t.subarray(n - r, n), 0), a.wnext = r, a.whave = a.wsize) : (a.wnext += i, a.wnext === a.wsize && (a.wnext = 0), a.whave < a.wsize && (a.whave += i))), 0;
}, Z = {
	inflateReset: er,
	inflateReset2: tr,
	inflateResetKeep: $n,
	inflateInit: rr,
	inflateInit2: nr,
	inflate: (e, t) => {
		let n, r, i, a, o, s, c, l, u, d, f, p, m, h, g = 0, _, v, y, b, x, S, C, w, T = /* @__PURE__ */ new Uint8Array(4), E, D, O = new Uint8Array([
			16,
			17,
			18,
			0,
			8,
			7,
			9,
			6,
			10,
			5,
			11,
			4,
			12,
			3,
			13,
			2,
			14,
			1,
			15
		]);
		if (Qn(e) || !e.output || !e.input && e.avail_in !== 0) return J;
		n = e.state, n.mode === Y && (n.mode = On), o = e.next_out, i = e.output, c = e.avail_out, a = e.next_in, r = e.input, s = e.avail_in, l = n.hold, u = n.bits, d = s, f = c, w = q;
		inf_leave: for (;;) switch (n.mode) {
			case _n:
				if (n.wrap === 0) {
					n.mode = On;
					break;
				}
				for (; u < 16;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				if (n.wrap & 2 && l === 35615) {
					n.wbits === 0 && (n.wbits = 15), n.check = 0, T[0] = l & 255, T[1] = l >>> 8 & 255, n.check = A(n.check, T, 2, 0), l = 0, u = 0, n.mode = vn;
					break;
				}
				if (n.head && (n.head.done = !1), !(n.wrap & 1) || (((l & 255) << 8) + (l >> 8)) % 31) {
					e.msg = "incorrect header check", n.mode = X;
					break;
				}
				if ((l & 15) !== gn) {
					e.msg = "unknown compression method", n.mode = X;
					break;
				}
				if (l >>>= 4, u -= 4, C = (l & 15) + 8, n.wbits === 0 && (n.wbits = C), C > 15 || C > n.wbits) {
					e.msg = "invalid window size", n.mode = X;
					break;
				}
				n.dmax = 1 << n.wbits, n.flags = 0, e.adler = n.check = 1, n.mode = l & 512 ? En : Y, l = 0, u = 0;
				break;
			case vn:
				for (; u < 16;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				if (n.flags = l, (n.flags & 255) !== gn) {
					e.msg = "unknown compression method", n.mode = X;
					break;
				}
				if (n.flags & 57344) {
					e.msg = "unknown header flags set", n.mode = X;
					break;
				}
				n.head && (n.head.text = l >> 8 & 1), n.flags & 512 && n.wrap & 4 && (T[0] = l & 255, T[1] = l >>> 8 & 255, n.check = A(n.check, T, 2, 0)), l = 0, u = 0, n.mode = yn;
			case yn:
				for (; u < 32;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				n.head && (n.head.time = l), n.flags & 512 && n.wrap & 4 && (T[0] = l & 255, T[1] = l >>> 8 & 255, T[2] = l >>> 16 & 255, T[3] = l >>> 24 & 255, n.check = A(n.check, T, 4, 0)), l = 0, u = 0, n.mode = bn;
			case bn:
				for (; u < 16;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				n.head && (n.head.xflags = l & 255, n.head.os = l >> 8), n.flags & 512 && n.wrap & 4 && (T[0] = l & 255, T[1] = l >>> 8 & 255, n.check = A(n.check, T, 2, 0)), l = 0, u = 0, n.mode = xn;
			case xn:
				if (n.flags & 1024) {
					for (; u < 16;) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					n.length = l, n.head && (n.head.extra_len = l), n.flags & 512 && n.wrap & 4 && (T[0] = l & 255, T[1] = l >>> 8 & 255, n.check = A(n.check, T, 2, 0)), l = 0, u = 0;
				} else n.head && (n.head.extra = null);
				n.mode = Sn;
			case Sn:
				if (n.flags & 1024 && (p = n.length, p > s && (p = s), p && (n.head && (C = n.head.extra_len - n.length, n.head.extra || (n.head.extra = new Uint8Array(n.head.extra_len)), n.head.extra.set(r.subarray(a, a + p), C)), n.flags & 512 && n.wrap & 4 && (n.check = A(n.check, r, p, a)), s -= p, a += p, n.length -= p), n.length)) break inf_leave;
				n.length = 0, n.mode = Cn;
			case Cn:
				if (n.flags & 2048) {
					if (s === 0) break inf_leave;
					p = 0;
					do
						C = r[a + p++], n.head && C && n.length < 65536 && (n.head.name += String.fromCharCode(C));
					while (C && p < s);
					if (n.flags & 512 && n.wrap & 4 && (n.check = A(n.check, r, p, a)), s -= p, a += p, C) break inf_leave;
				} else n.head && (n.head.name = null);
				n.length = 0, n.mode = wn;
			case wn:
				if (n.flags & 4096) {
					if (s === 0) break inf_leave;
					p = 0;
					do
						C = r[a + p++], n.head && C && n.length < 65536 && (n.head.comment += String.fromCharCode(C));
					while (C && p < s);
					if (n.flags & 512 && n.wrap & 4 && (n.check = A(n.check, r, p, a)), s -= p, a += p, C) break inf_leave;
				} else n.head && (n.head.comment = null);
				n.mode = Tn;
			case Tn:
				if (n.flags & 512) {
					for (; u < 16;) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					if (n.wrap & 4 && l !== (n.check & 65535)) {
						e.msg = "header crc mismatch", n.mode = X;
						break;
					}
					l = 0, u = 0;
				}
				n.head && (n.head.hcrc = n.flags >> 9 & 1, n.head.done = !0), e.adler = n.check = 0, n.mode = Y;
				break;
			case En:
				for (; u < 32;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				e.adler = n.check = Xn(l), l = 0, u = 0, n.mode = Dn;
			case Dn:
				if (n.havedict === 0) return e.next_out = o, e.avail_out = c, e.next_in = a, e.avail_in = s, n.hold = l, n.bits = u, fn;
				e.adler = n.check = 1, n.mode = Y;
			case Y: if (t === ln || t === un) break inf_leave;
			case On:
				if (n.last) {
					l >>>= u & 7, u -= u & 7, n.mode = Hn;
					break;
				}
				for (; u < 3;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				switch (n.last = l & 1, l >>>= 1, --u, l & 3) {
					case 0:
						n.mode = kn;
						break;
					case 1:
						if (sr(n), n.mode = Fn, t === un) {
							l >>>= 2, u -= 2;
							break inf_leave;
						}
						break;
					case 2:
						n.mode = Mn;
						break;
					case 3: e.msg = "invalid block type", n.mode = X;
				}
				l >>>= 2, u -= 2;
				break;
			case kn:
				for (l >>>= u & 7, u -= u & 7; u < 32;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				if ((l & 65535) != (l >>> 16 ^ 65535)) {
					e.msg = "invalid stored block lengths", n.mode = X;
					break;
				}
				if (n.length = l & 65535, l = 0, u = 0, n.mode = An, t === un) break inf_leave;
			case An: n.mode = jn;
			case jn:
				if (p = n.length, p) {
					if (p > s && (p = s), p > c && (p = c), p === 0) break inf_leave;
					i.set(r.subarray(a, a + p), o), s -= p, a += p, c -= p, o += p, n.length -= p;
					break;
				}
				n.mode = Y;
				break;
			case Mn:
				for (; u < 14;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				if (n.nlen = (l & 31) + 257, l >>>= 5, u -= 5, n.ndist = (l & 31) + 1, l >>>= 5, u -= 5, n.ncode = (l & 15) + 4, l >>>= 4, u -= 4, n.nlen > 286 || n.ndist > 30) {
					e.msg = "too many length or distance symbols", n.mode = X;
					break;
				}
				n.have = 0, n.mode = Nn;
			case Nn:
				for (; n.have < n.ncode;) {
					for (; u < 3;) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					n.lens[O[n.have++]] = l & 7, l >>>= 3, u -= 3;
				}
				for (; n.have < 19;) n.lens[O[n.have++]] = 0;
				if (n.lencode = n.lendyn, n.lenbits = 7, E = { bits: n.lenbits }, w = rn(an, n.lens, 0, 19, n.lencode, 0, n.work, E), n.lenbits = E.bits, w) {
					e.msg = "invalid code lengths set", n.mode = X;
					break;
				}
				n.have = 0, n.mode = Pn;
			case Pn:
				for (; n.have < n.nlen + n.ndist;) {
					for (; g = n.lencode[l & (1 << n.lenbits) - 1], _ = g >>> 24, v = g >>> 16 & 255, y = g & 65535, !(_ <= u);) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					if (y < 16) l >>>= _, u -= _, n.lens[n.have++] = y;
					else {
						if (y === 16) {
							for (D = _ + 2; u < D;) {
								if (s === 0) break inf_leave;
								s--, l += r[a++] << u, u += 8;
							}
							if (l >>>= _, u -= _, n.have === 0) {
								e.msg = "invalid bit length repeat", n.mode = X;
								break;
							}
							C = n.lens[n.have - 1], p = 3 + (l & 3), l >>>= 2, u -= 2;
						} else if (y === 17) {
							for (D = _ + 3; u < D;) {
								if (s === 0) break inf_leave;
								s--, l += r[a++] << u, u += 8;
							}
							l >>>= _, u -= _, C = 0, p = 3 + (l & 7), l >>>= 3, u -= 3;
						} else {
							for (D = _ + 7; u < D;) {
								if (s === 0) break inf_leave;
								s--, l += r[a++] << u, u += 8;
							}
							l >>>= _, u -= _, C = 0, p = 11 + (l & 127), l >>>= 7, u -= 7;
						}
						if (n.have + p > n.nlen + n.ndist) {
							e.msg = "invalid bit length repeat", n.mode = X;
							break;
						}
						for (; p--;) n.lens[n.have++] = C;
					}
				}
				if (n.mode === X) break;
				if (n.lens[256] === 0) {
					e.msg = "invalid code -- missing end-of-block", n.mode = X;
					break;
				}
				if (n.lenbits = 9, E = { bits: n.lenbits }, w = rn(on, n.lens, 0, n.nlen, n.lencode, 0, n.work, E), n.lenbits = E.bits, w) {
					e.msg = "invalid literal/lengths set", n.mode = X;
					break;
				}
				if (n.distbits = 6, n.distcode = n.distdyn, E = { bits: n.distbits }, w = rn(sn, n.lens, n.nlen, n.ndist, n.distcode, 0, n.work, E), n.distbits = E.bits, w) {
					e.msg = "invalid distances set", n.mode = X;
					break;
				}
				if (n.mode = Fn, t === un) break inf_leave;
			case Fn: n.mode = In;
			case In:
				if (s >= 6 && c >= 258) {
					e.next_out = o, e.avail_out = c, e.next_in = a, e.avail_in = s, n.hold = l, n.bits = u, Kt(e, f), o = e.next_out, i = e.output, c = e.avail_out, a = e.next_in, r = e.input, s = e.avail_in, l = n.hold, u = n.bits, n.mode === Y && (n.back = -1);
					break;
				}
				for (n.back = 0; g = n.lencode[l & (1 << n.lenbits) - 1], _ = g >>> 24, v = g >>> 16 & 255, y = g & 65535, !(_ <= u);) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				if (v && !(v & 240)) {
					for (b = _, x = v, S = y; g = n.lencode[S + ((l & (1 << b + x) - 1) >> b)], _ = g >>> 24, v = g >>> 16 & 255, y = g & 65535, !(b + _ <= u);) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					l >>>= b, u -= b, n.back += b;
				}
				if (l >>>= _, u -= _, n.back += _, n.length = y, v === 0) {
					n.mode = Vn;
					break;
				}
				if (v & 32) {
					n.back = -1, n.mode = Y;
					break;
				}
				if (v & 64) {
					e.msg = "invalid literal/length code", n.mode = X;
					break;
				}
				n.extra = v & 15, n.mode = Ln;
			case Ln:
				if (n.extra) {
					for (D = n.extra; u < D;) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					n.length += l & (1 << n.extra) - 1, l >>>= n.extra, u -= n.extra, n.back += n.extra;
				}
				n.was = n.length, n.mode = Rn;
			case Rn:
				for (; g = n.distcode[l & (1 << n.distbits) - 1], _ = g >>> 24, v = g >>> 16 & 255, y = g & 65535, !(_ <= u);) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				if (!(v & 240)) {
					for (b = _, x = v, S = y; g = n.distcode[S + ((l & (1 << b + x) - 1) >> b)], _ = g >>> 24, v = g >>> 16 & 255, y = g & 65535, !(b + _ <= u);) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					l >>>= b, u -= b, n.back += b;
				}
				if (l >>>= _, u -= _, n.back += _, v & 64) {
					e.msg = "invalid distance code", n.mode = X;
					break;
				}
				n.offset = y, n.extra = v & 15, n.mode = zn;
			case zn:
				if (n.extra) {
					for (D = n.extra; u < D;) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					n.offset += l & (1 << n.extra) - 1, l >>>= n.extra, u -= n.extra, n.back += n.extra;
				}
				if (n.offset > n.dmax) {
					e.msg = "invalid distance too far back", n.mode = X;
					break;
				}
				n.mode = Bn;
			case Bn:
				if (c === 0) break inf_leave;
				if (p = f - c, n.offset > p) {
					if (p = n.offset - p, p > n.whave && n.sane) {
						e.msg = "invalid distance too far back", n.mode = X;
						break;
					}
					p > n.wnext ? (p -= n.wnext, m = n.wsize - p) : m = n.wnext - p, p > n.length && (p = n.length), h = n.window;
				} else h = i, m = o - n.offset, p = n.length;
				p > c && (p = c), c -= p, n.length -= p;
				do
					i[o++] = h[m++];
				while (--p);
				n.length === 0 && (n.mode = In);
				break;
			case Vn:
				if (c === 0) break inf_leave;
				i[o++] = n.length, c--, n.mode = In;
				break;
			case Hn:
				if (n.wrap) {
					for (; u < 32;) {
						if (s === 0) break inf_leave;
						s--, l |= r[a++] << u, u += 8;
					}
					if (f -= c, e.total_out += f, n.total += f, n.wrap & 4 && f && (e.adler = n.check = n.flags ? A(n.check, i, f, o - f) : pe(n.check, i, f, o - f)), f = c, n.wrap & 4 && (n.flags ? l : Xn(l)) !== n.check) {
						e.msg = "incorrect data check", n.mode = X;
						break;
					}
					l = 0, u = 0;
				}
				n.mode = Un;
			case Un:
				if (n.wrap && n.flags) {
					for (; u < 32;) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					if (n.wrap & 4 && l !== (n.total | 0)) {
						e.msg = "incorrect length check", n.mode = X;
						break;
					}
					l = 0, u = 0;
				}
				n.mode = Wn;
			case Wn:
				w = dn;
				break inf_leave;
			case X:
				w = pn;
				break inf_leave;
			case Gn: return mn;
			case Kn:
			default: return J;
		}
		return e.next_out = o, e.avail_out = c, e.next_in = a, e.avail_in = s, n.hold = l, n.bits = u, (n.wsize || f !== e.avail_out && n.mode < X && (n.mode < Hn || t !== cn)) && cr(e, e.output, e.next_out, f - e.avail_out), d -= e.avail_in, f -= e.avail_out, e.total_in += d, e.total_out += f, n.total += f, n.wrap & 4 && f && (e.adler = n.check = n.flags ? A(n.check, i, f, e.next_out - f) : pe(n.check, i, f, e.next_out - f)), e.data_type = n.bits + (n.last ? 64 : 0) + (n.mode === Y ? 128 : 0) + (n.mode === Fn || n.mode === An ? 256 : 0), (d === 0 && f === 0 || t === cn) && w === q && (w = hn), w;
	},
	inflateEnd: (e) => {
		if (Qn(e)) return J;
		let t = e.state;
		return t.window &&= null, e.state = null, q;
	},
	inflateGetHeader: (e, t) => {
		if (Qn(e)) return J;
		let n = e.state;
		return n.wrap & 2 ? (n.head = t, t.done = !1, q) : J;
	},
	inflateSetDictionary: (e, t) => {
		let n = t.length, r, i, a;
		return Qn(e) || (r = e.state, r.wrap !== 0 && r.mode !== Dn) ? J : r.mode === Dn && (i = 1, i = pe(i, t, n, 0), i !== r.check) ? pn : (a = cr(e, t, n, n), a ? (r.mode = Gn, mn) : (r.havedict = 1, q));
	},
	inflateInfo: "pako inflate (from Nodeca project)"
};
function lr() {
	this.text = 0, this.time = 0, this.xflags = 0, this.os = 0, this.extra = null, this.extra_len = 0, this.name = "", this.comment = "", this.hcrc = 0, this.done = !1;
}
var ur = lr, dr = Object.prototype.toString, { Z_NO_FLUSH: fr, Z_FINISH: pr, Z_OK: mr, Z_STREAM_END: hr, Z_NEED_DICT: gr, Z_STREAM_ERROR: _r, Z_DATA_ERROR: vr, Z_MEM_ERROR: yr, Z_BUF_ERROR: br } = ge, xr = {
	chunkSize: 65536,
	windowBits: 15,
	to: ""
};
function Sr(e) {
	this.options = bt.assign({}, xr, e || {});
	let t = this.options;
	t.raw && t.windowBits >= 0 && t.windowBits < 16 && (t.windowBits = -t.windowBits, t.windowBits === 0 && (t.windowBits = -15)), t.windowBits >= 0 && t.windowBits < 16 && !(e && e.windowBits) && (t.windowBits += 32), t.windowBits > 15 && t.windowBits < 48 && (t.windowBits & 15 || (t.windowBits |= 15)), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new Dt(), this.strm.avail_out = 0;
	let n = Z.inflateInit2(this.strm, t.windowBits);
	if (n !== mr || (this.header = new ur(), Z.inflateGetHeader(this.strm, this.header), t.dictionary && (typeof t.dictionary == "string" ? t.dictionary = Tt.string2buf(t.dictionary) : dr.call(t.dictionary) === "[object ArrayBuffer]" && (t.dictionary = new Uint8Array(t.dictionary)), t.raw && (n = Z.inflateSetDictionary(this.strm, t.dictionary), n !== mr)))) throw Error(he[n]);
}
Sr.prototype.push = function(e, t) {
	let n = this.strm, r = this.options.chunkSize, i = this.options.dictionary, a, o, s;
	if (this.ended) return !1;
	for (o = t === ~~t ? t : t === !0 ? pr : fr, n.input = dr.call(e) === "[object ArrayBuffer]" ? new Uint8Array(e) : e, n.next_in = 0, n.avail_in = n.input.length;;) {
		for (n.avail_out === 0 && (n.output = new Uint8Array(r), n.next_out = 0, n.avail_out = r), a = Z.inflate(n, o), a === gr && i && (a = Z.inflateSetDictionary(n, i), a === mr ? a = Z.inflate(n, o) : a === vr && (a = gr)); n.avail_in > 0 && a === hr && n.state.wrap & 2 && n.state.flags !== 0 && n.input[n.next_in] !== 0;) Z.inflateReset(n), a = Z.inflate(n, o);
		switch (a) {
			case _r:
			case vr:
			case gr:
			case yr: return this.onEnd(a), this.ended = !0, !1;
		}
		if (s = n.avail_out, n.next_out && (n.avail_out === 0 || a === hr || o > 0)) {
			if (this.options.to === "string") {
				let e = Tt.utf8border(n.output, n.next_out), t = n.next_out - e, i = Tt.buf2string(n.output, e);
				n.next_out = t, n.avail_out = r - t, t && n.output.set(n.output.subarray(e, e + t), 0), this.onData(i);
			} else this.onData(n.output.length === n.next_out ? n.output : n.output.subarray(0, n.next_out)), n.avail_out = 0, n.next_out = 0;
		}
		if (a !== mr && a !== br || s !== 0) {
			if (a === hr) return a = Z.inflateEnd(this.strm), this.onEnd(a), this.ended = !0, !0;
			if (n.avail_in === 0) {
				if (o === pr) return a = Z.inflateEnd(this.strm), this.onEnd(a === mr ? br : a), this.ended = !0, !1;
				break;
			}
		}
	}
	return !0;
}, Sr.prototype.onData = function(e) {
	this.chunks.push(e);
}, Sr.prototype.onEnd = function(e) {
	e === mr && (this.result = this.options.to === "string" ? this.chunks.join("") : bt.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg;
};
function Cr(e, t) {
	let n = new Sr(t);
	if (n.push(e, !0), n.err) throw n.msg || he[n.err];
	return n.result;
}
function wr(e, t) {
	return t ||= {}, t.raw = !0, Cr(e, t);
}
var Tr = {
	Inflate: Sr,
	inflate: Cr,
	inflateRaw: wr,
	ungzip: Cr,
	constants: ge
}, { Deflate: Er, deflate: Dr, deflateRaw: Or, gzip: kr } = Ut, { Inflate: Ar, inflate: jr, inflateRaw: Mr, ungzip: Nr } = Tr, Pr = (e) => ({
	words: [],
	translatedLyric: "",
	romanLyric: "",
	isBG: !1,
	isDuet: !1,
	startTime: 0,
	endTime: 0,
	...e
}), Fr = (e) => ({
	startTime: 0,
	endTime: 0,
	word: "",
	...e
}), Ir = (e) => Math.round(e.split(":").map(Number).reverse().reduce((e, t, n) => e + t * 60 ** n, 0) * 1e3), Lr = (e) => `${Math.floor(e / 6e4).toString().padStart(2, "0")}:${Math.floor(e % 6e4 / 1e3).toString().padStart(2, "0")}.${Math.round(e % 1e3).toString().padStart(3, "0")}`, Q = (e) => !Number.isFinite(e) || e < 0 ? 0 : e, Rr = (e) => !Number.isFinite(e) || e < 0 ? 0 : e, zr = 60039999, Br = (e, t = zr) => Math.min(t, Q(e)), Vr = new TextEncoder().encode("!@#)(*$%"), Hr = new TextEncoder().encode("123ZXC!@"), Ur = new TextEncoder().encode("!@#)(NHL"), Wr = [
	[
		14,
		4,
		13,
		1,
		2,
		15,
		11,
		8,
		3,
		10,
		6,
		12,
		5,
		9,
		0,
		7,
		0,
		15,
		7,
		4,
		14,
		2,
		13,
		1,
		10,
		6,
		12,
		11,
		9,
		5,
		3,
		8,
		4,
		1,
		14,
		8,
		13,
		6,
		2,
		11,
		15,
		12,
		9,
		7,
		3,
		10,
		5,
		0,
		15,
		12,
		8,
		2,
		4,
		9,
		1,
		7,
		5,
		11,
		3,
		14,
		10,
		0,
		6,
		13
	],
	[
		15,
		1,
		8,
		14,
		6,
		11,
		3,
		4,
		9,
		7,
		2,
		13,
		12,
		0,
		5,
		10,
		3,
		13,
		4,
		7,
		15,
		2,
		8,
		15,
		12,
		0,
		1,
		10,
		6,
		9,
		11,
		5,
		0,
		14,
		7,
		11,
		10,
		4,
		13,
		1,
		5,
		8,
		12,
		6,
		9,
		3,
		2,
		15,
		13,
		8,
		10,
		1,
		3,
		15,
		4,
		2,
		11,
		6,
		7,
		12,
		0,
		5,
		14,
		9
	],
	[
		10,
		0,
		9,
		14,
		6,
		3,
		15,
		5,
		1,
		13,
		12,
		7,
		11,
		4,
		2,
		8,
		13,
		7,
		0,
		9,
		3,
		4,
		6,
		10,
		2,
		8,
		5,
		14,
		12,
		11,
		15,
		1,
		13,
		6,
		4,
		9,
		8,
		15,
		3,
		0,
		11,
		1,
		2,
		12,
		5,
		10,
		14,
		7,
		1,
		10,
		13,
		0,
		6,
		9,
		8,
		7,
		4,
		15,
		14,
		3,
		11,
		5,
		2,
		12
	],
	[
		7,
		13,
		14,
		3,
		0,
		6,
		9,
		10,
		1,
		2,
		8,
		5,
		11,
		12,
		4,
		15,
		13,
		8,
		11,
		5,
		6,
		15,
		0,
		3,
		4,
		7,
		2,
		12,
		1,
		10,
		14,
		9,
		10,
		6,
		9,
		0,
		12,
		11,
		7,
		13,
		15,
		1,
		3,
		14,
		5,
		2,
		8,
		4,
		3,
		15,
		0,
		6,
		10,
		10,
		13,
		8,
		9,
		4,
		5,
		11,
		12,
		7,
		2,
		14
	],
	[
		2,
		12,
		4,
		1,
		7,
		10,
		11,
		6,
		8,
		5,
		3,
		15,
		13,
		0,
		14,
		9,
		14,
		11,
		2,
		12,
		4,
		7,
		13,
		1,
		5,
		0,
		15,
		10,
		3,
		9,
		8,
		6,
		4,
		2,
		1,
		11,
		10,
		13,
		7,
		8,
		15,
		9,
		12,
		5,
		6,
		3,
		0,
		14,
		11,
		8,
		12,
		7,
		1,
		14,
		2,
		13,
		6,
		15,
		0,
		9,
		10,
		4,
		5,
		3
	],
	[
		12,
		1,
		10,
		15,
		9,
		2,
		6,
		8,
		0,
		13,
		3,
		4,
		14,
		7,
		5,
		11,
		10,
		15,
		4,
		2,
		7,
		12,
		9,
		5,
		6,
		1,
		13,
		14,
		0,
		11,
		3,
		8,
		9,
		14,
		15,
		5,
		2,
		8,
		12,
		3,
		7,
		0,
		4,
		10,
		1,
		13,
		11,
		6,
		4,
		3,
		2,
		12,
		9,
		5,
		15,
		10,
		11,
		14,
		1,
		7,
		6,
		0,
		8,
		13
	],
	[
		4,
		11,
		2,
		14,
		15,
		0,
		8,
		13,
		3,
		12,
		9,
		7,
		5,
		10,
		6,
		1,
		13,
		0,
		11,
		7,
		4,
		9,
		1,
		10,
		14,
		3,
		5,
		12,
		2,
		15,
		8,
		6,
		1,
		4,
		11,
		13,
		12,
		3,
		7,
		14,
		10,
		15,
		6,
		8,
		0,
		5,
		9,
		2,
		6,
		11,
		13,
		8,
		1,
		4,
		10,
		7,
		9,
		5,
		0,
		15,
		14,
		2,
		3,
		12
	],
	[
		13,
		2,
		8,
		4,
		6,
		15,
		11,
		1,
		10,
		9,
		3,
		14,
		5,
		0,
		12,
		7,
		1,
		15,
		13,
		8,
		10,
		3,
		7,
		4,
		12,
		5,
		6,
		11,
		0,
		14,
		9,
		2,
		7,
		11,
		4,
		1,
		9,
		12,
		14,
		2,
		0,
		6,
		10,
		13,
		15,
		3,
		5,
		8,
		2,
		1,
		14,
		7,
		4,
		10,
		8,
		13,
		15,
		12,
		9,
		0,
		3,
		5,
		6,
		11
	]
], Gr = [
	16,
	7,
	20,
	21,
	29,
	12,
	28,
	17,
	1,
	15,
	23,
	26,
	5,
	18,
	31,
	10,
	2,
	8,
	24,
	14,
	32,
	27,
	3,
	9,
	19,
	13,
	30,
	6,
	22,
	11,
	4,
	25
], Kr = [
	32,
	1,
	2,
	3,
	4,
	5,
	4,
	5,
	6,
	7,
	8,
	9,
	8,
	9,
	10,
	11,
	12,
	13,
	12,
	13,
	14,
	15,
	16,
	17,
	16,
	17,
	18,
	19,
	20,
	21,
	20,
	21,
	22,
	23,
	24,
	25,
	24,
	25,
	26,
	27,
	28,
	29,
	28,
	29,
	30,
	31,
	32,
	1
], qr = [
	1,
	1,
	2,
	2,
	2,
	2,
	2,
	2,
	1,
	2,
	2,
	2,
	2,
	2,
	2,
	1
], Jr = [
	56,
	48,
	40,
	32,
	24,
	16,
	8,
	0,
	57,
	49,
	41,
	33,
	25,
	17,
	9,
	1,
	58,
	50,
	42,
	34,
	26,
	18,
	10,
	2,
	59,
	51,
	43,
	35
], Yr = [
	62,
	54,
	46,
	38,
	30,
	22,
	14,
	6,
	61,
	53,
	45,
	37,
	29,
	21,
	13,
	5,
	60,
	52,
	44,
	36,
	28,
	20,
	12,
	4,
	27,
	19,
	11,
	3
], Xr = [
	13,
	16,
	10,
	23,
	0,
	4,
	2,
	27,
	14,
	5,
	20,
	9,
	22,
	18,
	11,
	3,
	25,
	7,
	15,
	6,
	26,
	19,
	12,
	1,
	40,
	51,
	30,
	36,
	46,
	54,
	29,
	39,
	50,
	44,
	32,
	47,
	43,
	48,
	38,
	55,
	33,
	52,
	45,
	41,
	49,
	35,
	28,
	31
];
function Zr(e, t) {
	let n = 0n, r = 1n << BigInt(t.length - 1);
	for (let i = 0; i < t.length; i++) {
		let a = t[i], o = a >> 5, s = a & 31, c = s >> 3, l = s & 7;
		e[o * 4 + 3 - c] >> 7 - l & 1 && (n |= r), r >>= 1n;
	}
	return n;
}
function Qr(e, t) {
	let n = 4294967280n, r = e & n;
	return (r << BigInt(t) | r >> BigInt(28 - t)) & n;
}
function $r(e, t) {
	let n = /* @__PURE__ */ new Int32Array(32), r = Zr(e, Jr), i = Zr(e, Yr), a = r << 4n, o = i << 4n;
	for (let e = 0; e < 16; e++) {
		let r = qr[e];
		a = Qr(a, r), o = Qr(o, r);
		let i = t === 1 ? 15 - e : e, s = 0n;
		for (let e = 0; e < Xr.length; e++) {
			let t = Xr[e];
			(t < 28 ? a >> BigInt(31 - t) & 1n : o >> BigInt(31 - (t - 27)) & 1n) == 1n && (s |= 1n << BigInt(47 - e));
		}
		let c = Number(s >> 40n & 255n), l = Number(s >> 32n & 255n), u = Number(s >> 24n & 255n), d = c << 16 | l << 8 | u, f = Number(s >> 16n & 255n), p = Number(s >> 8n & 255n), m = Number(s & 255n), h = f << 16 | p << 8 | m;
		n[i * 2] = d, n[i * 2 + 1] = h;
	}
	return n;
}
var ei = [
	34,
	42,
	50,
	58,
	2,
	10,
	18,
	26,
	36,
	44,
	52,
	60,
	4,
	12,
	20,
	28,
	38,
	46,
	54,
	62,
	6,
	14,
	22,
	30,
	40,
	48,
	56,
	64,
	8,
	16,
	24,
	32,
	33,
	41,
	49,
	57,
	1,
	9,
	17,
	25,
	35,
	43,
	51,
	59,
	3,
	11,
	19,
	27,
	37,
	45,
	53,
	61,
	5,
	13,
	21,
	29,
	39,
	47,
	55,
	63,
	7,
	15,
	23,
	31
], ti = [
	37,
	5,
	45,
	13,
	53,
	21,
	61,
	29,
	38,
	6,
	46,
	14,
	54,
	22,
	62,
	30,
	39,
	7,
	47,
	15,
	55,
	23,
	63,
	31,
	40,
	8,
	48,
	16,
	56,
	24,
	64,
	32,
	33,
	1,
	41,
	9,
	49,
	17,
	57,
	25,
	34,
	2,
	42,
	10,
	50,
	18,
	58,
	26,
	35,
	3,
	43,
	11,
	51,
	19,
	59,
	27,
	36,
	4,
	44,
	12,
	52,
	20,
	60,
	28
], ni = /* @__PURE__ */ new Int32Array(2048), ri = /* @__PURE__ */ new Int32Array(2048), ii = /* @__PURE__ */ new Int32Array(2048), ai = /* @__PURE__ */ new Int32Array(2048);
function oi() {
	let e = (e, t) => {
		let n = 0n;
		for (let r = 0; r < 64; r++) {
			let i = t[r];
			e >> BigInt(64 - i) & 1n && (n |= 1n << BigInt(63 - r));
		}
		return n;
	};
	for (let t = 0; t < 8; t++) for (let n = 0; n < 256; n++) {
		let r = e(BigInt(n) << BigInt(56 - t * 8), ei), i = t << 8 | n;
		ni[i] = Number(r >> 32n & 4294967295n), ri[i] = Number(r & 4294967295n);
	}
	for (let t = 0; t < 8; t++) for (let n = 0; n < 256; n++) {
		let r = e(BigInt(n) << BigInt(56 - t * 8), ti), i = t << 8 | n;
		ii[i] = Number(r >> 32n & 4294967295n), ai[i] = Number(r & 4294967295n);
	}
}
oi();
function si(e) {
	return e & 32 | (e & 31) >> 1 | (e & 1) << 4;
}
function ci(e) {
	let t = 0;
	for (let n = 0; n < 32; n++) {
		let r = Gr[n], i = 1 << 31 - n;
		e & 1 << 32 - r && (t |= i);
	}
	return t;
}
var $ = /* @__PURE__ */ new Int32Array(512);
function li() {
	for (let e = 0; e < 8; e++) for (let t = 0; t < 64; t++) {
		let n = si(t), r = Wr[e][n] << 28 - e * 4;
		$[e << 6 | t] = ci(r);
	}
}
li();
var ui = /* @__PURE__ */ new Int32Array(1024), di = /* @__PURE__ */ new Int32Array(1024);
function fi() {
	for (let e = 0; e < 4; e++) {
		let t = (3 - e) * 8;
		for (let n = 0; n < 256; n++) {
			let r = 0, i = 0, a = n << t;
			for (let e = 0; e < 24; e++) a >>> 32 - Kr[e] & 1 && (r |= 1 << 23 - e);
			for (let e = 24; e < 48; e++) a >>> 32 - Kr[e] & 1 && (i |= 1 << 47 - e);
			let o = e << 8 | n;
			ui[o] = r, di[o] = i;
		}
	}
}
fi();
function pi(e, t, n) {
	let r = e >>> 24 & 255, i = e >>> 16 & 255, a = e >>> 8 & 255, o = e & 255, s = ui[r] | ui[256 | i] | ui[512 | a] | ui[768 | o], c = di[r] | di[256 | i] | di[512 | a] | di[768 | o], l = s ^ t, u = c ^ n;
	return $[l >>> 18 & 63] | $[64 | l >>> 12 & 63] | $[128 | l >>> 6 & 63] | $[192 | l & 63] | $[256 | u >>> 18 & 63] | $[320 | u >>> 12 & 63] | $[384 | u >>> 6 & 63] | $[448 | u & 63];
}
function mi(e, t, n) {
	let r = 0, i = 0;
	for (let t = 0; t < 8; t++) {
		let n = t << 8 | e[t];
		r |= ni[n], i |= ri[n];
	}
	for (let e = 0; e < 15; e++) {
		let t = i;
		i = (r ^ pi(i, n[e * 2], n[e * 2 + 1])) >>> 0, r = t;
	}
	r = (r ^ pi(i, n[30], n[31])) >>> 0;
	let a = 0, o = 0;
	for (let e = 0; e < 4; e++) {
		let t = e << 8 | r >>> 24 - e * 8 & 255;
		a |= ii[t], o |= ai[t];
		let n = e + 4 << 8 | i >>> 24 - e * 8 & 255;
		a |= ii[n], o |= ai[n];
	}
	t[0] = a >>> 24 & 255, t[1] = a >>> 16 & 255, t[2] = a >>> 8 & 255, t[3] = a & 255, t[4] = o >>> 24 & 255, t[5] = o >>> 16 & 255, t[6] = o >>> 8 & 255, t[7] = o & 255;
}
new class {
	encryptSchedule;
	decryptSchedule;
	constructor() {
		this.decryptSchedule = [
			$r(Ur, 1),
			$r(Hr, 0),
			$r(Vr, 1)
		], this.encryptSchedule = [
			$r(Vr, 0),
			$r(Hr, 1),
			$r(Ur, 0)
		];
	}
	decryptBlock(e, t) {
		let n = /* @__PURE__ */ new Uint8Array(8), r = /* @__PURE__ */ new Uint8Array(8);
		mi(e, n, this.decryptSchedule[0]), mi(n, r, this.decryptSchedule[1]), mi(r, t, this.decryptSchedule[2]);
	}
	encryptBlock(e, t) {
		let n = /* @__PURE__ */ new Uint8Array(8), r = /* @__PURE__ */ new Uint8Array(8);
		mi(e, n, this.encryptSchedule[0]), mi(n, r, this.encryptSchedule[1]), mi(r, t, this.encryptSchedule[2]);
	}
}();
var hi = /^\[((?:\d+:)*\d+(?:\.\d+)?)\]/;
function gi(e) {
	let t = e.match(hi);
	if (!t) return null;
	let [n, r] = t;
	return {
		time: Ir(r),
		length: n.length
	};
}
function _i(e) {
	let t = e.trim(), n = gi(t);
	if (!n) return null;
	t = t.slice(n.length);
	let r = n.time;
	if (!t.trim()) return null;
	let i = [];
	for (; t.trim().length > 0;) {
		let e = t.indexOf("[");
		if (e <= 0) return null;
		let n = t.slice(0, e), a = gi(t.slice(e));
		if (!a) return null;
		i.push(Fr({
			word: n,
			startTime: r,
			endTime: a.time
		})), t = t.slice(e + a.length), r = a.time;
	}
	return Pr({ words: i });
}
function vi(e) {
	let t = [];
	for (let n of e.split(/\r?\n/)) {
		let e = _i(n);
		e && t.push(e);
	}
	t.sort((e, t) => (e.words[0]?.startTime ?? 2 ** 53 - 1) - (t.words[0]?.startTime ?? 2 ** 53 - 1));
	for (let e of t) {
		for (let t of e.words) t.startTime = Br(t.startTime), t.endTime = Br(t.endTime);
		e.startTime = Br(e.words[0]?.startTime ?? 0), e.endTime = Br(e.words[e.words.length - 1]?.endTime ?? 0);
	}
	return t;
}
function yi(e) {
	return e.map((e) => e.words.length ? `[${Lr(Br(e.words[0].startTime))}]${e.words.map((e) => `${e.word}[${Lr(Br(e.endTime))}]`).join("")}` : "").filter(Boolean).join("\n");
}
function bi(e) {
	return (e < 0 || e > 8) && (e = 0), {
		isDuet: e % 3 == 0 ? void 0 : e % 3 == 2,
		isBG: e <= 2 ? void 0 : e >= 6
	};
}
function xi(e) {
	let t = e.split(/\r?\n/).map((e) => e.trim()).filter((e) => e.length > 0), n = [], r = /^\[(\d+)\]/, i = /(.*?)\((\d+),(\d+)\)/g;
	for (let e of t) {
		let t = e.match(r);
		if (!t) continue;
		let [, a] = t, o = e.slice(t[0].length), s = [], c = bi(Number(a));
		for (let e of o.matchAll(i)) {
			let [, t, n, r] = e, i = Number(n), a = i + Number(r), o = t;
			s.push(Fr({
				word: o,
				startTime: i,
				endTime: a
			}));
		}
		let l = s[0]?.startTime ?? 0, u = s[s.length - 1]?.endTime ?? 0;
		s.length && (c.isBG === void 0 && (c.isBG = s.length > 0 && /^[(（]/.test(s[0].word) && /[）)]$/.test(s[s.length - 1].word)), c.isBG && s.length && (s[0].word = s[0].word.replace(/^[(（]/, ""), s[s.length - 1].word = s[s.length - 1].word.replace(/[）)]$/, "")), n.push(Pr({
			startTime: l,
			endTime: u,
			isDuet: !!c.isDuet,
			isBG: c.isBG,
			words: s
		})));
	}
	return n;
}
function Si(e) {
	let t = 0;
	return t += e.isDuet ? 2 : 1, t += e.isBG ? 6 : 3, t;
}
function Ci(e) {
	return e.map((e) => {
		let t = Si(e), n = [];
		return e.words.forEach((e) => {
			e.word.trim() || !n.length ? n.push({
				word: e.word,
				startTime: Q(e.startTime),
				duration: Rr(Q(e.endTime) - Q(e.startTime))
			}) : n[n.length - 1].word += e.word;
		}), `[${t}]${n.map((e) => `${e.word}(${e.startTime},${e.duration})`).join("")}`;
	}).join("\n");
}
function wi(e) {
	return e.map((e) => {
		let t = e.words.map((e) => e.word).join(""), n = e.isBG ? `(${t})` : t;
		return `[${Lr(Q(e.startTime))}]${n}`;
	}).join("\n");
}
function Ti(e) {
	let t = /(.*?)\((\d+),(\d+)\)/g, n = /^\[(\d+),(\d+)\]/;
	return e.split(/\r?\n/).map((e) => e.trim()).filter((e) => e.length > 0).map((e) => {
		let r = e.match(n);
		if (!r) return null;
		let [i, a, o] = r, s = Number(a), c = Number(o), l = [], u = e.slice(i.length).trim();
		if (!u) return null;
		for (let e of u.matchAll(t)) {
			let [, t, n, r] = e, i = Number(n), a = Number(r);
			l.push(Fr({
				word: t,
				startTime: i,
				endTime: i + a
			}));
		}
		let d = l.length > 0 && /^[(（]/.test(l[0].word) && /[）)]$/.test(l[l.length - 1].word);
		return d && (l[0].word = l[0].word.replace(/^[(（]/, ""), l[l.length - 1].word = l[l.length - 1].word.replace(/[）)]$/, "")), Pr({
			startTime: s,
			endTime: s + c,
			words: l,
			isBG: d
		});
	}).filter((e) => e !== null);
}
function Ei(e) {
	return e.map((e) => {
		let t = Q(e.startTime), n = Rr(Q(e.endTime) - t), r = [];
		for (let [t, { word: n, startTime: i, endTime: a }] of e.words.entries()) {
			if (!n.trim() && r.length) {
				r[r.length - 1] += n;
				continue;
			}
			let o = n;
			e.isBG && (t === 0 && (o = `（${o}`), t === e.words.length - 1 && (o += "）"));
			let s = Q(i), c = Rr(Q(a) - s);
			r.push(`${o}(${s},${c})`);
		}
		return `[${t},${n}]${r.join("")}`;
	}).join("\n");
}
var Di = /^[（(]/, Oi = /[）)]$/;
function ki(e) {
	return e.length > 0 && Di.test(e[0].word) && Oi.test(e[e.length - 1].word);
}
function Ai(e) {
	e[0].word = e[0].word.slice(1), e[e.length - 1].word = e[e.length - 1].word.slice(0, -1);
}
function ji(e) {
	let t = /^(.*?)\((\d+),(\d+),0\)/, n = /^\[(\d+),(\d+)\]/;
	return e.split(/\r?\n/).map((e) => e.trim()).filter((e) => e.length > 0).map((e) => {
		let r = e.match(n);
		if (!r) return null;
		let [i, a, o] = r, s = Number(a), c = Number(o), l = [], u = e.slice(i.length).trim();
		if (!u) return null;
		let d = -1, f = -1;
		for (;;) {
			let e = u.match(t);
			if (!e) break;
			let [n, r, i, a] = e;
			r && d !== -1 && l.push(Fr({
				word: r,
				startTime: d,
				endTime: f
			}));
			let o = Number(i), s = o + Number(a);
			[d, f] = [o, s], u = u.slice(n.length);
		}
		d !== -1 && u && l.push(Fr({
			word: u,
			startTime: d,
			endTime: f
		}));
		let p = ki(l);
		return p && Ai(l), Pr({
			startTime: s,
			endTime: s + c,
			words: l,
			isBG: p
		});
	}).filter((e) => e !== null);
}
function Mi(e) {
	return e.replace(/\(/g, "（").replace(/\)/g, "）");
}
function Ni(e) {
	return e.map((e) => {
		let t = Q(e.startTime), n = Rr(Q(e.endTime) - t), r = [];
		for (let [t, { word: n, startTime: i, endTime: a }] of e.words.entries()) {
			if (!n.trim() && r.length) {
				r[r.length - 1] += n;
				continue;
			}
			let o = Mi(n);
			e.isBG && (t === 0 && (o = `（${o}`), t === e.words.length - 1 && (o += "）"));
			let s = Q(i), c = Rr(Q(a) - s);
			r.push(`(${s},${c},0)${o}`);
		}
		return `[${t},${n}]${r.join("")}`;
	}).join("\n");
}
// src/lrc.ts
var Pi = (e, t, n) => ({
	words: [{
		text: e,
		startTime: t,
		endTime: n,
		emptyBeat: 0,
		romanText: ""
	}],
	translation: "",
	romanization: "",
	isBackground: !1,
	isDuet: !1,
	startTime: t,
	endTime: n,
	ignoreSync: !1
});
function Fi(e) {
	let t = e.split(/\r?\n/), n = [], r = /\[(\d{1,2}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g, i = 0;
	for (let e of t) {
		let t = e.replace(r, "").trim();
		for (let a of e.matchAll(r)) {
			let e = Number.parseInt(a[1], 10), r = Number.parseInt(a[2], 10), o = Number.parseFloat(a[3] ? `0.${a[3]}` : "0");
			n.push({
				time: Math.round((e * 60 + r + o) * 1e3),
				text: t,
				index: i++
			});
		}
	}
	n.sort((e, t) => e.time - t.time || e.index - t.index);
	let a = [], o = 0;
	for (; o < n.length;) {
		let e = n[o].time, t = [];
		for (; o < n.length && n[o].time === e;) t.push(n[o++]);
		let r = t.filter((e) => e.text.length > 0);
		if (r.length === 0) continue;
		let i = n[o]?.time ?? e + 1e4, s = Pi(r[0].text, e, i);
		s.translation = r[1]?.text ?? "", s.romanization = r[2]?.text ?? "", a.push(s);
		for (let t of r.slice(3)) a.push(Pi(t.text, e, i));
	}
	return a;
}
// src/index.ts
var Ii = "builtin.formats", Li = (e) => e.map((e) => ({
	words: e.words.map((e) => ({
		text: e.word,
		startTime: e.startTime,
		endTime: e.endTime,
		emptyBeat: 0,
		romanText: e.romanWord ?? ""
	})),
	translation: e.translatedLyric,
	romanization: e.romanLyric,
	isBackground: e.isBG,
	isDuet: e.isDuet,
	startTime: e.startTime,
	endTime: e.endTime,
	ignoreSync: !1
})), Ri = (e) => e.map((e) => ({
	words: e.words.map((e) => ({
		word: e.text,
		startTime: Math.round(e.startTime),
		endTime: Math.round(e.endTime),
		romanWord: e.romanText
	})),
	translatedLyric: e.translation,
	romanLyric: e.romanization,
	isBG: e.isBackground,
	isDuet: e.isDuet,
	startTime: Math.round(e.startTime),
	endTime: Math.round(e.endTime)
})), zi = [
	{
		id: "lrc",
		title: "LyRiC",
		order: 200,
		parse: Fi,
		stringify: wi
	},
	{
		id: "eslrc",
		title: "ESLyRiC",
		order: 300,
		parse: (e) => Li(vi(e)),
		stringify: yi
	},
	{
		id: "qrc",
		title: "QRC",
		order: 400,
		parse: (e) => Li(Ti(e)),
		stringify: Ei
	},
	{
		id: "yrc",
		title: "YRC",
		order: 500,
		parse: (e) => Li(ji(e)),
		stringify: Ni
	},
	{
		id: "lys",
		title: "Lyricify Syllable",
		order: 600,
		parse: (e) => Li(xi(e)),
		stringify: Ci
	}
], Bi = (e) => {
	for (let t of zi) e.formats.register({
		formatId: `${Ii}.${t.id}`,
		title: t.title,
		extensions: [t.id],
		order: t.order,
		importer: ({ text: e }) => ({
			lines: t.parse(e),
			metadata: []
		}),
		exporter: ({ document: e }) => t.stringify(Ri(e.lines))
	});
};
// src/plugin.ts
function Vi({ host: e }) {
	Bi(e);
}
export { Vi as activate };
