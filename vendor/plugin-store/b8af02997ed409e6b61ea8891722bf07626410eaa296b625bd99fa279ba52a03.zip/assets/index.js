import * as e from "react";
import t, { Fragment as n, createContext as r, createElement as i, useContext as a, useEffect as o, useState as s } from "react";
import { Fragment as c, jsx as l, jsxs as u } from "react/jsx-runtime";
import { Box as d, Button as f, Callout as p, Checkbox as m, Flex as h, IconButton as g, RadioGroup as _, Text as v, TextField as y } from "@radix-ui/themes";
var b = {
	split: {
		default: "Split word…",
		"zh-CN": "拆分单词…"
	},
	replace: {
		default: "Replace word…",
		"zh-CN": "替换单词…"
	},
	smooth: {
		default: "Smooth Timeline...",
		"zh-CN": "平滑时间轴..."
	},
	distribute: {
		default: "Distribute Romanization",
		"zh-CN": "自动分配罗马音"
	},
	check: {
		default: "Check Per-Word Romanization",
		"zh-CN": "检查逐字音译一致性"
	},
	cancel: {
		default: "Cancel",
		"zh-CN": "取消"
	},
	apply: {
		default: "Apply",
		"zh-CN": "应用"
	},
	confirm: {
		default: "Confirm",
		"zh-CN": "确认"
	},
	ignoreCase: {
		default: "Ignore case",
		"zh-CN": "忽略大小写"
	},
	noWord: {
		default: "Select one word first",
		"zh-CN": "请先选择一个单词"
	},
	failed: {
		default: "Word tool failed",
		"zh-CN": "单词工具执行失败"
	},
	distributeFailed: {
		default: "Romanization failed for {count} line(s)",
		"zh-CN": "{count} 行音译分配失败"
	},
	splitTitle: {
		default: "Split Word",
		"zh-CN": "拆分单词"
	},
	splitTip: {
		default: "After splitting, new words will evenly divide the original word's start/end time. Empty beats will be cleared.",
		"zh-CN": "拆分后新单词将会按自身单词字符平均分配原单词的始末时间，如有空拍则会被清除"
	},
	splitApplyToAll: {
		default: "Apply this splitting to all identical words",
		"zh-CN": "将此拆分规则应用于所有相同的单词"
	},
	replaceTitle: {
		default: "Replace Word",
		"zh-CN": "替换单词"
	},
	replaceDescription: {
		default: "New word:",
		"zh-CN": "新的单词内容:"
	},
	replacePlaceholder: {
		default: "New word",
		"zh-CN": "新单词"
	},
	replaceApplyToAll: {
		default: "Apply this replacing to all identical words",
		"zh-CN": "将此替换规则应用于所有相同的单词"
	},
	smoothTitle: {
		default: "Smooth Timeline",
		"zh-CN": "平滑时间轴"
	},
	smoothDescription: {
		default: "Smooth the timeline for CJK syllables.\nDoes not smooth syllables from other languages.",
		"zh-CN": "对 CJK 音节的时间轴进行平滑处理\n不会平滑其他语言的音节"
	},
	thresholdWarning: {
		default: "Setting a threshold that is too high may overstretch syllables and affect timestamp accuracy.",
		"zh-CN": "过高的阈值可能会导致过度拉伸音节，影响时间戳的准确性"
	},
	thresholdLabel: {
		default: "Smoothing Threshold",
		"zh-CN": "平滑阈值"
	},
	thresholdLow: {
		default: "Low (5%)",
		"zh-CN": "低 (5%)"
	},
	thresholdMedium: {
		default: "Medium (15%)",
		"zh-CN": "中 (15%)"
	},
	thresholdHigh: {
		default: "High (30%)",
		"zh-CN": "高 (30%)"
	},
	thresholdCustom: {
		default: "Custom",
		"zh-CN": "自定义"
	},
	customThreshold: {
		default: "Threshold",
		"zh-CN": "阈值"
	},
	mergeSyllables: {
		default: "Merge Syllables",
		"zh-CN": "合并音节"
	},
	mergeSyllablesHint: {
		default: "Produces Apple Music-like lyrics where CJK characters are merged together, but not suitable for regular use.",
		"zh-CN": "可以获得类似 Apple Music 的、把 CJK 合并到一起的歌词，但不适合日常使用"
	},
	scope: {
		default: "Scope",
		"zh-CN": "应用于"
	},
	scopeAll: {
		default: "All lyric lines",
		"zh-CN": "所有行"
	},
	scopeSelected: {
		default: "Selected lyric lines",
		"zh-CN": "所选行"
	},
	scopeSelectedFollowing: {
		default: "Selected and followings",
		"zh-CN": "所选行及其后续"
	},
	scopeCustom: {
		default: "Custom Range",
		"zh-CN": "自定义范围"
	},
	fromLine: {
		default: "From",
		"zh-CN": "从"
	},
	toLine: {
		default: "to",
		"zh-CN": "行 到"
	},
	line: {
		default: "line",
		"zh-CN": "行"
	}
};
// node_modules/.pnpm/wanakana@5.3.1/node_modules/wanakana/esm/index.js
function x(e) {
	return e === null ? "null" : e === Object(e) ? {}.toString.call(e).slice(8, -1).toLowerCase() : typeof e;
}
function S(e) {
	return x(e) !== "string" || !e.length;
}
function C(e = "", t, n) {
	if (S(e)) return !1;
	let r = e.charCodeAt(0);
	return t <= r && r <= n;
}
var w = { HEPBURN: "hepburn" }, ee = {
	useObsoleteKana: !1,
	passRomaji: !1,
	convertLongVowelMark: !0,
	upcaseKatakana: !1,
	IMEMode: !1,
	romanization: w.HEPBURN
}, T = 65345, te = 65370, E = 65313, ne = 65338, D = 12353, O = 12438, re = 12449, ie = 12540, ae = 19968, oe = 40879, se = 12293, ce = 12540, le = 12539, ue = [65296, 65305], de = [E, ne], fe = [T, te], pe = [65281, 65295], me = [65306, 65311], he = [65339, 65343], ge = [65371, 65376], _e = [65504, 65518], ve = [12352, 12447], ye = [12448, 12543], be = [65382, 65439], xe = [12539, 12540], Se = [65377, 65381], Ce = [12288, 12351], we = [19968, 40959], Te = [13312, 19903], Ee = [
	ve,
	ye,
	Se,
	be
], De = [
	Ce,
	Se,
	xe,
	pe,
	me,
	he,
	ge,
	_e
], Oe = [
	...Ee,
	...De,
	de,
	fe,
	ue,
	we,
	Te
], ke = [
	[256, 257],
	[274, 275],
	[298, 299],
	[332, 333],
	[362, 363]
], Ae = [[8216, 8217], [8220, 8221]];
[...ke], [...Ae];
function je(e = "") {
	return Oe.some(([t, n]) => C(e, t, n));
}
function Me(e = "", t) {
	let n = x(t) === "regexp";
	return !S(e) && [...e].every((e) => {
		let r = je(e);
		return n ? r || t.test(e) : r;
	});
}
var Ne = Number.isNaN || function(e) {
	return typeof e == "number" && e !== e;
};
function Pe(e, t) {
	return !!(e === t || Ne(e) && Ne(t));
}
function Fe(e, t) {
	if (e.length !== t.length) return !1;
	for (var n = 0; n < e.length; n++) if (!Pe(e[n], t[n])) return !1;
	return !0;
}
function Ie(e, t) {
	t === void 0 && (t = Fe);
	var n = null;
	function r() {
		var r = [...arguments];
		if (n && n.lastThis === this && t(r, n.lastArgs)) return n.lastResult;
		var i = e.apply(this, r);
		return n = {
			lastResult: i,
			lastArgs: r,
			lastThis: this
		}, i;
	}
	return r.clear = function() {
		n = null;
	}, r;
}
var Le = Object.prototype.hasOwnProperty;
function Re(e, t, n) {
	for (n of e.keys()) if (k(n, t)) return n;
}
function k(e, t) {
	var n, r, i;
	if (e === t) return !0;
	if (e && t && (n = e.constructor) === t.constructor) {
		if (n === Date) return e.getTime() === t.getTime();
		if (n === RegExp) return e.toString() === t.toString();
		if (n === Array) {
			if ((r = e.length) === t.length) for (; r-- && k(e[r], t[r]););
			return r === -1;
		}
		if (n === Set) {
			if (e.size !== t.size) return !1;
			for (r of e) if (i = r, i && typeof i == "object" && (i = Re(t, i), !i) || !t.has(i)) return !1;
			return !0;
		}
		if (n === Map) {
			if (e.size !== t.size) return !1;
			for (r of e) if (i = r[0], i && typeof i == "object" && (i = Re(t, i), !i) || !k(r[1], t.get(i))) return !1;
			return !0;
		}
		if (n === ArrayBuffer) e = new Uint8Array(e), t = new Uint8Array(t);
		else if (n === DataView) {
			if ((r = e.byteLength) === t.byteLength) for (; r-- && e.getInt8(r) === t.getInt8(r););
			return r === -1;
		}
		if (ArrayBuffer.isView(e)) {
			if ((r = e.byteLength) === t.byteLength) for (; r-- && e[r] === t[r];);
			return r === -1;
		}
		if (!n || typeof e == "object") {
			for (n in r = 0, e) if (Le.call(e, n) && ++r && !Le.call(t, n) || !(n in t) || !k(e[n], t[n])) return !1;
			return Object.keys(t).length === r;
		}
	}
	return e !== e && t !== t;
}
var ze = (e = {}) => Object.assign({}, ee, e);
function Be(e, t, n) {
	let r = t;
	function i(e, t) {
		if (e[t] !== void 0) return Object.assign({ "": e[""] + t }, e[t]);
	}
	function a(e, t) {
		let n = e.charAt(0);
		return o(Object.assign({ "": n }, r[n]), e.slice(1), t, t + 1);
	}
	function o(e, t, r, s) {
		if (!t) return n || Object.keys(e).length === 1 ? e[""] ? [[
			r,
			s,
			e[""]
		]] : [] : [[
			r,
			s,
			null
		]];
		if (Object.keys(e).length === 1) return [[
			r,
			s,
			e[""]
		]].concat(a(t, s));
		let c = i(e, t.charAt(0));
		return c === void 0 ? [[
			r,
			s,
			e[""]
		]].concat(a(t, s)) : o(c, t.slice(1), r, s + 1);
	}
	return a(e, 0);
}
function A(e) {
	return Object.entries(e).reduce((e, [t, n]) => (e[t] = x(n) === "string" ? { "": n } : A(n), e), {});
}
function Ve(e, t) {
	return t.split("").reduce((e, t) => (e[t] === void 0 && (e[t] = {}), e[t]), e);
}
function He(e = {}) {
	let t = {};
	return x(e) === "object" && Object.entries(e).forEach(([e, n]) => {
		let r = t;
		e.split("").forEach((e) => {
			r[e] === void 0 && (r[e] = {}), r = r[e];
		}), r[""] = n;
	}), function(e) {
		let n = JSON.parse(JSON.stringify(e));
		function r(e, t) {
			return e === void 0 || x(e) === "string" ? t : Object.entries(t).reduce((t, [n, i]) => (t[n] = r(e[n], i), t), e);
		}
		return r(n, t);
	};
}
function Ue(e, t) {
	return t ? x(t) === "function" ? t(e) : He(t)(e) : e;
}
var We = {
	a: "あ",
	i: "い",
	u: "う",
	e: "え",
	o: "お",
	k: {
		a: "か",
		i: "き",
		u: "く",
		e: "け",
		o: "こ"
	},
	s: {
		a: "さ",
		i: "し",
		u: "す",
		e: "せ",
		o: "そ"
	},
	t: {
		a: "た",
		i: "ち",
		u: "つ",
		e: "て",
		o: "と"
	},
	n: {
		a: "な",
		i: "に",
		u: "ぬ",
		e: "ね",
		o: "の"
	},
	h: {
		a: "は",
		i: "ひ",
		u: "ふ",
		e: "へ",
		o: "ほ"
	},
	m: {
		a: "ま",
		i: "み",
		u: "む",
		e: "め",
		o: "も"
	},
	y: {
		a: "や",
		u: "ゆ",
		o: "よ"
	},
	r: {
		a: "ら",
		i: "り",
		u: "る",
		e: "れ",
		o: "ろ"
	},
	w: {
		a: "わ",
		i: "ゐ",
		e: "ゑ",
		o: "を"
	},
	g: {
		a: "が",
		i: "ぎ",
		u: "ぐ",
		e: "げ",
		o: "ご"
	},
	z: {
		a: "ざ",
		i: "じ",
		u: "ず",
		e: "ぜ",
		o: "ぞ"
	},
	d: {
		a: "だ",
		i: "ぢ",
		u: "づ",
		e: "で",
		o: "ど"
	},
	b: {
		a: "ば",
		i: "び",
		u: "ぶ",
		e: "べ",
		o: "ぼ"
	},
	p: {
		a: "ぱ",
		i: "ぴ",
		u: "ぷ",
		e: "ぺ",
		o: "ぽ"
	},
	v: {
		a: "ゔぁ",
		i: "ゔぃ",
		u: "ゔ",
		e: "ゔぇ",
		o: "ゔぉ"
	}
}, Ge = {
	".": "。",
	",": "、",
	":": "：",
	"/": "・",
	"!": "！",
	"?": "？",
	"~": "〜",
	"-": "ー",
	"‘": "「",
	"’": "」",
	"“": "『",
	"”": "』",
	"[": "［",
	"]": "］",
	"(": "（",
	")": "）",
	"{": "｛",
	"}": "｝"
}, Ke = {
	k: "き",
	s: "し",
	t: "ち",
	n: "に",
	h: "ひ",
	m: "み",
	r: "り",
	g: "ぎ",
	z: "じ",
	d: "ぢ",
	b: "び",
	p: "ぴ",
	v: "ゔ",
	q: "く",
	f: "ふ"
}, qe = {
	ya: "ゃ",
	yi: "ぃ",
	yu: "ゅ",
	ye: "ぇ",
	yo: "ょ"
}, Je = {
	a: "ぁ",
	i: "ぃ",
	u: "ぅ",
	e: "ぇ",
	o: "ぉ"
}, Ye = {
	sh: "sy",
	ch: "ty",
	cy: "ty",
	chy: "ty",
	shy: "sy",
	j: "zy",
	jy: "zy",
	shi: "si",
	chi: "ti",
	tsu: "tu",
	ji: "zi",
	fu: "hu"
}, Xe = Object.assign({
	tu: "っ",
	wa: "ゎ",
	ka: "ヵ",
	ke: "ヶ"
}, Je, qe), Ze = {
	yi: "い",
	wu: "う",
	ye: "いぇ",
	wi: "うぃ",
	we: "うぇ",
	kwa: "くぁ",
	whu: "う",
	tha: "てゃ",
	thu: "てゅ",
	tho: "てょ",
	dha: "でゃ",
	dhu: "でゅ",
	dho: "でょ"
}, Qe = {
	wh: "う",
	kw: "く",
	qw: "く",
	q: "く",
	gw: "ぐ",
	sw: "す",
	ts: "つ",
	th: "て",
	tw: "と",
	dh: "で",
	dw: "ど",
	fw: "ふ",
	f: "ふ"
};
function $e() {
	let e = A(We), t = (t) => Ve(e, t);
	Object.entries(Ke).forEach(([e, n]) => {
		Object.entries(qe).forEach(([r, i]) => {
			t(e + r)[""] = n + i;
		});
	}), Object.entries(Ge).forEach(([e, n]) => {
		t(e)[""] = n;
	}), Object.entries(Qe).forEach(([e, n]) => {
		Object.entries(Je).forEach(([r, i]) => {
			let a = t(e + r);
			a[""] = n + i;
		});
	}), [
		"n",
		"n'",
		"xn"
	].forEach((e) => {
		t(e)[""] = "ん";
	}), e.c = JSON.parse(JSON.stringify(e.k)), Object.entries(Ye).forEach(([e, n]) => {
		let r = e.slice(0, e.length - 1), i = e.charAt(e.length - 1), a = t(r);
		a[i] = JSON.parse(JSON.stringify(t(n)));
	});
	function n(e) {
		return [...Object.entries(Ye), ["c", "k"]].reduce((t, [n, r]) => e.startsWith(r) ? t.concat(e.replace(r, n)) : t, []);
	}
	Object.entries(Xe).forEach(([e, r]) => {
		let i = (e) => e.charAt(e.length - 1), a = (e) => e.slice(0, e.length - 1), o = `x${e}`, s = t(o);
		s[""] = r;
		let c = t(`l${a(e)}`);
		c[i(e)] = s, n(e).forEach((n) => {
			["l", "x"].forEach((r) => {
				let o = t(r + a(n));
				o[i(n)] = t(r + e);
			});
		});
	}), Object.entries(Ze).forEach(([e, n]) => {
		t(e)[""] = n;
	});
	function r(e) {
		return Object.entries(e).reduce((e, [t, n]) => (e[t] = t ? r(n) : `っ${n}`, e), {});
	}
	return [
		...Object.keys(Ke),
		"c",
		"y",
		"w",
		"j"
	].forEach((t) => {
		let n = e[t];
		n[t] = r(n);
	}), delete e.n.n, Object.freeze(JSON.parse(JSON.stringify(e)));
}
var et = null;
function tt() {
	return et ??= $e(), et;
}
var nt = He({
	wi: "ゐ",
	we: "ゑ"
});
function rt(e) {
	let t = JSON.parse(JSON.stringify(e));
	return t.n.n = { "": "ん" }, t.n[" "] = { "": "ん" }, t;
}
function j(e = "") {
	return !S(e) && e.charCodeAt(0) === ce;
}
function it(e = "") {
	return !S(e) && e.charCodeAt(0) === le;
}
function at(e = "") {
	return S(e) ? !1 : j(e) ? !0 : C(e, D, O);
}
Ie((e, t, n) => {
	let r = tt();
	return r = e ? rt(r) : r, r = t ? nt(r) : r, n && (r = Ue(r, n)), r;
}, k);
function M(e = "") {
	return C(e, re, ie);
}
function ot(e = "") {
	return S(e) ? !1 : at(e) || M(e);
}
function st(e = "") {
	return !S(e) && [...e].every(ot);
}
function ct(e = "") {
	return !S(e) && [...e].every(M);
}
function lt(e = "") {
	return !S(e) && e.charCodeAt(0) === se;
}
function ut(e = "") {
	return C(e, ae, oe) || lt(e);
}
function dt(e = "") {
	return !S(e) && [...e].every(ut);
}
var ft = (e, t) => j(e) && t < 1, pt = (e, t) => j(e) && t > 0, mt = (e) => ["ヶ", "ヵ"].includes(e), ht = {
	a: "あ",
	i: "い",
	u: "う",
	e: "え",
	o: "う"
};
function gt(e = "", t, { isDestinationRomaji: n, convertLongVowelMark: r } = {}) {
	let i = "";
	return e.split("").reduce((a, o, s) => {
		if (it(o) || ft(o, s) || mt(o)) return a.concat(o);
		if (r && i && pt(o, s)) {
			let r = t(i).slice(-1);
			return M(e[s - 1]) && r === "o" && n ? a.concat("お") : a.concat(ht[r]);
		}
		if (!j(o) && M(o)) {
			let e = o.charCodeAt(0) + -96, t = String.fromCharCode(e);
			return i = t, a.concat(t);
		}
		return i = "", a.concat(o);
	}, []).join("");
}
var _t = null, vt = {
	あ: "a",
	い: "i",
	う: "u",
	え: "e",
	お: "o",
	か: "ka",
	き: "ki",
	く: "ku",
	け: "ke",
	こ: "ko",
	さ: "sa",
	し: "shi",
	す: "su",
	せ: "se",
	そ: "so",
	た: "ta",
	ち: "chi",
	つ: "tsu",
	て: "te",
	と: "to",
	な: "na",
	に: "ni",
	ぬ: "nu",
	ね: "ne",
	の: "no",
	は: "ha",
	ひ: "hi",
	ふ: "fu",
	へ: "he",
	ほ: "ho",
	ま: "ma",
	み: "mi",
	む: "mu",
	め: "me",
	も: "mo",
	ら: "ra",
	り: "ri",
	る: "ru",
	れ: "re",
	ろ: "ro",
	や: "ya",
	ゆ: "yu",
	よ: "yo",
	わ: "wa",
	ゐ: "wi",
	ゑ: "we",
	を: "wo",
	ん: "n",
	が: "ga",
	ぎ: "gi",
	ぐ: "gu",
	げ: "ge",
	ご: "go",
	ざ: "za",
	じ: "ji",
	ず: "zu",
	ぜ: "ze",
	ぞ: "zo",
	だ: "da",
	ぢ: "ji",
	づ: "zu",
	で: "de",
	ど: "do",
	ば: "ba",
	び: "bi",
	ぶ: "bu",
	べ: "be",
	ぼ: "bo",
	ぱ: "pa",
	ぴ: "pi",
	ぷ: "pu",
	ぺ: "pe",
	ぽ: "po",
	ゔぁ: "va",
	ゔぃ: "vi",
	ゔ: "vu",
	ゔぇ: "ve",
	ゔぉ: "vo"
}, yt = {
	"。": ".",
	"、": ",",
	"：": ":",
	"・": "/",
	"！": "!",
	"？": "?",
	"〜": "~",
	ー: "-",
	"「": "‘",
	"」": "’",
	"『": "“",
	"』": "”",
	"［": "[",
	"］": "]",
	"（": "(",
	"）": ")",
	"｛": "{",
	"｝": "}",
	"　": " "
}, bt = [
	"あ",
	"い",
	"う",
	"え",
	"お",
	"や",
	"ゆ",
	"よ"
], N = {
	ゃ: "ya",
	ゅ: "yu",
	ょ: "yo"
}, xt = {
	ぃ: "yi",
	ぇ: "ye"
}, St = {
	ぁ: "a",
	ぃ: "i",
	ぅ: "u",
	ぇ: "e",
	ぉ: "o"
}, Ct = [
	"き",
	"に",
	"ひ",
	"み",
	"り",
	"ぎ",
	"び",
	"ぴ",
	"ゔ",
	"く",
	"ふ"
], wt = {
	し: "sh",
	ち: "ch",
	じ: "j",
	ぢ: "j"
}, Tt = {
	っ: "",
	ゃ: "ya",
	ゅ: "yu",
	ょ: "yo",
	ぁ: "a",
	ぃ: "i",
	ぅ: "u",
	ぇ: "e",
	ぉ: "o"
}, Et = {
	b: "b",
	c: "t",
	d: "d",
	f: "f",
	g: "g",
	h: "h",
	j: "j",
	k: "k",
	m: "m",
	p: "p",
	q: "q",
	r: "r",
	s: "s",
	t: "t",
	v: "v",
	w: "w",
	x: "x",
	z: "z"
};
function Dt() {
	return _t ??= kt(), _t;
}
function Ot(e) {
	switch (e) {
		case w.HEPBURN: return Dt();
		default: return {};
	}
}
function kt() {
	let e = A(vt), t = (t) => Ve(e, t), n = (e, n) => {
		t(e)[""] = n;
	};
	return Object.entries(yt).forEach(([e, n]) => {
		t(e)[""] = n;
	}), [...Object.entries(N), ...Object.entries(St)].forEach(([e, t]) => {
		n(e, t);
	}), Ct.forEach((e) => {
		let r = t(e)[""][0];
		Object.entries(N).forEach(([t, i]) => {
			n(e + t, r + i);
		}), Object.entries(xt).forEach(([t, i]) => {
			n(e + t, r + i);
		});
	}), Object.entries(wt).forEach(([e, t]) => {
		Object.entries(N).forEach(([r, i]) => {
			n(e + r, t + i[1]);
		}), n(`${e}ぃ`, `${t}yi`), n(`${e}ぇ`, `${t}e`);
	}), e.っ = At(e), Object.entries(Tt).forEach(([e, t]) => {
		n(e, t);
	}), bt.forEach((e) => {
		n(`ん${e}`, `n'${t(e)[""]}`);
	}), Object.freeze(JSON.parse(JSON.stringify(e)));
}
function At(e) {
	return Object.entries(e).reduce((e, [t, n]) => {
		if (t) e[t] = At(n);
		else {
			let r = n.charAt(0);
			e[t] = Object.keys(Et).includes(r) ? Et[r] + n : n;
		}
		return e;
	}, {});
}
var jt = Ie((e, t) => {
	let n = Ot(e);
	return t && (n = Ue(n, t)), n;
}, k);
function Mt(e = "", t = {}, n) {
	let r = ze(t);
	return n ||= jt(r.romanization, r.customRomajiMapping), Nt(e, r, n).map((t) => {
		let [n, i, a] = t;
		return r.upcaseKatakana && ct(e.slice(n, i)) ? a.toUpperCase() : a;
	}).join("");
}
function Nt(e, t, n) {
	return n ||= jt(t.romanization, t.customRomajiMapping), Be(gt(e, Mt, Object.assign({}, { isDestinationRomaji: !0 }, t)), n, !t.IMEMode);
}
// src/punctuation.ts
var Pt = /* @__PURE__ */ new Set([
	"(",
	"[",
	"{",
	"<",
	"「",
	"『",
	"（",
	"【",
	"《",
	"〈",
	"〔",
	"｢",
	"“",
	"‘",
	"«",
	"‹",
	"¿",
	"¡"
]), Ft = /* @__PURE__ */ new Set([
	")",
	"]",
	"}",
	">",
	"」",
	"』",
	"）",
	"】",
	"》",
	"〉",
	"〕",
	"｣",
	"”",
	"’",
	"»",
	"›"
]), It = /* @__PURE__ */ new Set(["\""]), Lt = /* @__PURE__ */ new Set([
	",",
	"，",
	"。",
	"．",
	".",
	"?",
	"!",
	"！",
	"？",
	"、",
	"；",
	";",
	":",
	"：",
	"'",
	"’",
	"〜",
	"～",
	"-",
	"—",
	"…",
	"⋯",
	"·",
	"♪"
]), Rt = /* @__PURE__ */ new Set([
	...Pt,
	...Ft,
	...It,
	...Lt
]);
function P(e) {
	return Rt.has(e);
}
function F(e) {
	if (!e) return !1;
	for (let t of e) if (!P(t)) return !1;
	return !0;
}
// src/romanization.ts
var I = /* @__PURE__ */ new Set([
	"a",
	"e",
	"i",
	"o",
	"u"
]), zt = /* @__PURE__ */ new Set(["っ", "ッ"]);
function Bt(e) {
	return zt.has(e);
}
function Vt(e) {
	return e ? Me(e.replace(/[、，。！？\s]/g, "")) : !1;
}
function L(e) {
	return Mt(e, { upcaseKatakana: !1 });
}
function Ht(e) {
	return e === "ー";
}
function Ut(e) {
	if (!e) return !1;
	let t = Array.from(e).filter((e) => e.trim() !== "" && !P(e) && !/^\p{P}$/u.test(e)).join("");
	return t ? st(t) : !1;
}
var Wt = class {
	tokens;
	cursor = 0;
	constructor(e) {
		this.tokens = e;
	}
	get remaining() {
		return Math.max(0, this.tokens.length - this.cursor);
	}
	peek(e = 0) {
		return this.tokens[this.cursor + e];
	}
	consume(e) {
		if (e <= 0) return [];
		let t = this.tokens.slice(this.cursor, this.cursor + e);
		return this.cursor += e, t;
	}
	replaceCurrent(e) {
		this.cursor < this.tokens.length && (this.tokens[this.cursor] = e);
	}
};
function Gt(e) {
	let t = e.trim();
	if (!/^[a-zA-Z]+$/.test(t)) return null;
	let n = 0, r = t.toLowerCase();
	for (let e of r) I.has(e) && n++;
	if (n < 1) return null;
	let i = [], a = 0, o = t.length;
	for (; a < o;) {
		let e = a, n = r[a], s = a + 1 < o ? r[a + 1] : "";
		if (!I.has(n) && n === s) i.push(t.slice(e, a + 1)), a++;
		else {
			if (n === "n") {
				let n = a + 2 < o ? r[a + 2] : "", c = I.has(s), l = s === "y" && I.has(n);
				if (!c && !l) {
					i.push(t.slice(e, a + 1)), a++;
					continue;
				}
			}
			for (; a < o && !I.has(r[a]);) a++;
			a < o && a++, i.push(t.slice(e, a));
		}
	}
	return i.length <= 1 ? null : i;
}
function Kt(e, t = !0) {
	if (!e) return new Wt([]);
	let n = e.trim().split(/[\s\t]+/).filter((e) => e), r = [];
	for (let e of n) if (t) {
		let t = Gt(e);
		t ? r.push(...t) : r.push(e);
	} else r.push(e);
	return new Wt(r);
}
var qt = class {
	words;
	buffer;
	results;
	pendingWords = [];
	constructor(e, t) {
		this.words = e, this.buffer = Kt(t), this.results = Array(e.length).fill("");
	}
	predict() {
		if (this.buffer.remaining === 0) return this.getFallbackResults();
		for (let e = 0; e < this.words.length; e++) {
			let t = this.words[e];
			this.shouldSkipWord(t, e) || this.tryConsumePunctuation(t, e) || this.tryMatchAnchor(t, e) || this.pendingWords.push({
				index: e,
				word: t
			});
		}
		return this.flushPendingBuffer(this.buffer.consume(this.buffer.remaining)), this.results;
	}
	getFallbackResults() {
		return this.words.map((e) => Vt(e.text) ? L(e.text) : "");
	}
	shouldSkipWord(e, t) {
		return !e.text.trim() && (this.results[t] = "", !0);
	}
	tryConsumePunctuation(e, t) {
		if (F(e.text)) {
			let e = this.buffer.peek(0);
			return e && F(e) ? this.results[t] = this.buffer.consume(1)[0] : this.results[t] = "", !0;
		}
		return !1;
	}
	tryMatchAnchor(e, t) {
		let n = e.text.trim();
		if (!Ut(n) || Bt(n) || Ht(n)) return !1;
		let r = Jt(n), i = Math.min(this.buffer.remaining, 15);
		for (let e = 0; e < i; e++) {
			let n = this.buffer.peek(e);
			if (!n) continue;
			let i = Yt(n, r);
			if (i && !(e + +(i.type === "Suffix") < this.getPendingBufferWeight()) && this.checkLookahead(t, i.type, e)) return this.applyAnchorMatch(t, e, i, n), !0;
		}
		return !1;
	}
	checkLookahead(e, t, n) {
		if (t === "Prefix" || e + 1 >= this.words.length) return !0;
		let r = this.words[e + 1].text.trim();
		if (Ut(r) && !Bt(r) && !F(r) && !Ht(r)) {
			let e = Jt(r), t = this.buffer.peek(n + 1);
			if (t && !Yt(t, e)) return !1;
		}
		return !0;
	}
	applyAnchorMatch(e, t, n, r) {
		let i = this.buffer.consume(t);
		if (n.type === "Suffix") {
			let t = r.lastIndexOf(n.expected), a = r.slice(0, t);
			i.push(a), this.flushPendingBuffer(i), this.results[e] = n.expected, this.buffer.consume(1);
		} else if (this.flushPendingBuffer(i), n.type === "Exact") this.results[e] = this.buffer.consume(1)[0];
		else {
			this.results[e] = n.expected;
			let t = r.slice(n.expected.length);
			this.buffer.replaceCurrent(t);
		}
	}
	getPendingBufferWeight() {
		return this.pendingWords.reduce((e, t) => {
			let n = t.word.emptyBeat || 0;
			return e + 1 + n;
		}, 0);
	}
	flushPendingBuffer(e) {
		if (this.pendingWords.length === 0) return;
		let t = this.pendingWords.length, n = e.length;
		if (n === 0) {
			this.pendingWords.forEach((e) => {
				this.results[e.index] = "";
			}), this.pendingWords = [];
			return;
		}
		let r = this.pendingWords.map((e) => 1 + (e.word.emptyBeat || 0)), i = r.reduce((e, t) => e + t, 0), a = 0, o = 0;
		for (let s = 0; s < t; s++) {
			let c = r[s];
			o += c;
			let l = Math.round(i > 0 ? o / i * n : (s + 1) / t * n), u = Math.min(l, n) - a;
			if (u > 0) {
				let t = e.slice(a, a + u);
				this.results[this.pendingWords[s].index] = t.join(" "), a += u;
			} else this.results[this.pendingWords[s].index] = "";
		}
		this.pendingWords = [];
	}
};
function Jt(e) {
	let t = L(e), n = /* @__PURE__ */ new Set([t]);
	return e === "は" && n.add("wa"), e === "へ" && n.add("e"), e === "を" && n.add("o"), Array.from(n);
}
function Yt(e, t) {
	let n = e.toLowerCase();
	for (let e of t) {
		if (n === e) return {
			type: "Exact",
			expected: e
		};
		if (n.startsWith(e) && n.length > e.length) return {
			type: "Prefix",
			expected: e
		};
		if (n.endsWith(e) && n.length > e.length) {
			let t = n.slice(0, n.length - e.length), r = e[0], i = t[t.length - 1];
			if (I.has(r) && !I.has(i) && i !== "n") continue;
			return {
				type: "Suffix",
				expected: e
			};
		}
	}
	return null;
}
function Xt(e, t) {
	return new qt(e, t).predict();
}
var Zt = /* @__PURE__ */ new Map([
	["は", ["wa"]],
	["へ", ["e"]],
	["を", ["o"]]
]), Qt = /* @__PURE__ */ new Set([
	"ぁ",
	"ぃ",
	"ぅ",
	"ぇ",
	"ぉ",
	"ゃ",
	"ゅ",
	"ょ",
	"っ",
	"ゎ",
	"ゕ",
	"ゖ",
	"ァ",
	"ィ",
	"ゥ",
	"ェ",
	"ォ",
	"ャ",
	"ュ",
	"ョ",
	"ッ",
	"ヮ",
	"ヵ",
	"ヶ"
]), $t = (e) => {
	let t = e.trim();
	if (!t) return "";
	let n = "";
	for (let e of t) P(e) || (n += e);
	return n || t;
}, en = (e) => !(!e || Array.from(e).length !== 1 || Qt.has(e) || F(e) || /^\d+$/.test(e) || !Me(e) || dt(e)), tn = (e) => {
	let t = L(e).toLowerCase(), n = /* @__PURE__ */ new Set([t]), r = Zt.get(e);
	if (r) for (let e of r) n.add(e);
	return Array.from(n);
}, nn = (e) => e.map((e) => {
	let t = $t(e.text);
	if (!en(t)) return !1;
	let n = tn(t), r = (e.romanText || "").replace(/\s+/g, "").toLowerCase();
	return r === "" || !n.includes(r);
}), rn = {
	LOW: 5,
	MEDIUM: 15,
	HIGH: 30
}, an = /^[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}\p{Script=Bopomofo}]+$/u;
function R(e) {
	return e?.text ? /^\s*$/.test(e.text) : !1;
}
function on(e) {
	if (!e || typeof e != "string") return !1;
	let t = e.replace(/\s+/g, "");
	return t.length > 0 && an.test(t);
}
function sn(e) {
	return !e.ruby || e.ruby.length === 0 || e.ruby.length === 1;
}
function cn(e, t) {
	let n = Math.max(0, (e.endTime ?? 0) - (e.startTime ?? 0)), r = Math.max(0, (t.endTime ?? 0) - (t.startTime ?? 0)), i = (e.text || "").replace(/\s+/g, ""), a = (t.text || "").replace(/\s+/g, ""), o = Math.max(1, Array.from(i).length), s = Math.max(1, Array.from(a).length), c = n / o, l = r / s;
	return c + l === 0 ? 0 : Math.abs(c - l) / (c + l) * 100;
}
function ln(e) {
	let t = e.filter((e) => !R(e));
	if (t.length <= 1) return e;
	let n = t[0].startTime ?? 0, r = t[t.length - 1].endTime ?? 0, i = Math.max(0, r - n), a = t.map((e) => {
		let t = (e.text || "").replace(/\s+/g, "");
		return Math.max(1, Array.from(t).length);
	}), o = a.reduce((e, t) => e + t, 0), s = n, c = /* @__PURE__ */ new Map();
	for (let e = 0; e < t.length; e++) {
		let n = t[e], l = a[e], u = o > 0 ? Math.round(i * l / o) : 0, d = s, f = e === t.length - 1 ? r : s + u;
		s = f;
		let p = n.ruby;
		p && p.length === 1 && (p = [{
			...p[0],
			startTime: d,
			endTime: f
		}]), c.set(n, {
			...n,
			startTime: d,
			endTime: f,
			...p ? { ruby: p } : {}
		});
	}
	return e.map((e) => R(e) ? e : c.get(e) ?? e);
}
function un(e) {
	let t = e.filter((e) => !R(e)), n = t[0] ?? e[0], r = t[t.length - 1] ?? e[e.length - 1], i = e.map((e) => e.text ?? "").join(""), a = n.startTime ?? 0, o = r.endTime ?? 0, s = e.reduce((e, t) => e + (t.emptyBeat || 0), 0), c = e.map((e) => e.romanText?.trim()).filter(Boolean).join(" "), l = e.flatMap((e) => e.ruby || []);
	return {
		id: n.id,
		text: i,
		startTime: a,
		endTime: o,
		emptyBeat: s,
		romanText: c,
		...l.length > 0 ? { ruby: l } : {}
	};
}
function dn(e, t) {
	if (e.length <= 1) return e;
	let n = t?.threshold ?? rn.MEDIUM, r = t?.mergeSyllables ?? !1, i = [], a = 0;
	for (; a < e.length;) {
		let t = e[a];
		if (R(t)) {
			i.push(t), a++;
			continue;
		}
		let o = [t], s = t;
		for (; a + 1 < e.length;) {
			let t = a + 1, r = [];
			for (; t < e.length && R(e[t]);) r.push(e[t]), t++;
			if (t >= e.length) break;
			let i = e[t], c = on(s.text), l = on(i.text), u = sn(s), d = sn(i);
			if (c && l && u && d && cn(s, i) < n) o.push(...r, i), s = i, a = t;
			else break;
		}
		if (o.length === 1) i.push(o[0]);
		else {
			let e = ln(o);
			r ? i.push(un(e)) : i.push(...e);
		}
		a++;
	}
	return i;
}
function fn(e, t) {
	let n = dn(e, t), r = new Map(e.map((e) => [e.id, e])), i = new Set(n.map((e) => e.id)), a = [];
	for (let e of n) {
		if (r.get(e.id) === e) continue;
		let { id: t, ruby: n, ...i } = e;
		a.push({
			op: "updateWord",
			wordId: t,
			patch: n === void 0 ? i : {
				...i,
				ruby: n
			}
		});
	}
	for (let t of e) i.has(t.id) || a.push({
		op: "removeWord",
		wordId: t.id
	});
	return a;
}
// src/edits.ts
var z = (e, t, n, r) => {
	if (!n.length) return;
	let i = e.document.applyEdit(n, r, { expectedRevision: t.revision });
	if (!i.ok) throw Error(i.error.message);
}, B = (e, t) => e.lines.flatMap((e) => e.words).find((e) => e.id === t);
function pn(e, t) {
	let n = [], r = 0;
	for (let i of [...t].sort((e, t) => e - t)) i <= r || i >= e.length || (n.push(e.slice(r, i)), r = i);
	return n.push(e.slice(r)), n.filter(Boolean);
}
async function mn(e, t) {
	let n = await e.segmentation.segmentText({
		text: t.text,
		startTime: t.startTime,
		endTime: t.endTime
	}), r = /* @__PURE__ */ new Set(), i = 0;
	for (let e of n.slice(0, -1)) i += e.text.length, r.add(i);
	return r;
}
var hn = (e, t, n) => n ? e.toLowerCase() === t.toLowerCase() : e === t;
async function gn(e, t) {
	let n = e.document.readSnapshot(), r = B(n, t.wordId);
	if (!r) return;
	let i = [...t.splitIndices], a = pn(r.text, i);
	if (a.length <= 1) return;
	let o = [];
	for (let s of n.lines) for (let n of s.words) {
		if (t.applyToAll ? !hn(n.text, r.text, t.ignoreCase) : n.id !== r.id) continue;
		let c = t.ignoreCase ? pn(n.text, i) : a, l = await e.segmentation.segmentText({
			text: n.text,
			startTime: n.startTime,
			endTime: n.endTime
		}, c.length ? c : a);
		if (l.length <= 1) continue;
		let [u, ...d] = l;
		o.push({
			op: "updateWord",
			wordId: n.id,
			patch: {
				...u,
				emptyBeat: 0,
				romanText: "",
				romanWarning: !1,
				ruby: null
			}
		});
		for (let e of d.reverse()) o.push({
			op: "insertWord",
			lineId: s.id,
			afterWordId: n.id,
			word: {
				...e,
				emptyBeat: 0,
				romanText: ""
			}
		});
	}
	z(e, n, o, "Split lyric word");
}
function _n(e, t) {
	let n = e.document.readSnapshot(), r = B(n, t.wordId);
	r && r.text !== t.text && z(e, n, n.lines.flatMap((e) => e.words).filter((e) => t.applyToAll ? hn(e.text, r.text, t.ignoreCase) : e.id === r.id).map((e) => ({
		op: "updateWord",
		wordId: e.id,
		patch: { text: t.text }
	})), "Replace lyric word");
}
var vn = (e, t) => {
	let n = e.map((e, n) => ({
		...e,
		romanText: t?.[n] || e.romanText
	})), r = nn(n);
	return n.flatMap((t, n) => {
		let i = {};
		return t.romanText !== e[n].romanText && (i.romanText = t.romanText), r[n] !== !!e[n].romanWarning && (i.romanWarning = r[n]), Object.keys(i).length ? [{
			op: "updateWord",
			wordId: t.id,
			patch: i
		}] : [];
	});
};
function yn(e, t) {
	let n = e.document.readSnapshot(), r = [], i = [];
	return n.lines.forEach((e, n) => {
		if ((!t || t.has(e.id)) && e.words.length && e.romanization.trim()) try {
			r.push(...vn(e.words, Xt(e.words, e.romanization)));
		} catch {
			i.push(n + 1);
		}
	}), z(e, n, r, "Distribute line romanization"), i;
}
function bn(e) {
	let t = e.document.readSnapshot();
	z(e, t, t.lines.flatMap((e) => vn(e.words)), "Refresh romanization warnings");
}
function xn(e, t, n) {
	let r = e.document.readSnapshot();
	z(e, r, r.lines.filter((e) => t.has(e.id)).flatMap((e) => fn(e.words, n)), "Smooth lyric syllables");
}
function Sn(e, t, n, r, i) {
	let a = e.lines, o = new Set(t.lineIds), s = a;
	if (n === "selected") s = a.filter((e) => o.has(e.id));
	else if (n === "selected-following") {
		let e = a.findIndex((e) => o.has(e.id));
		s = e < 0 ? [] : a.slice(e);
	} else if (n === "custom") {
		let e = Number.parseInt(r, 10), t = Number.parseInt(i, 10);
		s = Number.isNaN(e) || Number.isNaN(t) ? [] : a.slice(Math.max(0, e - 1), Math.max(0, t));
	}
	return new Set(s.map((e) => e.id));
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/constants.js
var V = typeof window > "u" ? global : window, H = "@griffel/";
function Cn(e, t) {
	return V[Symbol.for(H + e)] || (V[Symbol.for(H + e)] = t), V[Symbol.for(H + e)];
}
var U = /*#__PURE__*/ Cn("DEBUG_RESET_CLASSES", {}), W = /*#__PURE__*/ Cn("DEFINITION_LOOKUP_TABLE", {}), G = "data-make-styles-bucket", wn = "data-priority", Tn = "data-container", En = process.env.NODE_ENV === "production" ? 10 : 18;
// node_modules/.pnpm/@emotion+hash@0.9.2/node_modules/@emotion/hash/dist/emotion-hash.esm.js
function K(e) {
	for (var t = 0, n, r = 0, i = e.length; i >= 4; ++r, i -= 4) n = e.charCodeAt(r) & 255 | (e.charCodeAt(++r) & 255) << 8 | (e.charCodeAt(++r) & 255) << 16 | (e.charCodeAt(++r) & 255) << 24, n = (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16), n ^= n >>> 24, t = (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16) ^ (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
	switch (i) {
		case 3: t ^= (e.charCodeAt(r + 2) & 255) << 16;
		case 2: t ^= (e.charCodeAt(r + 1) & 255) << 8;
		case 1: t ^= e.charCodeAt(r) & 255, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
	}
	return t ^= t >>> 13, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16), ((t ^ t >>> 15) >>> 0).toString(36);
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/utils/hashSequence.js
function q(e) {
	let t = e.length;
	if (t === 7) return e;
	for (let n = t; n < 7; n++) e += "0";
	return e;
}
function Dn(e, t, n = []) {
	return process.env.NODE_ENV === "production" ? "___" + q(K(e + t)) : "___" + q(K(e + t)) + "_" + q(K(n.join("")));
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/reduceToClassNameForSlots.js
function On(e, t) {
	let n = "", r = "";
	for (let i in e) {
		let a = e[i];
		if (a === 0) {
			r += i + " ";
			continue;
		}
		let o = Array.isArray(a), s = t === "rtl" ? (o ? a[1] : a) + " " : (o ? a[0] : a) + " ";
		n += s, r += s;
	}
	return [n.slice(0, -1), r.slice(0, -1)];
}
function kn(e, t) {
	let n = {};
	for (let r in e) {
		let [i, a] = On(e[r], t);
		if (a === "") {
			n[r] = "";
			continue;
		}
		let o = Dn(a, t), s = o + (i === "" ? "" : " " + i);
		W[o] = [e[r], t], n[r] = s;
	}
	return n;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/mergeClasses.js
var J = {};
function An() {
	let e = null, t = "", n = "", r = Array(arguments.length), i = "";
	for (let e = 0; e < arguments.length; e++) {
		let a = arguments[e];
		if (typeof a == "string" && a !== "") {
			let o = a.indexOf("___");
			if (o === -1) process.env.NODE_ENV !== "production" && a.split(" ").forEach((e) => {
				e.startsWith("r") && U[e] && (i ? console.error(`mergeClasses(): a passed string contains multiple classes produced by makeResetStyles (${a} & ${t}, this will lead to non-deterministic behavior. Learn more:https://griffel.js.org/react/api/make-reset-styles#limitations
Source string: ${a}`) : i = e);
			}), t += a + " ";
			else {
				let i = a.substr(o, En);
				o > 0 && (t += a.slice(0, o)), n += i, r[e] = i;
			}
			process.env.NODE_ENV !== "production" && a.indexOf("___", o + 1) !== -1 && console.error(`mergeClasses(): a passed string contains multiple identifiers of atomic classes (classes that start with "___"), it's possible that passed classes were concatenated in a wrong way. Source string: ${a}`);
		}
	}
	if (n === "") return t.slice(0, -1);
	let a = J[n];
	if (a !== void 0) return t + a;
	let o = [];
	for (let t = 0; t < arguments.length; t++) {
		let n = r[t];
		if (n) {
			let r = W[n];
			r ? (o.push(r[0]), process.env.NODE_ENV !== "production" && e !== null && e !== r[1] && console.error(`mergeClasses(): a passed string contains an identifier (${n}) that has different direction (dir="${r[1] ? "rtl" : "ltr"}") setting than other classes. This is not supported. Source string: ${arguments[t]}`), e = r[1]) : process.env.NODE_ENV !== "production" && console.error(`mergeClasses(): a passed string contains an identifier (${n}) that does not match any entry in cache. Source string: ${arguments[t]}`);
		}
	}
	let s = Object.assign.apply(Object, [{}].concat(o)), [c, l] = On(s, e), u = Dn(l, e, r), d = u + " " + c;
	return J[n] = d, W[u] = [s, e], t + d;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/store.js
var jn = {}, Mn = /* @__PURE__ */ new Set(), Y = {
	getChildrenSequences: (e) => {
		let t = Object.keys(J).find((t) => J[t].startsWith(e));
		return t ? t.split("___").filter((e) => e.length).map((e) => "___" + e) : [];
	},
	addCSSRule: (e) => {
		Mn.add(e);
	},
	addSequenceDetails: (e, t) => {
		Object.entries(e).forEach(([e, n]) => {
			jn[n.substring(0, En)] = {
				slotName: e,
				sourceURL: t
			};
		});
	},
	getCSSRules: () => Array.from(Mn),
	getSequenceDetails: (e) => jn[e]
};
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/utils.js
function Nn(e, t) {
	return Array.isArray(e) ? t === "rtl" ? e[1] : e[0] : e || "";
}
function Pn(e, t, n, r) {
	let i = e[0], a = e[1];
	return Object.entries(i).map(([e, i]) => {
		let o = Nn(i, a), s;
		if (n && t) {
			let i = n.find(({ className: e }) => e === o);
			!i && t[0][e] ? s = Nn(t[0][e], t[1]) : i && t[0][e] ? s = r && r.filter(({ debugClassNames: e }) => e.filter(({ className: e }) => e === o).length > 0).length > 0 ? i.className : i.overriddenBy : (!i && !t[0][e] || i && !t[0][e]) && (s = void 0);
		}
		return {
			className: o,
			overriddenBy: s
		};
	});
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getAtomicDebugSequenceTree.js
function Fn(e, t) {
	let n = W[e];
	if (n === void 0) return;
	let r = Pn(n, t ? W[t.sequenceHash] : void 0, t?.debugClassNames, t?.children), i = {
		sequenceHash: e,
		direction: n[1],
		children: [],
		debugClassNames: r
	};
	return Y.getChildrenSequences(i.sequenceHash).reverse().forEach((e) => {
		let t = Fn(e, i);
		t && i.children.push(t);
	}), i.children.length || (i.rules = {}, i.debugClassNames.forEach(({ className: t }) => {
		let n = Y.getSequenceDetails(e);
		n && (i.slot = n.slotName, i.sourceURL = n.sourceURL);
		let r = Y.getCSSRules().find((e) => e.includes(t));
		i.rules[t] = r;
	})), i;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getResetDebugSequence.js
function In(e) {
	if (U[e] === void 0) return;
	let t = {
		sequenceHash: e,
		direction: "ltr",
		children: [],
		debugClassNames: [{ className: e }]
	};
	t.rules = {}, t.slot = "makeResetStyles()";
	let [{ className: n }] = t.debugClassNames, r = Y.getCSSRules().filter((e) => e.includes(`.${n}`));
	return t.rules[n] = r.join(""), t;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/mergeDebugSequence.js
function Ln(e, t) {
	let n = e ? Fn(e) : void 0, r = t ? In(t) : void 0;
	if (n || r) return n ? r ? {
		sequenceHash: n.sequenceHash + r.sequenceHash,
		direction: n.direction,
		children: [n, r],
		debugClassNames: [...n.debugClassNames, ...r.debugClassNames]
	} : n : r;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/injectDevTools.js
function Rn(e) {
	let t = e.defaultView;
	if (!t || t.__GRIFFEL_DEVTOOLS__) return;
	let n = { getInfo: (e) => {
		let t, n;
		for (let r of e.classList) r.startsWith("___") && (t = r), U[r] && (n = r);
		return Ln(t, n);
	} };
	Object.defineProperty(t, "__GRIFFEL_DEVTOOLS__", {
		configurable: !1,
		enumerable: !1,
		get() {
			return n;
		}
	});
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/isDevToolsEnabled.js
var X = (() => {
	try {
		return !!(typeof window < "u" && window.sessionStorage?.getItem("__GRIFFEL_DEVTOOLS__"));
	} catch {
		return !1;
	}
})(), Z = "<unknown>";
function zn(e) {
	return Un(e) || Kn(e) || Jn(e);
}
var Bn = /^\s*at (.*?) ?\(((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/|[a-z]:\\|\\\\).*?)?\)?\s*$/i, Vn = /^\s*at ()((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/|[a-z]:\\|\\\\).*?)\s*$/i, Hn = /\((\S*)\)/;
function Un(e) {
	let t = Bn.exec(e) || Vn.exec(e);
	if (!t) return null;
	let n = t[2], r = n && n.indexOf("native") === 0, i = n && n.indexOf("eval") === 0, a = Hn.exec(n);
	return i && a !== null && (n = a[1]), {
		loc: r ? null : t[2],
		name: t[1] || Z
	};
}
var Wn = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|resource|\[native).*?|[^@]*bundle)\s*$/i, Gn = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;
function Kn(e) {
	let t = Wn.exec(e);
	if (!t) return null;
	let n = t[3], r = n && n.indexOf(" > eval") > -1, i = Gn.exec(n);
	return r && i !== null && (n = i[1]), {
		loc: t[3],
		name: t[1] || Z
	};
}
var qn = /^\s*(?:([^@]*)(?:\((.*?)\))?@)?(\S.*?)\s*$/i;
function Jn(e) {
	let t = qn.exec(e);
	return t ? {
		loc: t[3],
		name: t[1] || Z
	} : null;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getSourceURLfromError.js
function Yn() {
	let e = Xn(String((/* @__PURE__ */ Error()).stack).split("\n"));
	return e === void 0 ? void 0 : zn(e)?.loc;
}
function Xn(e) {
	for (let t = e.length - 1; t >= 0; --t) if (e[t].includes("at getSourceURLfromError")) return e[t + 3];
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/utils/normalizeCSSBucketEntry.js
function Zn(e) {
	if (!Array.isArray(e)) return [e];
	if (process.env.NODE_ENV !== "production" && e.length > 2) throw Error("CSS Bucket contains an entry with greater than 2 items, please report this to https://github.com/microsoft/griffel/issues");
	return e;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/createIsomorphicStyleSheet.js
function Qn(e, t, n, r) {
	let i = [];
	if (r[G] = t, r[wn] = String(n), e) for (let t in r) e.setAttribute(t, r[t]);
	function a(t) {
		return e?.sheet ? e.sheet.insertRule(t, e.sheet.cssRules.length) : i.push(t);
	}
	return {
		elementAttributes: r,
		insertRule: a,
		element: e,
		bucketName: t,
		cssRules() {
			return e?.sheet ? Array.from(e.sheet.cssRules).map((e) => e.cssText) : i;
		}
	};
}
var $n = /*#__PURE__*/ [
	"r",
	"d",
	"l",
	"v",
	"w",
	"f",
	"i",
	"h",
	"a",
	"s",
	"k",
	"t",
	"m",
	"c",
	"x"
].reduce((e, t, n) => (e[t] = n, e), {});
function er(e, t, n) {
	return e === "m" || e === "x" ? e + t + n : e + n;
}
function tr(e, t, n, r, i = {}) {
	let a = e === "m", o = e === "x", s = i.m, c = i.x, l = i.p ?? 0, u = er(e, c ?? s ?? "0", l);
	if (!r.stylesheets[u]) {
		let d = t && t.createElement("style"), f = Qn(d, e, l, {
			...r.styleElementAttributes,
			...a && { media: s },
			...o && { "data-container": c }
		});
		r.stylesheets[u] = f, t?.head && d && t.head.insertBefore(d, rr(t, n, e, r, i));
	}
	return r.stylesheets[u];
}
function nr(e, t, n) {
	return e.getAttribute("data-make-styles-bucket") === t ? t === "m" ? n.m === e.media : t !== "x" || n.x === e.getAttribute(Tn) : !1;
}
function rr(e, t, n, r, i = {}) {
	let a = $n[n], o = i.m ?? "", s = i.x ?? "", c = i.p ?? 0, l = (e) => a - $n[e.getAttribute(G)], u = e.head.querySelectorAll(`[${G}]`);
	if (n === "m" || n === "x") {
		let t = e.head.querySelectorAll(`[${G}="${n}"]`);
		t.length && (u = t, l = n === "m" ? (e) => r.compareMediaQueries(o, e.media) : (e) => r.compareContainerQueries(s, e.getAttribute("data-container") ?? ""));
	}
	let d = (e) => nr(e, n, i) ? c - Number(e.getAttribute(wn)) : l(e), f = u.length, p = f - 1;
	for (; p >= 0;) {
		let e = u.item(p);
		if (d(e) > 0) return e.nextSibling;
		p--;
	}
	return f > 0 ? u.item(0) : t ? t.nextSibling : null;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/safeInsertRule.js
var ir = /*#__PURE__*/ RegExp(":(-moz-placeholder|-moz-focus-inner|-moz-focusring|-ms-input-placeholder|-moz-read-write|-moz-read-only)");
function ar(e, t) {
	try {
		e.insertRule(t);
	} catch (e) {
		process.env.NODE_ENV !== "production" && !ir.test(t) && console.error(`There was a problem inserting the following rule: "${t}"`, e);
	}
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/createDOMRenderer.js
var or = 0, sr = (e, t) => e < t ? -1 : +(e > t);
function cr(e = typeof document > "u" ? void 0 : document, t = {}) {
	let { classNameHashSalt: n, unstable_filterCSSRule: r, insertionPoint: i, styleElementAttributes: a, compareMediaQueries: o = sr, compareContainerQueries: s = o } = t, c = {
		classNameHashSalt: n,
		insertionCache: {},
		stylesheets: {},
		styleElementAttributes: Object.freeze(a),
		compareMediaQueries: o,
		compareContainerQueries: s,
		id: `d${or++}`,
		insertCSSRules(t) {
			for (let n in t) {
				let a = t[n];
				for (let t = 0, o = a.length; t < o; t++) {
					let [o, s] = Zn(a[t]), l = tr(n, e, i || null, c, s);
					c.insertionCache[o] || (c.insertionCache[o] = n, process.env.NODE_ENV !== "production" && X && Y.addCSSRule(o), r ? r(o) && ar(l, o) : ar(l, o));
				}
			}
		}
	};
	return e && process.env.NODE_ENV !== "production" && X && Rn(e), c;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/insertionFactory.js
var lr = () => {
	let e = {};
	return function(t, n) {
		e[t.id] === void 0 && (t.insertCSSRules(n), e[t.id] = !0);
	};
};
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/__styles.js
function ur(e, t, n = lr) {
	let r = n(), i = null, a = null, o;
	process.env.NODE_ENV !== "production" && X && (o = Yn());
	function s(n) {
		let { dir: s, renderer: c } = n, l = s === "ltr";
		l ? i === null && (i = kn(e, s)) : a === null && (a = kn(e, s)), r(c, t);
		let u = l ? i : a;
		return process.env.NODE_ENV !== "production" && X && Y.addSequenceDetails(u, o), u;
	}
	return s;
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/utils/canUseDOM.js
function dr() {
	return typeof window < "u" && !!(window.document && window.document.createElement);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/useInsertionEffect.js
var fr = t.useInsertionEffect ? t.useInsertionEffect : void 0, pr = () => {
	let e = {};
	return function(t, n) {
		fr && dr() ? fr(() => {
			t.insertCSSRules(n);
		}, [t, n]) : e[t.id] === void 0 && (t.insertCSSRules(n), e[t.id] = !0);
	};
}, mr = /*#__PURE__*/ r(/*#__PURE__*/ cr());
function hr() {
	return a(mr);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/TextDirectionContext.js
var gr = /*#__PURE__*/ r("ltr");
function _r() {
	return a(gr);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/__styles.js
function vr(e, t) {
	let n = ur(e, t, pr);
	return function() {
		let e = _r(), t = hr();
		return n({
			dir: e,
			renderer: t
		});
	};
}
// node_modules/.pnpm/@fluentui+react-icons@2.0.333_react@19.2.7/node_modules/@fluentui/react-icons/lib/utils/useIconStyles.styles.js
var yr = vr({
	root: {
		mc9l5x: "f1w7gpdv",
		Bg96gwp: "fez10in"
	},
	rtl: { Bz10aip: "f13rod7r" }
}, { d: [
	".f1w7gpdv{display:inline;}",
	".fez10in{line-height:0;}",
	".f13rod7r{transform:scaleX(-1);}"
] }), br = e.createContext(void 0), xr = {};
br.Provider;
var Sr = () => e.useContext(br) ?? xr, Cr = "fui-Icon", wr = "data-fui-icon", Tr = (e, t) => {
	let { filled: n, idPrefix: r, title: i, primaryFill: a = "currentColor", ...o } = e, s = {
		...o,
		fill: a
	}, c = Sr(), l = !!(t?.flipInRtl && c?.textDirection === "rtl");
	return i && (s["aria-label"] = i), !s["aria-label"] && !s["aria-labelledby"] ? s["aria-hidden"] = !0 : s.role = "img", s[wr] = "", {
		state: s,
		isRtlFlip: l
	};
}, Er = (e, t) => {
	let n = yr(), { state: r, isRtlFlip: i } = Tr(e, t);
	return r.className = An(n.root, i && n.rtl, r.className), r;
}, Dr = vr({ root: { B8gzw0y: "f1dd5bof" } }, { m: [["@media (forced-colors: active){.f1dd5bof{forced-color-adjust:auto;}}", { m: "(forced-colors: active)" }]] }), Or = "url(#", kr = (t, n, r) => {
	let [i, a, ...o] = t, s = a;
	if (r && a) {
		let e = {};
		for (let t in a) {
			let n = a[t];
			if (typeof n != "string") e[t] = n;
			else if (t === "id") e[t] = r + n;
			else {
				let i = n.indexOf(Or);
				e[t] = i < 0 ? n : n.slice(0, i + 5) + r + n.slice(i + 5);
			}
		}
		s = e;
	}
	return e.createElement(i, {
		...s,
		key: n
	}, ...o.map((e, t) => kr(e, t, r)));
}, Ar = (e) => e === "1em" ? "20" : e, jr = (e, t, n) => typeof e != "string" && (t?.color || Array.isArray(e[0])) ? e.map((e, t) => kr(e, t, n)) : void 0, Mr = () => void 0, Nr = (t, n) => {
	let r = jr(t, n);
	return r ? function(i) {
		return e.useMemo(() => i ? jr(t, n, i) : r, [i]);
	} : Mr;
}, Pr = (t, n, r) => typeof n == "string" ? e.createElement("svg", {
	...t,
	dangerouslySetInnerHTML: { __html: n }
}) : r ? e.createElement("svg", t, ...r) : e.createElement("svg", t, ...n.map((n) => e.createElement("path", {
	d: n,
	fill: t.fill
}))), Fr = (t, n, r, i) => {
	let a = Ar(n), o = Nr(r, i), s = e.forwardRef((e, t) => {
		let s = Dr(), c = Er(e, { flipInRtl: i?.flipInRtl }), l = o(e.idPrefix);
		return Pr({
			...c,
			className: An(Cr, c.className, s.root),
			ref: t,
			width: n,
			height: n,
			viewBox: `0 0 ${a} ${a}`,
			xmlns: "http://www.w3.org/2000/svg"
		}, r, l);
	});
	return s.displayName = t, s;
}, Ir = /*#__PURE__*/ Fr("Info16Regular", "16", ["M8.5 7.5a.5.5 0 1 0-1 0v3a.5.5 0 0 0 1 0v-3Zm.25-2a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0ZM8 1a7 7 0 1 0 0 14A7 7 0 0 0 8 1ZM2 8a6 6 0 1 1 12 0A6 6 0 0 1 2 8Z"]), Lr = /*#__PURE__*/ Fr("Dismiss16Regular", "16", ["m2.59 2.72.06-.07a.5.5 0 0 1 .63-.06l.07.06L8 7.29l4.65-4.64a.5.5 0 0 1 .7.7L8.71 8l4.64 4.65c.18.17.2.44.06.63l-.06.07a.5.5 0 0 1-.63.06l-.07-.06L8 8.71l-4.65 4.64a.5.5 0 0 1-.7-.7L7.29 8 2.65 3.35a.5.5 0 0 1-.06-.63l.06-.07-.06.07Z"]), Rr = ".amll-word-tools-splitter{position:relative;display:inline-block;width:25px;margin:0 -7px;z-index:1;align-self:stretch;background:none;border:none;padding:0;font:inherit;color:inherit;cursor:text;appearance:none}\n.amll-word-tools-splitter:hover::before,.amll-word-tools-splitter[data-split=\"true\"]::before{content:\"\";position:absolute;left:50%;top:10%;bottom:10%;width:2px;background-color:var(--accent-6);transform:translateX(-50%);border-radius:1px}\n.amll-word-tools-splitter[data-split=\"true\"]::before{background-color:var(--accent-10)}\n.amll-word-tools-splitter:hover::after,.amll-word-tools-splitter[data-split=\"true\"]::after{content:\"\";position:absolute;left:50%;top:100%;margin-top:-4px;transform:translateX(-50%);width:0;height:0;border-left:5px solid transparent;border-right:5px solid transparent;border-bottom:5px solid var(--accent-6)}\n.amll-word-tools-splitter[data-split=\"true\"]::after{border-bottom-color:var(--accent-10)}\n.amll-word-tools-grapheme{display:inline-block;padding:0 1px;font-size:var(--font-size-5);line-height:var(--line-height-5);font-family:var(--code-font-family);user-select:none}", zr = (e, t, n) => {
	let [r, i] = s(n);
	return o(() => {
		let n = !0;
		return e.storage.kv.get(t).then((e) => {
			n && typeof e == "boolean" && i(e);
		}), () => {
			n = !1;
		};
	}, [e, t]), [r, (n) => {
		i(n), e.storage.kv.set(t, n);
	}];
}, Q = (e, t) => e.ui.notify({
	level: "error",
	message: e.i18n.t("failed"),
	detail: String(t)
}), Br = ({ host: e, label: t, applyToAll: n, setApplyToAll: r, ignoreCase: i, setIgnoreCase: a }) => /* @__PURE__ */ u(h, {
	direction: "column",
	gap: "2",
	children: [/* @__PURE__ */ l(v, {
		as: "label",
		size: "2",
		children: /* @__PURE__ */ u(h, {
			gap: "2",
			align: "center",
			children: [/* @__PURE__ */ l(m, {
				checked: n,
				onCheckedChange: (e) => r(e === !0)
			}), t]
		})
	}), /* @__PURE__ */ l(v, {
		as: "label",
		size: "2",
		children: /* @__PURE__ */ u(h, {
			gap: "2",
			align: "center",
			style: { opacity: n ? 1 : .5 },
			children: [/* @__PURE__ */ l(m, {
				disabled: !n,
				checked: i,
				onCheckedChange: (e) => a(e === !0)
			}), e.i18n.t("ignoreCase")]
		})
	})]
}), Vr = ({ host: e, viewId: t, target: r }) => {
	let i = r.wordId ? B(e.document.readSnapshot(), r.wordId) : void 0, a = i?.text ?? "", [m, g] = s(/* @__PURE__ */ new Set()), [_, v] = zr(e, "split.applyToAll", !1), [y, b] = zr(e, "split.ignoreCase", !0);
	o(() => {
		let t = !0;
		return i && mn(e, i).then((e) => t && g(e)).catch(() => t && g(/* @__PURE__ */ new Set())), () => {
			t = !1;
		};
	}, [e, i?.id]);
	let x = (e) => g((t) => {
		let n = new Set(t);
		return n.delete(e) || n.add(e), n;
	});
	return /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ l("style", { children: Rr }),
		/* @__PURE__ */ u(h, {
			direction: "column",
			gap: "2",
			children: [
				/* @__PURE__ */ u(p.Root, {
					color: "blue",
					children: [/* @__PURE__ */ l(p.Icon, { children: /* @__PURE__ */ l(Ir, {}) }), /* @__PURE__ */ l(p.Text, { children: e.i18n.t("splitTip") })]
				}),
				/* @__PURE__ */ l(d, {
					my: "3",
					children: /* @__PURE__ */ l(h, {
						align: "center",
						justify: "center",
						style: {
							backgroundColor: "var(--gray-4)",
							borderRadius: "var(--radius-2)",
							padding: "var(--space-4)",
							minHeight: "4em",
							userSelect: "none",
							overflowX: "auto",
							whiteSpace: "nowrap"
						},
						children: Array.from(a).map((e, t) => /* @__PURE__ */ u(n, { children: [t > 0 && /* @__PURE__ */ l("button", {
							type: "button",
							className: "amll-word-tools-splitter",
							"data-split": m.has(t),
							onClick: () => x(t)
						}), /* @__PURE__ */ l("span", {
							className: "amll-word-tools-grapheme",
							children: e
						})] }, `${e}-${t}`))
					})
				}),
				/* @__PURE__ */ l(Br, {
					host: e,
					label: e.i18n.t("splitApplyToAll"),
					applyToAll: _,
					setApplyToAll: v,
					ignoreCase: y,
					setIgnoreCase: b
				})
			]
		}),
		/* @__PURE__ */ l(h, {
			justify: "end",
			mt: "4",
			children: /* @__PURE__ */ l(f, {
				disabled: !i,
				onClick: () => {
					e.ui.closeView(t), i && gn(e, {
						wordId: i.id,
						splitIndices: m,
						applyToAll: _,
						ignoreCase: y
					}).catch((t) => Q(e, t));
				},
				children: e.i18n.t("confirm")
			})
		})
	] });
}, Hr = ({ host: e, viewId: t, target: n }) => {
	let r = n.wordId ? B(e.document.readSnapshot(), n.wordId) : void 0, [i, a] = s(r?.text ?? ""), [o, d] = s(!1), [p, m] = s(!0), g = () => {
		if (e.ui.closeView(t), r) try {
			_n(e, {
				wordId: r.id,
				text: i,
				applyToAll: o,
				ignoreCase: p
			});
		} catch (t) {
			Q(e, t);
		}
	};
	return /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ l(v, {
			as: "p",
			size: "2",
			mb: "4",
			children: e.i18n.t("replaceDescription")
		}),
		/* @__PURE__ */ u(h, {
			direction: "column",
			gap: "3",
			children: [/* @__PURE__ */ l(y.Root, {
				value: i,
				onChange: (e) => a(e.target.value),
				placeholder: e.i18n.t("replacePlaceholder"),
				onKeyDown: (e) => {
					e.key === "Enter" && g();
				},
				autoFocus: !0
			}), /* @__PURE__ */ l(Br, {
				host: e,
				label: e.i18n.t("replaceApplyToAll"),
				applyToAll: o,
				setApplyToAll: d,
				ignoreCase: p,
				setIgnoreCase: m
			})]
		}),
		/* @__PURE__ */ u(h, {
			gap: "3",
			mt: "4",
			justify: "end",
			children: [/* @__PURE__ */ l(f, {
				variant: "soft",
				color: "gray",
				onClick: () => e.ui.closeView(t),
				children: e.i18n.t("cancel")
			}), /* @__PURE__ */ l(f, {
				disabled: !r,
				onClick: g,
				children: e.i18n.t("confirm")
			})]
		})
	] });
}, Ur = ({ host: e, viewId: t }) => {
	let [n] = s(() => e.selection.get()), r = n.lineIds.length > 0, [i, a] = s(r ? "selected" : "all"), [o, d] = s("1"), [b, x] = s(() => String(e.document.readSnapshot().lines.length)), [S, C] = zr(e, "smoothing.tipDismissed", !1), [w, ee] = s("15"), [T, te] = s("15"), [E, ne] = s(!1), D = Number.parseFloat(T), O = w === "custom" && (Number.isNaN(D) || D < 0 || D > 100);
	return /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ l(v, {
			as: "p",
			size: "2",
			mb: "2",
			color: "gray",
			style: {
				whiteSpace: "pre-line",
				lineHeight: "2"
			},
			children: e.i18n.t("smoothDescription")
		}),
		/* @__PURE__ */ u(h, {
			direction: "column",
			gap: "4",
			children: [
				!S && /* @__PURE__ */ u(p.Root, {
					color: "amber",
					size: "1",
					variant: "soft",
					style: {
						display: "flex",
						alignItems: "center",
						paddingRight: "10px"
					},
					children: [
						/* @__PURE__ */ l(p.Icon, {
							style: {
								display: "flex",
								alignItems: "center"
							},
							children: /* @__PURE__ */ l(Ir, { style: { display: "block" } })
						}),
						/* @__PURE__ */ l(p.Text, {
							size: "1",
							style: { flex: 1 },
							children: e.i18n.t("thresholdWarning")
						}),
						/* @__PURE__ */ l(g, {
							size: "1",
							variant: "ghost",
							color: "gray",
							onClick: () => C(!0),
							style: { margin: 0 },
							children: /* @__PURE__ */ l(Lr, {})
						})
					]
				}),
				/* @__PURE__ */ u(h, {
					direction: "column",
					gap: "2",
					children: [
						/* @__PURE__ */ l(v, {
							size: "2",
							weight: "bold",
							children: e.i18n.t("thresholdLabel")
						}),
						/* @__PURE__ */ l(_.Root, {
							value: w,
							onValueChange: (e) => ee(e),
							children: /* @__PURE__ */ u(h, {
								direction: "column",
								gap: "2",
								children: [
									/* @__PURE__ */ l(_.Item, {
										value: "5",
										children: e.i18n.t("thresholdLow")
									}),
									/* @__PURE__ */ l(_.Item, {
										value: "15",
										children: e.i18n.t("thresholdMedium")
									}),
									/* @__PURE__ */ l(_.Item, {
										value: "30",
										children: e.i18n.t("thresholdHigh")
									}),
									/* @__PURE__ */ l(_.Item, {
										value: "custom",
										children: e.i18n.t("thresholdCustom")
									})
								]
							})
						}),
						w === "custom" && /* @__PURE__ */ u(h, {
							align: "center",
							gap: "2",
							ml: "4",
							children: [/* @__PURE__ */ l(v, {
								size: "2",
								children: e.i18n.t("customThreshold")
							}), /* @__PURE__ */ u(y.Root, {
								style: { width: "80px" },
								size: "1",
								type: "number",
								min: "0",
								max: "100",
								value: T,
								onChange: (e) => te(e.target.value),
								color: O ? "red" : void 0,
								children: [/* @__PURE__ */ l(y.Slot, {}), /* @__PURE__ */ l(y.Slot, { children: "%" })]
							})]
						})
					]
				}),
				/* @__PURE__ */ u(h, {
					direction: "column",
					gap: "1",
					children: [/* @__PURE__ */ l(v, {
						as: "label",
						size: "2",
						children: /* @__PURE__ */ u(h, {
							gap: "2",
							align: "center",
							children: [/* @__PURE__ */ l(m, {
								checked: E,
								onCheckedChange: (e) => ne(e === !0)
							}), /* @__PURE__ */ l(v, {
								weight: "bold",
								children: e.i18n.t("mergeSyllables")
							})]
						})
					}), /* @__PURE__ */ l(v, {
						size: "1",
						color: "gray",
						ml: "5",
						children: e.i18n.t("mergeSyllablesHint")
					})]
				}),
				/* @__PURE__ */ u(h, {
					direction: "column",
					gap: "2",
					children: [
						/* @__PURE__ */ l(v, {
							size: "2",
							weight: "bold",
							children: e.i18n.t("scope")
						}),
						/* @__PURE__ */ u(_.Root, {
							value: i,
							onValueChange: (e) => a(e),
							children: [
								/* @__PURE__ */ l(_.Item, {
									value: "all",
									children: e.i18n.t("scopeAll")
								}),
								/* @__PURE__ */ u(_.Item, {
									value: "selected",
									disabled: !r,
									children: [e.i18n.t("scopeSelected"), r && ` (${n.lineIds.length})`]
								}),
								/* @__PURE__ */ l(_.Item, {
									value: "selected-following",
									disabled: !r,
									children: e.i18n.t("scopeSelectedFollowing")
								}),
								/* @__PURE__ */ l(_.Item, {
									value: "custom",
									children: e.i18n.t("scopeCustom")
								})
							]
						}),
						i === "custom" && /* @__PURE__ */ u(h, {
							align: "center",
							gap: "2",
							ml: "4",
							children: [
								/* @__PURE__ */ l(v, {
									size: "2",
									children: e.i18n.t("fromLine")
								}),
								/* @__PURE__ */ l(y.Root, {
									style: { width: "60px" },
									size: "1",
									type: "number",
									value: o,
									onChange: (e) => d(e.target.value)
								}),
								/* @__PURE__ */ l(v, {
									size: "2",
									children: e.i18n.t("toLine")
								}),
								/* @__PURE__ */ l(y.Root, {
									style: { width: "60px" },
									size: "1",
									type: "number",
									value: b,
									onChange: (e) => x(e.target.value)
								}),
								/* @__PURE__ */ l(v, {
									size: "2",
									children: e.i18n.t("line")
								})
							]
						})
					]
				})
			]
		}),
		/* @__PURE__ */ u(h, {
			gap: "3",
			mt: "5",
			justify: "end",
			children: [/* @__PURE__ */ l(f, {
				variant: "soft",
				color: "gray",
				onClick: () => e.ui.closeView(t),
				children: e.i18n.t("cancel")
			}), /* @__PURE__ */ l(f, {
				disabled: O,
				onClick: () => {
					if (O) return;
					let r = Sn(e.document.readSnapshot(), n, i, o, b);
					e.ui.closeView(t);
					try {
						xn(e, r, {
							threshold: w === "custom" ? D : Number(w),
							mergeSyllables: E
						});
					} catch (t) {
						Q(e, t);
					}
				},
				children: e.i18n.t("apply")
			})]
		})
	] });
}, $ = "builtin.word-tools", Wr = (e, t) => {
	try {
		t();
	} catch (t) {
		e.ui.notify({
			level: "error",
			message: e.i18n.t("failed"),
			detail: String(t)
		});
	}
}, Gr = (e, t) => {
	if (t && typeof t == "object" && !Array.isArray(t) && typeof t.wordId == "string") return t.wordId;
	let { wordIds: n } = e.selection.get();
	return n.length === 1 ? n[0] : void 0;
};
function Kr({ host: e }) {
	e.romanization.registerPredictor((e, t) => Xt(e, t));
	for (let [t, n] of [["split", Vr], ["replace", Hr]]) {
		let r = `${$}.${t}`, a = {};
		e.views.registerView({
			id: r,
			kind: "dialog-view",
			title: t === "split" ? b.splitTitle : b.replaceTitle,
			size: "small",
			view: () => i(n, {
				host: e,
				viewId: r,
				target: a
			})
		}), e.commands.register({
			id: r,
			title: b[t],
			handler: (t) => {
				a.wordId = Gr(e, t), a.wordId ? e.ui.openView(r) : e.ui.notify({
					level: "warning",
					message: e.i18n.t("noWord")
				});
			}
		}), e.menus.register({
			id: `${r}.menu`,
			menu: "context.lyricWord",
			command: r
		});
	}
	let t = `${$}.smooth`;
	e.views.registerView({
		id: t,
		kind: "dialog-view",
		title: b.smoothTitle,
		size: "small",
		view: () => i(Ur, {
			host: e,
			viewId: t
		})
	}), e.commands.register({
		id: t,
		title: b.smooth,
		handler: () => e.ui.openView(t)
	}), e.menus.register({
		id: `${t}.menu`,
		menu: "menu.tool",
		command: t
	});
	let n = `${$}.distribute-romanization`;
	e.commands.register({
		id: n,
		title: b.distribute,
		handler: () => Wr(e, () => {
			let { lineIds: t } = e.selection.get(), n = yn(e, t.length ? new Set(t) : void 0);
			n.length && e.ui.notify({
				level: "error",
				message: e.i18n.t("distributeFailed", { count: n.length }),
				detail: n.join(", ")
			});
		})
	});
	let r = `${$}.check-romanization`;
	e.commands.register({
		id: r,
		title: b.check,
		handler: () => Wr(e, () => bn(e))
	});
	for (let t of [n, r]) e.menus.register({
		id: `${t}.menu`,
		menu: "menu.tool",
		command: t,
		group: "romanization"
	});
}
export { Kr as activate };
