import * as e from "react";
import t, { createContext as n, createElement as r, useContext as i, useEffect as a, useId as o, useState as s } from "react";
import { jsx as c, jsxs as l } from "react/jsx-runtime";
import { Box as u, Button as d, Callout as f, Card as p, Checkbox as m, Flex as h, IconButton as g, Kbd as ee, Text as _, Tooltip as v } from "@radix-ui/themes";
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/constants.js
var y = typeof window > "u" ? global : window, b = "@griffel/";
function x(e, t) {
	return y[Symbol.for(b + e)] || (y[Symbol.for(b + e)] = t), y[Symbol.for(b + e)];
}
var S = /*#__PURE__*/ x("DEBUG_RESET_CLASSES", {}), C = /*#__PURE__*/ x("DEFINITION_LOOKUP_TABLE", {}), w = "data-make-styles-bucket", T = "data-priority", E = "data-container", D = process.env.NODE_ENV === "production" ? 10 : 18;
// node_modules/.pnpm/@emotion+hash@0.9.2/node_modules/@emotion/hash/dist/emotion-hash.esm.js
function O(e) {
	for (var t = 0, n, r = 0, i = e.length; i >= 4; ++r, i -= 4) n = e.charCodeAt(r) & 255 | (e.charCodeAt(++r) & 255) << 8 | (e.charCodeAt(++r) & 255) << 16 | (e.charCodeAt(++r) & 255) << 24, n = (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16), n ^= n >>> 24, t = (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16) ^ (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
	switch (i) {
		case 3: t ^= (e.charCodeAt(r + 2) & 255) << 16;
		case 2: t ^= (e.charCodeAt(r + 1) & 255) << 8;
		case 1: t ^= e.charCodeAt(r) & 255, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
	}
	return t ^= t >>> 13, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16), ((t ^ t >>> 15) >>> 0).toString(36);
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/utils/hashSequence.js
function k(e) {
	let t = e.length;
	if (t === 7) return e;
	for (let n = t; n < 7; n++) e += "0";
	return e;
}
function A(e, t, n = []) {
	return process.env.NODE_ENV === "production" ? "___" + k(O(e + t)) : "___" + k(O(e + t)) + "_" + k(O(n.join("")));
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/reduceToClassNameForSlots.js
function j(e, t) {
	let n = "", r = "";
	for (let i in e) {
		let a = e[i];
		if (a === 0) {
			r += i + " ";
			continue;
		}
		let o = Array.isArray(a), s = t === "rtl" ? (o ? a[1] : a) + " " : (o ? a[0] : a) + " ";
		n += s, r += s;
	}
	return [n.slice(0, -1), r.slice(0, -1)];
}
function M(e, t) {
	let n = {};
	for (let r in e) {
		let [i, a] = j(e[r], t);
		if (a === "") {
			n[r] = "";
			continue;
		}
		let o = A(a, t), s = o + (i === "" ? "" : " " + i);
		C[o] = [e[r], t], n[r] = s;
	}
	return n;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/mergeClasses.js
var N = {};
function P() {
	let e = null, t = "", n = "", r = Array(arguments.length), i = "";
	for (let e = 0; e < arguments.length; e++) {
		let a = arguments[e];
		if (typeof a == "string" && a !== "") {
			let o = a.indexOf("___");
			if (o === -1) process.env.NODE_ENV !== "production" && a.split(" ").forEach((e) => {
				e.startsWith("r") && S[e] && (i ? console.error(`mergeClasses(): a passed string contains multiple classes produced by makeResetStyles (${a} & ${t}, this will lead to non-deterministic behavior. Learn more:https://griffel.js.org/react/api/make-reset-styles#limitations
Source string: ${a}`) : i = e);
			}), t += a + " ";
			else {
				let i = a.substr(o, D);
				o > 0 && (t += a.slice(0, o)), n += i, r[e] = i;
			}
			process.env.NODE_ENV !== "production" && a.indexOf("___", o + 1) !== -1 && console.error(`mergeClasses(): a passed string contains multiple identifiers of atomic classes (classes that start with "___"), it's possible that passed classes were concatenated in a wrong way. Source string: ${a}`);
		}
	}
	if (n === "") return t.slice(0, -1);
	let a = N[n];
	if (a !== void 0) return t + a;
	let o = [];
	for (let t = 0; t < arguments.length; t++) {
		let n = r[t];
		if (n) {
			let r = C[n];
			r ? (o.push(r[0]), process.env.NODE_ENV !== "production" && e !== null && e !== r[1] && console.error(`mergeClasses(): a passed string contains an identifier (${n}) that has different direction (dir="${r[1] ? "rtl" : "ltr"}") setting than other classes. This is not supported. Source string: ${arguments[t]}`), e = r[1]) : process.env.NODE_ENV !== "production" && console.error(`mergeClasses(): a passed string contains an identifier (${n}) that does not match any entry in cache. Source string: ${arguments[t]}`);
		}
	}
	let s = Object.assign.apply(Object, [{}].concat(o)), [c, l] = j(s, e), u = A(l, e, r), d = u + " " + c;
	return N[n] = d, C[u] = [s, e], t + d;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/store.js
var F = {}, I = /* @__PURE__ */ new Set(), L = {
	getChildrenSequences: (e) => {
		let t = Object.keys(N).find((t) => N[t].startsWith(e));
		return t ? t.split("___").filter((e) => e.length).map((e) => "___" + e) : [];
	},
	addCSSRule: (e) => {
		I.add(e);
	},
	addSequenceDetails: (e, t) => {
		Object.entries(e).forEach(([e, n]) => {
			F[n.substring(0, D)] = {
				slotName: e,
				sourceURL: t
			};
		});
	},
	getCSSRules: () => Array.from(I),
	getSequenceDetails: (e) => F[e]
};
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/utils.js
function R(e, t) {
	return Array.isArray(e) ? t === "rtl" ? e[1] : e[0] : e || "";
}
function z(e, t, n, r) {
	let i = e[0], a = e[1];
	return Object.entries(i).map(([e, i]) => {
		let o = R(i, a), s;
		if (n && t) {
			let i = n.find(({ className: e }) => e === o);
			!i && t[0][e] ? s = R(t[0][e], t[1]) : i && t[0][e] ? s = r && r.filter(({ debugClassNames: e }) => e.filter(({ className: e }) => e === o).length > 0).length > 0 ? i.className : i.overriddenBy : (!i && !t[0][e] || i && !t[0][e]) && (s = void 0);
		}
		return {
			className: o,
			overriddenBy: s
		};
	});
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getAtomicDebugSequenceTree.js
function B(e, t) {
	let n = C[e];
	if (n === void 0) return;
	let r = z(n, t ? C[t.sequenceHash] : void 0, t?.debugClassNames, t?.children), i = {
		sequenceHash: e,
		direction: n[1],
		children: [],
		debugClassNames: r
	};
	return L.getChildrenSequences(i.sequenceHash).reverse().forEach((e) => {
		let t = B(e, i);
		t && i.children.push(t);
	}), i.children.length || (i.rules = {}, i.debugClassNames.forEach(({ className: t }) => {
		let n = L.getSequenceDetails(e);
		n && (i.slot = n.slotName, i.sourceURL = n.sourceURL);
		let r = L.getCSSRules().find((e) => e.includes(t));
		i.rules[t] = r;
	})), i;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getResetDebugSequence.js
function V(e) {
	if (S[e] === void 0) return;
	let t = {
		sequenceHash: e,
		direction: "ltr",
		children: [],
		debugClassNames: [{ className: e }]
	};
	t.rules = {}, t.slot = "makeResetStyles()";
	let [{ className: n }] = t.debugClassNames, r = L.getCSSRules().filter((e) => e.includes(`.${n}`));
	return t.rules[n] = r.join(""), t;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/mergeDebugSequence.js
function H(e, t) {
	let n = e ? B(e) : void 0, r = t ? V(t) : void 0;
	if (n || r) return n ? r ? {
		sequenceHash: n.sequenceHash + r.sequenceHash,
		direction: n.direction,
		children: [n, r],
		debugClassNames: [...n.debugClassNames, ...r.debugClassNames]
	} : n : r;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/injectDevTools.js
function U(e) {
	let t = e.defaultView;
	if (!t || t.__GRIFFEL_DEVTOOLS__) return;
	let n = { getInfo: (e) => {
		let t, n;
		for (let r of e.classList) r.startsWith("___") && (t = r), S[r] && (n = r);
		return H(t, n);
	} };
	Object.defineProperty(t, "__GRIFFEL_DEVTOOLS__", {
		configurable: !1,
		enumerable: !1,
		get() {
			return n;
		}
	});
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/isDevToolsEnabled.js
var W = (() => {
	try {
		return !!(typeof window < "u" && window.sessionStorage?.getItem("__GRIFFEL_DEVTOOLS__"));
	} catch {
		return !1;
	}
})(), G = "<unknown>";
function te(e) {
	return ae(e) || ce(e) || ue(e);
}
var ne = /^\s*at (.*?) ?\(((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/|[a-z]:\\|\\\\).*?)?\)?\s*$/i, re = /^\s*at ()((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/|[a-z]:\\|\\\\).*?)\s*$/i, ie = /\((\S*)\)/;
function ae(e) {
	let t = ne.exec(e) || re.exec(e);
	if (!t) return null;
	let n = t[2], r = n && n.indexOf("native") === 0, i = n && n.indexOf("eval") === 0, a = ie.exec(n);
	return i && a !== null && (n = a[1]), {
		loc: r ? null : t[2],
		name: t[1] || G
	};
}
var oe = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|resource|\[native).*?|[^@]*bundle)\s*$/i, se = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;
function ce(e) {
	let t = oe.exec(e);
	if (!t) return null;
	let n = t[3], r = n && n.indexOf(" > eval") > -1, i = se.exec(n);
	return r && i !== null && (n = i[1]), {
		loc: t[3],
		name: t[1] || G
	};
}
var le = /^\s*(?:([^@]*)(?:\((.*?)\))?@)?(\S.*?)\s*$/i;
function ue(e) {
	let t = le.exec(e);
	return t ? {
		loc: t[3],
		name: t[1] || G
	} : null;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getSourceURLfromError.js
function de() {
	let e = fe(String((/* @__PURE__ */ Error()).stack).split("\n"));
	return e === void 0 ? void 0 : te(e)?.loc;
}
function fe(e) {
	for (let t = e.length - 1; t >= 0; --t) if (e[t].includes("at getSourceURLfromError")) return e[t + 3];
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/utils/normalizeCSSBucketEntry.js
function pe(e) {
	if (!Array.isArray(e)) return [e];
	if (process.env.NODE_ENV !== "production" && e.length > 2) throw Error("CSS Bucket contains an entry with greater than 2 items, please report this to https://github.com/microsoft/griffel/issues");
	return e;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/createIsomorphicStyleSheet.js
function me(e, t, n, r) {
	let i = [];
	if (r[w] = t, r[T] = String(n), e) for (let t in r) e.setAttribute(t, r[t]);
	function a(t) {
		return e?.sheet ? e.sheet.insertRule(t, e.sheet.cssRules.length) : i.push(t);
	}
	return {
		elementAttributes: r,
		insertRule: a,
		element: e,
		bucketName: t,
		cssRules() {
			return e?.sheet ? Array.from(e.sheet.cssRules).map((e) => e.cssText) : i;
		}
	};
}
var K = /*#__PURE__*/ [
	"r",
	"d",
	"l",
	"v",
	"w",
	"f",
	"i",
	"h",
	"a",
	"s",
	"k",
	"t",
	"m",
	"c",
	"x"
].reduce((e, t, n) => (e[t] = n, e), {});
function he(e, t, n) {
	return e === "m" || e === "x" ? e + t + n : e + n;
}
function ge(e, t, n, r, i = {}) {
	let a = e === "m", o = e === "x", s = i.m, c = i.x, l = i.p ?? 0, u = he(e, c ?? s ?? "0", l);
	if (!r.stylesheets[u]) {
		let d = t && t.createElement("style"), f = me(d, e, l, {
			...r.styleElementAttributes,
			...a && { media: s },
			...o && { "data-container": c }
		});
		r.stylesheets[u] = f, t?.head && d && t.head.insertBefore(d, ve(t, n, e, r, i));
	}
	return r.stylesheets[u];
}
function _e(e, t, n) {
	return e.getAttribute("data-make-styles-bucket") === t ? t === "m" ? n.m === e.media : t !== "x" || n.x === e.getAttribute(E) : !1;
}
function ve(e, t, n, r, i = {}) {
	let a = K[n], o = i.m ?? "", s = i.x ?? "", c = i.p ?? 0, l = (e) => a - K[e.getAttribute(w)], u = e.head.querySelectorAll(`[${w}]`);
	if (n === "m" || n === "x") {
		let t = e.head.querySelectorAll(`[${w}="${n}"]`);
		t.length && (u = t, l = n === "m" ? (e) => r.compareMediaQueries(o, e.media) : (e) => r.compareContainerQueries(s, e.getAttribute("data-container") ?? ""));
	}
	let d = (e) => _e(e, n, i) ? c - Number(e.getAttribute(T)) : l(e), f = u.length, p = f - 1;
	for (; p >= 0;) {
		let e = u.item(p);
		if (d(e) > 0) return e.nextSibling;
		p--;
	}
	return f > 0 ? u.item(0) : t ? t.nextSibling : null;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/safeInsertRule.js
var ye = /*#__PURE__*/ RegExp(":(-moz-placeholder|-moz-focus-inner|-moz-focusring|-ms-input-placeholder|-moz-read-write|-moz-read-only)");
function q(e, t) {
	try {
		e.insertRule(t);
	} catch (e) {
		process.env.NODE_ENV !== "production" && !ye.test(t) && console.error(`There was a problem inserting the following rule: "${t}"`, e);
	}
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/createDOMRenderer.js
var be = 0, xe = (e, t) => e < t ? -1 : +(e > t);
function Se(e = typeof document > "u" ? void 0 : document, t = {}) {
	let { classNameHashSalt: n, unstable_filterCSSRule: r, insertionPoint: i, styleElementAttributes: a, compareMediaQueries: o = xe, compareContainerQueries: s = o } = t, c = {
		classNameHashSalt: n,
		insertionCache: {},
		stylesheets: {},
		styleElementAttributes: Object.freeze(a),
		compareMediaQueries: o,
		compareContainerQueries: s,
		id: `d${be++}`,
		insertCSSRules(t) {
			for (let n in t) {
				let a = t[n];
				for (let t = 0, o = a.length; t < o; t++) {
					let [o, s] = pe(a[t]), l = ge(n, e, i || null, c, s);
					c.insertionCache[o] || (c.insertionCache[o] = n, process.env.NODE_ENV !== "production" && W && L.addCSSRule(o), r ? r(o) && q(l, o) : q(l, o));
				}
			}
		}
	};
	return e && process.env.NODE_ENV !== "production" && W && U(e), c;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/insertionFactory.js
var Ce = () => {
	let e = {};
	return function(t, n) {
		e[t.id] === void 0 && (t.insertCSSRules(n), e[t.id] = !0);
	};
};
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/__styles.js
function we(e, t, n = Ce) {
	let r = n(), i = null, a = null, o;
	process.env.NODE_ENV !== "production" && W && (o = de());
	function s(n) {
		let { dir: s, renderer: c } = n, l = s === "ltr";
		l ? i === null && (i = M(e, s)) : a === null && (a = M(e, s)), r(c, t);
		let u = l ? i : a;
		return process.env.NODE_ENV !== "production" && W && L.addSequenceDetails(u, o), u;
	}
	return s;
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/utils/canUseDOM.js
function Te() {
	return typeof window < "u" && !!(window.document && window.document.createElement);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/useInsertionEffect.js
var J = t.useInsertionEffect ? t.useInsertionEffect : void 0, Ee = () => {
	let e = {};
	return function(t, n) {
		J && Te() ? J(() => {
			t.insertCSSRules(n);
		}, [t, n]) : e[t.id] === void 0 && (t.insertCSSRules(n), e[t.id] = !0);
	};
}, De = /*#__PURE__*/ n(/*#__PURE__*/ Se());
function Oe() {
	return i(De);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/TextDirectionContext.js
var ke = /*#__PURE__*/ n("ltr");
function Ae() {
	return i(ke);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/__styles.js
function Y(e, t) {
	let n = we(e, t, Ee);
	return function() {
		let e = Ae(), t = Oe();
		return n({
			dir: e,
			renderer: t
		});
	};
}
// node_modules/.pnpm/@fluentui+react-icons@2.0.344_react@19.2.7/node_modules/@fluentui/react-icons/lib/utils/useIconStyles.styles.js
var je = Y({
	root: {
		mc9l5x: "f1w7gpdv",
		Bg96gwp: "fez10in"
	},
	rtl: { Bz10aip: "f13rod7r" }
}, { d: [
	".f1w7gpdv{display:inline;}",
	".fez10in{line-height:0;}",
	".f13rod7r{transform:scaleX(-1);}"
] }), X = e.createContext(void 0), Me = {};
X.Provider;
var Ne = () => e.useContext(X) ?? Me, Pe = "fui-Icon", Fe = "data-fui-icon", Ie = (e, t) => {
	let { filled: n, idPrefix: r, title: i, primaryFill: a = "currentColor", ...o } = e, s = {
		...o,
		fill: a
	}, c = Ne(), l = !!(t?.flipInRtl && c?.textDirection === "rtl");
	return i && (s["aria-label"] = i), !s["aria-label"] && !s["aria-labelledby"] ? s["aria-hidden"] = !0 : s.role = "img", s[Fe] = "", {
		state: s,
		isRtlFlip: l
	};
}, Le = (e, t) => {
	let n = je(), { state: r, isRtlFlip: i } = Ie(e, t);
	return r.className = P(n.root, i && n.rtl, r.className), r;
}, Re = Y({ root: { B8gzw0y: "f1dd5bof" } }, { m: [["@media (forced-colors: active){.f1dd5bof{forced-color-adjust:auto;}}", { m: "(forced-colors: active)" }]] }), ze = "url(#", Z = (t, n, r) => {
	let [i, a, ...o] = t, s = a;
	if (r && a) {
		let e = {};
		for (let t in a) {
			let n = a[t];
			if (typeof n != "string") e[t] = n;
			else if (t === "id") e[t] = r + n;
			else {
				let i = n.indexOf(ze);
				e[t] = i < 0 ? n : n.slice(0, i + 5) + r + n.slice(i + 5);
			}
		}
		s = e;
	}
	return e.createElement(i, {
		...s,
		key: n
	}, ...o.map((e, t) => Z(e, t, r)));
}, Be = (e) => e === "1em" ? "20" : e, Q = (e, t, n) => typeof e != "string" && (t?.color || Array.isArray(e[0])) ? e.map((e, t) => Z(e, t, n)) : void 0, Ve = () => void 0, He = (t, n) => {
	let r = Q(t, n);
	return r ? function(i) {
		return e.useMemo(() => i ? Q(t, n, i) : r, [i]);
	} : Ve;
}, Ue = (t, n, r) => typeof n == "string" ? e.createElement("svg", {
	...t,
	dangerouslySetInnerHTML: { __html: n }
}) : r ? e.createElement("svg", t, ...r) : e.createElement("svg", t, ...n.map((n) => e.createElement("path", {
	d: n,
	fill: t.fill
}))), $ = (t, n, r, i) => {
	let a = Be(n), o = He(r, i), s = e.forwardRef((e, t) => {
		let s = Re(), c = Le(e, { flipInRtl: i?.flipInRtl }), l = o(e.idPrefix);
		return Ue({
			...c,
			className: P(Pe, c.className, s.root),
			ref: t,
			width: n,
			height: n,
			viewBox: `0 0 ${a} ${a}`,
			xmlns: "http://www.w3.org/2000/svg"
		}, r, l);
	});
	return s.displayName = t, s;
}, We = /*#__PURE__*/ $("ArrowResetRegular", "1em", ["M5.85 2.65c.2.2.2.5 0 .7L4.21 5H11a6 6 0 1 1-6 6 .5.5 0 0 1 1 0 5 5 0 1 0 5-5H4.2l1.65 1.65a.5.5 0 1 1-.7.7l-2.5-2.5a.5.5 0 0 1 0-.7l2.5-2.5c.2-.2.5-.2.7 0"], { flipInRtl: !0 }), Ge = /*#__PURE__*/ $("Info16Regular", "16", ["M8.5 7.5a.5.5 0 1 0-1 0v3a.5.5 0 0 0 1 0zm.25-2a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0M8 1a7 7 0 1 0 0 14A7 7 0 0 0 8 1M2 8a6 6 0 1 1 12 0A6 6 0 0 1 2 8"]), Ke = /*#__PURE__*/ $("ArrowLeft16Regular", "16", ["M13.5 8.5a.5.5 0 0 0 0-1H3.8l4.03-3.63a.5.5 0 1 0-.66-.74l-5 4.5a.5.5 0 0 0 0 .74l5 4.5a.5.5 0 1 0 .66-.74L3.8 8.5z"]), qe = /*#__PURE__*/ $("Timer16Regular", "16", ["M5 1.5c0-.28.22-.5.5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5M7.5 5a.5.5 0 0 0-.5.5v4a.5.5 0 0 0 1 0v-4a.5.5 0 0 0-.5-.5m6 4a6 6 0 1 1-12 0 6 6 0 0 1 12 0m-1 0a5 5 0 1 0-10 0 5 5 0 0 0 10 0m-.05-6.36a.5.5 0 1 0-.7.7l1.4 1.41a.5.5 0 1 0 .7-.7z"]), Je = /*#__PURE__*/ $("ErrorCircle16Regular", "16", ["M8 1a7 7 0 1 1 0 14A7 7 0 0 1 8 1m0 1a6 6 0 1 0 0 12A6 6 0 0 0 8 2m0 8a.75.75 0 1 1 0 1.5.75.75 0 0 1 0-1.5m0-5.5a.5.5 0 0 1 .5.41V8.5a.5.5 0 0 1-1 .09V5c0-.28.22-.5.5-.5"]), Ye = /*#__PURE__*/ $("Dismiss16Regular", "16", ["m2.59 2.72.06-.07a.5.5 0 0 1 .63-.06l.07.06L8 7.29l4.65-4.64a.5.5 0 0 1 .7.7L8.71 8l4.64 4.65c.18.17.2.44.06.63l-.06.07a.5.5 0 0 1-.63.06l-.07-.06L8 8.71l-4.65 4.64a.5.5 0 0 1-.7-.7L7.29 8 2.65 3.35a.5.5 0 0 1-.06-.63l.06-.07z"]);
// src/Panel.tsx
function Xe(e) {
	return e < 1e3 ? `${Math.round(e)} ms` : `${(e / 1e3).toFixed(2)} s`;
}
var Ze = ({ model: e }) => {
	let [, t] = s(0);
	a(() => e.subscribe(() => t((e) => e + 1)), [e]);
	let n = (t, n) => e.host.i18n.t(t), r = o(), i = o(), y = e.host.bpm.getState(), b = y.status === "completed" ? {
		...y,
		result: y,
		calculationTime: y.calculationTimeMs
	} : y, x = e.host.audio.getState(), S = y.status === "completed" ? Math.round(y.bpm * y.scale * (y.followPlaybackRate ? x.playbackRate : 1)) : null, C = y.followPlaybackRate, w = e.host.bpm.setFollowPlaybackRate, T = y.showBeatLines, E = e.host.bpm.setShowBeatLines, D = () => e.host.bpm.setScale(y.scale / 2), O = () => e.host.bpm.setScale(y.scale * 2), k = y.scale !== 1, A = x.loaded, j = e.mode === "key", M = e.mode === "spectrogram", N = e.taps, P = e.highlighted, F = e.setMode, I = e.host.bpm.tap, L = e.clearTaps, R = e.reset, z = e.tipSeen, B = e.setTipSeen, V = "--", H = "--";
	b.status === "completed" ? (V = `${S ?? Math.round(b.result.bpm)}`, H = Xe(b.calculationTime)) : b.status === "analyzing" && (V = n("sidebar.bpm.analyzing", "正在分析"));
	let U = b.status === "analyzing", W = b.status === "completed", G = k || N.length > 0 || W && b.calculationTime === 0;
	return /* @__PURE__ */ c(u, {
		p: "4",
		children: /* @__PURE__ */ l(h, {
			direction: "column",
			gap: "4",
			children: [
				/* @__PURE__ */ l(h, {
					direction: "column",
					align: "center",
					gap: "1",
					style: {
						position: "relative",
						width: "100%"
					},
					children: [
						/* @__PURE__ */ c(_, {
							size: "1",
							color: "gray",
							weight: "medium",
							children: "BPM"
						}),
						/* @__PURE__ */ l(h, {
							align: "center",
							justify: "center",
							gap: "5",
							style: { width: "100%" },
							children: [
								/* @__PURE__ */ c(v, {
									content: n("sidebar.bpm.halve", "减半 BPM"),
									children: /* @__PURE__ */ c(d, {
										size: "2",
										variant: "soft",
										color: "gray",
										disabled: !W || y.scale >= 64,
										onClick: D,
										style: { fontFamily: "var(--default-font-family-mono)" },
										children: "÷2"
									})
								}),
								/* @__PURE__ */ c(_, {
									size: U ? "6" : "8",
									weight: "bold",
									style: {
										fontFamily: "var(--default-font-family-mono)",
										fontVariantNumeric: "tabular-nums"
									},
									children: V
								}),
								/* @__PURE__ */ c(v, {
									content: n("sidebar.bpm.double", "加倍 BPM"),
									children: /* @__PURE__ */ c(d, {
										size: "2",
										variant: "soft",
										color: "gray",
										disabled: !W,
										onClick: O,
										style: { fontFamily: "var(--default-font-family-mono)" },
										children: "×2"
									})
								})
							]
						}),
						W && G && /* @__PURE__ */ c(v, {
							content: n("sidebar.bpm.reset", "重置 BPM"),
							children: /* @__PURE__ */ c(g, {
								size: "2",
								variant: "ghost",
								color: "gray",
								"aria-label": n("sidebar.bpm.reset"),
								onClick: R,
								style: {
									position: "absolute",
									right: 0,
									top: "100%",
									transform: "translateY(-50%)"
								},
								children: /* @__PURE__ */ c(We, { style: { fontSize: 18 } })
							})
						})
					]
				}),
				/* @__PURE__ */ l(h, {
					align: "center",
					justify: "center",
					gap: "2",
					children: [/* @__PURE__ */ c(qe, { style: { color: "var(--gray-10)" } }), /* @__PURE__ */ c(_, {
						size: "2",
						color: "gray",
						style: { fontFamily: "var(--default-font-family-mono)" },
						children: H
					})]
				}),
				b.status === "error" && /* @__PURE__ */ l(f.Root, {
					color: "red",
					size: "1",
					children: [/* @__PURE__ */ c(f.Icon, { children: /* @__PURE__ */ c(Je, {}) }), /* @__PURE__ */ c(f.Text, { children: b.error })]
				}),
				/* @__PURE__ */ l(h, {
					align: "center",
					gap: "2",
					mt: "2",
					children: [/* @__PURE__ */ c(m, {
						id: r,
						checked: C,
						onCheckedChange: (e) => w(!!e)
					}), /* @__PURE__ */ c(_, {
						size: "2",
						asChild: !0,
						children: /* @__PURE__ */ c("label", {
							htmlFor: r,
							style: {
								userSelect: "none",
								cursor: "pointer"
							},
							children: n("sidebar.bpm.followPlaybackRate", "跟随音频播放倍速")
						})
					})]
				}),
				/* @__PURE__ */ l(h, {
					align: "center",
					gap: "2",
					children: [/* @__PURE__ */ c(m, {
						id: i,
						checked: T,
						onCheckedChange: (e) => E(!!e)
					}), /* @__PURE__ */ c(_, {
						size: "2",
						asChild: !0,
						children: /* @__PURE__ */ c("label", {
							htmlFor: i,
							style: {
								userSelect: "none",
								cursor: "pointer"
							},
							children: n("sidebar.bpm.showBeatLines", "在频谱图上显示拍子")
						})
					})]
				}),
				!z && (j || M) && /* @__PURE__ */ l(f.Root, {
					color: "blue",
					size: "1",
					variant: "soft",
					style: {
						display: "flex",
						alignItems: "center",
						paddingRight: "10px"
					},
					children: [
						/* @__PURE__ */ c(f.Icon, {
							style: {
								display: "flex",
								alignItems: "center"
							},
							children: /* @__PURE__ */ c(Ge, { style: { display: "block" } })
						}),
						/* @__PURE__ */ c(f.Text, {
							size: "1",
							style: { flex: 1 },
							children: n("sidebar.bpm.slidingWindowTip", "只会使用最近 10 次校准数据计算 BPM")
						}),
						/* @__PURE__ */ c(g, {
							size: "1",
							variant: "ghost",
							color: "gray",
							"aria-label": n("sidebar.bpm.dismissTip"),
							onClick: () => B(!0),
							style: {
								margin: 0,
								display: "flex",
								alignItems: "center",
								justifyContent: "center"
							},
							children: /* @__PURE__ */ c(Ye, {})
						})
					]
				}),
				!j && !M && /* @__PURE__ */ l(h, {
					direction: "column",
					gap: "2",
					align: "start",
					children: [/* @__PURE__ */ c(d, {
						size: "2",
						variant: "soft",
						disabled: !A,
						onClick: () => F("key"),
						style: {
							alignSelf: "flex-start",
							cursor: "pointer"
						},
						children: n("sidebar.bpm.manualCalibration", "手动打拍校准")
					}), /* @__PURE__ */ c(d, {
						size: "2",
						variant: "soft",
						disabled: !A,
						onClick: () => F("spectrogram"),
						style: {
							alignSelf: "flex-start",
							cursor: "pointer"
						},
						children: n("sidebar.bpm.spectrogramCalibration", "使用频谱图校准")
					})]
				}),
				j && /* @__PURE__ */ c(p, {
					size: "2",
					children: /* @__PURE__ */ l(h, {
						direction: "column",
						gap: "3",
						style: { position: "relative" },
						children: [/* @__PURE__ */ l(h, {
							align: "center",
							justify: "start",
							children: [/* @__PURE__ */ c(g, {
								size: "1",
								variant: "ghost",
								color: "gray",
								"aria-label": n("sidebar.bpm.back"),
								onClick: () => {
									F("off"), L();
								},
								style: {
									position: "absolute",
									left: 0,
									top: 0,
									cursor: "pointer"
								},
								children: /* @__PURE__ */ c(Ke, {})
							}), /* @__PURE__ */ c(h, {
								align: "center",
								justify: "center",
								style: {
									width: "100%",
									paddingLeft: "28px",
									paddingRight: "28px"
								},
								children: /* @__PURE__ */ l(_, {
									size: "2",
									weight: P ? "bold" : "medium",
									role: "button",
									tabIndex: 0,
									onKeyDown: (e) => {
										e.key === "Enter" && (e.preventDefault(), I());
									},
									onClick: () => I(),
									style: {
										textAlign: "center",
										color: P ? "var(--accent-11)" : void 0,
										cursor: "pointer",
										userSelect: "none"
									},
									children: [
										n("sidebar.bpm.tapInstructionPrefix", "根据节拍按下 "),
										/* @__PURE__ */ c(ee, { children: e.host.bpm.getTapKeyLabel() }),
										n("sidebar.bpm.tapInstructionSuffix", " 或点击此处")
									]
								})
							})]
						}), /* @__PURE__ */ c(h, {
							gap: "1",
							style: { width: "100%" },
							justify: "center",
							children: Array.from({ length: 10 }).map((e, t) => /* @__PURE__ */ c(u, { style: {
								flex: 1,
								height: "4px",
								borderRadius: "2px",
								backgroundColor: t < Math.min(N.length, 10) ? "var(--accent-9)" : "var(--gray-5)"
							} }, t))
						})]
					})
				}),
				M && /* @__PURE__ */ c(p, {
					size: "2",
					children: /* @__PURE__ */ l(h, {
						direction: "column",
						gap: "3",
						style: { position: "relative" },
						children: [/* @__PURE__ */ l(h, {
							align: "center",
							justify: "start",
							children: [/* @__PURE__ */ c(g, {
								size: "1",
								variant: "ghost",
								color: "gray",
								"aria-label": n("sidebar.bpm.back"),
								onClick: () => {
									F("off"), L();
								},
								style: {
									position: "absolute",
									left: 0,
									top: 0,
									cursor: "pointer"
								},
								children: /* @__PURE__ */ c(Ke, {})
							}), /* @__PURE__ */ c(h, {
								align: "center",
								justify: "center",
								style: {
									width: "100%",
									paddingLeft: "28px",
									paddingRight: "28px"
								},
								children: /* @__PURE__ */ c(_, {
									size: "2",
									weight: P ? "bold" : "medium",
									style: {
										textAlign: "center",
										color: P ? "var(--accent-11)" : void 0,
										userSelect: "none"
									},
									children: n("sidebar.bpm.clickOnSpectrogramToCalibrate", "在频谱图上点击以校准")
								})
							})]
						}), /* @__PURE__ */ c(h, {
							gap: "1",
							style: { width: "100%" },
							justify: "center",
							children: Array.from({ length: 10 }).map((e, t) => /* @__PURE__ */ c(u, { style: {
								flex: 1,
								height: "4px",
								borderRadius: "2px",
								backgroundColor: t < Math.min(N.length, 10) ? "var(--accent-9)" : "var(--gray-5)"
							} }, t))
						})]
					})
				})
			]
		})
	});
};
// src/calibration.ts
function Qe(e, t) {
	if (e.length === 0) return 0;
	if (e.length === 1) return e[0];
	let n = 60 / t;
	if (n <= 0) return e[0];
	let r = e[0], i = (e.length >= 4 ? e.slice(1) : e).map((e) => {
		let t = (e - r) % n;
		return t > n / 2 ? t -= n : t < -n / 2 && (t += n), t;
	});
	i.sort((e, t) => e - t);
	let a = Math.floor(i.length / 2), o = r + (i.length % 2 == 0 ? (i[a - 1] + i[a]) / 2 : i[a]);
	for (; o < 0;) o += n;
	return o;
}
function $e(e, t) {
	if (!Number.isFinite(t) || t < 0) throw Error("Invalid tap time");
	let n = e.at(-1), r = n !== void 0 && (t <= n || t - n > 2.5) ? [t] : [...e, t].slice(-10), i = r.length < 2 ? 0 : Math.round(60 / ((r.at(-1) - r[0]) / (r.length - 1)));
	return {
		taps: r,
		result: i >= 20 && i <= 400 ? {
			bpm: i,
			baseBpm: i,
			anchorTick: Qe(r, i),
			confidence: 1,
			ticks: []
		} : null
	};
}
// src/model.ts
var et = class {
	host;
	taps = [];
	mode = "off";
	highlighted = !1;
	tipSeen = !1;
	listeners = /* @__PURE__ */ new Set();
	resources = [];
	timer;
	disposed = !1;
	constructor(e) {
		this.host = e, this.resources.push(e.bpm.connect("builtin.metronome.sidebar", this.tap)), this.resources.push(e.bpm.onChanged(() => {
			let t = e.bpm.getState().tapMode;
			t !== void 0 && t !== this.mode && (this.mode = t, this.taps = []), this.emit();
		}), e.audio.onChanged(() => this.emit()), e.i18n.onLocaleChanged(() => this.emit())), e.storage.kv.get("tipSeen").then((e) => {
			this.disposed || (this.tipSeen = e === !0, this.emit());
		}).catch(this.report);
	}
	report = (e) => {
		this.disposed || this.host.ui.notify({
			level: "error",
			message: String(e)
		});
	};
	emit = () => {
		for (let e of this.listeners) e();
	};
	subscribe = (e) => (this.listeners.add(e), () => {
		this.listeners.delete(e);
	});
	tap = (e) => {
		let t = $e(this.taps, e);
		this.taps = t.taps, t.result && this.host.bpm.applyCalibration(t.result), this.highlighted = !0, clearTimeout(this.timer), this.timer = setTimeout(() => {
			this.highlighted = !1, this.emit();
		}, 100), this.emit();
	};
	setMode = (e) => {
		this.mode = e, this.taps = [], this.host.bpm.setTapMode(e), this.emit();
	};
	clearTaps = () => {
		this.taps = [], this.emit();
	};
	reset = () => {
		this.clearTaps(), this.host.bpm.reset();
	};
	setTipSeen = (e) => {
		this.host.storage.kv.set("tipSeen", e).then(() => {
			this.disposed || (this.tipSeen = e, this.emit());
		}).catch(this.report);
	};
	dispose = () => {
		if (!this.disposed) {
			this.disposed = !0, clearTimeout(this.timer);
			for (let e of this.resources) e.dispose();
			this.listeners.clear();
		}
	};
};
// src/plugin.ts
function tt({ host: e, signal: t }) {
	let n = new et(e), i = e.views.registerView({
		id: "builtin.metronome.sidebar",
		kind: "sidebar",
		title: {
			default: "BPM",
			"zh-CN": "节拍器"
		},
		view: () => r(Ze, { model: n })
	}), a = () => {
		t.removeEventListener("abort", a), n.dispose(), i.dispose();
	};
	return t.addEventListener("abort", a, { once: !0 }), t.aborted && a(), a;
}
export { tt as activate };
