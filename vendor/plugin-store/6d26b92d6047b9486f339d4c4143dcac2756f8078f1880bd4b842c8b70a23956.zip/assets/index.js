import { Button as e, Flex as t, Grid as n, Select as r, Switch as i, Text as a, TextArea as o, TextField as s } from "@radix-ui/themes";
import { useEffect as c, useRef as l, useState as u, useSyncExternalStore as d } from "react";
import { jsx as f, jsxs as p } from "react/jsx-runtime";
var m = {
	"command.title": {
		default: "Import from plain text…",
		"cs-CZ": "Importovat z prostého textu…",
		"da-DK": "Importér fra almindelig tekst…",
		"es-ES": "Importar desde texto plano…",
		"fr-FR": "Importer depuis du texte brut…",
		"id-ID": "Impor dari Teks Polos…",
		"pl-PL": "Importuj z tekstu nieformatowanego…",
		"pt-BR": "Importar de texto simples…",
		"ru-RU": "Импорт из простого текста…",
		"sk-SK": "Importovať z obyčajného textu…",
		"zh-CN": "从纯文本导入…"
	},
	"form.title": {
		default: "Import Lyrics from Plain Text",
		"cs-CZ": "Importovat titulky z prostého textu",
		"da-DK": "Importér sangtekster fra almindelig tekst",
		"es-ES": "Importar letras desde texto plano",
		"fr-FR": "Importer des paroles depuis du texte brut",
		"id-ID": "Impor Lirik Teks Polos",
		"pl-PL": "Importuj tekst z tekstu nieformatowanego",
		"pt-BR": "Importar letras de texto simples",
		"ru-RU": "Импорт текста из простого текста",
		"sk-SK": "Importovať texty z obyčajného textu",
		"zh-CN": "导入纯文本歌词"
	},
	"form.submit": {
		default: "Import",
		"cs-CZ": "Importovat",
		"da-DK": "Importér",
		"es-ES": "Importar",
		"fr-FR": "Importer",
		"id-ID": "Impor Lirik",
		"pl-PL": "Importuj",
		"pt-BR": "Importar",
		"ru-RU": "Импортировать",
		"sk-SK": "Importovať",
		"zh-CN": "导入歌词"
	},
	"mode.caption": {
		default: "Text content",
		"cs-CZ": "Obsah textu",
		"da-DK": "Tekstindhold",
		"es-ES": "Contenido del texto",
		"fr-FR": "Contenu du texte",
		"id-ID": "Mode Impor",
		"pl-PL": "Zawartość tekstu",
		"pt-BR": "Conteúdo do texto",
		"ru-RU": "Содержимое текста",
		"sk-SK": "Obsah textu",
		"zh-CN": "导入模式"
	},
	"mode.lyric": {
		default: "Lyrics Only",
		"cs-CZ": "Pouze titulky",
		"da-DK": "Kun sangtekster",
		"es-ES": "Solo letras",
		"fr-FR": "Paroles uniquement",
		"id-ID": "Hanya Lirik",
		"pl-PL": "Tylko tekst",
		"pt-BR": "Apenas letras",
		"ru-RU": "Только текст",
		"sk-SK": "Iba texty",
		"zh-CN": "仅歌词"
	},
	"mode.withTranslation": {
		default: "Lyrics with translation",
		"cs-CZ": "titulky s překladem",
		"da-DK": "Sangtekster med oversættelse",
		"es-ES": "Letras con traducción",
		"fr-FR": "Paroles avec traduction",
		"id-ID": "Lirik dan Terjemahan",
		"pl-PL": "Tekst z tłumaczeniem",
		"pt-BR": "Letras com tradução",
		"ru-RU": "Текст с переводом",
		"sk-SK": "Texty s prekladom",
		"zh-CN": "歌词和翻译歌词"
	},
	"mode.withRoman": {
		default: "Lyrics with romanization",
		"cs-CZ": "titulky s romanizací",
		"da-DK": "Sangtekster med romanisering",
		"es-ES": "Letras con romanización",
		"fr-FR": "Paroles avec romanisation",
		"id-ID": "Lirik dan Romanisasi",
		"pl-PL": "Tekst z romanizacją",
		"pt-BR": "Letras com romanização",
		"ru-RU": "Текст с романизацией",
		"sk-SK": "Texty s romanizáciou",
		"zh-CN": "歌词和音译歌词"
	},
	"mode.withBoth": {
		default: "Lyrics with both",
		"cs-CZ": "titulky s obojím",
		"da-DK": "Sangtekster med begge",
		"es-ES": "Letras con ambos",
		"fr-FR": "Paroles avec les deux",
		"id-ID": "Lirik, Terjemahan, dan Romanisasi",
		"pl-PL": "Tekst z oboma",
		"pt-BR": "Letras com ambos",
		"ru-RU": "Текст с обоими",
		"sk-SK": "Texty s oboma",
		"zh-CN": "歌词和翻译、音译歌词"
	},
	"separation.caption": {
		default: "Translation/Romanization Format",
		"cs-CZ": "Formát překladu/romanizace",
		"da-DK": "Oversættelses-/romaniseringsformat",
		"es-ES": "Formato de traducción/romanización",
		"fr-FR": "Format de traduction/romanisation",
		"id-ID": "Mode Pemisah Baris (Terjemahan dan Romanisasi)",
		"pl-PL": "Format tłumaczenia/romanizacji",
		"pt-BR": "Formato de tradução/romanização",
		"ru-RU": "Формат перевода/романизации",
		"sk-SK": "Formát prekladu/romanizácie",
		"zh-CN": "歌词分行（翻译和音译）模式"
	},
	"separation.multipleLine": {
		default: "Interleaved Multiple Lines",
		"cs-CZ": "Prokládané více řádků",
		"da-DK": "Sammenflettet flere linjer",
		"es-ES": "Múltiples líneas intercaladas",
		"fr-FR": "Lignes multiples intercalées",
		"id-ID": "Pemisah Baris Berselang-seling",
		"pl-PL": "Przeplatane wiele linii",
		"pt-BR": "Múltiplas linhas intercaladas",
		"ru-RU": "Чередующиеся строки",
		"sk-SK": "Prekladané viac riadkov",
		"zh-CN": "多行交错分隔"
	},
	"separation.sameLine": {
		default: "Same Line Separation",
		"cs-CZ": "Oddělení na stejném řádku",
		"da-DK": "Samme linje adskillelse",
		"es-ES": "Separación en misma línea",
		"fr-FR": "Séparation sur la même ligne",
		"id-ID": "Pemisah di Baris yang Sama",
		"pl-PL": "Separacja w tej samej linii",
		"pt-BR": "Separação na mesma linha",
		"ru-RU": "Разделение в одной строке",
		"sk-SK": "Oddelenie na rovnakom riadku",
		"zh-CN": "同行分隔"
	},
	separator: {
		default: "Line Separator",
		"cs-CZ": "Oddělovač řádků",
		"da-DK": "Linjeseparator",
		"es-ES": "Separador de línea",
		"fr-FR": "Séparateur de ligne",
		"id-ID": "Pemisah Baris Lirik",
		"pl-PL": "Separator linii",
		"pt-BR": "Separador de linha",
		"ru-RU": "Разделитель строк",
		"sk-SK": "Oddeľovač riadkov",
		"zh-CN": "歌词行分隔符"
	},
	swapTransAndRoman: {
		default: "Swap translation and romanization lines",
		"cs-CZ": "Prohodit řádky překladu a romanizace",
		"da-DK": "Byt oversættelses- og romaniseringslinjer",
		"es-ES": "Intercambiar líneas de traducción y romanización",
		"fr-FR": "Permuter les lignes de traduction et de romanisation",
		"id-ID": "Tukarkan Baris Terjemahan dan Romanisasi",
		"pl-PL": "Zamień linie tłumaczenia i romanizacji",
		"pt-BR": "Trocar linhas de tradução e romanização",
		"ru-RU": "Поменять местами строки перевода и романизации",
		"sk-SK": "Prehodiť riadky prekladu a romanizácie",
		"zh-CN": "交换翻译行和音译行"
	},
	wordSeparator: {
		default: "Word Separator",
		"cs-CZ": "Oddělovač slov",
		"da-DK": "Ordseparator",
		"es-ES": "Separador de palabras",
		"fr-FR": "Séparateur de mots",
		"id-ID": "Pemisah Kata",
		"pl-PL": "Separator słów",
		"pt-BR": "Separador de palavras",
		"ru-RU": "Разделитель слов",
		"sk-SK": "Oddeľovač slov",
		"zh-CN": "单词分隔符"
	},
	enableSpecialPrefix: {
		default: "Enable Special Prefix",
		"cs-CZ": "Povolit speciální předponu",
		"da-DK": "Aktiver specielt præfiks",
		"es-ES": "Habilitar prefijo especial",
		"fr-FR": "Activer le préfixe spécial",
		"id-ID": "Aktifkan Prefiks Khusus",
		"pl-PL": "Włącz specjalny prefiks",
		"pt-BR": "Ativar prefixo especial",
		"ru-RU": "Включить специальный префикс",
		"sk-SK": "Povoliť špeciálnu predponu",
		"zh-CN": "启用特殊前缀"
	},
	bgLyricPrefix: {
		default: "Background Lyric Prefix",
		"cs-CZ": "Předpona doprovodné titulky",
		"da-DK": "Baggrundssangtekst-præfiks",
		"es-ES": "Prefijo de letra de fondo",
		"fr-FR": "Préfixe de paroles de fond",
		"id-ID": "Prefiks Lirik Latar",
		"pl-PL": "Prefiks linii w tle",
		"pt-BR": "Prefixo de letra de fundo",
		"ru-RU": "Префикс фонового текста",
		"sk-SK": "Predpona sprievodného textu",
		"zh-CN": "背景歌词前缀"
	},
	duetLyricPrefix: {
		default: "Duet Lyric Prefix",
		"cs-CZ": "Předpona duetové titulky",
		"da-DK": "Duetsangtekst-præfiks",
		"es-ES": "Prefijo de letra de dueto",
		"fr-FR": "Préfixe de paroles de duo",
		"id-ID": "Prefiks Lirik Duet",
		"pl-PL": "Prefiks lnii w duecie",
		"pt-BR": "Prefixo de letra de dueto",
		"ru-RU": "Префикс дуэтного текста",
		"sk-SK": "Predpona duetového textu",
		"zh-CN": "对唱歌词前缀"
	},
	enableEmptyBeat: {
		default: "Enable Empty Beat",
		"cs-CZ": "Povolit prázdnou dobu",
		"da-DK": "Aktiver tom takt",
		"es-ES": "Habilitar tiempo vacío",
		"fr-FR": "Activer le temps vide",
		"id-ID": "Aktifkan Ketukan Kosong",
		"pl-PL": "Włącz pusty takt",
		"pt-BR": "Ativar batida vazia",
		"ru-RU": "Включить пустую долю",
		"sk-SK": "Povoliť prázdnu dobu",
		"zh-CN": "启用空拍"
	},
	emptyBeatSymbol: {
		default: "Empty Beat Symbol",
		"cs-CZ": "Symbol prázdné doby",
		"da-DK": "Tom takt-symbol",
		"es-ES": "Símbolo de tiempo vacío",
		"fr-FR": "Symbole de temps vide",
		"id-ID": "Simbol Ketukan Kosong",
		"pl-PL": "Symbol pustego taktu",
		"pt-BR": "Símbolo de batida vazia",
		"ru-RU": "Символ пустой доли",
		"sk-SK": "Symbol prázdnej doby",
		"zh-CN": "空拍符号"
	},
	text: {
		default: "Lyrics text",
		"zh-CN": "歌词文本"
	},
	"error.failed": {
		default: "Failed to import plain text lyrics. Check the text and the import settings.",
		"zh-CN": "导入纯文本歌词失败，请检查输入的文本是否正确，或者导入设置是否正确"
	}
}, h = {
	mode: "lyric",
	lineSeparatorMode: "interleaved-line",
	lineSeparator: "|",
	swapTransAndRoman: !1,
	wordSeparator: "\\",
	enableSpecialPrefix: !1,
	bgLyricPrefix: "<",
	duetLyricPrefix: ">",
	enableEmptyBeat: !1,
	emptyBeatSymbol: "^"
}, g = (e) => ({
	text: e,
	startTime: 0,
	endTime: 0,
	emptyBeat: 0,
	romanText: ""
}), _ = (e) => {
	switch (e) {
		case "lyric-trans": return ["translation"];
		case "lyric-roman": return ["romanization"];
		case "lyric-trans-roman": return ["translation", "romanization"];
		default: return [];
	}
};
function v(e, t) {
	let n = e.split("\n"), r = [], i = (e = "") => {
		let n = e, i = !1, a = !1;
		if (t.enableSpecialPrefix) for (;;) if (t.bgLyricPrefix && n.startsWith(t.bgLyricPrefix)) i = !0, n = n.slice(t.bgLyricPrefix.length);
		else if (t.duetLyricPrefix && n.startsWith(t.duetLyricPrefix)) a = !0, n = n.slice(t.duetLyricPrefix.length);
		else break;
		let o = {
			words: [g(n)],
			translation: "",
			romanization: "",
			isBackground: i,
			isDuet: a,
			startTime: 0,
			endTime: 0,
			ignoreSync: !1
		};
		return r.push(o), o;
	}, [a, o] = _(t.mode);
	if (!a) for (let e of n) i(e);
	else if (t.lineSeparatorMode === "interleaved-line") {
		let e = o ? 3 : 2;
		for (let t = 0; t < n.length; t += e) {
			let e = i(n[t]);
			e[a] = n[t + 1] ?? "", o && (e[o] = n[t + 2] ?? "");
		}
	} else for (let e of n) {
		let n = e.split(t.lineSeparator), r = i(n[0] ?? "");
		r[a] = n[1] ?? "", o && (r[o] = n[2] ?? "");
	}
	if (t.swapTransAndRoman) for (let e of r) [e.romanization, e.translation] = [e.translation, e.romanization];
	if (t.wordSeparator.length > 0) for (let e of r) e.words = e.words.map((e) => e.text).join("").split(t.wordSeparator).map(g);
	if (t.enableEmptyBeat && t.emptyBeatSymbol.length > 0) for (let e of r) for (let n of e.words) for (; n.text.endsWith(t.emptyBeatSymbol);) n.text = n.text.slice(0, -t.emptyBeatSymbol.length), n.emptyBeat += 1;
	return r;
}
// src/import.ts
var y = "options", b = (e) => {
	let t = { ...h };
	if (typeof e != "object" || !e || Array.isArray(e)) return t;
	for (let n of Object.keys(t)) typeof e[n] == typeof t[n] && (t[n] = e[n]);
	return t;
}, x = async (e, t, n) => {
	try {
		let r = await e.project.importDocument({
			lines: v(t, n),
			metadata: []
		}, "Import plain text lyrics");
		if (r.ok) return !0;
		r.error.code !== "cancelled" && e.ui.notify({
			level: "error",
			message: e.i18n.t("error.failed"),
			detail: r.error.message
		});
	} catch (t) {
		e.ui.notify({
			level: "error",
			message: e.i18n.t("error.failed"),
			detail: String(t)
		});
	}
	return !1;
}, S = (e) => /* @__PURE__ */ f(a, {
	color: "gray",
	size: "2",
	children: e.children
}), C = (a, m) => {
	let g = "", _ = (e) => {
		let t = a.i18n.onLocaleChanged(e);
		return () => t.dispose();
	};
	return function() {
		let v = () => a.i18n.locale;
		d(_, v, v);
		let C = a.i18n.t, [w, T] = u(g), [E, D] = u(h), [O, k] = u(!1), A = l(!1);
		c(() => {
			let e = !0;
			return a.storage.kv.get(y).then((t) => {
				e && !A.current && D(b(t));
			}).catch(() => void 0), () => {
				e = !1;
			};
		}, []);
		let j = (e, t) => {
			A.current = !0;
			let n = {
				...E,
				[e]: t
			};
			D(n), a.storage.kv.set(y, { ...n }).catch(() => void 0);
		}, M = E.mode === "lyric";
		return /* @__PURE__ */ p(t, {
			direction: "column",
			children: [/* @__PURE__ */ f(t, {
				justify: "end",
				mb: "2",
				children: /* @__PURE__ */ f(e, {
					disabled: O,
					onClick: async () => {
						k(!0);
						let e = await x(a, w, E);
						k(!1), e && a.ui.closeView(m);
					},
					children: C("form.submit")
				})
			}), /* @__PURE__ */ p(t, {
				gap: "4",
				direction: {
					initial: "column",
					sm: "row"
				},
				children: [/* @__PURE__ */ f(o, {
					"aria-label": C("text"),
					style: {
						height: "calc(80vh - 5em)",
						flex: "1 1 auto",
						fontFamily: "var(--code-font-family)"
					},
					value: w,
					onChange: (e) => {
						g = e.currentTarget.value, T(g);
					}
				}), /* @__PURE__ */ p(n, {
					columns: "2",
					gapY: "2",
					gapX: "4",
					style: {
						whiteSpace: "nowrap",
						flex: "0 0 auto",
						alignItems: "center",
						alignContent: "start",
						textAlign: "end"
					},
					children: [
						/* @__PURE__ */ f(S, { children: C("mode.caption") }),
						/* @__PURE__ */ p(r.Root, {
							value: E.mode,
							onValueChange: (e) => j("mode", e),
							children: [/* @__PURE__ */ f(r.Trigger, {}), /* @__PURE__ */ p(r.Content, { children: [
								/* @__PURE__ */ f(r.Item, {
									value: "lyric",
									children: C("mode.lyric")
								}),
								/* @__PURE__ */ f(r.Item, {
									value: "lyric-trans",
									children: C("mode.withTranslation")
								}),
								/* @__PURE__ */ f(r.Item, {
									value: "lyric-roman",
									children: C("mode.withRoman")
								}),
								/* @__PURE__ */ f(r.Item, {
									value: "lyric-trans-roman",
									children: C("mode.withBoth")
								})
							] })]
						}),
						/* @__PURE__ */ f(S, { children: C("separation.caption") }),
						/* @__PURE__ */ p(r.Root, {
							disabled: M,
							value: E.lineSeparatorMode,
							onValueChange: (e) => j("lineSeparatorMode", e),
							children: [/* @__PURE__ */ f(r.Trigger, {}), /* @__PURE__ */ p(r.Content, { children: [/* @__PURE__ */ f(r.Item, {
								value: "interleaved-line",
								children: C("separation.multipleLine")
							}), /* @__PURE__ */ f(r.Item, {
								value: "same-line-separator",
								children: C("separation.sameLine")
							})] })]
						}),
						/* @__PURE__ */ f(S, { children: C("separator") }),
						/* @__PURE__ */ f(s.Root, {
							disabled: M || E.lineSeparatorMode !== "same-line-separator",
							value: E.lineSeparator,
							onChange: (e) => j("lineSeparator", e.currentTarget.value)
						}),
						/* @__PURE__ */ f(S, { children: C("swapTransAndRoman") }),
						/* @__PURE__ */ f(i, {
							checked: E.swapTransAndRoman,
							onCheckedChange: (e) => j("swapTransAndRoman", e)
						}),
						/* @__PURE__ */ f(S, { children: C("wordSeparator") }),
						/* @__PURE__ */ f(s.Root, {
							value: E.wordSeparator,
							onChange: (e) => j("wordSeparator", e.currentTarget.value)
						}),
						/* @__PURE__ */ f(S, { children: C("enableSpecialPrefix") }),
						/* @__PURE__ */ f(i, {
							checked: E.enableSpecialPrefix,
							onCheckedChange: (e) => j("enableSpecialPrefix", e)
						}),
						/* @__PURE__ */ f(S, { children: C("bgLyricPrefix") }),
						/* @__PURE__ */ f(s.Root, {
							disabled: !E.enableSpecialPrefix,
							value: E.bgLyricPrefix,
							onChange: (e) => j("bgLyricPrefix", e.currentTarget.value)
						}),
						/* @__PURE__ */ f(S, { children: C("duetLyricPrefix") }),
						/* @__PURE__ */ f(s.Root, {
							disabled: !E.enableSpecialPrefix,
							value: E.duetLyricPrefix,
							onChange: (e) => j("duetLyricPrefix", e.currentTarget.value)
						}),
						/* @__PURE__ */ f(S, { children: C("enableEmptyBeat") }),
						/* @__PURE__ */ f(i, {
							checked: E.enableEmptyBeat,
							onCheckedChange: (e) => j("enableEmptyBeat", e)
						}),
						/* @__PURE__ */ f(S, { children: C("emptyBeatSymbol") }),
						/* @__PURE__ */ f(s.Root, {
							disabled: !E.enableEmptyBeat,
							value: E.emptyBeatSymbol,
							onChange: (e) => j("emptyBeatSymbol", e.currentTarget.value)
						})
					]
				})]
			})]
		});
	};
}, w = "builtin.plain-text-import", T = `${w}.run`, E = `${w}.dialog`, D = (e) => {
	e.views.registerView({
		id: E,
		kind: "dialog-view",
		title: m["form.title"],
		size: "full",
		view: C(e, E)
	}), e.commands.register({
		id: T,
		title: m["command.title"],
		handler: () => e.ui.openView(E)
	}), e.menus.register({
		id: `${w}.menu.file`,
		command: T,
		menu: "menu.file",
		group: "import",
		order: 100
	});
};
// src/plugin.ts
function O({ host: e }) {
	D(e);
}
export { O as activate };
