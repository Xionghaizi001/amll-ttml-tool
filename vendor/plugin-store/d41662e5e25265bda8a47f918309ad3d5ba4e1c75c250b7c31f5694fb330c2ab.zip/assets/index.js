import * as e from "react";
import t, { createContext as n, useContext as r, useEffect as i, useState as a } from "react";
import { Fragment as o, jsx as s, jsxs as c } from "react/jsx-runtime";
import { Box as l, Button as u, Callout as d, Checkbox as f, Flex as p, IconButton as m, RadioGroup as h, Select as g, Text as _, TextArea as ee, TextField as v } from "@radix-ui/themes";
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/constants.js
var y = typeof window > "u" ? global : window, b = "@griffel/";
function x(e, t) {
	return y[Symbol.for(b + e)] || (y[Symbol.for(b + e)] = t), y[Symbol.for(b + e)];
}
var S = /*#__PURE__*/ x("DEBUG_RESET_CLASSES", {}), C = /*#__PURE__*/ x("DEFINITION_LOOKUP_TABLE", {}), w = "data-make-styles-bucket", T = "data-priority", E = "data-container", D = process.env.NODE_ENV === "production" ? 10 : 18;
// node_modules/.pnpm/@emotion+hash@0.9.2/node_modules/@emotion/hash/dist/emotion-hash.esm.js
function O(e) {
	for (var t = 0, n, r = 0, i = e.length; i >= 4; ++r, i -= 4) n = e.charCodeAt(r) & 255 | (e.charCodeAt(++r) & 255) << 8 | (e.charCodeAt(++r) & 255) << 16 | (e.charCodeAt(++r) & 255) << 24, n = (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16), n ^= n >>> 24, t = (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16) ^ (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
	switch (i) {
		case 3: t ^= (e.charCodeAt(r + 2) & 255) << 16;
		case 2: t ^= (e.charCodeAt(r + 1) & 255) << 8;
		case 1: t ^= e.charCodeAt(r) & 255, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
	}
	return t ^= t >>> 13, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16), ((t ^ t >>> 15) >>> 0).toString(36);
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/utils/hashSequence.js
function k(e) {
	let t = e.length;
	if (t === 7) return e;
	for (let n = t; n < 7; n++) e += "0";
	return e;
}
function A(e, t, n = []) {
	return process.env.NODE_ENV === "production" ? "___" + k(O(e + t)) : "___" + k(O(e + t)) + "_" + k(O(n.join("")));
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/reduceToClassNameForSlots.js
function j(e, t) {
	let n = "", r = "";
	for (let i in e) {
		let a = e[i];
		if (a === 0) {
			r += i + " ";
			continue;
		}
		let o = Array.isArray(a), s = t === "rtl" ? (o ? a[1] : a) + " " : (o ? a[0] : a) + " ";
		n += s, r += s;
	}
	return [n.slice(0, -1), r.slice(0, -1)];
}
function M(e, t) {
	let n = {};
	for (let r in e) {
		let [i, a] = j(e[r], t);
		if (a === "") {
			n[r] = "";
			continue;
		}
		let o = A(a, t), s = o + (i === "" ? "" : " " + i);
		C[o] = [e[r], t], n[r] = s;
	}
	return n;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/mergeClasses.js
var N = {};
function P() {
	let e = null, t = "", n = "", r = Array(arguments.length), i = "";
	for (let e = 0; e < arguments.length; e++) {
		let a = arguments[e];
		if (typeof a == "string" && a !== "") {
			let o = a.indexOf("___");
			if (o === -1) process.env.NODE_ENV !== "production" && a.split(" ").forEach((e) => {
				e.startsWith("r") && S[e] && (i ? console.error(`mergeClasses(): a passed string contains multiple classes produced by makeResetStyles (${a} & ${t}, this will lead to non-deterministic behavior. Learn more:https://griffel.js.org/react/api/make-reset-styles#limitations
Source string: ${a}`) : i = e);
			}), t += a + " ";
			else {
				let i = a.substr(o, D);
				o > 0 && (t += a.slice(0, o)), n += i, r[e] = i;
			}
			process.env.NODE_ENV !== "production" && a.indexOf("___", o + 1) !== -1 && console.error(`mergeClasses(): a passed string contains multiple identifiers of atomic classes (classes that start with "___"), it's possible that passed classes were concatenated in a wrong way. Source string: ${a}`);
		}
	}
	if (n === "") return t.slice(0, -1);
	let a = N[n];
	if (a !== void 0) return t + a;
	let o = [];
	for (let t = 0; t < arguments.length; t++) {
		let n = r[t];
		if (n) {
			let r = C[n];
			r ? (o.push(r[0]), process.env.NODE_ENV !== "production" && e !== null && e !== r[1] && console.error(`mergeClasses(): a passed string contains an identifier (${n}) that has different direction (dir="${r[1] ? "rtl" : "ltr"}") setting than other classes. This is not supported. Source string: ${arguments[t]}`), e = r[1]) : process.env.NODE_ENV !== "production" && console.error(`mergeClasses(): a passed string contains an identifier (${n}) that does not match any entry in cache. Source string: ${arguments[t]}`);
		}
	}
	let s = Object.assign.apply(Object, [{}].concat(o)), [c, l] = j(s, e), u = A(l, e, r), d = u + " " + c;
	return N[n] = d, C[u] = [s, e], t + d;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/store.js
var F = {}, I = /* @__PURE__ */ new Set(), L = {
	getChildrenSequences: (e) => {
		let t = Object.keys(N).find((t) => N[t].startsWith(e));
		return t ? t.split("___").filter((e) => e.length).map((e) => "___" + e) : [];
	},
	addCSSRule: (e) => {
		I.add(e);
	},
	addSequenceDetails: (e, t) => {
		Object.entries(e).forEach(([e, n]) => {
			F[n.substring(0, D)] = {
				slotName: e,
				sourceURL: t
			};
		});
	},
	getCSSRules: () => Array.from(I),
	getSequenceDetails: (e) => F[e]
};
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/utils.js
function R(e, t) {
	return Array.isArray(e) ? t === "rtl" ? e[1] : e[0] : e || "";
}
function te(e, t, n, r) {
	let i = e[0], a = e[1];
	return Object.entries(i).map(([e, i]) => {
		let o = R(i, a), s;
		if (n && t) {
			let i = n.find(({ className: e }) => e === o);
			!i && t[0][e] ? s = R(t[0][e], t[1]) : i && t[0][e] ? s = r && r.filter(({ debugClassNames: e }) => e.filter(({ className: e }) => e === o).length > 0).length > 0 ? i.className : i.overriddenBy : (!i && !t[0][e] || i && !t[0][e]) && (s = void 0);
		}
		return {
			className: o,
			overriddenBy: s
		};
	});
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getAtomicDebugSequenceTree.js
function z(e, t) {
	let n = C[e];
	if (n === void 0) return;
	let r = te(n, t ? C[t.sequenceHash] : void 0, t?.debugClassNames, t?.children), i = {
		sequenceHash: e,
		direction: n[1],
		children: [],
		debugClassNames: r
	};
	return L.getChildrenSequences(i.sequenceHash).reverse().forEach((e) => {
		let t = z(e, i);
		t && i.children.push(t);
	}), i.children.length || (i.rules = {}, i.debugClassNames.forEach(({ className: t }) => {
		let n = L.getSequenceDetails(e);
		n && (i.slot = n.slotName, i.sourceURL = n.sourceURL);
		let r = L.getCSSRules().find((e) => e.includes(t));
		i.rules[t] = r;
	})), i;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getResetDebugSequence.js
function ne(e) {
	if (S[e] === void 0) return;
	let t = {
		sequenceHash: e,
		direction: "ltr",
		children: [],
		debugClassNames: [{ className: e }]
	};
	t.rules = {}, t.slot = "makeResetStyles()";
	let [{ className: n }] = t.debugClassNames, r = L.getCSSRules().filter((e) => e.includes(`.${n}`));
	return t.rules[n] = r.join(""), t;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/mergeDebugSequence.js
function re(e, t) {
	let n = e ? z(e) : void 0, r = t ? ne(t) : void 0;
	if (n || r) return n ? r ? {
		sequenceHash: n.sequenceHash + r.sequenceHash,
		direction: n.direction,
		children: [n, r],
		debugClassNames: [...n.debugClassNames, ...r.debugClassNames]
	} : n : r;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/injectDevTools.js
function ie(e) {
	let t = e.defaultView;
	if (!t || t.__GRIFFEL_DEVTOOLS__) return;
	let n = { getInfo: (e) => {
		let t, n;
		for (let r of e.classList) r.startsWith("___") && (t = r), S[r] && (n = r);
		return re(t, n);
	} };
	Object.defineProperty(t, "__GRIFFEL_DEVTOOLS__", {
		configurable: !1,
		enumerable: !1,
		get() {
			return n;
		}
	});
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/isDevToolsEnabled.js
var B = (() => {
	try {
		return !!(typeof window < "u" && window.sessionStorage?.getItem("__GRIFFEL_DEVTOOLS__"));
	} catch {
		return !1;
	}
})(), V = "<unknown>";
function ae(e) {
	return le(e) || fe(e) || me(e);
}
var oe = /^\s*at (.*?) ?\(((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/|[a-z]:\\|\\\\).*?)?\)?\s*$/i, se = /^\s*at ()((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|\/|[a-z]:\\|\\\\).*?)\s*$/i, ce = /\((\S*)\)/;
function le(e) {
	let t = oe.exec(e) || se.exec(e);
	if (!t) return null;
	let n = t[2], r = n && n.indexOf("native") === 0, i = n && n.indexOf("eval") === 0, a = ce.exec(n);
	return i && a !== null && (n = a[1]), {
		loc: r ? null : t[2],
		name: t[1] || V
	};
}
var ue = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|resource|\[native).*?|[^@]*bundle)\s*$/i, de = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;
function fe(e) {
	let t = ue.exec(e);
	if (!t) return null;
	let n = t[3], r = n && n.indexOf(" > eval") > -1, i = de.exec(n);
	return r && i !== null && (n = i[1]), {
		loc: t[3],
		name: t[1] || V
	};
}
var pe = /^\s*(?:([^@]*)(?:\((.*?)\))?@)?(\S.*?)\s*$/i;
function me(e) {
	let t = pe.exec(e);
	return t ? {
		loc: t[3],
		name: t[1] || V
	} : null;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/devtools/getSourceURLfromError.js
function he() {
	let e = ge(String((/* @__PURE__ */ Error()).stack).split("\n"));
	return e === void 0 ? void 0 : ae(e)?.loc;
}
function ge(e) {
	for (let t = e.length - 1; t >= 0; --t) if (e[t].includes("at getSourceURLfromError")) return e[t + 3];
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/runtime/utils/normalizeCSSBucketEntry.js
function _e(e) {
	if (!Array.isArray(e)) return [e];
	if (process.env.NODE_ENV !== "production" && e.length > 2) throw Error("CSS Bucket contains an entry with greater than 2 items, please report this to https://github.com/microsoft/griffel/issues");
	return e;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/createIsomorphicStyleSheet.js
function ve(e, t, n, r) {
	let i = [];
	if (r[w] = t, r[T] = String(n), e) for (let t in r) e.setAttribute(t, r[t]);
	function a(t) {
		return e?.sheet ? e.sheet.insertRule(t, e.sheet.cssRules.length) : i.push(t);
	}
	return {
		elementAttributes: r,
		insertRule: a,
		element: e,
		bucketName: t,
		cssRules() {
			return e?.sheet ? Array.from(e.sheet.cssRules).map((e) => e.cssText) : i;
		}
	};
}
var H = /*#__PURE__*/ [
	"r",
	"d",
	"l",
	"v",
	"w",
	"f",
	"i",
	"h",
	"a",
	"s",
	"k",
	"t",
	"m",
	"c",
	"x"
].reduce((e, t, n) => (e[t] = n, e), {});
function ye(e, t, n) {
	return e === "m" || e === "x" ? e + t + n : e + n;
}
function be(e, t, n, r, i = {}) {
	let a = e === "m", o = e === "x", s = i.m, c = i.x, l = i.p ?? 0, u = ye(e, c ?? s ?? "0", l);
	if (!r.stylesheets[u]) {
		let d = t && t.createElement("style"), f = ve(d, e, l, {
			...r.styleElementAttributes,
			...a && { media: s },
			...o && { "data-container": c }
		});
		r.stylesheets[u] = f, t?.head && d && t.head.insertBefore(d, Se(t, n, e, r, i));
	}
	return r.stylesheets[u];
}
function xe(e, t, n) {
	return e.getAttribute("data-make-styles-bucket") === t ? t === "m" ? n.m === e.media : t !== "x" || n.x === e.getAttribute(E) : !1;
}
function Se(e, t, n, r, i = {}) {
	let a = H[n], o = i.m ?? "", s = i.x ?? "", c = i.p ?? 0, l = (e) => a - H[e.getAttribute(w)], u = e.head.querySelectorAll(`[${w}]`);
	if (n === "m" || n === "x") {
		let t = e.head.querySelectorAll(`[${w}="${n}"]`);
		t.length && (u = t, l = n === "m" ? (e) => r.compareMediaQueries(o, e.media) : (e) => r.compareContainerQueries(s, e.getAttribute("data-container") ?? ""));
	}
	let d = (e) => xe(e, n, i) ? c - Number(e.getAttribute(T)) : l(e), f = u.length, p = f - 1;
	for (; p >= 0;) {
		let e = u.item(p);
		if (d(e) > 0) return e.nextSibling;
		p--;
	}
	return f > 0 ? u.item(0) : t ? t.nextSibling : null;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/safeInsertRule.js
var Ce = /*#__PURE__*/ RegExp(":(-moz-placeholder|-moz-focus-inner|-moz-focusring|-ms-input-placeholder|-moz-read-write|-moz-read-only)");
function U(e, t) {
	try {
		e.insertRule(t);
	} catch (e) {
		process.env.NODE_ENV !== "production" && !Ce.test(t) && console.error(`There was a problem inserting the following rule: "${t}"`, e);
	}
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/renderer/createDOMRenderer.js
var we = 0, Te = (e, t) => e < t ? -1 : +(e > t);
function Ee(e = typeof document > "u" ? void 0 : document, t = {}) {
	let { classNameHashSalt: n, unstable_filterCSSRule: r, insertionPoint: i, styleElementAttributes: a, compareMediaQueries: o = Te, compareContainerQueries: s = o } = t, c = {
		classNameHashSalt: n,
		insertionCache: {},
		stylesheets: {},
		styleElementAttributes: Object.freeze(a),
		compareMediaQueries: o,
		compareContainerQueries: s,
		id: `d${we++}`,
		insertCSSRules(t) {
			for (let n in t) {
				let a = t[n];
				for (let t = 0, o = a.length; t < o; t++) {
					let [o, s] = _e(a[t]), l = be(n, e, i || null, c, s);
					c.insertionCache[o] || (c.insertionCache[o] = n, process.env.NODE_ENV !== "production" && B && L.addCSSRule(o), r ? r(o) && U(l, o) : U(l, o));
				}
			}
		}
	};
	return e && process.env.NODE_ENV !== "production" && B && ie(e), c;
}
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/insertionFactory.js
var De = () => {
	let e = {};
	return function(t, n) {
		e[t.id] === void 0 && (t.insertCSSRules(n), e[t.id] = !0);
	};
};
// node_modules/.pnpm/@griffel+core@1.21.4/node_modules/@griffel/core/src/__styles.js
function Oe(e, t, n = De) {
	let r = n(), i = null, a = null, o;
	process.env.NODE_ENV !== "production" && B && (o = he());
	function s(n) {
		let { dir: s, renderer: c } = n, l = s === "ltr";
		l ? i === null && (i = M(e, s)) : a === null && (a = M(e, s)), r(c, t);
		let u = l ? i : a;
		return process.env.NODE_ENV !== "production" && B && L.addSequenceDetails(u, o), u;
	}
	return s;
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/utils/canUseDOM.js
function ke() {
	return typeof window < "u" && !!(window.document && window.document.createElement);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/useInsertionEffect.js
var W = t.useInsertionEffect ? t.useInsertionEffect : void 0, Ae = () => {
	let e = {};
	return function(t, n) {
		W && ke() ? W(() => {
			t.insertCSSRules(n);
		}, [t, n]) : e[t.id] === void 0 && (t.insertCSSRules(n), e[t.id] = !0);
	};
}, je = /*#__PURE__*/ n(/*#__PURE__*/ Ee());
function Me() {
	return r(je);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/TextDirectionContext.js
var Ne = /*#__PURE__*/ n("ltr");
function Pe() {
	return r(Ne);
}
// node_modules/.pnpm/@griffel+react@1.7.8_react@19.2.7/node_modules/@griffel/react/src/__styles.js
function G(e, t) {
	let n = Oe(e, t, Ae);
	return function() {
		let e = Pe(), t = Me();
		return n({
			dir: e,
			renderer: t
		});
	};
}
// node_modules/.pnpm/@fluentui+react-icons@2.0.333_react@19.2.7/node_modules/@fluentui/react-icons/lib/utils/useIconStyles.styles.js
var Fe = G({
	root: {
		mc9l5x: "f1w7gpdv",
		Bg96gwp: "fez10in"
	},
	rtl: { Bz10aip: "f13rod7r" }
}, { d: [
	".f1w7gpdv{display:inline;}",
	".fez10in{line-height:0;}",
	".f13rod7r{transform:scaleX(-1);}"
] }), K = e.createContext(void 0), Ie = {};
K.Provider;
var Le = () => e.useContext(K) ?? Ie, Re = "fui-Icon", ze = "data-fui-icon", Be = (e, t) => {
	let { filled: n, idPrefix: r, title: i, primaryFill: a = "currentColor", ...o } = e, s = {
		...o,
		fill: a
	}, c = Le(), l = !!(t?.flipInRtl && c?.textDirection === "rtl");
	return i && (s["aria-label"] = i), !s["aria-label"] && !s["aria-labelledby"] ? s["aria-hidden"] = !0 : s.role = "img", s[ze] = "", {
		state: s,
		isRtlFlip: l
	};
}, Ve = (e, t) => {
	let n = Fe(), { state: r, isRtlFlip: i } = Be(e, t);
	return r.className = P(n.root, i && n.rtl, r.className), r;
}, He = G({ root: { B8gzw0y: "f1dd5bof" } }, { m: [["@media (forced-colors: active){.f1dd5bof{forced-color-adjust:auto;}}", { m: "(forced-colors: active)" }]] }), Ue = "url(#", q = (t, n, r) => {
	let [i, a, ...o] = t, s = a;
	if (r && a) {
		let e = {};
		for (let t in a) {
			let n = a[t];
			if (typeof n != "string") e[t] = n;
			else if (t === "id") e[t] = r + n;
			else {
				let i = n.indexOf(Ue);
				e[t] = i < 0 ? n : n.slice(0, i + 5) + r + n.slice(i + 5);
			}
		}
		s = e;
	}
	return e.createElement(i, {
		...s,
		key: n
	}, ...o.map((e, t) => q(e, t, r)));
}, We = (e) => e === "1em" ? "20" : e, J = (e, t, n) => typeof e != "string" && (t?.color || Array.isArray(e[0])) ? e.map((e, t) => q(e, t, n)) : void 0, Ge = () => void 0, Ke = (t, n) => {
	let r = J(t, n);
	return r ? function(i) {
		return e.useMemo(() => i ? J(t, n, i) : r, [i]);
	} : Ge;
}, qe = (t, n, r) => typeof n == "string" ? e.createElement("svg", {
	...t,
	dangerouslySetInnerHTML: { __html: n }
}) : r ? e.createElement("svg", t, ...r) : e.createElement("svg", t, ...n.map((n) => e.createElement("path", {
	d: n,
	fill: t.fill
}))), Y = (t, n, r, i) => {
	let a = We(n), o = Ke(r, i), s = e.forwardRef((e, t) => {
		let s = He(), c = Ve(e, { flipInRtl: i?.flipInRtl }), l = o(e.idPrefix);
		return qe({
			...c,
			className: P(Re, c.className, s.root),
			ref: t,
			width: n,
			height: n,
			viewBox: `0 0 ${a} ${a}`,
			xmlns: "http://www.w3.org/2000/svg"
		}, r, l);
	});
	return s.displayName = t, s;
}, Je = /*#__PURE__*/ Y("EditRegular", "1em", ["M17.18 2.93a2.97 2.97 0 0 0-4.26-.06l-9.37 9.38c-.33.33-.56.74-.66 1.2l-.88 3.94a.5.5 0 0 0 .6.6l3.93-.87c.46-.1.9-.34 1.23-.68l9.36-9.36a2.97 2.97 0 0 0 .05-4.15Zm-3.55.65a1.97 1.97 0 1 1 2.8 2.8l-.68.66-2.8-2.79.68-.67Zm-1.38 1.38 2.8 2.8-7.99 7.97c-.2.2-.46.35-.74.41l-3.16.7.7-3.18c.07-.27.2-.51.4-.7l8-8Z"]), Ye = /*#__PURE__*/ Y("DeleteRegular", "1em", ["M8.5 4h3a1.5 1.5 0 0 0-3 0Zm-1 0a2.5 2.5 0 0 1 5 0h5a.5.5 0 0 1 0 1h-1.05l-1.2 10.34A3 3 0 0 1 12.27 18H7.73a3 3 0 0 1-2.98-2.66L3.55 5H2.5a.5.5 0 0 1 0-1h5ZM5.74 15.23A2 2 0 0 0 7.73 17h4.54a2 2 0 0 0 1.99-1.77L15.44 5H4.56l1.18 10.23ZM8.5 7.5c.28 0 .5.22.5.5v6a.5.5 0 0 1-1 0V8c0-.28.22-.5.5-.5ZM12 8a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V8Z"]), Xe = /*#__PURE__*/ Y("Info16Regular", "16", ["M8.5 7.5a.5.5 0 1 0-1 0v3a.5.5 0 0 0 1 0v-3Zm.25-2a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0ZM8 1a7 7 0 1 0 0 14A7 7 0 0 0 8 1ZM2 8a6 6 0 1 1 12 0A6 6 0 0 1 2 8Z"]), Ze = {
	title: {
		default: "Advanced segmentation",
		"zh-CN": "高级分词"
	},
	auto: {
		default: "Auto segmentation",
		"zh-CN": "自动分词"
	},
	apply: {
		default: "Apply",
		"zh-CN": "应用"
	},
	cancel: {
		default: "Cancel",
		"zh-CN": "取消"
	},
	scope: {
		default: "Scope",
		"zh-CN": "应用范围"
	},
	all: {
		default: "All lyric lines",
		"zh-CN": "所有歌词行"
	},
	from: {
		default: "From",
		"zh-CN": "从第"
	},
	to: {
		default: "to",
		"zh-CN": "行到第"
	},
	line: {
		default: "line",
		"zh-CN": "行"
	},
	rules: {
		default: "Automatic segmentation rules",
		"zh-CN": "自动分词规则"
	},
	cjk: {
		default: "Split CJK by character",
		"zh-CN": "CJK 按字符分词"
	},
	english: {
		default: "Split English words by syllable",
		"zh-CN": "西文单词按音节分词"
	},
	language: {
		default: "Choose a language model:",
		"zh-CN": "选择一个分词语言模型："
	},
	tip: {
		default: "Original syllable duration is redistributed by character count and weight.",
		"zh-CN": "分词后，原音节的时长会按照字符数和权重重新分配给新的音节"
	},
	postProcess: {
		default: "Post-processing",
		"zh-CN": "后处理"
	},
	punct: {
		default: "Punctuation handling",
		"zh-CN": "标点符号处理"
	},
	merge: {
		default: "Merge with neighbors",
		"zh-CN": "合并到相邻音节"
	},
	standalone: {
		default: "Standalone segment",
		"zh-CN": "设为新音节"
	},
	empty: {
		default: "Remove empty segments",
		"zh-CN": "移除空白音节"
	},
	custom: {
		default: "Custom segmentation rules",
		"zh-CN": "自定义分词规则"
	},
	customInput: {
		default: "Enter a word to split manually...",
		"zh-CN": "输入单词进行手动分割..."
	},
	addRule: {
		default: "Add custom rule",
		"zh-CN": "添加到自定义规则"
	},
	ignore: {
		default: "One word per line; listed words will not be segmented automatically",
		"zh-CN": "每行一个单词，在此列表中的单词将不会被自动分词"
	},
	test: {
		default: "Segmentation test",
		"zh-CN": "分词测试"
	},
	input: {
		default: "Enter a lyric line or word to test...",
		"zh-CN": "输入一行歌词或单词进行测试..."
	},
	preview: {
		default: "Preview result:",
		"zh-CN": "预览结果："
	},
	emptyText: {
		default: "Empty",
		"zh-CN": "空白"
	},
	failed: {
		default: "Segmentation failed",
		"zh-CN": "分词失败"
	}
}, X = "builtin.segmentation.advanced", Z = (e) => Ze[e], Q = (e) => e.segmentation, Qe = {
	splitCJK: !0,
	splitEnglish: !1,
	punctuationMode: "merge",
	punctuationWeight: .2,
	removeEmptySegments: !0,
	ignoreListText: "",
	customRules: {},
	lang: "en-us"
}, $e = (e) => ({
	...Qe,
	...Q(e).getConfig?.() ?? {}
}), et = [
	{
		label: "English (US)",
		value: "en-us"
	},
	{
		label: "Deutsch (German)",
		value: "de"
	},
	{
		label: "Français (French)",
		value: "fr"
	},
	{
		label: "Español (Spanish)",
		value: "es"
	},
	{
		label: "Bahasa Indonesia (Indonesian)",
		value: "id"
	},
	{
		label: "Italiano (Italian)",
		value: "it"
	},
	{
		label: "Português (Portuguese)",
		value: "pt"
	},
	{
		label: "Pусский (Russian)",
		value: "ru"
	}
], tt = ".amll-seg-previewWord{display:inline-block;padding:.25em .5em;border-radius:var(--radius-4);background:var(--color-panel);box-shadow:var(--base-card-surface-box-shadow)}.amll-seg-ruleList{max-height:150px;overflow-y:auto;border:1px solid var(--gray-5);border-radius:var(--radius-2);padding:var(--space-2)}.amll-seg-splitter{width:8px;height:2em;padding:0;border:0;background:var(--gray-8);cursor:pointer}.amll-seg-splitter[data-split=true]{background:var(--accent-9);width:3px}.amll-seg-grapheme{padding:0 .15em}";
function nt(e, t) {
	let n = [], r = 0;
	for (let i of [...t].sort((e, t) => e - t)) n.push(e.slice(r, i)), r = i;
	return n.push(e.slice(r)), n.filter(Boolean);
}
async function $(e, t, n, r) {
	let i = e.document.readSnapshot(), a = t === "all" ? 0 : Math.max(0, Math.min(i.lines.length, (Number.parseInt(n, 10) || 1) - 1)), o = t === "all" ? i.lines.length : Math.max(a, Math.min(i.lines.length, Number.parseInt(r, 10) || i.lines.length)), s = [];
	for (let t of i.lines.slice(a, o)) for (let n of t.words) {
		let r = await e.segmentation.segmentText({
			text: n.text,
			startTime: n.startTime,
			endTime: n.endTime
		});
		if (!(r.length <= 1)) {
			s.push({
				op: "updateWord",
				wordId: n.id,
				patch: {
					text: r[0].text,
					startTime: r[0].startTime,
					endTime: r[0].endTime
				}
			});
			for (let e of [...r.slice(1)].reverse()) s.push({
				op: "insertWord",
				lineId: t.id,
				afterWordId: n.id,
				word: {
					text: e.text,
					startTime: e.startTime,
					endTime: e.endTime,
					emptyBeat: 0,
					romanText: ""
				}
			});
		}
	}
	if (s.length) {
		let t = e.document.applyEdit(s, "Segment lyric lines", { expectedRevision: i.revision });
		if (!t.ok) throw Error(t.error.message);
	}
}
function rt({ host: e }) {
	let [t, n] = a("all"), [r, y] = a("1"), [b, x] = a("1"), [S, C] = a(() => $e(e)), [w, T] = a(""), [E, D] = a([]), [O, k] = a(!1), [A, j] = a(""), [M, N] = a(/* @__PURE__ */ new Set()), P = (e, t) => C((n) => ({
		...n,
		[e]: t
	}));
	i(() => {
		Q(e).setConfig?.(S);
	}, [e, S]), i(() => {
		let t = !0;
		if (!w.trim()) D([]);
		else return e.segmentation.segmentText({
			text: w,
			startTime: 0,
			endTime: 1e4
		}).then((e) => {
			t && D(e.map((e) => e.text));
		}).catch(() => {
			t && D([]);
		}), () => {
			t = !1;
		};
	}, [
		e,
		w,
		S
	]);
	let F = Object.entries(S.customRules), I = () => {
		A && (P("customRules", {
			...S.customRules,
			[A]: nt(A, M)
		}), j(""), N(/* @__PURE__ */ new Set()));
	}, L = (e, t) => {
		j(e);
		let n = 0, r = /* @__PURE__ */ new Set();
		for (let e of t.slice(0, -1)) n += e.length, r.add(n);
		N(r);
	}, R = async () => {
		k(!0);
		try {
			await $(e, t, r, b), e.ui.closeView(X);
		} catch (t) {
			e.ui.notify({
				level: "error",
				message: e.i18n.t("failed"),
				detail: String(t)
			});
		} finally {
			k(!1);
		}
	};
	return /* @__PURE__ */ c(o, { children: [
		/* @__PURE__ */ s("style", { children: tt }),
		/* @__PURE__ */ c(p, {
			direction: "column",
			gap: "4",
			children: [
				/* @__PURE__ */ c(p, {
					direction: "column",
					gap: "2",
					children: [/* @__PURE__ */ s(_, { children: e.i18n.t("scope") }), /* @__PURE__ */ c(h.Root, {
						value: t,
						onValueChange: (e) => n(e),
						children: [/* @__PURE__ */ c(p, {
							gap: "2",
							align: "center",
							children: [/* @__PURE__ */ s(h.Item, { value: "all" }), /* @__PURE__ */ s(_, { children: e.i18n.t("all") })]
						}), /* @__PURE__ */ c(p, {
							gap: "2",
							align: "center",
							mt: "2",
							children: [
								/* @__PURE__ */ s(h.Item, { value: "range" }),
								/* @__PURE__ */ s(_, { children: e.i18n.t("from") }),
								/* @__PURE__ */ s(v.Root, {
									type: "number",
									value: r,
									disabled: t !== "range",
									onChange: (e) => y(e.target.value),
									style: { maxWidth: 80 }
								}),
								/* @__PURE__ */ s(_, { children: e.i18n.t("to") }),
								/* @__PURE__ */ s(v.Root, {
									type: "number",
									value: b,
									disabled: t !== "range",
									onChange: (e) => x(e.target.value),
									style: { maxWidth: 80 }
								}),
								/* @__PURE__ */ s(_, { children: e.i18n.t("line") })
							]
						})]
					})]
				}),
				/* @__PURE__ */ c(p, {
					direction: "column",
					gap: "2",
					children: [
						/* @__PURE__ */ s(_, { children: e.i18n.t("rules") }),
						/* @__PURE__ */ c(p, {
							gap: "2",
							align: "center",
							children: [/* @__PURE__ */ s(f, {
								checked: S.splitCJK,
								onCheckedChange: (e) => P("splitCJK", !!e)
							}), /* @__PURE__ */ s(_, { children: e.i18n.t("cjk") })]
						}),
						/* @__PURE__ */ c(p, {
							gap: "2",
							align: "center",
							children: [/* @__PURE__ */ s(f, {
								checked: S.splitEnglish,
								onCheckedChange: (e) => P("splitEnglish", !!e)
							}), /* @__PURE__ */ s(_, { children: e.i18n.t("english") })]
						}),
						S.splitEnglish && /* @__PURE__ */ c(p, {
							direction: "column",
							gap: "1",
							ml: "5",
							children: [/* @__PURE__ */ s(_, {
								size: "2",
								color: "gray",
								children: e.i18n.t("language")
							}), /* @__PURE__ */ c(g.Root, {
								value: S.lang,
								onValueChange: (e) => P("lang", e),
								children: [/* @__PURE__ */ s(g.Trigger, { style: { width: "100%" } }), /* @__PURE__ */ s(g.Content, { children: et.map((e) => /* @__PURE__ */ s(g.Item, {
									value: e.value,
									children: e.label
								}, e.value)) })]
							})]
						}),
						/* @__PURE__ */ c(d.Root, {
							color: "blue",
							children: [/* @__PURE__ */ s(d.Icon, { children: /* @__PURE__ */ s(Xe, {}) }), /* @__PURE__ */ s(d.Text, { children: e.i18n.t("tip") })]
						})
					]
				}),
				/* @__PURE__ */ c(p, {
					direction: "column",
					gap: "3",
					children: [
						/* @__PURE__ */ s(_, { children: e.i18n.t("postProcess") }),
						/* @__PURE__ */ s(_, { children: e.i18n.t("punct") }),
						/* @__PURE__ */ c(h.Root, {
							value: S.punctuationMode,
							onValueChange: (e) => P("punctuationMode", e),
							children: [/* @__PURE__ */ c(p, {
								gap: "2",
								align: "center",
								children: [/* @__PURE__ */ s(h.Item, { value: "merge" }), /* @__PURE__ */ s(_, { children: e.i18n.t("merge") })]
							}), /* @__PURE__ */ c(p, {
								gap: "2",
								align: "center",
								mt: "2",
								children: [/* @__PURE__ */ s(h.Item, { value: "standalone" }), /* @__PURE__ */ s(_, { children: e.i18n.t("standalone") })]
							})]
						}),
						/* @__PURE__ */ s(v.Root, {
							type: "number",
							value: S.punctuationWeight,
							disabled: S.punctuationMode !== "standalone",
							onChange: (e) => P("punctuationWeight", Number(e.target.value)),
							style: { maxWidth: 100 }
						}),
						/* @__PURE__ */ c(p, {
							gap: "2",
							align: "center",
							children: [/* @__PURE__ */ s(f, {
								checked: S.removeEmptySegments,
								onCheckedChange: (e) => P("removeEmptySegments", !!e)
							}), /* @__PURE__ */ s(_, { children: e.i18n.t("empty") })]
						})
					]
				}),
				/* @__PURE__ */ c(p, {
					direction: "column",
					gap: "2",
					children: [
						/* @__PURE__ */ s(_, { children: e.i18n.t("custom") }),
						/* @__PURE__ */ s(v.Root, {
							placeholder: e.i18n.t("customInput"),
							value: A,
							onChange: (e) => {
								j(e.target.value), N(/* @__PURE__ */ new Set());
							}
						}),
						/* @__PURE__ */ s(p, {
							align: "center",
							justify: "center",
							style: {
								background: "var(--gray-4)",
								borderRadius: "var(--radius-2)",
								padding: "var(--space-4)",
								minHeight: "4em",
								userSelect: "none",
								overflowX: "auto",
								whiteSpace: "nowrap"
							},
							children: [...A].map((e, t) => /* @__PURE__ */ c("span", {
								style: {
									display: "inline-flex",
									alignItems: "center"
								},
								children: [t > 0 && /* @__PURE__ */ s("button", {
									type: "button",
									className: "amll-seg-splitter",
									"data-split": M.has(t),
									onClick: () => N((e) => {
										let n = new Set(e);
										return n.has(t) ? n.delete(t) : n.add(t), n;
									})
								}), /* @__PURE__ */ s("span", {
									className: "amll-seg-grapheme",
									children: e
								})]
							}, `${t}-${e}`))
						}),
						/* @__PURE__ */ s(u, {
							onClick: I,
							disabled: !A,
							children: e.i18n.t("addRule")
						}),
						F.length > 0 && /* @__PURE__ */ s(l, {
							className: "amll-seg-ruleList",
							children: F.map(([e, t]) => /* @__PURE__ */ c(p, {
								justify: "between",
								align: "center",
								style: {
									padding: "var(--space-1) 0 var(--space-2)",
									marginBottom: "var(--space-2)",
									borderBottom: "3px solid var(--gray-3)"
								},
								children: [/* @__PURE__ */ c(p, {
									align: "center",
									gap: "2",
									wrap: "wrap",
									children: [
										/* @__PURE__ */ s("span", {
											className: "amll-seg-previewWord",
											children: e
										}),
										/* @__PURE__ */ s(_, {
											color: "gray",
											children: "→"
										}),
										t.map((t, n) => /* @__PURE__ */ s("span", {
											className: "amll-seg-previewWord",
											children: t
										}, `${e}-${n}`))
									]
								}), /* @__PURE__ */ c(p, {
									gap: "1",
									children: [/* @__PURE__ */ s(m, {
										size: "1",
										variant: "ghost",
										color: "gray",
										onClick: () => L(e, t),
										children: /* @__PURE__ */ s(Je, {})
									}), /* @__PURE__ */ s(m, {
										size: "1",
										variant: "ghost",
										color: "gray",
										onClick: () => {
											let t = { ...S.customRules };
											delete t[e], P("customRules", t);
										},
										children: /* @__PURE__ */ s(Ye, {})
									})]
								})]
							}, e))
						})
					]
				}),
				/* @__PURE__ */ s(ee, {
					placeholder: e.i18n.t("ignore"),
					value: S.ignoreListText,
					onChange: (e) => P("ignoreListText", e.target.value),
					style: {
						minHeight: 100,
						resize: "vertical"
					}
				}),
				/* @__PURE__ */ c(p, {
					direction: "column",
					gap: "2",
					children: [
						/* @__PURE__ */ s(_, { children: e.i18n.t("test") }),
						/* @__PURE__ */ s(v.Root, {
							placeholder: e.i18n.t("input"),
							value: w,
							onChange: (e) => T(e.target.value)
						}),
						/* @__PURE__ */ s(_, {
							size: "2",
							children: e.i18n.t("preview")
						}),
						/* @__PURE__ */ s(l, {
							style: {
								backgroundColor: "var(--gray-4)",
								borderRadius: "var(--radius-2)",
								padding: "var(--space-2)",
								minHeight: "4em"
							},
							children: /* @__PURE__ */ s(p, {
								gap: "1",
								wrap: "wrap",
								align: "center",
								children: E.map((t, n) => /* @__PURE__ */ s("span", {
									className: "amll-seg-previewWord",
									children: t || e.i18n.t("emptyText")
								}, `${t}-${n}`))
							})
						})
					]
				})
			]
		}),
		/* @__PURE__ */ c(p, {
			gap: "3",
			mt: "4",
			justify: "end",
			children: [/* @__PURE__ */ s(u, {
				variant: "soft",
				color: "gray",
				onClick: () => e.ui.closeView(X),
				children: e.i18n.t("cancel")
			}), /* @__PURE__ */ s(u, {
				disabled: O,
				onClick: R,
				children: e.i18n.t("apply")
			})]
		})
	] });
}
function it({ host: e }) {
	e.views.registerView({
		id: X,
		kind: "dialog-view",
		title: Z("title"),
		size: "large",
		view: () => /* @__PURE__ */ s(rt, { host: e })
	});
	let t = X;
	e.commands.register({
		id: t,
		title: Z("title"),
		handler: () => e.ui.openView(t)
	}), e.menus.register({
		id: `${t}.menu`,
		menu: "menu.tool",
		command: t,
		group: "segmentation"
	});
	let n = "builtin.segmentation.auto";
	e.commands.register({
		id: n,
		title: Z("auto"),
		handler: () => $(e, "all", "1", "1")
	}), e.menus.register({
		id: `${n}.menu`,
		menu: "menu.tool",
		command: n,
		group: "segmentation"
	});
}
export { it as activate };
